# RBAC + ABAC (do both)

## RBAC (roles)
- CLIENT
- STYLIST
- RECEPTION
- MANAGER
- OWNER
- ADMIN
- SUPPORT

## Permissions (fine-grained)
Examples:
- ops.read.users
- ops.write.users
- ops.read.bookings
- ops.refund.payments
- ops.view.pii
- studio.write.availability

## ABAC (attributes)
Even ops users need scoping:
- manager.salonIds => can only access those salons
- receptionist.locationId => only location bookings
- time-based constraints for contractors (optional)

## Rules
- Every endpoint must enforce:
  - Authentication
  - Authorization (perm)
  - Object-level checks (ABAC)
