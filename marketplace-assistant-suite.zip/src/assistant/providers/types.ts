/** SINGLE-BUSINESS TYPES */
export type Invoice = { invoiceId: string; clientId: string; amount: number; status: "sent" | "paid" | "refunded" };
export type Promo = { code: string; percentOff: number; active: boolean };
export type KPI = { key: string; value: number; unit?: string };
export type Task = { taskId: string; title: string; status: "open" | "done" };

export interface PaymentsProvider {
  createInvoice(input: { clientId: string; amount: number }): Promise<Invoice>;
  refund(input: { invoiceId: string }): Promise<Invoice>;
}
export interface MarketingProvider { createPromo(input: { code: string; percentOff: number }): Promise<Promo>; }
export interface AnalyticsProvider { kpis(input: {}): Promise<KPI[]>; }
export interface OpsProvider { listTasks(input: {}): Promise<Task[]>; }
export interface AdminProvider {
  showAudit(input: { limit: number }): Promise<Array<{ at: string; type: string; details: any }>>;
  gdprExport(input: { userId: string }): Promise<{ url: string }>;
}

/** MARKETPLACE TYPES */
export type ProviderProfile = { providerId: string; displayName: string; rating: number; city?: string; services: Array<{ name: string; price: number; durationMin: number }> };
export type ProviderSearchResult = { providerId: string; displayName: string; rating: number; distanceMi?: number; priceFrom?: number };
export type Slot = { slotId: string; providerId: string; startISO: string; durationMin: number; price: number; serviceName: string };
export type BookingHold = { holdId: string; slotId: string; providerId: string; clientId: string; expiresAtISO: string };
export type Booking = { bookingId: string; slotId: string; providerId: string; clientId: string; status: "confirmed" | "canceled" | "completed" };
export type PaymentIntent = { paymentIntentId: string; amount: number; fee: number; currency: string; status: "requires_payment" | "succeeded" | "canceled" };
export type Payout = { payoutId: string; providerId: string; amount: number; releaseAtISO: string; status: "scheduled" | "paid" | "held" };
export type Message = { messageId: string; bookingId: string; fromId: string; text: string; atISO: string };
export type Review = { reviewId: string; bookingId: string; providerId: string; rating: number; text?: string; atISO: string };
export type Dispute = { disputeId: string; bookingId: string; status: "open" | "resolved"; reason: string; outcome?: string; refundAmount?: number };

export interface MarketplaceDiscoveryProvider {
  searchProviders(input: { service: string; location: string; dateISO?: string; timeHint?: string; priceMax?: number }): Promise<ProviderSearchResult[]>;
  providerProfile(input: { providerId: string }): Promise<ProviderProfile | null>;
  searchSlots(input: { providerId: string; dateISO?: string; durationMin: number; service?: string }): Promise<Slot[]>;
}

export interface MarketplaceBookingProvider {
  createHold(input: { providerId: string; clientId: string; service?: string; dateISO?: string; timeHint?: string }): Promise<BookingHold>;
  confirmBooking(input: { holdId: string; paymentIntentId: string }): Promise<Booking>;
  cancelBooking(input: { bookingId: string; reason: string }): Promise<Booking>;
}

export interface MarketplacePaymentsProvider {
  createPaymentIntent(input: { holdId: string; amount: number }): Promise<PaymentIntent>;
  schedulePayout(input: { providerId: string; amount: number; releaseAtISO: string }): Promise<Payout>;
  issueRefund(input: { bookingId: string; amount: number; reason: string }): Promise<{ ok: true }>;
}

export interface MarketplaceMessagingProvider {
  sendMessage(input: { bookingId: string; fromId: string; text: string }): Promise<Message>;
}

export interface MarketplaceReputationProvider {
  submitReview(input: { bookingId: string; rating: number; text?: string }): Promise<Review>;
}

export interface MarketplaceDisputesProvider {
  openDispute(input: { bookingId: string; reason: string }): Promise<Dispute>;
  resolveDispute(input: { disputeId: string; outcome: "refund" | "deny" | "partial"; refundAmount: number }): Promise<Dispute>;
}

export type Providers = {
  payments: PaymentsProvider;
  marketing: MarketingProvider;
  analytics: AnalyticsProvider;
  ops: OpsProvider;
  admin: AdminProvider;

  marketDiscovery: MarketplaceDiscoveryProvider;
  marketBooking: MarketplaceBookingProvider;
  marketPayments: MarketplacePaymentsProvider;
  marketMessaging: MarketplaceMessagingProvider;
  marketReputation: MarketplaceReputationProvider;
  marketDisputes: MarketplaceDisputesProvider;
};
