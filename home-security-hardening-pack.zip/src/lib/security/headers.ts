type HeaderTuple = [string, string];

export function buildSecurityHeaders(opts?: {
  cspNonce?: string;
  allowSwagger?: boolean;
}) : HeaderTuple[] {
  const isProd = process.env.NODE_ENV === "production";

  // Strict CSP baseline. Tune per app needs.
  // If you use Next.js inline scripts/styles, prefer nonces/hashes instead of unsafe-inline.
  const csp = [
    "default-src 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    "frame-ancestors 'none'",
    "form-action 'self'",
    "img-src 'self' data: https:",
    "font-src 'self' data: https:",
    "style-src 'self' https:",
    "script-src 'self' https:",
    "connect-src 'self' https:",
    "upgrade-insecure-requests"
  ].join("; ");

  const headers: HeaderTuple[] = [
    ["X-Content-Type-Options", "nosniff"],
    ["Referrer-Policy", "strict-origin-when-cross-origin"],
    ["X-Frame-Options", "DENY"],
    // Permissions-Policy: disable what you don't use
    ["Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()"],
    // HSTS only in prod and only when you are actually on HTTPS everywhere
    ...(isProd
      ? [["Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload"] as HeaderTuple]
      : []),
    ["Content-Security-Policy", csp],
  ];

  return headers;
}
