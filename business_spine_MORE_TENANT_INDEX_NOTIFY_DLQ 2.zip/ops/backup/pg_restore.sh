#!/usr/bin/env bash
set -euo pipefail
FILE="${1:?provide dump file}"
echo "[restore] restoring from $FILE"
pg_restore --clean --if-exists --no-owner --no-acl --dbname "$DATABASE_URL" "$FILE"
echo "[restore] done"
