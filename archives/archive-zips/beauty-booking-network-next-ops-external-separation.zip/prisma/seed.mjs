import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
const money = (n) => Math.round(n * 100);

async function main() {
  await prisma.follow.deleteMany();
  await prisma.booking.deleteMany();
  await prisma.salonServiceOverride.deleteMany();
  await prisma.availabilityRule.deleteMany();
  await prisma.salonMembership.deleteMany();
  await prisma.serviceTemplate.deleteMany();
  await prisma.stylistProfile.deleteMany();
  await prisma.salon.deleteMany();
  await prisma.session.deleteMany();
  await prisma.account.deleteMany();
  await prisma.user.deleteMany();
  await prisma.verificationToken.deleteMany();

  const salon = await prisma.salon.create({
    data: {
      slug: "luxe-salon",
      name: "Luxe Salon",
      area: "Downtown",
      address: "1901 Thornridge Cir",
      hours: "10:00am – 8:00pm",
      rating: 4.8,
      coverUrl: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1600&q=80",
    }
  });

  await prisma.user.create({ data: { email: "owner@demo.com", name: "Owner", role: "OWNER" }});

  const uJade = await prisma.user.create({ data: { email: "jade@demo.com", name: "Jade", role: "STYLIST" }});
  const uNoor = await prisma.user.create({ data: { email: "noor@demo.com", name: "Noor", role: "STYLIST" }});
  const client = await prisma.user.create({ data: { email: "client@demo.com", name: "Client", role: "CLIENT" }});

  const jade = await prisma.stylistProfile.create({
    data: {
      userId: uJade.id,
      slug: "jade",
      displayName: "Jade Monroe",
      title: "Color + Soft Dimension",
      bio: "Quiet luxury color work. Clean blends, healthy hair, editorial finish.",
      heroUrl: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&w=1600&q=80",
      avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=1600&q=80"
      ],
      socials: { instagram: "jadexcolor" }
    }
  });

  const noor = await prisma.stylistProfile.create({
    data: {
      userId: uNoor.id,
      slug: "noor",
      displayName: "Noor Vale",
      title: "Silk Press + Healthy Styles",
      bio: "Healthy styling, silky finishes, longevity-focused appointments.",
      heroUrl: "https://images.unsplash.com/photo-1582095133179-bfd08e2fc6b3?auto=format&fit=crop&w=1600&q=80",
      avatarUrl: "https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1600948836101-f9ffda59d250?auto=format&fit=crop&w=1600&q=80"
      ],
      socials: { instagram: "noorstyles" }
    }
  });

  await prisma.salonMembership.createMany({
    data: [
      { salonId: salon.id, stylistId: jade.id, settings: { allowDirectBookings: true, requireApprovalForNewClients: false, managerCanViewCalendar: true } },
      { salonId: salon.id, stylistId: noor.id, settings: { allowDirectBookings: true, requireApprovalForNewClients: true, managerCanViewCalendar: true } }
    ]
  });

  const jadeBal = await prisma.serviceTemplate.create({ data: { stylistId: jade.id, name:"Balayage", durationMin:150, basePriceCents: money(240), category:"Color" }});
  await prisma.serviceTemplate.create({ data: { stylistId: jade.id, name:"Women’s Haircut", durationMin:45, basePriceCents: money(120), category:"Cut" }});
  const noorSilk = await prisma.serviceTemplate.create({ data: { stylistId: noor.id, name:"Silk Press", durationMin:60, basePriceCents: money(105), category:"Style" }});
  await prisma.serviceTemplate.create({ data: { stylistId: noor.id, name:"Brow Sculpt", durationMin:30, basePriceCents: money(55), category:"Brow" }});

  await prisma.salonServiceOverride.create({ data: { salonId: salon.id, serviceId: jadeBal.id, priceCents: money(255) }});

  const rules = [];
  for (const dow of [1,2,3,4,5,6]) {
    rules.push({ ownerType:"STYLIST", stylistId: jade.id, dow, startMin: 600, endMin: 1080 });
    rules.push({ ownerType:"STYLIST", stylistId: noor.id, dow, startMin: 600, endMin: 1080 });
  }
  await prisma.availabilityRule.createMany({ data: rules });

  await prisma.follow.create({ data: { followerUserId: client.id, stylistId: jade.id }});

  const startAt = new Date();
  startAt.setUTCDate(startAt.getUTCDate() + 1);
  startAt.setUTCHours(16,0,0,0);
  const endAt = new Date(startAt);
  endAt.setUTCMinutes(endAt.getUTCMinutes() + 60);

  await prisma.booking.create({
    data: {
      clientUserId: client.id,
      stylistId: noor.id,
      salonId: salon.id,
      serviceId: noorSilk.id,
      startAt,
      endAt,
      priceCentsFinal: noorSilk.basePriceCents,
      status: "PENDING_APPROVAL",
      approvalRequired: true,
    }
  });

  console.log("Seeded demo accounts:");
  console.log("- owner@demo.com (OWNER)");
  console.log("- jade@demo.com (STYLIST)");
  console.log("- noor@demo.com (STYLIST)");
  console.log("- client@demo.com (CLIENT)");
}

main().catch((e)=>{ console.error(e); process.exit(1); }).finally(async()=>{ await prisma.$disconnect(); });
