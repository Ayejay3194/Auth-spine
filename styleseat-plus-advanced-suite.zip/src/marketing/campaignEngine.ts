export class CampaignEngine {
  run(name: string, audience: string[]) {
    return { name, sent: audience.length };
  }
}
