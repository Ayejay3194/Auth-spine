import PreLaunchChecklist from "../../../../components/PreLaunchChecklist";

export default function PreLaunchPage() {
  return <PreLaunchChecklist />;
}
