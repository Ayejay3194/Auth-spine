# DPIA (Template)

1. Description: what data, why, who accesses it
2. Necessity: can you collect less
3. Risks: likelihood/impact
4. Mitigations: encryption, RLS, audit logs, consent, minimization
5. Residual risk: accept/mitigate/avoid
