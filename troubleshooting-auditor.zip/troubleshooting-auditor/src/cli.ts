import fs from "node:fs";
import path from "node:path";
import { runAudit } from "./runAudit.js";
import { toJson, toMarkdown } from "./report/format.js";
import type { RunCommand } from "./auditors/commands.js";

function getArg(flag: string): string | null {
  const idx = process.argv.indexOf(flag);
  if (idx === -1) return null;
  return process.argv[idx + 1] ?? null;
}

function getArgs(flag: string): string[] {
  const out: string[] = [];
  for (let i = 0; i < process.argv.length; i++) {
    if (process.argv[i] === flag) out.push(process.argv[i + 1] ?? "");
  }
  return out.filter(Boolean);
}

function parseCsv(v: string | null): string[] {
  if (!v) return [];
  return v.split(",").map(s => s.trim()).filter(Boolean);
}

const root = getArg("--root") ?? process.cwd();
const format = (getArg("--format") ?? "md").toLowerCase();
const outPath = getArg("--out");

const runArgs = getArgs("--run") as RunCommand[];
const endpoints = parseCsv(getArg("--endpoints"));

const report = await runAudit({ root, run: runArgs, endpoints });

const rendered = format === "json" ? toJson(report) : toMarkdown(report);

if (outPath) {
  const full = path.resolve(outPath);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, rendered, "utf-8");
  // eslint-disable-next-line no-console
  console.log(`Wrote report to ${full}`);
} else {
  // eslint-disable-next-line no-console
  console.log(rendered);
}

process.exit(report.summary.errors > 0 ? 1 : 0);
