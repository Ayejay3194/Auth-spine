SAAS OPS (CHANGE/RELEASE/CAPACITY)

Change Management
- Approvals + emergency changes
- Rollback plans
- Maintenance windows + comms
- Feature flags

Release Management
- Versioning + deprecation
- Staging validation
- Prod checklists + postmortems

Capacity Planning
- Headroom targets + triggers
- Forecasting + cost projections
- Quarterly reviews
