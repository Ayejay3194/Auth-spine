import { ToneLevel, TurnInput } from "./types";

export type DampenerResult = {
  allowPassiveAggressive: boolean;
  toneLevelAfterDampen: ToneLevel;
  notes: string[];
};

export function applyMemoryDampener(input: TurnInput, tone: ToneLevel): DampenerResult {
  const notes: string[] = [];
  const { state } = input;

  const everyN = state.maxPassiveAggressiveEveryNTurns ?? 4;
  const last = state.lastPassiveAggressiveAtTurn;

  if (tone <= 1) {
    notes.push("Tone <= 1 -> passive-aggressive not needed.");
    return { allowPassiveAggressive: false, toneLevelAfterDampen: tone, notes };
  }

  if (last == null) {
    notes.push("No recent passive-aggressive usage -> allowed.");
    return { allowPassiveAggressive: true, toneLevelAfterDampen: tone, notes };
  }

  const since = state.turnIndex - last;
  if (since < everyN) {
    notes.push(`Passive-aggressive used ${since} turns ago (<${everyN}) -> block + soften.`);
    const softened: ToneLevel = (tone - 1) as ToneLevel;
    return { allowPassiveAggressive: false, toneLevelAfterDampen: softened, notes };
  }

  notes.push(`Passive-aggressive last used ${since} turns ago (>=${everyN}) -> allowed.`);
  return { allowPassiveAggressive: true, toneLevelAfterDampen: tone, notes };
}
