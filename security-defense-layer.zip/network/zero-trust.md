Zero Trust Network Rules

- No implicit trust between services
- Mutual TLS for service-to-service
- Internal services on private subnets
- External access only through gateway
