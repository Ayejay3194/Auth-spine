
import fs from "node:fs";
import path from "node:path";

const ROOT = new URL("../dist", import.meta.url).pathname.replace(/\/$/, "");
const banned = [/\bemail\b/i, /\bphone\b/i, /\baddress\b/i, /\bssn\b/i, /birth\s*date/i];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(p);
    else if (entry.isFile() && entry.name.endsWith(".js")) {
      const txt = fs.readFileSync(p, "utf-8");
      for (const re of banned) {
        if (re.test(txt)) {
          console.error(`PII-ish token "${re}" found in ${p}`);
          process.exit(1);
        }
      }
    }
  }
}

if (fs.existsSync(ROOT)) walk(ROOT);
