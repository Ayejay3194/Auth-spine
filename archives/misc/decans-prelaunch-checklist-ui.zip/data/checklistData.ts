export type ChecklistItem = {
  id: string;
  text: string;
  critical: boolean;
};

export type ChecklistCategory = {
  category: string;
  priority: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  items: ChecklistItem[];
};

export const checklistData: ChecklistCategory[] = [
  {
    category: "🔐 Authentication & Security",
    priority: "CRITICAL",
    items: [
      { id: "auth1", text: "Sign up works with valid email", critical: true },
      { id: "auth2", text: "Login works with correct credentials", critical: true },
      { id: "auth3", text: "Login fails gracefully with wrong credentials", critical: true },
      { id: "auth4", text: "Password reset flow works end-to-end", critical: true },
      { id: "auth5", text: "Email verification works", critical: true },
      { id: "auth6", text: "Sessions persist after page refresh", critical: true },
      { id: "auth7", text: "Logout clears all session data", critical: true },
      { id: "auth8", text: "Protected routes block unauthorized users", critical: true },
      { id: "auth9", text: "JWT tokens expire correctly", critical: true },
      { id: "auth10", text: "Token refresh logic works", critical: true },
      { id: "auth11", text: "Rate limiting prevents brute force (10 failed attempts)", critical: true },
      { id: "auth12", text: "SQL injection attempts blocked (test: admin'--)", critical: true },
      { id: "auth13", text: "XSS attempts sanitized (test: <script>alert('xss')</script>)", critical: true },
      { id: "auth14", text: "CSRF protection enabled", critical: true },
      { id: "auth15", text: "Password strength requirements enforced (min 8 chars, etc.)", critical: true },
      { id: "auth16", text: "Sessions timeout after inactivity", critical: false },
      { id: "auth17", text: "Multi-device login handled correctly", critical: false },
      { id: "auth18", text: "Account deletion works and removes all data", critical: false },
    ],
  },
  {
    category: "💳 Payments & Billing",
    priority: "CRITICAL",
    items: [
      { id: "pay1", text: "Test credit card works (Stripe test mode)", critical: true },
      { id: "pay2", text: "Payment success updates subscription status", critical: true },
      { id: "pay3", text: "Payment failure handled gracefully", critical: true },
      { id: "pay4", text: "Webhook signature verification works", critical: true },
      { id: "pay5", text: "Failed payment retry logic works", critical: true },
      { id: "pay6", text: "Subscription cancellation works", critical: true },
      { id: "pay7", text: "Canceled users lose access to paid features", critical: true },
      { id: "pay8", text: "Refund processing works", critical: true },
      { id: "pay9", text: "Invoice generation and email delivery", critical: true },
      { id: "pay10", text: "Proration works on plan changes", critical: false },
      { id: "pay11", text: "Trial period logic works correctly", critical: false },
      { id: "pay12", text: "Usage-based billing calculates correctly", critical: false },
      { id: "pay13", text: "Multiple payment methods can be saved", critical: false },
      { id: "pay14", text: "Tax calculation works (if applicable)", critical: false },
      { id: "pay15", text: "Dunning management handles failed cards", critical: false },
    ],
  },
  {
    category: "🏢 Multi-Tenancy (if applicable)",
    priority: "CRITICAL",
    items: [
      { id: "tenant1", text: "Create 2 test accounts (Tenant A & B)", critical: true },
      { id: "tenant2", text: "Tenant A CANNOT see Tenant B’s data", critical: true },
      { id: "tenant3", text: "All database queries filter by tenant_id", critical: true },
      { id: "tenant4", text: "API calls scoped to correct tenant", critical: true },
      { id: "tenant5", text: "File uploads isolated per tenant", critical: true },
      { id: "tenant6", text: "Team invites work within tenant boundary", critical: true },
      { id: "tenant7", text: "Switching workspaces updates context", critical: true },
      { id: "tenant8", text: "Billing isolated per tenant", critical: true },
      { id: "tenant9", text: "Analytics show only tenant’s data", critical: true },
      { id: "tenant10", text: "Webhooks scoped to correct tenant", critical: false },
      { id: "tenant11", text: "Rate limits applied per tenant", critical: false },
    ],
  },
  {
    category: "👥 User Management & RBAC",
    priority: "HIGH",
    items: [
      { id: "rbac1", text: "Admin can access admin panel", critical: true },
      { id: "rbac2", text: "Regular user CANNOT access admin panel", critical: true },
      { id: "rbac3", text: "Different roles see different UI elements", critical: true },
      { id: "rbac4", text: "API endpoints check permissions", critical: true },
      { id: "rbac5", text: "Team member invites work", critical: false },
      { id: "rbac6", text: "Role assignment/changes work", critical: false },
      { id: "rbac7", text: "Team member removal works", critical: false },
      { id: "rbac8", text: "Permissions cascade correctly", critical: false },
    ],
  },
  {
    category: "📊 Core Features & Business Logic",
    priority: "HIGH",
    items: [
      { id: "feat1", text: "Main feature #1 works end-to-end", critical: true },
      { id: "feat2", text: "Main feature #2 works end-to-end", critical: true },
      { id: "feat3", text: "Main feature #3 works end-to-end", critical: true },
      { id: "feat4", text: "Data saves correctly to database", critical: true },
      { id: "feat5", text: "Data loads correctly from database", critical: true },
      { id: "feat6", text: "Search functionality works", critical: false },
      { id: "feat7", text: "Filtering works correctly", critical: false },
      { id: "feat8", text: "Sorting works correctly", critical: false },
      { id: "feat9", text: "Pagination works", critical: false },
      { id: "feat10", text: "File uploads work (if applicable)", critical: false },
      { id: "feat11", text: "File downloads work (if applicable)", critical: false },
      { id: "feat12", text: "Notifications/emails send correctly", critical: false },
      { id: "feat13", text: "Real-time updates work (if applicable)", critical: false },
    ],
  },
  {
    category: "🎨 Frontend & UX",
    priority: "MEDIUM",
    items: [
      { id: "ui1", text: "All pages load without errors", critical: true },
      { id: "ui2", text: "Navigation works on all pages", critical: true },
      { id: "ui3", text: "Forms validate input correctly", critical: true },
      { id: "ui4", text: "Error messages are user-friendly", critical: true },
      { id: "ui5", text: "Loading states show during async operations", critical: false },
      { id: "ui6", text: "Success messages show after actions", critical: false },
      { id: "ui7", text: "Mobile responsive design works", critical: false },
      { id: "ui8", text: "Works in Chrome, Firefox, Safari", critical: false },
      { id: "ui9", text: "Images load correctly", critical: false },
      { id: "ui10", text: "No broken links", critical: false },
      { id: "ui11", text: "Accessibility: keyboard navigation works", critical: false },
      { id: "ui12", text: "Accessibility: screen reader compatible", critical: false },
      { id: "ui13", text: "Dark mode works (if applicable)", critical: false },
    ],
  },
];
