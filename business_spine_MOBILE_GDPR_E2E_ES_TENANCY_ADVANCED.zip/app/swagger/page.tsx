export default function Swagger() {
  return (
    <main style={{ padding: 24 }}>
      <h1>API Docs</h1>
      <p>OpenAPI JSON: <code>/api/openapi.json</code></p>
    </main>
  );
}
