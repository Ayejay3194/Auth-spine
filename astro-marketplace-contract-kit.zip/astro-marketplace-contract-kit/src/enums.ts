export const BODY_ORDER = [
  "sun",
  "moon",
  "mercury",
  "venus",
  "mars",
  "jupiter",
  "saturn",
  "uranus",
  "neptune",
  "pluto",
  "node_mean",
  "node_true",
  "lilith_mean",
  "lilith_true",
  "chiron",
  "part_of_fortune",
  "vertex",
  "asc",
  "mc"
] as const;

export type BodyKey = (typeof BODY_ORDER)[number];

export const HOUSE_ORDER = [
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "h7",
  "h8",
  "h9",
  "h10",
  "h11",
  "h12"
] as const;

export type HouseKey = (typeof HOUSE_ORDER)[number];

export const ZODIAC_SIGNS = [
  "aries",
  "taurus",
  "gemini",
  "cancer",
  "leo",
  "virgo",
  "libra",
  "scorpio",
  "sagittarius",
  "capricorn",
  "aquarius",
  "pisces"
] as const;

export type ZodiacSign = (typeof ZODIAC_SIGNS)[number];
