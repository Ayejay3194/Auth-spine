import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readText, readJson, safeReadText } from "../utils/fs.js";

export function auditRewrites(root: string): AuditSection {
  const section: AuditSection = { id: "rewrites", title: "Rewrite Rules (Deep-Link 404)", findings: [] };

  const netlifyToml = path.join(root, "netlify.toml");
  const redirects = path.join(root, "public", "_redirects");
  if (exists(netlifyToml)) {
    const raw = safeReadText(netlifyToml) ?? "";
    const hasSpaFallback =
      /\[\[redirects\]\][\s\S]*from\s*=\s*"\/\*"[\s\S]*to\s*=\s*"\/index\.html"/m.test(raw) ||
      /\[\[redirects\]\][\s\S]*from\s*=\s*"\/\*"[\s\S]*to\s*=\s*"\/"/m.test(raw) ||
      /status\s*=\s*200/m.test(raw);
    if (!hasSpaFallback) {
      section.findings.push({
        id: "rewrites.netlify.missing",
        title: "Netlify config found but SPA fallback redirect not detected",
        severity: "WARN",
        details: "Missing fallback redirects cause routes like /settings to 404 on refresh for SPAs.",
        fix: "Add a Netlify redirect: from='/*' to='/index.html' status=200 (or use public/_redirects).",
        evidence: { file: "netlify.toml" },
      });
    }
  } else if (exists(redirects)) {
    const raw = readText(redirects);
    const hasRule = /^\/\*\s+\/index\.html\s+200/m.test(raw) || /^\/\*\s+\/\s+200/m.test(raw);
    if (!hasRule) {
      section.findings.push({
        id: "rewrites.netlify.redirects",
        title: "public/_redirects exists but SPA fallback not detected",
        severity: "WARN",
        details: "Netlify deep links can 404 without a catch-all rewrite.",
        fix: "Add: `/*  /index.html  200` to public/_redirects for an SPA.",
        evidence: { file: "public/_redirects" },
      });
    }
  }

  const vercelJson = path.join(root, "vercel.json");
  if (exists(vercelJson)) {
    try {
      const v = readJson<any>(vercelJson);
      const rewrites = v.rewrites ?? [];
      const hasCatchAll =
        Array.isArray(rewrites) &&
        rewrites.some((r: any) => r?.source === "/(.*)" && (r?.destination === "/index.html" || r?.destination === "/"));
      if (!hasCatchAll) {
        section.findings.push({
          id: "rewrites.vercel.catchall",
          title: "vercel.json found but no obvious SPA catch-all rewrite",
          severity: "INFO",
          details: "If this is a static SPA, missing catch-all rewrites can break deep links.",
          fix: "Add a rewrite: source='/(.*)' destination='/index.html' (static SPA only). Next apps usually shouldn't do this.",
          evidence: { file: "vercel.json" },
        });
      }
    } catch {
      section.findings.push({
        id: "rewrites.vercel.invalid",
        title: "vercel.json exists but failed to parse",
        severity: "WARN",
        details: "Invalid vercel.json can cause routing/deploy surprises.",
        fix: "Fix JSON syntax in vercel.json.",
        evidence: { file: "vercel.json" },
      });
    }
  }

  const firebaseJson = path.join(root, "firebase.json");
  if (exists(firebaseJson)) {
    try {
      const f = readJson<any>(firebaseJson);
      const rewrites = f?.hosting?.rewrites ?? [];
      const hasSpa = Array.isArray(rewrites) && rewrites.some((r: any) => r?.source === "**" && r?.destination === "/index.html");
      if (!hasSpa) {
        section.findings.push({
          id: "rewrites.firebase.missing",
          title: "firebase.json found but SPA rewrite not detected",
          severity: "WARN",
          details: "Firebase Hosting needs rewrites for SPA deep links, or you get refresh 404s.",
          fix: "Add hosting.rewrites: [{ source: '**', destination: '/index.html' }].",
          evidence: { file: "firebase.json" },
        });
      }
    } catch {
      section.findings.push({
        id: "rewrites.firebase.invalid",
        title: "firebase.json exists but failed to parse",
        severity: "WARN",
        details: "Invalid firebase.json can break hosting behavior.",
        fix: "Fix JSON syntax.",
        evidence: { file: "firebase.json" },
      });
    }
  }

  const swa = path.join(root, "staticwebapp.config.json");
  if (exists(swa)) {
    try {
      const s = readJson<any>(swa);
      const navFallback = s?.navigationFallback?.rewrite;
      if (!navFallback) {
        section.findings.push({
          id: "rewrites.swa.missing",
          title: "staticwebapp.config.json found but navigationFallback missing",
          severity: "WARN",
          details: "Azure Static Web Apps needs navigationFallback for SPA deep links.",
          fix: "Add navigationFallback: { rewrite: '/index.html' }.",
          evidence: { file: "staticwebapp.config.json" },
        });
      }
    } catch {
      section.findings.push({
        id: "rewrites.swa.invalid",
        title: "staticwebapp.config.json failed to parse",
        severity: "WARN",
        details: "Invalid config can break routing behavior.",
        fix: "Fix JSON syntax.",
        evidence: { file: "staticwebapp.config.json" },
      });
    }
  }

  const nginx = path.join(root, "nginx.conf");
  if (exists(nginx)) {
    const raw = readText(nginx);
    const hasTryFiles = /try_files\s+\$uri\s+\$uri\/\s+\/index\.html;/m.test(raw);
    if (!hasTryFiles) {
      section.findings.push({
        id: "rewrites.nginx.tryfiles",
        title: "nginx.conf found but no try_files SPA fallback detected",
        severity: "INFO",
        details: "Missing `try_files ... /index.html` can break deep links for SPAs.",
        fix: "Add: `try_files $uri $uri/ /index.html;` in the relevant location block.",
        evidence: { file: "nginx.conf" },
      });
    }
  }

  if (section.findings.length === 0) {
    section.findings.push({
      id: "rewrites.none",
      title: "No obvious rewrite config issues detected",
      severity: "INFO",
      details: "Nothing obvious stood out.",
    });
  }

  return section;
}
