export type AnalyticsEvent = {
  id: string;
  userId?: string;
  sessionId?: string;
  name: string;
  ts: string;
  props?: Record<string, string | number | boolean | null>;
};

export interface AnalyticsIngest {
  track(evt: AnalyticsEvent): Promise<void>;
}

export interface AnalyticsQuery {
  countByName(name: string, from: string, to: string): Promise<number>;
  topEvents(from: string, to: string, limit?: number): Promise<Array<{ name: string; count: number }>>;
}

export class InMemoryAnalytics implements AnalyticsIngest, AnalyticsQuery {
  private rows: AnalyticsEvent[] = [];
  async track(evt: AnalyticsEvent) { this.rows.push(evt); }

  async countByName(name: string, from: string, to: string) {
    const a = Date.parse(from), b = Date.parse(to);
    return this.rows.filter(r => r.name === name && Date.parse(r.ts) >= a && Date.parse(r.ts) <= b).length;
  }

  async topEvents(from: string, to: string, limit = 10) {
    const a = Date.parse(from), b = Date.parse(to);
    const m = new Map<string, number>();
    for (const r of this.rows) {
      const t = Date.parse(r.ts);
      if (t < a || t > b) continue;
      m.set(r.name, (m.get(r.name) ?? 0) + 1);
    }
    return Array.from(m.entries()).sort((x,y)=>y[1]-x[1]).slice(0,limit).map(([name,count])=>({name,count}));
  }
}
