import path from "node:path";
import fs from "node:fs/promises";
import { Table as ArrowTable, Vector, Float64Vector, Utf8Vector, Int32Vector, BoolVector } from "apache-arrow";
import { LakeConfig, datasetBase } from "../io/paths.js";
import { readParquetToArrowTable, writeArrowTableToParquet } from "../io/parquetArrow.js";
import { manifestForSingleFile } from "../registry/manifest.js";
import { registerDataset } from "../registry/registry.js";

export type CompileArgs = {
  cfg: LakeConfig;
  input: { dataset: string; version: string; files: string[]; schemaVersion: string };
  output: { dataset: string; version: string; schemaVersion: string };
  generator: string;
  compression?: "snappy" | "zstd" | "gzip" | "uncompressed";
};

function vectorToArray(v: Vector): any[] {
  const out = new Array(v.length);
  for (let i = 0; i < v.length; i++) out[i] = v.get(i);
  return out;
}

function makeVector(arr: any[]): Vector {
  if (arr.every(x => typeof x === "number" || x == null)) return Float64Vector.from(arr.map(x => (x == null ? NaN : x)));
  if (arr.every(x => typeof x === "boolean" || x == null)) return BoolVector.from(arr.map(x => !!x));
  if (arr.every(x => Number.isInteger(x) || x == null)) return Int32Vector.from(arr.map(x => (x == null ? 0 : x)));
  return Utf8Vector.from(arr.map(x => (x == null ? "" : String(x))));
}

export async function compileTrainingSet(args: CompileArgs): Promise<{ outFile: string; manifest: string }> {
  const sorted = [...args.input.files].sort();
  const tables: ArrowTable[] = [];
  for (const f of sorted) tables.push(await readParquetToArrowTable(f));
  if (!tables.length) throw new Error("No input files");

  const colNames = new Set<string>();
  for (const t of tables) t.schema.fields.forEach(f => colNames.add(f.name));
  const cols = [...colNames].sort();

  const outCols: Record<string, any[]> = {};
  for (const c of cols) outCols[c] = [];

  for (const t of tables) {
    for (const c of cols) {
      const v = t.getChild(c);
      const arr = v ? vectorToArray(v) : new Array(t.numRows).fill(null);
      outCols[c].push(...arr);
    }
  }

  const vectors: Record<string, Vector> = {};
  for (const c of cols) vectors[c] = makeVector(outCols[c]);
  const outTable = ArrowTable.new(vectors);

  const outDir = datasetBase(args.cfg, args.output.dataset, args.output.version);
  await fs.mkdir(outDir, { recursive: true });
  const outFile = path.join(outDir, "snapshot.parquet");

  await writeArrowTableToParquet(outFile, outTable, {
    compression: args.compression ?? "zstd",
    metadata: {
      dataset: args.output.dataset,
      version: args.output.version,
      schemaVersion: args.output.schemaVersion,
      compiledFrom: `${args.input.dataset}@${args.input.version}`,
    }
  });

  await registerDataset(args.cfg, {
    dataset: args.output.dataset,
    version: args.output.version,
    schemaVersion: args.output.schemaVersion,
    description: "Compiled training snapshot",
    tags: ["training", "snapshot"]
  });

  const manifest = await manifestForSingleFile(
    args.cfg,
    "training_compile",
    args.output.dataset,
    args.output.version,
    args.output.schemaVersion,
    outFile,
    args.generator,
    outTable.numRows
  );

  return { outFile, manifest };
}
