REFUND LEAKAGE DETECTION
========================

Detect:
- refund without dispute
- refund without admin action
- refund frequency spikes
- refunds exceeding thresholds per day/week
- high refund rate by provider/service

Actions:
- alert admin
- require approval for refunds over threshold
- auto-hold instant payouts when refund anomalies spike
