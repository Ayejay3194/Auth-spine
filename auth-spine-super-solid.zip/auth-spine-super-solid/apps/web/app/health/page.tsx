export default async function HealthPage() {
  const res = await fetch('http://localhost:3000/api/health', { cache: 'no-store' }).catch(() => null as any)
  let data: any = null
  if (res?.ok) data = await res.json()

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">System Health</h1>
      <p className="text-slate-600">If this is red, something is on fire. If it's green, it&apos;s merely smoldering.</p>
      <pre className="bg-slate-900 text-slate-100 rounded-xl p-4 overflow-x-auto text-sm">
{JSON.stringify(data ?? { status: 'unknown', hint: 'Start dev server and hit /api/health' }, null, 2)}
      </pre>
    </div>
  )
}
