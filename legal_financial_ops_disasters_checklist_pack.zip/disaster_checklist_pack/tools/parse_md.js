import fs from "node:fs";

function slugify(s){
  return s.toLowerCase().replace(/[^a-z0-9]+/g,"_").replace(/^_+|_+$/g,"");
}

function parse(md){
  const lines = md.split(/\r?\n/);
  let section="general";
  let group="general";
  const items=[];
  const sectionOrder=[];
  for(const raw of lines){
    const ln = raw.trim();
    if(!ln) continue;
    if(ln.startsWith("## ")){ section=ln.slice(3).trim(); group="general"; if(!sectionOrder.includes(section)) sectionOrder.push(section); continue; }
    if(ln.startsWith("# ")){ section=ln.slice(2).trim(); group="general"; if(!sectionOrder.includes(section)) sectionOrder.push(section); continue; }
    const m1 = ln.match(/^\*\*(.+)\*\*$/);
    if(m1){ group=m1[1].trim(); continue; }
    const m2 = ln.match(/^- \[ \] (.+)$/);
    if(m2){ items.push([section, group, m2[1].trim()]); continue; }
  }
  let counter=0;
  const out={schema:"checklist.v1", title:"Disaster Checklist", sections:[]};
  for(const sec of sectionOrder){
    const secItems = items.filter(i=>i[0]===sec);
    if(!secItems.length) continue;
    const secId=`sec.${slugify(sec)}`;
    const groups=[];
    const groupOrder=[];
    for(const [,g] of secItems){ if(!groupOrder.includes(g)) groupOrder.push(g); }
    for(const g of groupOrder){
      const gid=`${secId}.${slugify(g)}`;
      const gItems=secItems.filter(i=>i[1]===g).map(i=>i[2]);
      const gi={id:gid, title:g, items:[]};
      for(const t of gItems){
        counter++;
        gi.items.push({id:`${gid}.${String(counter).padStart(4,"0")}`, text:t, severity:"unknown"});
      }
      groups.push(gi);
    }
    out.sections.push({id:secId, title:sec, groups});
  }
  return out;
}

const [,,mdPath,jsonPath,jsonlPath]=process.argv;
if(!mdPath||!jsonPath||!jsonlPath){
  console.error("usage: node parse_md.js <md> <json> <jsonl>");
  process.exit(1);
}
const md=fs.readFileSync(mdPath,"utf8");
const checklist=parse(md);
fs.writeFileSync(jsonPath, JSON.stringify(checklist,null,2));
const jsonl=[];
for(const sec of checklist.sections){
  for(const grp of sec.groups){
    for(const item of grp.items){
      jsonl.push(JSON.stringify({id:item.id, section:sec.title, group:grp.title, text:item.text, severity:item.severity, tags:[]}));
    }
  }
}
fs.writeFileSync(jsonlPath, jsonl.join("\n"));
console.log("ok");
