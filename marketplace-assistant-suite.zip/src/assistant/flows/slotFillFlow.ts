import type { Flow } from "./flowTypes.js";
import { runTool } from "../tools/registry.js";

export function makeSlotFillFlow(audit: any): Flow {
  return {
    id: "slotFill",
    async handle({ ctx, text, state, tools }) {
      const af = state.activeFlow;
      const toolId = af?.slots?.toolId as string;
      const base = af?.slots?.input ?? {};
      const payload = parseKeyVals(text);
      const merged = { ...base, ...payload };

      const missing = (af?.slots?.missing as string[]) ?? [];
      // fill first missing if user just typed a value
      if (missing.length === 1 && merged.value !== undefined && merged[missing[0]] === undefined) {
        merged[missing[0]] = merged.value; delete merged.value;
      }

      const newMissing = missing.filter(k => merged[k] === undefined || merged[k] === null || merged[k] === "");
      if (newMissing.length) {
        return {
          state: { ...state, activeFlow: { ...af, slots: { ...af.slots, input: merged, missing: newMissing } } },
          reply: { text: `Still need: ${newMissing.join(", ")}`, ui: { type: "form", title: "Missing info", fields: newMissing.map(k => ({ key: k, label: k, type: k.includes("amount") ? "number" : "text" })) }, done: false }
        };
      }

      if (af?.requiresConfirm) {
        return {
          state: { ...state, activeFlow: { id: "confirm", step: "confirm", slots: {}, requiresConfirm: true, confirmPhrase: "YES", pendingAction: { toolId, input: merged } } },
          reply: { text: "Type **YES** to confirm.", done: false }
        };
      }

      const tool = tools.get(toolId);
      const res = await runTool({ tool, ctx, input: merged, audit });
      return { state: { ...state, activeFlow: undefined }, reply: res.ok ? { text: "Done.", done: true } : { text: `Failed: ${res.error.message}`, done: true } };
    }
  };
}

function parseKeyVals(text: string) {
  const out: any = {};
  const pairs = text.split(/\s+/).filter(Boolean);
  for (const p of pairs) {
    const m = p.match(/^([a-zA-Z_][a-zA-Z0-9_]*)=(.+)$/);
    if (m) out[m[1]] = maybeNumber(m[2]);
  }
  if (Object.keys(out).length) return out;
  return { value: maybeNumber(text.trim()) };
}
function maybeNumber(v: string) {
  const n = Number(v);
  return Number.isFinite(n) && v.match(/^[0-9.]+$/) ? n : v;
}
