import YAML from "yaml";
import { findFiles, readText, rel } from "../utils/fs.js";
import type { Check, Finding } from "../types.js";

export const OpenApiAuthCheck: Check = {
  id: "api.openapi_auth",
  title: "OpenAPI requires auth schemes",
  category: "API",
  async run(ctx) {
    const rule = ctx.profile.rules?.openapi ?? {};
    const requireAuth = rule.requireAuthSchemes ?? true;
    const sev = rule.severity ?? "P0";
    if (!requireAuth) return [];

    const files = findFiles(ctx.root, ["**/*openapi*.{yml,yaml,json}", "**/*swagger*.{yml,yaml,json}"])
      .filter(f => !f.includes("node_modules/") && !f.includes("dist/"));

    const findings: Finding[] = [];
    for (const f of files) {
      const txt = readText(f);
      if (!txt) continue;
      let doc: any;
      try {
        doc = f.endsWith(".json") ? JSON.parse(txt) : YAML.parse(txt);
      } catch { continue; }

      const schemes = doc?.components?.securitySchemes ?? doc?.securityDefinitions;
      const hasSchemes = schemes && Object.keys(schemes).length > 0;
      const hasGlobalSecurity = Array.isArray(doc?.security) && doc.security.length > 0;

      if (!hasSchemes || !hasGlobalSecurity) {
        findings.push({
          id: this.id,
          title: this.title,
          category: this.category,
          severity: sev,
          evidence: [{
            message: `OpenAPI spec missing security schemes and/or global security requirements`,
            file: rel(ctx.root, f),
            hint: "Define securitySchemes (e.g., bearerAuth) and apply global security or per-route security."
          }]
        });
      }
    }
    return findings;
  }
};
