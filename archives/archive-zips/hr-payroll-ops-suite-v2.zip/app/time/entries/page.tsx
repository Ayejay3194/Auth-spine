
import { db } from "@/lib/db";

export default async function TimeEntries() {
  const entries = await db.timeEntry.findMany({
    take: 100,
    orderBy: { createdAt: "desc" },
    include: { employee: true, timesheet: true }
  });

  return (
    <div className="grid">
      <div className="panel">
        <div className="h1">Time Entries</div>
        <div className="small">Entries can be attached to timesheets for approval.</div>
      </div>
      <div className="panel">
        <table className="table">
          <thead><tr><th>Employee</th><th>Start</th><th>End</th><th>Minutes</th><th>Timesheet</th></tr></thead>
          <tbody>
            {entries.map(t => (
              <tr key={t.id}>
                <td>{t.employee.firstName} {t.employee.lastName}</td>
                <td>{t.startAt.toISOString()}</td>
                <td>{t.endAt ? t.endAt.toISOString() : "-"}</td>
                <td>{t.minutes ?? "-"}</td>
                <td>{t.timesheet ? t.timesheet.status : "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
