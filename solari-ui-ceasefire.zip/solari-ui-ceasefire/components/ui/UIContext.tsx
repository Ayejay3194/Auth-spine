"use client";
import React from "react";

type UIState = {
  theme: "dark" | "light";
  setTheme: (t: UIState["theme"]) => void;
};

const UIContext = React.createContext<UIState | null>(null);

export function useUI() {
  const ctx = React.useContext(UIContext);
  if (!ctx) throw new Error("useUI outside provider");
  return ctx;
}

export function UIProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = React.useState<UIState["theme"]>("dark");
  return (
    <UIContext.Provider value={{ theme, setTheme }}>
      {children}
    </UIContext.Provider>
  );
}
