import { validateEnv } from '@auth-spine/core'

validateEnv()
console.log('✅ env ok')
