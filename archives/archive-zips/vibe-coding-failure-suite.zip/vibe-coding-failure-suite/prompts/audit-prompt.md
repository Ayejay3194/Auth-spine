# Cursor / LLM Audit Prompt: Vibe Coding Risk Sweep

You are auditing a repo for common “vibe coding” failures. Be strict and concrete.

Deliver:
1) Top 20 risks (ranked) with file paths and line ranges.
2) Any secret exposures or dangerous config.
3) Auth/authz and data access review (RLS, IDOR, role checks).
4) Injection/XSS review (raw SQL, dangerouslySetInnerHTML, eval).
5) File upload/storage review (type/size/path sanitization).
6) Performance smells (N+1, SELECT *, missing pagination, unbounded loops).
7) Observability gaps (no request IDs, logs without structure, missing alerts).
8) Fix plan: smallest safe diffs first.

Rules:
- Assume attackers are clever.
- If you’re unsure, mark as “needs verification” and explain how to verify.
