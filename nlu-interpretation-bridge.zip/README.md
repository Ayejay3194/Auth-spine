
# Advanced NLU + Interpretation Layer

This package provides a production-ready bridge between:
- NLU (intent/entity extraction)
- Dialogue state & slot filling
- Interpretation engines (astrology, HD, psychology, etc.)

Architecture:
User Input → NLU → Dialogue Manager → Interpretation Engine → Response Composer
