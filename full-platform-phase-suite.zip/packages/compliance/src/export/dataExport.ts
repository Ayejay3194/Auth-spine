import type { ID } from "@suite/core";

export type ExportFormat = "json" | "csv" | "html";

export interface ExportSource {
  userProfile(tenantId: ID, userId: ID): Promise<Record<string,any>>;
  bookings(tenantId: ID, userId: ID): Promise<any[]>;
  payments(tenantId: ID, userId: ID): Promise<any[]>;
  messages(tenantId: ID, userId: ID): Promise<any[]>;
}

export async function exportUserData(src: ExportSource, tenantId: ID, userId: ID, format: ExportFormat) {
  const data = {
    profile: await src.userProfile(tenantId, userId),
    bookings: await src.bookings(tenantId, userId),
    payments: await src.payments(tenantId, userId),
    messages: await src.messages(tenantId, userId),
  };

  if (format === "json") return { mime: "application/json", body: JSON.stringify(data, null, 2) };

  if (format === "csv") {
    const rows = [
      { section: "profile", value: JSON.stringify(data.profile) },
      { section: "bookings", value: JSON.stringify(data.bookings) },
      { section: "payments", value: JSON.stringify(data.payments) },
      { section: "messages", value: JSON.stringify(data.messages) },
    ];
    const csv = ["section,value", ...rows.map(r => `${r.section},"${r.value.replace(/"/g,'""')}"`)].join("\n");
    return { mime: "text/csv", body: csv };
  }

  const html = `<!doctype html><html><body>
  <h1>Account Data Export</h1>
  <h2>Profile</h2><pre>${esc(JSON.stringify(data.profile, null, 2))}</pre>
  <h2>Bookings</h2><pre>${esc(JSON.stringify(data.bookings, null, 2))}</pre>
  <h2>Payments</h2><pre>${esc(JSON.stringify(data.payments, null, 2))}</pre>
  <h2>Messages</h2><pre>${esc(JSON.stringify(data.messages, null, 2))}</pre>
  </body></html>`;
  return { mime: "text/html", body: html };
}

function esc(s: string) {
  return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
