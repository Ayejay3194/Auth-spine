export type JobName =
  | "search.reindex"
  | "email.send"
  | "sms.send"
  | "backup.snapshot"
  | "analytics.rollup";

export type JobPayloads = {
  "search.reindex": { tenantId: string; type: string };
  "email.send": { tenantId: string; to: string; templateId: string; vars: Record<string,any> };
  "sms.send": { tenantId: string; to: string; body: string };
  "backup.snapshot": { tenantId: string; kind: "db"|"files"; target: string };
  "analytics.rollup": { tenantId: string; sinceISO: string };
};
