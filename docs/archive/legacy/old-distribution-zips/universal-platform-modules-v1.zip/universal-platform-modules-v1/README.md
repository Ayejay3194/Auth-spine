# Universal Pro Platform - Module Registry V1 (TypeScript)

This zip contains a plug-in style module map for a multi-vertical professional platform.
It is intentionally framework-agnostic, but fits Next.js/Node/TS stacks.

## Contents
- `modules/` — module specs, dependency graph, feature flags
- `verticals/` — vertical configuration templates (beauty, fitness, etc.)
- `tiers/` — tier gating matrices (solo/grow/salon/enterprise)
- `events/` — domain events catalog (for pub/sub, queues, audit, analytics)
- `api/` — route + handler stubs (Next.js-friendly)
- `docs/` — integration notes

## How to use
1) Start with `modules/registry.ts`
2) Load a tier (from `tiers/*.json`) and vertical (from `verticals/*.json`)
3) Compute enabled modules with `modules/enablement.ts`
4) Wire events + handlers using `events/catalog.ts` and `api/*`

This is a **V1 architecture kit**: you can implement modules incrementally.
