export default function AdminPage() {
  return (
    <div className="p-8 space-y-4">
      <h1 className="text-3xl font-bold">Admin</h1>
      <p className="text-slate-700">Role gate is enforced in middleware. Congrats, you are the chosen one.</p>
    </div>
  )
}
