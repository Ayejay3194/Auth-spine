export function parseLocation(input: string) {
  return input; // placeholder
}
