Terms of Service Placeholder

- Acceptable use
- Account rules
- Payments (if applicable)
- Liability limits
- Termination
- Dispute resolution
- Contact details

Replace with real counsel-reviewed language before launch.
