# Testing Spine Pack (Vitest + Playwright + Testcontainers + k6)

Drop into your repo root.

## Install (dev deps)
npm i -D vitest @vitest/coverage-v8 @types/node tsx
npm i -D @playwright/test
npm i -D testcontainers supertest dotenv zod execa cross-env
npm i -D @types/supertest

# load testing
npm i -D k6

## Browsers
npx playwright install --with-deps

## Run
npm run test:unit
npm run test:integration
npm run test:e2e
npm run test:security
npm run test:load

## CI
See .github/workflows/test.yml
