import { Pattern } from "../../core/intent.js";

export const patterns: Pattern[] = [
  {
    "spine": "fulfillment",
    "intent": "list_orders",
    "re": "list orders|show orders|order queue",
    "baseConfidence": 0.72,
    "hint": "list orders"
  },
  {
    "spine": "fulfillment",
    "intent": "create_shipment",
    "re": "create shipment|ship order|fulfill",
    "baseConfidence": 0.78,
    "hint": "create shipment"
  },
  {
    "spine": "fulfillment",
    "intent": "add_tracking",
    "re": "add tracking|tracking number|set tracking",
    "baseConfidence": 0.78,
    "hint": "add tracking"
  },
  {
    "spine": "fulfillment",
    "intent": "mark_delivered",
    "re": "mark delivered|delivered",
    "baseConfidence": 0.7,
    "hint": "mark delivered"
  }
];
