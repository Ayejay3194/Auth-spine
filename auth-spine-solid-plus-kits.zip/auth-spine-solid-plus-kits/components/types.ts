export type UIAuthority = "ROUTE" | "GLOBAL_STORE" | "LOCAL_COMPONENT" | "SERVER_STATE" | "CSS_ONLY";

export type TroubleshootItem = {
  id: string;
  problem: string;
  symptomSignals?: string[];
  authority: UIAuthority[];
  rootCauses: string[];
  solutions: string[];
  verifySteps: string[];
  code: string;
  antiPatterns?: string[];
  notes?: string[];
};

export type TroubleshootData = Record<string, TroubleshootItem[]>;
