export interface SessionStore<T> {
  get(key: string): Promise<T | null>;
  set(key: string, value: T, ttlSeconds: number): Promise<void>;
  delete(key: string): Promise<void>;
}

export interface KeyValueStore {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  delete(key: string): Promise<void>;
}

export class InMemorySessionStore<T> implements SessionStore<T> {
  private m = new Map<string, { v: T; exp: number }>();
  async get(key: string) {
    const it = this.m.get(key);
    if (!it) return null;
    if (Date.now() > it.exp) { this.m.delete(key); return null; }
    return it.v;
  }
  async set(key: string, value: T, ttlSeconds: number) {
    this.m.set(key, { v: value, exp: Date.now() + ttlSeconds * 1000 });
  }
  async delete(key: string) { this.m.delete(key); }
}

export class InMemoryKV implements KeyValueStore {
  private m = new Map<string, string>();
  async get(key: string) { return this.m.get(key) ?? null; }
  async set(key: string, value: string) { this.m.set(key, value); }
  async delete(key: string) { this.m.delete(key); }
}
