OPS RUNBOOKS
============

Runbooks (minimum set):
- Payments outage
- Payroll failure
- Double booking incident
- Data discrepancy (ledger vs bank)
- Vendor payout failure
- Security incident suspected
- Email/notifications outage
- Backup restore failure
