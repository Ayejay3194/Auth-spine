import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerBookingTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "booking.list",
    title: "List bookings",
    description: "Lists upcoming bookings for the user.",
    inputSchema: { type: "object", properties: { userId: { type: "string" } }, required: ["userId"] },
    async run(ctx, input) {
      const data = await p.booking.listBookings({ userId: input.userId });
      return { ok: true, data };
    }
  });

  reg.register({
    id: "booking.cancel",
    title: "Cancel booking",
    description: "Cancels a booking by id.",
    inputSchema: { type: "object", properties: { bookingId: { type: "string" } }, required: ["bookingId"] },
    async run(ctx, input) {
      const data = await p.booking.cancelBooking({ bookingId: input.bookingId });
      return { ok: true, data };
    }
  });
}
