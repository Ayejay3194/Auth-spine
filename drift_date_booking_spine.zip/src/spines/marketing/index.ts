export { spine as marketingSpine } from './spine.js';
