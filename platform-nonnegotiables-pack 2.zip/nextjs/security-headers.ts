import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

export function withSecurityHeaders(req: NextRequest) {
  const res = NextResponse.next();

  // HSTS (only valid over HTTPS)
  res.headers.set("Strict-Transport-Security", "max-age=63072000; includeSubDomains; preload");

  // Basic hardening
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("X-Frame-Options", "DENY");
  res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");

  // CSP (tighten per app needs)
  res.headers.set(
    "Content-Security-Policy",
    "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; base-uri 'self';"
  );

  return res;
}
