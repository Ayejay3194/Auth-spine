# Security Baseline (Next.js + Supabase friendly)

## Cookies
- Use `httpOnly`, `secure`, `sameSite=lax|strict`, `path=/`.
- Short-lived access token + long-lived refresh token (rotating) if JWT.
- Never store session tokens in localStorage.

## Headers (minimum)
- Content-Security-Policy (CSP)
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- Referrer-Policy: no-referrer
- Permissions-Policy

## Rate limits (starter)
- Login: 5/15min per IP + 5/15min per email
- Register: 5/hour per IP
- Reset password: 3/hour per IP
- Webhooks: 60/min per endpoint (plus signature check)

## Supabase RLS rules of thumb
- Enable RLS on **every** user-data table.
- Write policies per operation (SELECT/INSERT/UPDATE/DELETE), not “ALL”.
- Never ship `service_role` to clients. Ever.
- Add tests that use anon/auth roles so you catch bypasses early.

## File uploads
- Validate size + mime + extension. Store in **private** buckets by default.
- Sanitize filenames; never trust client-provided content-type.
- Consider malware scanning hooks for high-risk uploads.
