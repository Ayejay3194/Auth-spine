export interface SessionStore<T> {
  get(key: string): Promise<T | null>;
  set(key: string, value: T, ttlSeconds?: number): Promise<void>;
  inc?(key: string, by: number, ttlSeconds?: number): Promise<number>;
}

export class InMemorySessionStore<T> implements SessionStore<T> {
  private m = new Map<string, { v: T; exp?: number }>();

  async get(key: string): Promise<T | null> {
    const it = this.m.get(key);
    if (!it) return null;
    if (it.exp && Date.now() > it.exp) {
      this.m.delete(key);
      return null;
    }
    return it.v;
  }

  async set(key: string, value: T, ttlSeconds?: number): Promise<void> {
    const exp = ttlSeconds ? Date.now() + ttlSeconds * 1000 : undefined;
    this.m.set(key, { v: value, exp });
  }

  async inc(key: string, by: number, ttlSeconds?: number): Promise<number> {
    const cur = (await this.get(key)) as any;
    const next = (typeof cur === "number" ? cur : cur?.count ?? 0) + by;
    // store as {count:number} if caller used object style, else number
    if (cur && typeof cur === "object" && "count" in cur) {
      await this.set(key, { ...cur, count: next } as any, ttlSeconds);
    } else {
      await this.set(key, next as any, ttlSeconds);
    }
    return next;
  }
}
