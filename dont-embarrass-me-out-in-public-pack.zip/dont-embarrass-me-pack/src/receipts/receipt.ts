import crypto from "crypto";
import { stableHash } from "../observability/logger";
import type { RequestContext } from "../runtime/types";

export type ReceiptStatus = "validated" | "approved" | "rejected";

export interface Receipt {
  id: string;
  tenantId: string;
  requestId: string;
  actorId: string;
  action: string;
  entityType: string;
  entityId: string;
  status: ReceiptStatus;
  createdAtISO: string;

  payloadHash: string;
  prevHash?: string;
  chainHash: string;

  signature: string; // HMAC over chainHash
}

function randId(prefix: string) {
  return `${prefix}_${crypto.randomBytes(8).toString("hex")}`;
}

export function createReceipt(args: {
  ctx: RequestContext;
  action: string;
  entityType: string;
  entityId: string;
  payload: unknown;
  status: ReceiptStatus;
  prevHash?: string;
}): Receipt {
  const createdAtISO = new Date().toISOString();
  const payloadHash = stableHash(JSON.stringify(args.payload ?? null));
  const base = {
    tenantId: args.ctx.tenantId,
    requestId: args.ctx.requestId,
    actorId: args.ctx.actor.userId,
    action: args.action,
    entityType: args.entityType,
    entityId: args.entityId,
    status: args.status,
    createdAtISO,
    payloadHash,
    prevHash: args.prevHash
  };

  const chainHash = stableHash(JSON.stringify(base));
  const secret = process.env.AUDIT_SECRET || "dev_secret";
  const signature = crypto.createHmac("sha256", secret).update(chainHash).digest("hex");

  return {
    id: randId("rcpt"),
    ...base,
    chainHash,
    signature
  };
}

export function verifyReceipt(r: Receipt): { ok: boolean; tampered: boolean } {
  const secret = process.env.AUDIT_SECRET || "dev_secret";
  const base = {
    tenantId: r.tenantId,
    requestId: r.requestId,
    actorId: r.actorId,
    action: r.action,
    entityType: r.entityType,
    entityId: r.entityId,
    status: r.status,
    createdAtISO: r.createdAtISO,
    payloadHash: r.payloadHash,
    prevHash: r.prevHash
  };
  const expectedChain = stableHash(JSON.stringify(base));
  const expectedSig = crypto.createHmac("sha256", secret).update(expectedChain).digest("hex");
  const tampered = expectedChain !== r.chainHash || expectedSig !== r.signature;
  return { ok: !tampered, tampered };
}
