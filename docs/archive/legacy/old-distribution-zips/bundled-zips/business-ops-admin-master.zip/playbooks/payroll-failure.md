PAYROLL FAILURE
---------------
1. Freeze payroll
2. Notify admin
3. Investigate discrepancy
4. Resume after approval
