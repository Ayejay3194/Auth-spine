from fastapi import FastAPI, HTTPException
from typing import List, Dict, Any
from datetime import datetime, timezone
import json
from .schemas import Example, ParseRequest, ParseResponse, TrainRequest, ModelInfo
from . import storage
from .versioning import new_model_id, write_metadata, list_models, get_active_id, set_active_id, read_metadata, model_path
from .intent_model import train_intents, predict_intents
from .entities import extract_entities, DEFAULT_REGEX

app = FastAPI(title="Wit-like NLU (Pro-ish)", version="0.2.0")

@app.get("/health")
def health():
    return {"ok": True, "time": datetime.now(timezone.utc).isoformat()}

@app.post("/examples")
def add_examples(items: List[Example]):
    payload = [it.model_dump() for it in items]
    storage.append_examples(payload)
    return {"ok": True, "added": len(payload)}

@app.get("/examples")
def get_examples(limit: int = 200):
    return {"items": storage.load_examples(limit=limit)}

@app.post("/train")
def train(req: TrainRequest):
    examples = storage.load_examples()
    if len(examples) < req.min_examples:
        raise HTTPException(status_code=400, detail=f"Need at least {req.min_examples} examples. Have {len(examples)}.")
    model_id = new_model_id()

    # Train intent model
    intent_res = train_intents(model_id, examples)

    # Entity rules: start with defaults + anything curated in data/entities.json
    entities_file = (model_path(model_id).parent / "entities.json")
    # Instead: copy global rules (data/entity_rules.json) if present
    global_rules_path = __import__("pathlib").Path("data") / "entity_rules.json"
    rules = {"regex": DEFAULT_REGEX, "lookups": {}}
    if global_rules_path.exists():
        rules = json.loads(global_rules_path.read_text(encoding="utf-8"))
    (model_path(model_id) / "entity_rules.json").write_text(json.dumps(rules, indent=2), encoding="utf-8")

    meta = {
        "id": model_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "notes": req.notes,
        "stats": {
            **intent_res.stats,
            "entity_rule_entities": list((rules.get("lookups") or {}).keys())
        }
    }
    write_metadata(model_id, meta)

    # If no active model yet, activate first
    if get_active_id() is None:
        set_active_id(model_id)

    return {"ok": True, "model_id": model_id, "active": (get_active_id() == model_id), "stats": meta["stats"]}

@app.get("/models")
def models() -> Dict[str, Any]:
    active = get_active_id()
    out = []
    for mid in list_models():
        meta = read_metadata(mid)
        out.append({
            "id": mid,
            "created_at": meta.get("created_at"),
            "active": (mid == active),
            "stats": meta.get("stats") or {},
            "notes": meta.get("notes")
        })
    return {"items": out, "active_id": active}

@app.post("/models/{model_id}/activate")
def activate(model_id: str):
    mp = model_path(model_id)
    if not mp.exists():
        raise HTTPException(status_code=404, detail="Model not found")
    set_active_id(model_id)
    return {"ok": True, "active_id": model_id}

@app.post("/parse", response_model=ParseResponse)
def parse(req: ParseRequest):
    active = get_active_id()
    if not active:
        raise HTTPException(status_code=400, detail="No active model. Train first.")
    intents = predict_intents(active, req.text, top_k=req.top_k_intents)
    entities = extract_entities(active, req.text, threshold=req.entity_threshold)
    return {"text": req.text, "intents": intents, "entities": entities, "model_id": active}

@app.get("/entity-rules")
def get_entity_rules():
    # Global rules live in data/entity_rules.json (editable without training)
    from pathlib import Path
    p = Path("data") / "entity_rules.json"
    if not p.exists():
        # write defaults once
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({"regex": DEFAULT_REGEX, "lookups": {}}, indent=2), encoding="utf-8")
    return json.loads(p.read_text(encoding="utf-8"))

@app.post("/entity-rules")
def set_entity_rules(rules: Dict[str, Any]):
    from pathlib import Path
    p = Path("data") / "entity_rules.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(rules, indent=2), encoding="utf-8")
    return {"ok": True}
