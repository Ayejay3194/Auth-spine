"use client";
import { Protected } from "@/components/auth/Protected";
import { Shell } from "@/components/layout/Shell";

export default function NatalPage() {
  return (
    <Protected>
      <Shell route="natal">
        <div className="glass rounded-xl2 p-6">
          <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Natal</div>
          <h2 className="mt-2 text-3xl font-black">Natal</h2>
          <p className="mt-2 text-white/70 max-w-2xl">
            Same auth, same router, responsive layout. No duplicated “mobile app” and “desktop app”.
          </p>
        </div>
      </Shell>
    </Protected>
  );
}
