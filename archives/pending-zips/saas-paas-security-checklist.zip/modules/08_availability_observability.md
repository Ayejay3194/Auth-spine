AVAILABILITY & UPTIME

HA Architecture
- Multi-AZ, optionally multi-region
- Load balancing + autoscaling
- Health checks + automated failover
- Stateless services + externalized sessions
- Redundant cache/queues/storage
- Circuit breakers, retries, timeouts
- Graceful degradation

SLA Management
- SLIs/SLOs, error budgets
- Maintenance windows + notification
- SLA credits policy
- RTO/RPO definitions

Monitoring/Observability
- APM, infra/db/network monitoring
- Synthetic + RUM
- P50/P95/P99 latency
- Dependency monitoring
- Certificate/DNS/CDN monitoring
- On-call + escalation

Status Page
- Public status + components
- Subscriptions (email/SMS/chat)
- Postmortems
- Private enterprise status pages
