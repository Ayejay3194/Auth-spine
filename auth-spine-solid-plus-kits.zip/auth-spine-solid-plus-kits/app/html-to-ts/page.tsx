import HTMLToTSConflictKit from "@/components/HTMLToTSConflictKit";
export default function Page() { return <HTMLToTSConflictKit />; }
