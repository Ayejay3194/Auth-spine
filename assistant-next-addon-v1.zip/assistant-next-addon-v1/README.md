# Assistant Next Add-on V1 (TS/React/Node/Next.js)

This add-on closes the "sounds natural" gaps by adding:
- Conversation state + slot carryover
- Confidence gating + disambiguation
- Info-gain clarifying questions
- Tool outcome mapping (so you don't say "Booked!" when it failed)
- Eval harness with scripted chats (200 conversations)

## Drop-in
Copy `src/assistant-addons/*` into your app (or import directly).

## Core types
- `ConversationState` keeps per-session context
- `ToolResult` standardizes tool outcomes
- `GateDecision` controls: act vs clarify vs disambiguate

## Suggested wiring
1) Parse message -> `NluResult`
2) Load state -> `getConversationState(sessionId)`
3) Apply carryover -> `applyCarryover(state, nlu)`
4) Run gate -> `gate(nlu, state)`
5) If `clarify`: ask `clarifyQuestion(...)`
6) If `disambiguate`: ask `disambiguateQuestion(...)`
7) If `act`: call tool(s), get `ToolResult`, render reply via `toolOutcomeReply(...)`
8) Persist state -> `saveConversationState(sessionId, nextState)`

## Eval
Run:
- `node eval/run.mjs`
It will simulate 200 conversations and print completion / turn counts.

Note: This harness is deterministic and model-agnostic. Replace the stub NLU with yours.
