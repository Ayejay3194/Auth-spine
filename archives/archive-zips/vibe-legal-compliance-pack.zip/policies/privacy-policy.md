# Privacy Policy (Template)

**Last updated:** {{DATE}}

## 1. What we collect
### Account & profile data
- name, email, phone (optional), profile details
- stylist portfolio media, services, pricing

### Booking & transaction data
- appointment history, cancellation records
- payment metadata (processor token, last4, receipts) via {{PAYMENT_PROCESSOR}}

### Device & usage data
- IP address, device/browser info, pages/actions, approximate location (if enabled)

### Messages
- messages between clients and stylists (content + timestamps)

## 2. Why we collect it
- provide the Service and bookings
- customer support, fraud prevention, security monitoring
- analytics (non-sensitive, minimized)
- legal compliance

## 3. Legal bases (EU/UK)
{{LEGAL_BASES_LIST}} (contract, legitimate interests, consent where required)

## 4. How we share data
- **Service providers** (hosting, email, analytics, payments)
- **Stylists/salons** (to fulfill bookings)
- **Legal** (court orders, law enforcement requests)
We do **not** sell personal information unless explicitly stated.

## 5. Cookies & tracking
We use essential cookies and optional analytics/marketing cookies where enabled via consent.

## 6. Data retention
We retain data only as long as necessary. See `policies/data-retention-schedule.md`.

## 7. Your rights
Depending on region:
- access, correction, deletion
- export/portability
- withdraw consent
- opt-out of sale/sharing (CA)
- lodge a complaint with regulators (EU/UK)

## 8. Security
We use encryption in transit, access controls, monitoring, and incident response. See Security Addendum for customers if applicable.

## 9. Children
Service not directed to children under {{MIN_AGE}}. We do not knowingly collect children’s data.

## 10. International transfers
If data is transferred internationally, we use appropriate safeguards (e.g., SCCs) where required.

## 11. Contact
Privacy contact: {{PRIVACY_EMAIL}}
