export function churnRisk(cancellations: number) {
  if (cancellations > 5) return 'high';
  if (cancellations > 2) return 'medium';
  return 'low';
}
