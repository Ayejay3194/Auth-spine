"use client";
import { useAuth } from "./AuthContext";

export function LoginCard() {
  const { login } = useAuth();
  return (
    <div className="glass rounded-xl2 p-6 max-w-xl">
      <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Auth</div>
      <h2 className="mt-2 text-3xl font-black">Login required</h2>
      <p className="mt-2 text-white/70">Fake auth for the starter. Click login and you're in.</p>
      <div className="mt-5 flex flex-wrap gap-3">
        <button className="btn btn-primary" onClick={() => login()}>Login</button>
        <button className="btn" onClick={() => login("admin@example.com")}>Login as admin (demo)</button>
      </div>
      <p className="mt-4 text-xs text-white/60">
        Replace with real auth later. The layout + gates stay the same.
      </p>
    </div>
  );
}
