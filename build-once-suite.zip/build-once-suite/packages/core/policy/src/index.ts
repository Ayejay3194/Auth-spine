export type Permission = string;

export type Role = { id: string; name: string; permissions: Permission[] };
export type RoleBinding = { userId: string; roleId: string; scope?: { orgId?: string } };

export type PolicyContext = {
  userId: string;
  orgId?: string;
  attrs?: Record<string, string>;
};

export interface AccessControl {
  has(ctx: PolicyContext, perm: Permission): Promise<boolean>;
  enforce(ctx: PolicyContext, perm: Permission): Promise<void>;
}

export class InMemoryRBAC implements AccessControl {
  constructor(private roles: Role[], private bindings: RoleBinding[]) {}

  async has(ctx: PolicyContext, perm: Permission): Promise<boolean> {
    const roleIds = this.bindings
      .filter(b => b.userId === ctx.userId && (!b.scope?.orgId || b.scope.orgId === ctx.orgId))
      .map(b => b.roleId);
    const perms = new Set<string>();
    for (const r of this.roles.filter(r => roleIds.includes(r.id))) for (const p of r.permissions) perms.add(p);
    return perms.has(perm);
  }

  async enforce(ctx: PolicyContext, perm: Permission): Promise<void> {
    if (!(await this.has(ctx, perm))) throw new Error(`FORBIDDEN: missing permission ${perm}`);
  }
}
