export interface Slot {
  slotId: string;
  startISO: string; // datetime ISO in user's tz or UTC depending on your spine convention
  durationMin: number;
  providerId?: string;
}

export interface Booking {
  bookingId: string;
  slotId: string;
  service: string;
  contactMethod: "video" | "phone" | "chat";
  notes?: string;
  status: "confirmed" | "canceled";
}

export interface BookingProvider {
  findAvailableSlots(input: { service: string; dateISO?: string; partOfDay?: string; durationMin: number; timezone?: string }): Promise<Slot[]>;
  createBooking(input: { userId: string; slotId: string; service: string; contactMethod: "video" | "phone" | "chat"; notes?: string }): Promise<Booking>;
  rescheduleBooking(input: { userId: string; bookingId: string; newSlotId: string }): Promise<Booking>;
  cancelBooking(input: { userId: string; bookingId: string; reason?: string }): Promise<Booking>;
  listBookings(input: { userId: string }): Promise<Booking[]>;
}
