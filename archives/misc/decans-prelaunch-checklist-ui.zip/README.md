# Decans Pre-Launch Checklist UI (Next.js + Tailwind)

## Contents
- `components/PreLaunchChecklist.tsx` (client component with localStorage persistence + reset)
- `data/checklistData.ts` (editable checklist data)
- `app/admin/prelaunch/page.tsx` (App Router page)

## Install deps
```bash
npm i lucide-react
```

## Placement (recommended)
Copy into your repo root:
- `/components/PreLaunchChecklist.tsx`
- `/data/checklistData.ts`
- `/app/admin/prelaunch/page.tsx`

## Notes
- Persists state in browser localStorage under key: `decans.prelaunchChecklist.v1`
- Tailwind required (classes used throughout)
