import path from "node:path";
import { readFile } from "node:fs/promises";
import type { Policy, DiffResult } from "./types.js";
import { anyMatch } from "./glob.js";

type Violation = { code: string; message: string; path?: string; };

export async function enforce(root: string, policy: Policy, diff: DiffResult): Promise<Violation[]> {
  const v: Violation[] = [];

  if (diff.changed.length > policy.maxFilesChanged) {
    v.push({ code: "TOO_MANY_CHANGES", message: `Changed files (${diff.changed.length}) exceeds maxFilesChanged (${policy.maxFilesChanged}).` });
  }

  for (const c of diff.changed) {
    if (anyMatch(policy.protected, c.path)) {
      v.push({ code: "PROTECTED_TOUCHED", message: `Protected path changed: ${c.path}`, path: c.path });
    }
  }

  for (const c of diff.changed) {
    if (c.status === "deleted" && anyMatch(policy.denyDelete, c.path)) {
      v.push({ code: "DELETE_DENIED", message: `Deletion denied: ${c.path}`, path: c.path });
    }
  }

  for (const c of diff.changed) {
    if (!anyMatch(policy.allowedTouch, c.path)) {
      v.push({ code: "TOUCH_OUTSIDE_ALLOWLIST", message: `Changed outside allowlist: ${c.path}`, path: c.path });
    }
  }

  if (policy.requireChangelog) {
    const chPath = path.join(root, policy.changelogPath);
    try {
      const ch = await readFile(chPath, "utf-8");
      const ok = /##\s+Unreleased[\s\S]*?-\s+.+/m.test(ch);
      if (!ok) v.push({ code: "CHANGELOG_REQUIRED", message: `Add a bullet under ## Unreleased in ${policy.changelogPath}.` });
    } catch {
      v.push({ code: "CHANGELOG_MISSING", message: `Changelog missing at ${policy.changelogPath}.` });
    }
  }

  return v;
}
