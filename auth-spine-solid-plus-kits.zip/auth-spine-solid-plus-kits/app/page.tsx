export default function Page() {
  return (
    <div className="bg-white rounded-2xl shadow-soft p-6 md:p-8 border border-slate-200/60">
      <h1 className="text-3xl font-black text-slate-900">Auth-Spine Solid + UI Kits</h1>
      <p className="mt-2 text-slate-700">
        This mini app bundles: a reliability checklist (docs), a UI authority troubleshoot kit, and an HTML→TS conflict resolver.
      </p>
      <div className="mt-6 grid gap-3 md:grid-cols-2">
        <a className="rounded-xl border border-slate-200 bg-slate-50 p-4 font-semibold hover:bg-slate-100" href="/docs">
          Read the “Super Solid” checklist →
        </a>
        <a className="rounded-xl border border-slate-200 bg-slate-50 p-4 font-semibold hover:bg-slate-100" href="/ui-toolkit">
          UI Troubleshoot Kit →
        </a>
        <a className="rounded-xl border border-slate-200 bg-slate-50 p-4 font-semibold hover:bg-slate-100" href="/html-to-ts">
          HTML→TS Conflict Resolver →
        </a>
        <a className="rounded-xl border border-slate-200 bg-slate-50 p-4 font-semibold hover:bg-slate-100" href="/health">
          Health endpoint demo →
        </a>
      </div>
    </div>
  );
}
