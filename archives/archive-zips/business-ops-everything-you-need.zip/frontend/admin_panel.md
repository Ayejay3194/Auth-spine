Admin controls and switches.
