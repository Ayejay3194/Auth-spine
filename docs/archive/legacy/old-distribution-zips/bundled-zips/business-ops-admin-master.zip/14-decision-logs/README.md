# 14-decision-logs

Why decisions were made.
