import readline from "node:readline";
import { buildRuntime } from "../assistant/runtime.js";
import { makeMockProviders } from "./mockProviders.js";

const auditEvents: any[] = [];
const audit = { async write(ev: any) { auditEvents.unshift({ at: ev.at.toISOString(), type: ev.type, details: ev.details }); } };
const clock = { now: () => new Date() };

const { assistant } = buildRuntime({ providers: makeMockProviders(), audit, clock });

const ctx = { businessId: "biz_1", userId: "user_1", role: "owner", timezone: "America/New_York", locale: "en-US", channel: "web" as const };
let state: any = {};

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log("No‑LLM Assistant Demo. Try: 'create invoice $75 for cl_1', 'show revenue', 'show tasks', 'audit log'.");
rl.setPrompt("> ");
rl.prompt();

rl.on("line", async (line) => {
  const out = await assistant.handle(ctx, state, line);
  state = out.state;
  console.log(out.reply.text);
  if (out.reply.ui) console.log(JSON.stringify(out.reply.ui, null, 2));
  rl.prompt();
});
