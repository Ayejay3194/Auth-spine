export interface DeviceRecord {
  id: string;
  userId: string;
  name?: string;
  trusted: boolean;
  createdAt: string;
  lastSeenAt: string;
  revokedAt?: string;
}

export interface DeviceStore {
  upsert(d: Omit<DeviceRecord, "createdAt" | "lastSeenAt">): Promise<DeviceRecord>;
  listByUser(userId: string): Promise<DeviceRecord[]>;
  trust(userId: string, deviceId: string, trusted: boolean): Promise<void>;
  revoke(userId: string, deviceId: string, at: string): Promise<void>;
}
