import { pickTone } from "./tones";
import { renderTemplate } from "./templates";

export type Intent =
  | "book_service"
  | "check_availability"
  | "reschedule_booking"
  | "cancel_booking"
  | "pricing_quote"
  | "service_info"
  | "help"
  | "complaint"
  | "contact_support"
  | (string & {});

export interface NluResult {
  intent: Intent;
  entities: Record<string, any>;
  confidence: number;
  sentiment?: "pos" | "neu" | "neg";
  urgency?: "low" | "medium" | "high";
}

export function respond(nlu: NluResult) {
  const tone = pickTone({ intent: nlu.intent, sentiment: nlu.sentiment, urgency: nlu.urgency });

  switch (nlu.intent) {
    case "book_service": {
      const missing = missingAny(nlu.entities, ["service", "date", "time"]);
      if (missing.length) return renderTemplate(tone, "ASK_MISSING", { missing: missing.join(", ") });
      return renderTemplate(tone, "BOOK_CONFIRM", nlu.entities);
    }
    case "check_availability": {
      const missing = missingAny(nlu.entities, ["service", "date"]);
      if (missing.length) return renderTemplate(tone, "ASK_MISSING", { missing: missing.join(", ") });
      return renderTemplate(tone, "AVAILABILITY", { ...nlu.entities, slots: "10:30am, 1pm, 4:15pm" });
    }
    case "reschedule_booking": {
      const missing = missingAny(nlu.entities, ["date", "time"]);
      if (missing.length) return renderTemplate(tone, "ASK_MISSING", { missing: missing.join(", ") });
      return renderTemplate(tone, "RESCHEDULE_CONFIRM", nlu.entities);
    }
    case "cancel_booking": {
      return renderTemplate(tone, "CANCEL_CONFIRM", nlu.entities);
    }
    case "complaint": {
      return "I hear you. Tell me what happened and what outcome you want (refund, reschedule, or follow-up).";
    }
    case "contact_support": {
      return "Got it. Describe the issue in one sentence and include any error text you see.";
    }
    case "help":
    default:
      return "I can book, reschedule, cancel, quote pricing, and answer service questions. Tell me what you need.";
  }
}

function missingAny(entities: Record<string, any>, keys: string[]) {
  return keys.filter((k) => !entities?.[k]);
}
