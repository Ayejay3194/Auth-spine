# Assistant Polish Layer V1 (TS/React/Node)

Adds the final "sounds human" polish:
- Micro-timing delays (humanDelay)
- Acknowledgment fragments (maybeAcknowledge)
- Ellipsis discipline helpers (thinkingPhrases)
- Repetition guard (pickNonRepeating)
- Banned phrase filter (sanitizeCopy)
- End-of-turn restraint helpers (finalizeReply)

## Drop-in
Copy `src/assistant-polish/*` into your project.

## Suggested wiring (server or client)
Before sending a reply:
1) `await humanDelay(...)` (optional)
2) `reply = maybeAcknowledge(state) + reply`
3) `reply = sanitizeCopy(reply)`
4) `reply = finalizeReply(reply)` (optional trimming)

## State requirement
Uses a small `PolishState`:
- lastResponseKey
- lastAssistantText
- lastAckAt
