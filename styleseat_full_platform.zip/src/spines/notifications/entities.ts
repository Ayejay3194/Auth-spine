// notifications entities.ts
