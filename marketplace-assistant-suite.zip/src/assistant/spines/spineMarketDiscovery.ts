import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerMarketDiscoveryTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "market.search_providers",
    title: "Search providers",
    description: "Finds providers matching service/location and optional date/time.",
    inputSchema: { type: "object", properties: { service: { type: "string" }, location: { type: "string" }, dateISO: { type: "string" }, timeHint: { type: "string" } }, required: ["service","location"] },
    async run(ctx, input) { return { ok: true, data: await p.marketDiscovery.searchProviders(input) }; }
  });

  reg.register({
    id: "market.search_slots",
    title: "Search slots",
    description: "Finds bookable slots for a provider.",
    inputSchema: { type: "object", properties: { providerId: { type: "string" }, dateISO: { type: "string" }, durationMin: { type: "number" } }, required: ["providerId","durationMin"] },
    async run(ctx, input) { return { ok: true, data: await p.marketDiscovery.searchSlots(input) }; }
  });
}
