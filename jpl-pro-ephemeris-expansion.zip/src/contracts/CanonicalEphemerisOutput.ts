
export interface CanonicalEphemerisOutput {
  engineVersion: string;
  kernelFingerprint: string;
  timeModelVersion: string;
  eopVersion: string;

  input: {
    utc: string;
    latitude: number;
    longitude: number;
    elevationMeters?: number;
    frame: 'ICRF' | 'J2000' | 'ITRF';
  };

  times: {
    utc: string;
    tai: string;
    tt: string;
    tdb: string;
  };

  bodies: {
    name: string;
    positionAU: [number, number, number];
    velocityAUPerDay: [number, number, number];
    longitudeDeg: number;
    latitudeDeg: number;
    distanceAU: number;
    retrograde: boolean;
  }[];

  houses?: {
    system: string;
    cuspsDeg: number[];
  };

  aspects?: {
    body1: string;
    body2: string;
    type: string;
    orbDeg: number;
  }[];

  checks: {
    passed: boolean;
    warnings: string[];
  };
}
