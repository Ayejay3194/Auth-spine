"use client";
import { useState } from "react";

export function MLNoShowCard(){
  const [clientUserId, setClientUserId] = useState("");
  const [out, setOut] = useState<any>(null);

  async function run(){
    setOut(null);
    const r = await fetch("/api/patterns/no-show", {
      method:"POST",
      headers:{ "content-type":"application/json" },
      body: JSON.stringify({ clientUserId: clientUserId || undefined })
    });
    const j = await r.json();
    setOut(j);
  }

  return (
    <div className="rounded-[28px] border p-6" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
      <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>ML (scikit-learn)</div>
      <h2 className="serif mt-2 text-2xl">No-show risk</h2>
      <p className="mt-2 text-sm" style={{color:"var(--muted)"}}>Calls the ML sidecar. Leave blank to score the signed-in user.</p>

      <div className="mt-4 flex flex-wrap gap-2">
        <input value={clientUserId} onChange={(e)=>setClientUserId(e.target.value)} placeholder="clientUserId (optional)"
          className="min-w-[260px] flex-1 rounded-xl border px-3 py-3 text-sm"
          style={{borderColor:"var(--border)", background:"var(--panel2)", color:"var(--text)"}} />
        <button onClick={run} className="rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>
          Score
        </button>
      </div>

      {out ? (
        <pre className="mt-4 rounded-2xl border p-4 text-xs overflow-auto" style={{borderColor:"var(--border)", background:"var(--panel2)", color:"var(--text)"}}>
{JSON.stringify(out, null, 2)}
        </pre>
      ) : null}
    </div>
  );
}
