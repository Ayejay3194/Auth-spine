# Integration Log (Example)

This file is an example of how to track structural changes.

- 2025-01-01
  - Created `projects/simple-saas-nextjs` app.
  - Added `User` and `Project` models to Prisma.
  - Implemented basic dashboard with project list.
