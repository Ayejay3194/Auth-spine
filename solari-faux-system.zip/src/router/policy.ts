import { NLUResult, RouteDecision, SkillName } from "../types.js";
import { clamp01 } from "../utils/text.js";

export function route(nlu: NLUResult): RouteDecision {
  const skill = pickSkill(nlu);

  // Decide action based on confidence and intent needs
  let action: RouteDecision["action"] = "fulfill";
  let reason = "default fulfill";

  if (nlu.intent === "unknown" || nlu.confidence < 0.45) {
    action = "clarify";
    reason = "low confidence";
  }

  // some intents need entities
  if (nlu.intent === "ask_weather" && !nlu.entities.some(e => e.kind === "location")) {
    action = "clarify";
    reason = "weather needs a location";
  }

  const tone = inferTone(nlu);

  return { skill, action, reason, tone };
}

function pickSkill(nlu: NLUResult): SkillName {
  switch (nlu.intent) {
    case "greeting":
    case "goodbye":
    case "smalltalk":
      return "ChitchatSkill";
    case "ask_astrology":
      return "AstroInterpreterSkill";
    case "ask_weather":
      return "WeatherSkill";
    case "planning":
      return "PlannerSkill";
    case "bug_report":
      return "BugTriageSkill";
    case "request_file":
      return "FileHelperSkill";
    default:
      return "FallbackSkill";
  }
}

function inferTone(nlu: NLUResult): { snark: number; warmth: number; verbosity: number } {
  // base
  let snark = 0.55;
  let warmth = 0.45;
  let verbosity = 0.55;

  if (nlu.sentiment === "negative") {
    warmth += 0.15;
    snark -= 0.1;
  }
  if (nlu.sentiment === "intense") {
    snark += 0.1;
    verbosity += 0.05;
  }
  if (nlu.intent === "bug_report") {
    snark -= 0.15;
    warmth += 0.1;
    verbosity += 0.1;
  }

  // explicit override
  if (nlu.styleRequest) {
    snark = nlu.styleRequest.snark;
    warmth = nlu.styleRequest.warmth;
    verbosity = nlu.styleRequest.verbosity;
  }

  return {
    snark: clamp01(snark),
    warmth: clamp01(warmth),
    verbosity: clamp01(verbosity),
  };
}
