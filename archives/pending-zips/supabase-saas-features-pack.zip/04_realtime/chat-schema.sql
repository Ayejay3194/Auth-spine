-- Chat tables (tenant-scoped)
create table if not exists chat_threads (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  kind text not null, -- DM | GROUP | CHANNEL
  created_at timestamptz default now()
);

create table if not exists chat_members (
  thread_id uuid not null,
  tenant_id uuid not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'MEMBER',
  primary key(thread_id, user_id)
);

create table if not exists chat_messages (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  thread_id uuid not null,
  sender_id uuid not null references auth.users(id),
  body text not null,
  created_at timestamptz default now(),
  deleted_at timestamptz
);

-- Realtime: enable publication for messages, enforce RLS so only members see.
