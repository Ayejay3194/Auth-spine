Roles, permissions, audit logs.
