CRISIS COMMUNICATIONS
=====================

Principles:
- Acknowledge quickly
- State what we know
- State what we're doing
- Give next update time

Never:
- Blame users
- Overpromise
- Go silent

Channels:
- Status page
- Email
- In-app banner
