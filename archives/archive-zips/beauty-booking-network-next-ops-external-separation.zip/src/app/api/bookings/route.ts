import { prisma } from "@/lib/prisma";
import { z } from "zod";

const Body = z.object({
  stylistId: z.string(),
  salonId: z.string().nullable().optional(),
  serviceId: z.string(),
  startAt: z.string(), // ISO
});

export async function POST(req: Request) {
  const data = Body.parse(await req.json());
  const startAt = new Date(data.startAt);

  const stylist = await prisma.stylistProfile.findUnique({
    where: { id: data.stylistId },
    include: { memberships: { where: { status: "ACTIVE" }, orderBy: { effectiveFrom: "desc" }, take: 1 } }
  });
  if (!stylist) return new Response("Invalid stylist", { status: 400 });

  const service = await prisma.serviceTemplate.findUnique({ where: { id: data.serviceId } });
  if (!service) return new Response("Invalid service", { status: 400 });

  const endAt = new Date(startAt);
  endAt.setUTCMinutes(endAt.getUTCMinutes() + service.durationMin);

  const membership = stylist.memberships[0] || null;
  const settings: any = membership?.settings || {};
  const approvalRequired = Boolean(settings.requireApprovalForNewClients);
  const status = approvalRequired ? "PENDING_APPROVAL" : "CONFIRMED";

  // price resolution: salon override if salonId provided
  let priceCentsFinal = service.basePriceCents;
  if (data.salonId) {
    const o = await prisma.salonServiceOverride.findUnique({ where: { salonId_serviceId: { salonId: data.salonId, serviceId: service.id } } });
    if (o?.priceCents) priceCentsFinal = o.priceCents;
  }

  // conflict: same stylist & startAt
  const conflict = await prisma.booking.findFirst({
    where: { stylistId: data.stylistId, startAt, status: { in: ["REQUESTED","PENDING_APPROVAL","CONFIRMED"] } },
    select: { id: true },
  });
  if (conflict) return new Response("Slot taken", { status: 409 });

  const booking = await prisma.booking.create({
    data: {
      stylistId: data.stylistId,
      salonId: data.salonId ?? null,
      serviceId: data.serviceId,
      startAt,
      endAt,
      priceCentsFinal,
      approvalRequired,
      status,
    }
  });

  return Response.json({ booking });
}
