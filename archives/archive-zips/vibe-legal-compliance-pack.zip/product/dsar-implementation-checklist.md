# DSAR Implementation Checklist (Access/Export/Delete)

## Endpoints
- POST /privacy/request (create DSAR request)
- GET /privacy/request/:id (status)
- POST /privacy/request/:id/verify (email token or auth)
- POST /privacy/request/:id/export (generate export job)
- POST /privacy/request/:id/delete (queue deletion job)

## Verification
- if logged in: require re-auth for delete/export
- if logged out: signed email link token with expiry

## Export scope
- profile
- bookings
- messages (where lawful)
- invoices/receipts metadata
- consent history

## Deletion scope
- hard delete PII where possible
- anonymize transactional records if legally required to keep
- delete from storage objects
- purge search index
- ensure backups expire per retention

## Logging
- DSAR requests must be auditable without storing extra PII.
