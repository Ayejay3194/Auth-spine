# 04-financial-ops

Revenue, expenses, margin, cash flow.
