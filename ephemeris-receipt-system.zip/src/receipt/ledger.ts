import { createHmac } from "node:crypto";
import { canonicalJson, sha256Hex } from "./canonical.js";
import type { CanonicalReceiptV1 } from "./types.js";

export type LedgerEntry = {
  prevHash: string | null;
  entryHash: string;      // sha256 of canonicalized receipt
  chainHash: string;      // sha256(prevChainHash + entryHash)
  signature: string;      // HMAC(chainHash)
  receipt: CanonicalReceiptV1;
};

export function signChainHash(chainHash: string, secret: string): string {
  return createHmac("sha256", secret).update(chainHash).digest("hex");
}

export function makeLedgerEntry(args: {
  receipt: CanonicalReceiptV1;
  prevChainHash: string | null;
  secret: string;
}): LedgerEntry {
  const entryHash = sha256Hex(canonicalJson(args.receipt));
  const chainHash = sha256Hex((args.prevChainHash ?? "") + entryHash);
  const signature = signChainHash(chainHash, args.secret);
  return {
    prevHash: args.prevChainHash,
    entryHash,
    chainHash,
    signature,
    receipt: args.receipt,
  };
}

export function verifyLedgerEntry(args: {
  entry: LedgerEntry;
  expectedPrevChainHash: string | null;
  secret: string;
}): { ok: boolean; reason?: string } {
  const recomputedEntryHash = sha256Hex(canonicalJson(args.entry.receipt));
  if (recomputedEntryHash !== args.entry.entryHash) {
    return { ok: false, reason: "Receipt hash mismatch (receipt tampered or non-canonical)" };
  }
  if (args.entry.prevHash !== args.expectedPrevChainHash) {
    return { ok: false, reason: "prevHash mismatch (chain broken)" };
  }
  const recomputedChainHash = sha256Hex((args.expectedPrevChainHash ?? "") + args.entry.entryHash);
  if (recomputedChainHash !== args.entry.chainHash) {
    return { ok: false, reason: "chainHash mismatch (chain broken)" };
  }
  const sig = signChainHash(args.entry.chainHash, args.secret);
  if (sig !== args.entry.signature) {
    return { ok: false, reason: "signature mismatch (wrong secret or tampered entry)" };
  }
  return { ok: true };
}
