# Disaster Recovery Tests

Operational tests you run against real environments.

- Prove backups exist
- Prove restores work
- Record restore time and data age (RTO/RPO reality)

See: `restore-rehearsal.sh`
