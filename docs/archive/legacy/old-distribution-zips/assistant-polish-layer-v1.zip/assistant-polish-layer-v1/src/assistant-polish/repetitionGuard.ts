import type { PolishState } from "./types";

/**
 * Prevents repetitive replies by avoiding the same responseKey twice in a row.
 * Use with your existing template keys.
 */
export function pickNonRepeating<T extends string>(
  state: PolishState,
  key: T,
  alternates: T[] = []
): T {
  if (!state.lastResponseKey) {
    state.lastResponseKey = key;
    return key;
  }

  if (state.lastResponseKey === key && alternates.length) {
    const alt = alternates[Math.floor(Math.random() * alternates.length)];
    state.lastResponseKey = alt;
    return alt;
  }

  state.lastResponseKey = key;
  return key;
}

/**
 * Light text-level repetition check (optional).
 * If you pass in a candidate reply that matches the last one too closely, swap it.
 */
export function tooSimilar(a?: string, b?: string) {
  if (!a || !b) return false;
  const na = normalize(a), nb = normalize(b);
  if (na === nb) return true;
  // crude similarity: shared prefix length
  let i = 0;
  while (i < na.length && i < nb.length && na[i] === nb[i]) i++;
  return i / Math.max(na.length, nb.length) > 0.85;
}

function normalize(s: string) {
  return s.toLowerCase().replace(/\s+/g, " ").trim();
}
