// analytics tools.ts
