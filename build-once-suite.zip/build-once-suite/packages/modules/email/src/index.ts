import type { AuditStore } from "@suite/core-audit";

export type EmailType = "welcome" | "security_alert" | "invoice" | "marketing";

export type EmailTemplate = {
  key: string;
  subject: string;
  previewText?: string;
  html: string;
  text: string;
  variables: string[];
  darkModeHtml?: string;
};

export type EmailPrefs = {
  marketing: boolean;
  productUpdates: boolean;
  security: boolean;
};

export interface EmailAdapter {
  send(msg: { to: string; subject: string; html: string; text: string; headers?: Record<string,string> }): Promise<void>;
}

export interface TemplateStore {
  get(key: string): Promise<EmailTemplate | null>;
  upsert(tpl: EmailTemplate): Promise<void>;
}

export class EmailService {
  constructor(private store: TemplateStore, private adapter: EmailAdapter, private audit: AuditStore) {}

  async send(to: string, type: EmailType, vars: Record<string, string | number>, opts?: { useDark?: boolean; actorUserId?: string }) {
    const key = `type:${type}`;
    const tpl = await this.store.get(key);
    if (!tpl) throw new Error(`Missing email template ${key}`);
    const subject = render(tpl.subject, vars);
    const html = render(opts?.useDark && tpl.darkModeHtml ? tpl.darkModeHtml : tpl.html, vars);
    const text = render(tpl.text, vars);
    await this.adapter.send({ to, subject, html, text, headers: tpl.previewText ? { "X-Preview-Text": tpl.previewText } : undefined });
    await this.audit.append({ actor: { actorType: "system", userId: opts?.actorUserId }, action: "email.sent", targetType: "email", targetId: to, metadata: { type } });
  }
}

export function render(t: string, vars: Record<string, string | number>) {
  return t.replace(/\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}/g, (_, k) => String(vars[k] ?? ""));
}
