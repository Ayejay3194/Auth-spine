// ai_insights entities.ts
