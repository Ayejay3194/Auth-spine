import test from "node:test";
import assert from "node:assert/strict";
import { buildForwardKey, buildReverseKey } from "../util.js";

test("buildForwardKey normalizes consistently", () => {
  const a = buildForwardKey({ query: "  New   York  ", locale: "EN", countryCodes: ["US", "ca"] });
  const b = buildForwardKey({ query: "new york", locale: "en", countryCodes: ["ca", "us"] });
  assert.equal(a, b);
});

test("buildReverseKey rounds coords", () => {
  const a = buildReverseKey({ lat: 40.71281234, lon: -74.00601234, locale: "en" });
  const b = buildReverseKey({ lat: 40.71281239, lon: -74.00601236, locale: "en" });
  assert.equal(a, b);
});
