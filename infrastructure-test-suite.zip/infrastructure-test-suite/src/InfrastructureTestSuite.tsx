import React, { useState } from 'react';
import { CheckCircle2, XCircle, AlertCircle, ChevronDown, ChevronRight, Download } from 'lucide-react';

type ExpandedCategories = Record<string, boolean>;
type TestResult = 'pass' | 'fail';
type TestResults = Record<string, TestResult>;

const InfrastructureTestSuite: React.FC = () => {
const [expandedCategories, setExpandedCategories] = useState<ExpandedCategories>({});
const [testResults, setTestResults] = useState<TestResults>({});

const testSuite = [
{
category: "Architecture & Design",
tests: [
{ id: "arch1", test: "Architecture documentation exists and is up-to-date", critical: true },
{ id: "arch2", test: "System components and dependencies are mapped", critical: true },
{ id: "arch3", test: "Scalability requirements are defined and documented", critical: false },
{ id: "arch4", test: "Failure modes identified and mitigation strategies documented", critical: true },
{ id: "arch5", test: "Data flow diagrams exist for all major processes", critical: false },
{ id: "arch6", test: "Service boundaries are clearly defined", critical: true },
{ id: "arch7", test: "API contracts are versioned and documented", critical: true },
]
},
{
category: "Security",
tests: [
{ id: "sec1", test: "All credentials are stored in secrets management (no hardcoded secrets)", critical: true },
{ id: "sec2", test: "Encryption at rest enabled for all sensitive data stores", critical: true },
{ id: "sec3", test: "TLS/SSL certificates are valid and not expiring within 30 days", critical: true },
{ id: "sec4", test: "All network traffic uses encryption in transit", critical: true },
{ id: "sec5", test: "Security groups/firewall rules follow least privilege", critical: true },
{ id: "sec6", test: "Multi-factor authentication enforced for privileged access", critical: true },
{ id: "sec7", test: "Regular security scanning (SAST/DAST) is automated", critical: true },
{ id: "sec8", test: "Vulnerability management process is in place", critical: true },
{ id: "sec9", test: "Access logs are enabled and retained", critical: true },
{ id: "sec10", test: "Penetration testing conducted within last 12 months", critical: false },
{ id: "sec11", test: "WAF configured with appropriate rules", critical: true },
{ id: "sec12", test: "DDoS protection is enabled", critical: false },
{ id: "sec13", test: "API rate limiting is configured", critical: true },
]
},
{
category: "Network Architecture",
tests: [
{ id: "net1", test: "Network segmentation implemented (public/private subnets)", critical: true },
{ id: "net2", test: "Load balancers have health checks configured", critical: true },
{ id: "net3", test: "DNS records have appropriate TTL values", critical: false },
{ id: "net4", test: "CDN configured for static assets", critical: false },
{ id: "net5", test: "Network ACLs are properly configured", critical: true },
{ id: "net6", test: "VPN or bastion host configured for secure administrative access", critical: true },
{ id: "net7", test: "Network bandwidth limits are documented and monitored", critical: false },
]
},
{
category: "Compute Resources",
tests: [
{ id: "comp1", test: "Autoscaling policies are configured and tested", critical: true },
{ id: "comp2", test: "Resource limits (CPU/memory) are defined for all services", critical: true },
{ id: "comp3", test: "Health check endpoints exist for all services", critical: true },
{ id: "comp4", test: "Graceful shutdown is implemented for all services", critical: true },
{ id: "comp5", test: "Container images are scanned for vulnerabilities", critical: true },
{ id: "comp6", test: "Resource utilization is monitored", critical: true },
{ id: "comp7", test: "Unused resources are identified and cleaned up", critical: false },
]
},
{
category: "Data & Storage",
tests: [
{ id: "data1", test: "Automated backups are configured", critical: true },
{ id: "data2", test: "Backup restoration has been tested within last 90 days", critical: true },
{ id: "data3", test: "Database replication is configured", critical: true },
{ id: "data4", test: "Point-in-time recovery is enabled", critical: true },
{ id: "data5", test: "Data retention policies are defined and enforced", critical: true },
{ id: "data6", test: "Database connection pooling is configured", critical: false },
{ id: "data7", test: "Database indexes are optimized", critical: false },
{ id: "data8", test: "Slow query logging is enabled", critical: true },
{ id: "data9", test: "Storage capacity monitoring and alerting configured", critical: true },
{ id: "data10", test: "Data residency requirements are met", critical: true },
]
},
{
category: "Monitoring & Observability",
tests: [
{ id: "mon1", test: "Centralized logging is implemented", critical: true },
{ id: "mon2", test: "Log retention policy is defined and enforced", critical: true },
{ id: "mon3", test: "Application performance monitoring (APM) is configured", critical: true },
{ id: "mon4", test: "Distributed tracing is implemented", critical: false },
{ id: "mon5", test: "Key metrics dashboards exist", critical: true },
{ id: "mon6", test: "Alerting rules are configured for critical services", critical: true },
{ id: "mon7", test: "Alerts are actionable and have runbooks", critical: true },
{ id: "mon8", test: "Alert fatigue is managed (low false positive rate)", critical: true },
{ id: "mon9", test: "On-call rotation is defined", critical: true },
{ id: "mon10", test: "Synthetic monitoring/uptime checks are configured", critical: true },
{ id: "mon11", test: "Error tracking and aggregation is implemented", critical: true },
]
},
{
category: "Deployment & CI/CD",
tests: [
{ id: "cicd1", test: "Automated deployment pipeline exists", critical: true },
{ id: "cicd2", test: "Automated testing runs before deployment", critical: true },
{ id: "cicd3", test: "Code review is required before merging", critical: true },
{ id: "cicd4", test: "Rollback procedure is documented and tested", critical: true },
{ id: "cicd5", test: "Infrastructure as code is version controlled", critical: true },
{ id: "cicd6", test: "Environment parity (dev/staging/prod) is maintained", critical: true },
{ id: "cicd7", test: "Deployment strategy (blue-green/canary) is implemented", critical: false },
{ id: "cicd8", test: "Deployment approvals are required for production", critical: true },
{ id: "cicd9", test: "Secrets are not stored in version control", critical: true },
{ id: "cicd10", test: "Build artifacts are versioned and stored", critical: true },
]
},
{
category: "Disaster Recovery",
tests: [
{ id: "dr1", test: "RTO and RPO are defined for all critical systems", critical: true },
{ id: "dr2", test: "Disaster recovery plan is documented", critical: true },
{ id: "dr3", test: "DR procedures tested within last 6 months", critical: true },
{ id: "dr4", test: "Multi-region/multi-AZ deployment for critical services", critical: true },
{ id: "dr5", test: "Failover testing is regularly performed", critical: true },
{ id: "dr6", test: "Incident response plan exists", critical: true },
{ id: "dr7", test: "Communication plan for outages is defined", critical: true },
{ id: "dr8", test: "Backup data is stored in separate geographic location", critical: true },
]
},
{
category: "Performance",
tests: [
{ id: "perf1", test: "Performance benchmarks are established", critical: false },
{ id: "perf2", test: "Caching strategy is implemented", critical: true },
{ id: "perf3", test: "Database query performance is monitored", critical: true },
{ id: "perf4", test: "Load testing is performed regularly", critical: false },
{ id: "perf5", test: "API response times are within SLA", critical: true },
{ id: "perf6", test: "Resource bottlenecks are identified and documented", critical: false },
{ id: "perf7", test: "Asynchronous processing for long-running tasks", critical: true },
]
},
{
category: "Cost Management",
tests: [
{ id: "cost1", test: "Resource tagging strategy is implemented", critical: true },
{ id: "cost2", test: "Cost monitoring and alerting is configured", critical: true },
{ id: "cost3", test: "Budget limits are defined", critical: true },
{ id: "cost4", test: "Regular cost optimization reviews are scheduled", critical: false },
{ id: "cost5", test: "Unused resources are automatically identified", critical: false },
{ id: "cost6", test: "Reserved instances/savings plans are utilized", critical: false },
{ id: "cost7", test: "Non-production environments auto-shutdown configured", critical: false },
]
},
{
category: "Compliance & Governance",
tests: [
{ id: "comp1", test: "Compliance requirements are documented", critical: true },
{ id: "comp2", test: "Audit logging is enabled", critical: true },
{ id: "comp3", test: "Access control policies are enforced", critical: true },
{ id: "comp4", test: "Regular compliance audits are performed", critical: true },
{ id: "comp5", test: "Data privacy requirements are met", critical: true },
{ id: "comp6", test: "Change management process is documented", critical: true },
{ id: "comp7", test: "Policy as code is implemented", critical: false },
]
},
{
category: "Documentation",
tests: [
{ id: "doc1", test: "Architecture diagrams are current", critical: true },
{ id: "doc2", test: "API documentation is complete and up-to-date", critical: true },
{ id: "doc3", test: "Runbooks exist for common operations", critical: true },
{ id: "doc4", test: "Incident response procedures are documented", critical: true },
{ id: "doc5", test: "Onboarding documentation exists", critical: false },
{ id: "doc6", test: "Infrastructure inventory is maintained", critical: true },
{ id: "doc7", test: "Dependencies are documented", critical: true },
]
}
];

const toggleCategory = (category: string) => {
setExpandedCategories(prev => ({
...prev,
[category]: !prev[category]
}));
};

const handleTestChange = (testId: string, value: TestResult) => {
setTestResults(prev => ({
...prev,
[testId]: value
}));
};

const getStats = () => {
const total = testSuite.reduce((sum, cat) => sum + cat.tests.length, 0);
const completed = Object.keys(testResults).length;
const passed = Object.values(testResults).filter(v => v === 'pass').length;
const failed = Object.values(testResults).filter(v => v === 'fail').length;
const critical = testSuite.reduce((sum, cat) =>
sum + cat.tests.filter(t => t.critical && testResults[t.id] === 'fail').length, 0
);

return { total, completed, passed, failed, critical };
};

const exportResults = () => {
const stats = getStats();
let report = `Infrastructure Test Suite Results\n`;
report += `Generated: ${new Date().toLocaleString()}\n\n`;
report += `Summary:\n`;
report += `Total Tests: ${stats.total}\n`;
report += `Completed: ${stats.completed}\n`;
report += `Passed: ${stats.passed}\n`;
report += `Failed: ${stats.failed}\n`;
report += `Critical Failures: ${stats.critical}\n\n`;
report += `Completion: ${Math.round((stats.completed / stats.total) * 100)}%\n\n`;

testSuite.forEach(category => {
  report += `\n${category.category}\n${'='.repeat(category.category.length)}\n`;
  category.tests.forEach(test => {
    const result = testResults[test.id] || 'pending';
    const status = result === 'pass' ? '✓' : result === 'fail' ? '✗' : '○';
    const critical = test.critical ? '[CRITICAL]' : '';
    report += `${status} ${test.test} ${critical}\n`;
  });
});

const blob = new Blob([report], { type: 'text/plain' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = `infrastructure-test-report-${new Date().toISOString().split('T')[0]}.txt`;
a.click();
URL.revokeObjectURL(url);
};

const stats = getStats();
const completionPercent = Math.round((stats.completed / stats.total) * 100);

return (
<div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
<div className="max-w-6xl mx-auto">
<div className="bg-white rounded-lg shadow-lg p-8 mb-6">
<h1 className="text-3xl font-bold text-slate-800 mb-2">Infrastructure Testing Suite</h1>
<p className="text-slate-600 mb-6">Comprehensive checklist to validate your infrastructure before deployment</p>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <div className="bg-blue-50 rounded-lg p-4">
          <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
          <div className="text-sm text-slate-600">Total Tests</div>
        </div>
        <div className="bg-green-50 rounded-lg p-4">
          <div className="text-2xl font-bold text-green-600">{stats.passed}</div>
          <div className="text-sm text-slate-600">Passed</div>
        </div>
        <div className="bg-red-50 rounded-lg p-4">
          <div className="text-2xl font-bold text-red-600">{stats.failed}</div>
          <div className="text-sm text-slate-600">Failed</div>
        </div>
        <div className="bg-orange-50 rounded-lg p-4">
          <div className="text-2xl font-bold text-orange-600">{stats.critical}</div>
          <div className="text-sm text-slate-600">Critical Failures</div>
        </div>
        <div className="bg-purple-50 rounded-lg p-4">
          <div className="text-2xl font-bold text-purple-600">{completionPercent}%</div>
          <div className="text-sm text-slate-600">Complete</div>
        </div>
      </div>

      <div className="w-full bg-slate-200 rounded-full h-3 mb-4">
        <div 
          className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-500"
          style={{ width: `${completionPercent}%` }}
        />
      </div>

      <button
        onClick={exportResults}
        className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg hover:bg-slate-700 transition-colors"
      >
        <Download size={18} />
        Export Report
      </button>
    </div>

    {stats.critical > 0 && (
      <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-lg">
        <div className="flex items-center gap-2 text-red-800 font-semibold mb-1">
          <AlertCircle size={20} />
          Critical Issues Detected
        </div>
        <p className="text-red-700 text-sm">
          You have {stats.critical} critical test{stats.critical !== 1 ? 's' : ''} failing. These must be resolved before production deployment.
        </p>
      </div>
    )}

    <div className="space-y-4">
      {testSuite.map((category, idx) => {
        const isExpanded = expandedCategories[category.category] ?? true;
        const categoryTests = category.tests;
        const categoryPassed = categoryTests.filter(t => testResults[t.id] === 'pass').length;
        const categoryFailed = categoryTests.filter(t => testResults[t.id] === 'fail').length;
        const categoryCritical = categoryTests.filter(t => t.critical && testResults[t.id] === 'fail').length;

        return (
          <div key={idx} className="bg-white rounded-lg shadow-md overflow-hidden">
            <button
              onClick={() => toggleCategory(category.category)}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                {isExpanded ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
                <h2 className="text-xl font-semibold text-slate-800">{category.category}</h2>
                <span className="text-sm text-slate-500">({categoryTests.length} tests)</span>
              </div>
              <div className="flex gap-4 text-sm">
                <span className="text-green-600">{categoryPassed} passed</span>
                {categoryFailed > 0 && <span className="text-red-600">{categoryFailed} failed</span>}
                {categoryCritical > 0 && (
                  <span className="text-red-600 font-semibold">{categoryCritical} critical</span>
                )}
              </div>
            </button>

            {isExpanded && (
              <div className="border-t border-slate-200 p-4">
                <div className="space-y-3">
                  {categoryTests.map((test) => (
                    <div
                      key={test.id}
                      className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                        testResults[test.id] === 'pass' ? 'bg-green-50' :
                        testResults[test.id] === 'fail' ? 'bg-red-50' : 'bg-slate-50'
                      }`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-slate-800">{test.test}</span>
                          {test.critical && (
                            <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded font-semibold">
                              CRITICAL
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleTestChange(test.id, 'pass')}
                          className={`p-2 rounded-lg transition-all ${
                            testResults[test.id] === 'pass'
                              ? 'bg-green-500 text-white shadow-md'
                              : 'bg-white border border-slate-300 text-slate-600 hover:bg-green-50'
                          }`}
                        >
                          <CheckCircle2 size={20} />
                        </button>
                        <button
                          onClick={() => handleTestChange(test.id, 'fail')}
                          className={`p-2 rounded-lg transition-all ${
                            testResults[test.id] === 'fail'
                              ? 'bg-red-500 text-white shadow-md'
                              : 'bg-white border border-slate-300 text-slate-600 hover:bg-red-50'
                          }`}
                        >
                          <XCircle size={20} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>

    <div className="mt-8 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-lg">
      <h3 className="font-semibold text-blue-900 mb-2">Usage Instructions</h3>
      <ul className="text-sm text-blue-800 space-y-1">
        <li>• Work through each category systematically</li>
        <li>• Mark tests as passed (✓) or failed (✗) based on your infrastructure</li>
        <li>• Critical tests MUST pass before production deployment</li>
        <li>• Export your results to track progress and share with your team</li>
        <li>• Re-run this checklist before major deployments</li>
      </ul>
    </div>
  </div>
</div>

);
};

export default InfrastructureTestSuite;
