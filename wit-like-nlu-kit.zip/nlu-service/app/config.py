import os
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
MODEL_PATH = os.getenv("NLU_MODEL_PATH", str(ROOT / "models" / "model.joblib"))
TRAINING_PATH = os.getenv("NLU_TRAINING_PATH", str(ROOT / "data" / "training.jsonl"))
