import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import type { AuditSection } from "../types.js";
import { waitForPort } from "../utils/net.js";
import { detectFramework } from "./framework.js";
import { discoverRoutes } from "./routes.js";
import { readJson, exists } from "../utils/fs.js";
import path from "node:path";

export type ServeMode = "auto" | "next" | "vite" | "none";

type ServePlan = { mode: "next" | "vite"; port: number; cmd: string; args: string[]; needsBuild: boolean; };

function planServe(root: string, serve: ServeMode, portOverride?: number): ServePlan | null {
  const { framework } = detectFramework(root);
  const pkgPath = path.join(root, "package.json");
  const pkg = exists(pkgPath) ? readJson<any>(pkgPath) : {};
  const scripts = pkg.scripts ?? {};

  const pick = (mode: "next" | "vite"): ServePlan => {
    if (mode === "next") {
      return { mode, port: portOverride ?? 3000, cmd: "npm", args: ["run", "start"], needsBuild: true };
    }
    return { mode, port: portOverride ?? 4173, cmd: "npm", args: ["run", "preview"], needsBuild: true };
  };

  if (serve === "none") return null;
  if (serve === "next") return pick("next");
  if (serve === "vite") return pick("vite");

  // auto
  if (framework === "next") return pick("next");
  if (framework === "vite") return pick("vite");

  // fallback: if scripts.preview exists, try it
  if (scripts["preview"]) return { mode: "vite", port: portOverride ?? 4173, cmd: "npm", args: ["run", "preview"], needsBuild: true };
  if (scripts["start"]) return { mode: "next", port: portOverride ?? 3000, cmd: "npm", args: ["run", "start"], needsBuild: true };
  return null;
}

function tail(s: string, n = 2000) { return s.length <= n ? s : s.slice(-n); }

export async function auditLocalCrawl(args: {
  root: string;
  serve: ServeMode;
  crawl: boolean;
  port?: number;
  baseUrl?: string;
  crawlMax?: number;
  buildFirst?: boolean;
}): Promise<AuditSection> {
  const section: AuditSection = { id: "localCrawl", title: "Local Preview + Route Refresh Simulation", findings: [] };
  if (args.serve === "none" && !args.crawl) return section;

  const plan = planServe(args.root, args.serve, args.port);

  let child: ChildProcessWithoutNullStreams | null = null;
  let started = false;
  let stdout = "";
  let stderr = "";

  const stop = async () => {
    if (child && !child.killed) {
      child.kill("SIGTERM");
      await new Promise((r) => setTimeout(r, 800));
      if (!child.killed) child.kill("SIGKILL");
    }
  };

  try {
    if (plan) {
      if (args.buildFirst ?? true) {
        section.findings.push({
          id: "local.build.note",
          title: "Preview simulation assumes a build exists",
          severity: "INFO",
          details: "If preview/start fails, run `npm run build` first or enable --run build.",
          evidence: { planned: plan },
        });
      }

      child = spawn(plan.cmd, plan.args, { cwd: args.root, shell: process.platform === "win32", env: process.env });
      child.stdout.on("data", (d) => (stdout += d.toString()));
      child.stderr.on("data", (d) => (stderr += d.toString()));

      const ok = await waitForPort("127.0.0.1", plan.port, 35_000);
      if (!ok) {
        section.findings.push({
          id: "local.serve.fail",
          title: "Preview server did not open the expected port",
          severity: "ERROR",
          details: "Your preview/start process didn't become reachable. That usually means it crashed or is listening on a different port.",
          fix: "Check captured logs. Also confirm your script uses the expected port or pass --port explicitly.",
          evidence: { port: plan.port, stdoutTail: tail(stdout, 4000), stderrTail: tail(stderr, 4000), plan },
        });
        await stop();
        return section;
      }

      started = true;
      section.findings.push({
        id: "local.serve.ok",
        title: `Preview server reachable on port ${plan.port}`,
        severity: "INFO",
        details: "Server is up. Now we can do the refresh/deep-link checks.",
        evidence: { plan, stdoutTail: tail(stdout, 1500), stderrTail: tail(stderr, 1500) },
      });
    }

    if (!args.crawl) {
      await stop();
      return section;
    }

    const baseUrl = (args.baseUrl ?? (plan ? `http://127.0.0.1:${plan.port}` : "http://127.0.0.1:3000")).replace(/\/$/, "");
    const routes = discoverRoutes(args.root);
    const crawlMax = args.crawlMax ?? 120;
    const targets = routes.slice(0, crawlMax);
    if (targets.length === 0) {
      section.findings.push({
        id: "crawl.none",
        title: "No discovered routes to crawl",
        severity: "INFO",
        details: "If you're not using Next, add explicit crawl targets with --endpoints or extend the crawler for your router.",
      });
      await stop();
      return section;
    }

    const bad: Array<{ route: string; status: number; bodyTail: string }> = [];
    const ok: Array<{ route: string; status: number }> = [];

    for (const r of targets) {
      const url = `${baseUrl}${r === "/" ? "/" : r}`;
      try {
        const res = await fetch(url, { method: "GET" });
        const text = await res.text();
        if (res.status >= 400) bad.push({ route: r, status: res.status, bodyTail: tail(text, 1200) });
        else ok.push({ route: r, status: res.status });
      } catch (e) {
        bad.push({ route: r, status: 0, bodyTail: `Fetch error: ${String(e)}` });
      }
    }

    if (bad.length) {
      section.findings.push({
        id: "crawl.bad",
        title: `Route refresh simulation found ${bad.length} failing routes`,
        severity: "ERROR",
        details: "These routes failed when fetched directly (refresh/deep-link behavior). This is exactly the prod 404 problem, caught locally.",
        fix: "If this is a static SPA deployment: add correct host rewrites to index.html. If SSR: confirm routes exist and build output includes them.",
        evidence: { baseUrl, bad: bad.slice(0, 80), truncated: bad.length > 80, okCount: ok.length, crawled: targets.length },
      });
    } else {
      section.findings.push({
        id: "crawl.ok",
        title: `Route refresh simulation passed (${ok.length}/${targets.length})`,
        severity: "INFO",
        details: "Routes responded OK in local preview. That makes prod routing issues much less likely.",
        evidence: { baseUrl, crawled: targets.length },
      });
    }

    await stop();
    return section;
  } catch (e) {
    section.findings.push({
      id: "localCrawl.error",
      title: "Local preview/crawl threw an error",
      severity: "ERROR",
      details: "The auditor itself hit an error while trying to run preview/crawl.",
      fix: "Check the evidence and rerun with fewer options to isolate the failure.",
      evidence: { error: String(e), stdoutTail: tail(stdout, 2000), stderrTail: tail(stderr, 2000), started },
    });
    await stop();
    return section;
  }
}
