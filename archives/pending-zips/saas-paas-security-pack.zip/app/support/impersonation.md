# Impersonation (support) rules
- Requires customer consent toggle OR ticket reference
- Time-limited session (15-30 minutes)
- Read-only by default
- Every action logged to audit_logs (actor_type=SUPPORT)
- Customer notification: email/in-app banner
