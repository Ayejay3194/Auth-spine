import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerCoreTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "payments.create_invoice",
    title: "Create invoice",
    description: "Creates an invoice for a client.",
    inputSchema: { type: "object", properties: { clientId: { type: "string" }, amount: { type: "number" } }, required: ["clientId","amount"] },
    async run(ctx, input) { return { ok: true, data: await p.payments.createInvoice({ clientId: input.clientId, amount: input.amount }) }; }
  });

  reg.register({
    id: "payments.refund",
    title: "Refund invoice",
    description: "Refunds an invoice.",
    inputSchema: { type: "object", properties: { invoiceId: { type: "string" } }, required: ["invoiceId"] },
    async run(ctx, input) { return { ok: true, data: await p.payments.refund({ invoiceId: input.invoiceId }) }; }
  });

  reg.register({
    id: "marketing.create_promo",
    title: "Create promo",
    description: "Creates a promo code.",
    inputSchema: { type: "object", properties: { code: { type: "string" }, percentOff: { type: "number" } }, required: ["code","percentOff"] },
    async run(ctx, input) { return { ok: true, data: await p.marketing.createPromo({ code: input.code, percentOff: input.percentOff }) }; }
  });

  reg.register({
    id: "analytics.kpi",
    title: "KPIs",
    description: "Shows key metrics.",
    inputSchema: { type: "object", properties: {} },
    async run() { return { ok: true, data: await p.analytics.kpis({}) }; }
  });

  reg.register({
    id: "ops.list_tasks",
    title: "List tasks",
    description: "Lists tasks.",
    inputSchema: { type: "object", properties: {} },
    async run() { return { ok: true, data: await p.ops.listTasks({}) }; }
  });

  reg.register({
    id: "admin.show_audit",
    title: "Audit log",
    description: "Shows audit events.",
    inputSchema: { type: "object", properties: { limit: { type: "number" } }, required: ["limit"] },
    async run(ctx, input) { return { ok: true, data: await p.admin.showAudit({ limit: input.limit }) }; }
  });

  reg.register({
    id: "gdpr.export_request",
    title: "GDPR export",
    description: "Creates a GDPR export.",
    inputSchema: { type: "object", properties: { userId: { type: "string" } }, required: ["userId"] },
    async run(ctx, input) { return { ok: true, data: await p.admin.gdprExport({ userId: input.userId }) }; }
  });
}
