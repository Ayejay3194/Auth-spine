import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerMarketBookingTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "market.booking.hold",
    title: "Create booking hold",
    description: "Reserves a slot temporarily to prevent double-booking.",
    inputSchema: { type: "object", properties: { providerId: { type: "string" }, clientId: { type: "string" }, service: { type: "string" }, dateISO: { type: "string" }, timeHint: { type: "string" } }, required: ["providerId","clientId"] },
    async run(ctx, input) { return { ok: true, data: await p.marketBooking.createHold(input) }; }
  });

  reg.register({
    id: "market.booking.confirm",
    title: "Confirm booking",
    description: "Confirms a booking from a hold after payment succeeds.",
    inputSchema: { type: "object", properties: { holdId: { type: "string" }, paymentIntentId: { type: "string" } }, required: ["holdId","paymentIntentId"] },
    async run(ctx, input) { return { ok: true, data: await p.marketBooking.confirmBooking(input) }; }
  });

  reg.register({
    id: "market.booking.cancel",
    title: "Cancel booking",
    description: "Cancels a marketplace booking.",
    inputSchema: { type: "object", properties: { bookingId: { type: "string" }, reason: { type: "string" } }, required: ["bookingId","reason"] },
    async run(ctx, input) { return { ok: true, data: await p.marketBooking.cancelBooking(input) }; }
  });
}
