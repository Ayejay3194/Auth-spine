"use client";
import React from "react";
import type { AuthState, User } from "./types";

type AuthCtx = AuthState & {
  login: (email?: string) => void;
  logout: () => void;
  setRoles: (roles: string[]) => void;
};

const Ctx = React.createContext<AuthCtx | null>(null);

export function useAuth() {
  const v = React.useContext(Ctx);
  if (!v) throw new Error("useAuth must be used within AuthProvider");
  return v;
}

export function AuthContextProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<User | null>(null);
  const [loading, setLoading] = React.useState(false);

  function login(email = "aj@example.com") {
    setLoading(true);
    setTimeout(() => {
      setUser({ id: "u_1", email, roles: ["user"] });
      setLoading(false);
    }, 250);
  }

  function logout() {
    setUser(null);
  }

  function setRoles(roles: string[]) {
    setUser((u) => (u ? { ...u, roles } : u));
  }

  return (
    <Ctx.Provider value={{ user, loading, login, logout, setRoles }}>
      {children}
    </Ctx.Provider>
  );
}
