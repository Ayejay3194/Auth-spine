import { Worker } from "bullmq";
import Redis from "ioredis";

const url = process.env.REDIS_URL || "redis://localhost:6379";
const connection = new Redis(url);

const log = (m) => console.log("[worker]", m);

new Worker("campaigns", async job => {
  log(`campaign ${job.id} ${JSON.stringify(job.data)}`);
  return { ok: true };
}, { connection });

new Worker("reports", async job => {
  log(`report ${job.id} ${JSON.stringify(job.data)}`);
  return { url: "/reports/demo.csv" };
}, { connection });

new Worker("webhooks", async job => {
  log(`webhook ${job.id} ${JSON.stringify(job.data)}`);
  return { delivered: true };
}, { connection });

log("Workers up.");
