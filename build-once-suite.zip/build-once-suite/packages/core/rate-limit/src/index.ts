export type RateLimitPolicy = { key: string; windowSec: number; max: number; burst?: number };
export type RateLimitResult = { allowed: boolean; remaining: number; resetAt: string };

export interface RateLimiter {
  check(userId: string, policy: RateLimitPolicy): Promise<RateLimitResult>;
}

export class InMemorySlidingWindow implements RateLimiter {
  private hits = new Map<string, number[]>();

  async check(userId: string, policy: RateLimitPolicy): Promise<RateLimitResult> {
    const now = Date.now();
    const windowMs = policy.windowSec * 1000;
    const key = `${userId}:${policy.key}`;
    const arr = this.hits.get(key) ?? [];
    const fresh = arr.filter(ts => now - ts < windowMs);
    const allowed = fresh.length < policy.max;
    if (allowed) fresh.push(now);
    this.hits.set(key, fresh);
    const resetAt = new Date(now + (windowMs - (now - (fresh[0] ?? now)))).toISOString();
    return { allowed, remaining: Math.max(0, policy.max - fresh.length), resetAt };
  }
}
