# Dev Log

Date: YYYY-MM-DD

## What I Planned

- [ ] Task 1
- [ ] Task 2
- [ ] Task 3

## What I Actually Did

- Implemented...
- Fixed...
- Learned...

## Problems / Errors

- Error message:
- Suspected cause:
- Fix (or next step):

## Next Steps

- [ ] ...
- [ ] ...
