"use client";
import { Protected } from "@/components/auth/Protected";
import { Shell } from "@/components/layout/Shell";

export default function ProfilePage() {
  return (
    <Protected>
      <Shell route="profile">
        <div className="glass rounded-xl2 p-6">
          <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Me</div>
          <h2 className="mt-2 text-3xl font-black">Me</h2>
          <p className="mt-2 text-white/70 max-w-2xl">
            Same auth, same router, responsive layout. No duplicated “mobile app” and “desktop app”.
          </p>
        </div>
      </Shell>
    </Protected>
  );
}
