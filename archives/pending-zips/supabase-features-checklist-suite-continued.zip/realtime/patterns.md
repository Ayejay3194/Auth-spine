# Realtime Reliability Patterns (Supabase Realtime)

## Dedupe Keys
- Every broadcast event should include a `message_id` (UUID v7 recommended) and `channel_id`.
- Clients keep an LRU cache of message_ids to drop duplicates.

## Ack Flow
- For critical messages: sender broadcasts, receivers respond with `ack` (message_id, receiver_id).
- Sender retries until quorum or timeout.

## Ordering
- If you need ordering, add `sequence` per channel and enforce monotonic increments on server side.
- Clients buffer out-of-order events briefly (e.g. 250-500ms) then reconcile.

## Backoff
- Exponential backoff with jitter:
  - base: 250ms
  - max: 30s
  - jitter: +/- 25%
- Reset backoff after stable connection window.

## Presence
- Heartbeat interval 10-20s
- Timeout 45-60s
- Avoid sending full presence payloads on every tick; send deltas.

