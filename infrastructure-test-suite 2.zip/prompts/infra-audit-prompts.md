# Infra Audit Prompts (Copy/Paste)

1) Find public exposure:
- 0.0.0.0/0 ingress
- publicly_accessible flags
- public buckets
- wildcard CORS
Return exact files/lines and fixes.

2) Least privilege:
Identify wildcard IAM actions/resources and propose scoped replacements.

3) DR reality check:
What is backed up, retention, restore steps, gaps vs RTO/RPO.

4) Observability coverage:
Logs, metrics, traces, request IDs. What’s missing?

5) CI/CD risk:
Verify tests/scans/gates/rollback hooks exist. Patch workflows.
