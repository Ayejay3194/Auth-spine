import { SkillContext, SkillResult } from "../types.js";

export interface Skill {
  name: string;
  run(ctx: SkillContext): Promise<SkillResult>;
}
