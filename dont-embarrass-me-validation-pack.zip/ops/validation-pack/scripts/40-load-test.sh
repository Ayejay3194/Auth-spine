#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/out"
BASE_URL="$(cat "$OUT/target_base_url.txt")"

echo "== Load test =="
echo "Target: $BASE_URL"

if command -v k6 >/dev/null 2>&1; then
  TARGET_BASE_URL="$BASE_URL" k6 run "$ROOT/configs/load/k6-smoke.js" > "$OUT/k6-smoke.log" || true
  TARGET_BASE_URL="$BASE_URL" k6 run "$ROOT/configs/load/k6-auth-abuse.js" > "$OUT/k6-auth-abuse.log" || true
elif command -v artillery >/dev/null 2>&1; then
  TARGET_BASE_URL="$BASE_URL" artillery run "$ROOT/configs/load/artillery.yml" --output "$OUT/artillery.json" || true
else
  echo "Neither k6 nor artillery installed. Skipping."
  echo "{}" > "$OUT/load-test.json"
fi
