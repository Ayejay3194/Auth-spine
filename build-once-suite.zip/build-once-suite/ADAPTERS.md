# Adapters: swap vendors without rewriting modules

Everything under `packages/modules/*` should depend only on:
- `packages/core/*` contracts
- module contracts
- adapter interfaces

To switch vendors:
- Email: replace `@suite/adapters-email-console` with SES/SendGrid adapter
- Webhooks: replace in-memory store + delivery engine with persistent store + retry queue
- Notifications: replace realtime adapter with SSE/WebSocket implementation
- Billing: plug Stripe adapter (not included in this starter to avoid vendor lock)
