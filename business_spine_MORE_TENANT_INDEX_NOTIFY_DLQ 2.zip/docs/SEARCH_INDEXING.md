# Search Indexing Pipeline
- Jobs are queued on `reportQueue`:
  - `index_provider` (upsert one doc)
  - `reindex_all_providers` (full rebuild, stub)

Endpoint:
- POST /api/search/reindex/providers (owner/admin)

Wire this by calling `enqueueProviderIndex()` whenever a provider/service changes.
