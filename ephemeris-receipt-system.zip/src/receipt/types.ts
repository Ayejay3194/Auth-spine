import { z } from "zod";

export const ReceiptSchemaV1 = z.object({
  schema: z.literal("CanonicalEphemerisReceipt@v1"),
  createdAt: z.string(), // ISO8601 UTC
  engine: z.object({
    name: z.string(),
    version: z.string(),
    gitSha: z.string().optional(),
    buildId: z.string().optional(),
    runtime: z.string().optional(),
  }),
  input: z.object({
    inputHash: z.string(), // sha256 of canonicalized input JSON
    redacted: z.boolean().default(true),
  }),
  output: z.object({
    outputHash: z.string(), // sha256 of canonicalized output JSON
    contract: z.string(),   // e.g., CanonicalEphemerisOutput@v1
  }),
  provenance: z.object({
    kernel: z.object({
      id: z.string(),            // e.g., DE440
      bytesSha256: z.string(),   // sha256 of kernel bytes
      segment: z.string().optional(),
      degree: z.number().int().positive().optional(),
      subintervalDays: z.number().positive().optional(),
      coverage: z.object({
        start: z.string(),
        end: z.string(),
      }).optional(),
    }),
    time: z.object({
      tzdbVersion: z.string().optional(),
      leapSecondsSha256: z.string().optional(),
      deltaTModel: z.string().optional(),
      inputScale: z.enum(["UTC","TAI","TT","TDB","UT1"]).optional(),
      internalScale: z.enum(["TT","TDB"]).optional(),
    }).optional(),
    iau: z.object({
      precession: z.string().optional(), // e.g., IAU2006
      nutation: z.string().optional(),   // e.g., IAU2000B
      eopSnapshotId: z.string().optional(),
    }).optional(),
  }),
  validation: z.object({
    goldenVectorId: z.string().optional(),
    maxAbsError: z.number().optional(),
    comparedAgainst: z.string().optional(), // e.g., JPL Horizons snapshot hash
  }).optional(),
});

export type CanonicalReceiptV1 = z.infer<typeof ReceiptSchemaV1>;
