Security Documentation

- Architecture diagrams
- Threat models
- Runbooks
- Audit evidence
