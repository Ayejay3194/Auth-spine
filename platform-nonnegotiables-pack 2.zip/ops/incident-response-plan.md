Incident Response Plan (Minimum)

1) Triage
- Identify what happened (who/what/when)
- Contain: disable accounts, rotate keys, block IPs

2) Preserve evidence
- Snapshot logs
- Snapshot databases (if safe)
- Preserve request IDs

3) Eradicate + Recover
- Patch root cause
- Restore from backups if needed
- Validate auth + permissions

4) Notify
- Internal stakeholders
- Users/regulators if required

5) Postmortem
- Timeline
- Root cause
- Corrective actions
