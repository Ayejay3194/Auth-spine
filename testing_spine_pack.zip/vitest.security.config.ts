import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    include: ["tests/security/**/*.test.ts"],
    testTimeout: 60_000,
    reporters: ["default"],
  },
});
