import type { ID, Money, Result } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type Location = { id: ID; businessId: ID; name: string; address?: string };
export type TeamMember = { id: ID; businessId: ID; locationId?: ID; name: string; role: "owner"|"manager"|"stylist"|"assistant"; commissionRate?: number };

export type Commission = { id: ID; businessId: ID; memberId: ID; bookingId: ID; amount: Money; createdAtISO: string };

export class TeamService {
  private locations: Location[] = [];
  private members: TeamMember[] = [];
  private commissions: Commission[] = [];

  createLocation(input: Omit<Location,"id">): Location { const l = { ...input, id: cuid("loc") }; this.locations.push(l); return l; }
  listLocations(businessId: ID) { return this.locations.filter(l => l.businessId===businessId); }

  addMember(input: Omit<TeamMember,"id">): TeamMember { const m = { ...input, id: cuid("tm") }; this.members.push(m); return m; }
  listMembers(businessId: ID, locationId?: ID) { return this.members.filter(m => m.businessId===businessId && (locationId ? m.locationId===locationId : true)); }

  recordCommission(input: { businessId: ID; memberId: ID; bookingId: ID; gross: Money }): Result<Commission> {
    const mem = this.members.find(m => m.id === input.memberId && m.businessId === input.businessId);
    if (!mem) return { ok: false, error: { code: "NOT_FOUND", message: "Member not found" } };
    const rate = mem.commissionRate ?? 0;
    const amount = { amount: Math.round(input.gross.amount * rate * 100)/100, currency: input.gross.currency };
    const c: Commission = { id: cuid("com"), businessId: input.businessId, memberId: input.memberId, bookingId: input.bookingId, amount, createdAtISO: new Date().toISOString() };
    this.commissions.push(c);
    return { ok: true, data: c };
  }

  listCommissions(businessId: ID, limit=200) { return this.commissions.filter(c => c.businessId===businessId).slice(-limit).reverse(); }
}
