import { TenantContext } from "../../platform/tenant/types";
import { MemoryRateLimiter, RateLimiter } from "./limiter";
import { audit } from "../observability/audit";

const limiter: RateLimiter = new MemoryRateLimiter();

export async function enforceRateLimit(ctx: TenantContext, scope: string, max: number, windowMs: number) {
  const key = `t:${ctx.tenantId}:u:${ctx.userId}:${scope}`;
  const res = await limiter.limit(key, max, windowMs);
  if (!res.allowed) {
    await audit({
      event: "rate_limit_block",
      tenantId: ctx.tenantId,
      actorId: ctx.userId,
      requestId: ctx.requestId,
      meta: { scope, max, windowMs, resetAt: res.resetAt }
    });
    const err = new Error("RATE_LIMITED");
    (err as any).status = 429;
    throw err;
  }
  return res;
}
