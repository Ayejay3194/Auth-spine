ESCALATION RULES
================

Auto-escalate when:
- dispute exceeds $X
- no response within SLA
- repeat disputes by same party
- chargeback risk detected

Escalation actions:
- freeze payouts
- senior agent assignment
- admin visibility
