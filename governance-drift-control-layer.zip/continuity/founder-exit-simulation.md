FOUNDER EXIT SIMULATION
=======================

Quarterly test:
- remove founder approvals
- simulate incident
- resolve using documented playbooks
- assess gaps

Goal:
System runs without personality dependency.
