# RTO/RPO Verification Checklist

Component: ______________________

- RTO target: _______
- RPO target: _______

Last drill:
- Date:
- Backup/Snapshot ID:
- Restore completed in:
- Data age at restore:
- Smoke tests pass? (y/n)
- Issues found:
- Follow-ups:
