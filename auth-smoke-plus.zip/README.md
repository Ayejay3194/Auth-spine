# Auth & Tenant Isolation Smoke Tests

Includes:
- Auth token validation
- JWT shape + claim assertions
- Tenant isolation (IDOR protection)
- Health check
- Missing auth negative tests

Run with:
npm test
