import { getConversationState, saveConversationState } from "../src/assistant-addons/conversationStore.ts";
import { detectCorrection, applyRepair, applyCarryover } from "../src/assistant-addons/carryover.ts";
import { gate } from "../src/assistant-addons/confidenceGate.ts";
import { clarifyQuestion, disambiguateQuestion } from "../src/assistant-addons/clarify.ts";
import { toolOutcomeReply } from "../src/assistant-addons/toolOutcomes.ts";

/**
 * This is a deterministic harness. Replace `stubNlu` + `stubTool` with your real pipeline.
 */

const scripts = makeScripts(200);
let completed = 0;
let turnsTotal = 0;

for (const script of scripts) {
  const sessionId = script.sessionId;
  const state = getConversationState(sessionId);

  let turn = 0;
  let done = false;
  let lastAssistant = "";

  for (const user of script.turns) {
    turn++;
    const isCorrection = detectCorrection(user);
    let nlu = stubNlu(user);

    nlu = applyRepair(state, nlu, isCorrection);
    nlu = applyCarryover(state, nlu);

    const decision = gate(nlu, state);

    if (decision.type === "clarify") {
      lastAssistant = clarifyQuestion(nlu.intent, decision.missing);
      continue;
    }
    if (decision.type === "disambiguate") {
      lastAssistant = disambiguateQuestion(decision.options);
      continue;
    }

    // act
    const toolRes = stubTool(nlu.intent, nlu.entities);
    lastAssistant = toolOutcomeReply(nlu.intent, toolRes);

    // simplistic completion rule: any ok outcome ends
    if (toolRes.outcome === "ok") { done = true; break; }
  }

  saveConversationState(state);

  turnsTotal += turn;
  if (done) completed++;
}

const completionRate = (completed / scripts.length) * 100;
const avgTurns = turnsTotal / scripts.length;

console.log(JSON.stringify({
  scripts: scripts.length,
  completed,
  completionRate: Number(completionRate.toFixed(2)),
  avgTurns: Number(avgTurns.toFixed(2)),
}, null, 2));

function stubNlu(text) {
  const t = text.toLowerCase();
  const entities = {};
  if (t.includes("bk")) entities.booking_ref = text.match(/BK\d{4}/)?.[0];

  // crude extraction for demo
  if (t.includes("book") || t.includes("schedule")) return { intent: "book_service", entities, confidence: 0.72 };
  if (t.includes("available") || t.includes("open")) return { intent: "check_availability", entities, confidence: 0.7 };
  if (t.includes("reschedule") || t.includes("move")) return { intent: "reschedule_booking", entities, confidence: 0.74 };
  if (t.includes("cancel")) return { intent: "cancel_booking", entities, confidence: 0.78 };
  if (t.includes("price") || t.includes("how much")) return { intent: "pricing_quote", entities, confidence: 0.76 };
  return { intent: "unknown", entities, confidence: 0.4 };
}

function stubTool(intent, entities) {
  // tool outcomes that mimic reality a bit
  if (intent === "cancel_booking" && !entities.booking_ref) {
    return { outcome: "needs_more_info", missing: ["booking_ref"] };
  }
  if (intent === "book_service") {
    const missing = ["service","date","time"].filter(k => !entities[k]);
    if (missing.length) return { outcome: "needs_more_info", missing };
    return { outcome: "ok", data: { service: entities.service, date: entities.date, time: entities.time } };
  }
  if (intent === "check_availability") {
    const missing = ["service","date"].filter(k => !entities[k]);
    if (missing.length) return { outcome: "needs_more_info", missing };
    return { outcome: "ok", data: ["10:30am","1pm","4:15pm"] };
  }
  if (intent === "reschedule_booking") {
    const missing = ["date","time"].filter(k => !entities[k]);
    if (missing.length) return { outcome: "needs_more_info", missing };
    return { outcome: "ok", data: { date: entities.date, time: entities.time } };
  }
  return { outcome: "ok", data: "ok" };
}

function makeScripts(n) {
  const sessions = [];
  for (let i=0;i<n;i++) {
    sessions.push({
      sessionId: `S${String(i).padStart(4,"0")}`,
      turns: sampleTurns(),
    });
  }
  return sessions;
}

function sampleTurns() {
  const canned = [
    ["book a haircut", "Thursday", "3pm"],
    ["is anything open for massage", "tomorrow"],
    ["reschedule my appointment", "actually Friday", "after 5"],
    ["cancel my booking", "BK1234"],
    ["how much is balayage"],
  ];
  return canned[Math.floor(Math.random() * canned.length)];
}
