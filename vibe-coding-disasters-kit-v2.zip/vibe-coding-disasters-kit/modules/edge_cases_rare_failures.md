# EDGE CASES & RARE FAILURES

## Boundary Conditions

- [ ] Empty arrays/lists not handled
- [ ] Single item lists breaking
- [ ] Maximum length strings breaking
- [ ] Empty strings causing errors
- [ ] Null vs undefined confusion
- [ ] Zero values treated as null
- [ ] Negative numbers not considered
- [ ] Very large numbers breaking
- [ ] Very small decimals (precision loss)
- [ ] Special characters breaking
- [ ] Unicode characters breaking
- [ ] Emoji breaking system
- [ ] Right-to-left text breaking layout
- [ ] Long words breaking layout
- [ ] No content state not handled

## Date/Time Disasters

- [ ] Timezone bugs everywhere
- [ ] Hardcoded timezone assumptions
- [ ] Daylight Saving Time bugs
- [ ] Leap year not handled
- [ ] Leap second issues
- [ ] Date parsing errors
- [ ] ISO 8601 format issues
- [ ] Date format ambiguity (MM/DD vs DD/MM)
- [ ] Wrong date calculations
- [ ] Time travel bugs (comparing across zones)
- [ ] Unix timestamp overflow (Y2038 problem)
- [ ] Storing dates as strings
- [ ] Not using UTC internally
- [ ] Business day calculations wrong
- [ ] Holiday detection wrong
- [ ] Month boundaries bugs
- [ ] Year boundaries bugs
- [ ] Century bugs

## Concurrency Issues

- [ ] Race conditions
- [ ] Deadlocks
- [ ] Livelocks
- [ ] Thread starvation
- [ ] Resource contention
- [ ] Lost updates
- [ ] Dirty reads
- [ ] Non-repeatable reads
- [ ] Phantom reads
- [ ] Write-write conflicts
- [ ] Read-write conflicts
- [ ] Incorrect isolation level
- [ ] No pessimistic locking
- [ ] No optimistic locking
- [ ] Lock timeouts
- [ ] Database locks not released
- [ ] Table-level locks causing issues
- [ ] Concurrent modification exceptions
- [ ] Atomic operations not atomic
- [ ] Critical sections not protected

## Network & External Dependencies

- [ ] Assuming network is reliable
- [ ] No timeout handling
- [ ] Services calling each other in circle
- [ ] Cascading failures
- [ ] Service mesh issues
- [ ] DNS failures not handled
- [ ] SSL certificate expiration
- [ ] Certificate validation disabled
- [ ] Man-in-the-middle vulnerability
- [ ] Third-party API down breaks everything
- [ ] External service slow makes app slow
- [ ] No circuit breaker
- [ ] Retry storms
- [ ] Thundering herd on startup
- [ ] Services cannot start without dependencies
- [ ] Startup order dependencies

---
