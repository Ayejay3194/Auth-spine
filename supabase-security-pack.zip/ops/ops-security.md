
# Ops Security Checklist

- MFA enforced for ADMIN / OWNER
- Ops UI hosted on ops.domain.com
- RLS still applies to ops queries
- Sensitive reads logged
- No service_role key in frontend
- Ops DB access via Supabase SQL editor only
