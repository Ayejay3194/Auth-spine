import YAML from "yaml";
import { findFiles, readText, rel } from "../utils/fs.js";
import type { Check, Finding } from "../types.js";

function walkContainers(manifest: any): any[] {
  const spec = manifest?.spec?.template?.spec ?? manifest?.spec;
  const containers = spec?.containers ?? [];
  return Array.isArray(containers) ? containers : [];
}

export const K8sBaselineCheck: Check = {
  id: "k8s.security_baseline",
  title: "Kubernetes baseline security context",
  category: "Kubernetes",
  async run(ctx) {
    const rule = ctx.profile.rules?.k8s ?? {};
    const requireRO = rule.requireReadOnlyRootFilesystem ?? true;
    const requireNonRoot = rule.requireRunAsNonRoot ?? true;
    const sev = rule.severity ?? "P1";

    const files = findFiles(ctx.root, ["**/*.yml", "**/*.yaml"])
      .filter(f => !f.includes("node_modules/") && !f.includes("dist/"));

    const findings: Finding[] = [];
    for (const f of files) {
      const txt = readText(f);
      if (!txt) continue;
      // quick filter
      if (!txt.includes("kind:")) continue;

      let docs: any[] = [];
      try { docs = YAML.parseAllDocuments(txt).map(d => d.toJSON()).filter(Boolean); } catch { continue; }

      for (const doc of docs) {
        const kind = doc?.kind;
        if (!kind) continue;
        const containers = walkContainers(doc);
        for (const c of containers) {
          const sc = c.securityContext ?? {};
          if (requireNonRoot && sc.runAsNonRoot !== true) {
            findings.push({
              id: this.id,
              title: this.title,
              category: this.category,
              severity: sev,
              evidence: [{
                message: `${kind}/${doc?.metadata?.name ?? "unknown"} container ${c.name ?? ""} missing runAsNonRoot:true`,
                file: rel(ctx.root, f),
                hint: "Set securityContext.runAsNonRoot: true and specify a non-root UID."
              }]
            });
          }
          if (requireRO && sc.readOnlyRootFilesystem !== true) {
            findings.push({
              id: this.id,
              title: this.title,
              category: this.category,
              severity: sev,
              evidence: [{
                message: `${kind}/${doc?.metadata?.name ?? "unknown"} container ${c.name ?? ""} missing readOnlyRootFilesystem:true`,
                file: rel(ctx.root, f),
                hint: "Set securityContext.readOnlyRootFilesystem: true and mount writable paths explicitly."
              }]
            });
          }
        }
      }
    }
    return findings;
  }
};
