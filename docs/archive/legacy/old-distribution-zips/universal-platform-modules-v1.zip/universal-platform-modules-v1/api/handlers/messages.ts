import type { EventName } from "@/events/catalog";

export interface SendMessageInput {
  conversationId: string;
  senderUserId: string;
  body: string;
}

export async function sendMessage(input: SendMessageInput) {
  // TODO:
  // 1) validate membership
  // 2) insert message
  // 3) publish SSE/WS event
  const emitted: EventName[] = ["message.created"];
  return { messageId: "TODO", emitted };
}
