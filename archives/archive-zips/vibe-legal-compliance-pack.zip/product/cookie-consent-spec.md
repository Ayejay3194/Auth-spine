# Cookie Consent Banner Spec

## Requirements
- show banner on first visit (where required)
- categories: essential (always on), preferences, analytics, marketing
- granular toggles + “Accept all” + “Reject non-essential”
- store proof: user_id (if logged in), anon_id, timestamp, region, choices, policy version

## Storage schema (example)
table: consent_events
- id (uuid)
- subject_id (uuid or text)
- subject_type ('user'|'anon')
- region (text)
- policy_version (text)
- preferences (jsonb)
- created_at (timestamptz)

## UI
- small banner, link to cookie policy, manage preferences modal
