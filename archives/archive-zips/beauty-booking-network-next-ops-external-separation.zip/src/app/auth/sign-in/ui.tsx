"use client";
import { signIn } from "next-auth/react";
import { useState } from "react";

export function SignInPanel(){
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  async function sendMagicLink(e: React.FormEvent){
    e.preventDefault();
    setSent(false);
    await signIn("email", { email, callbackUrl: "/me/following" });
    setSent(true);
  }

  return (
    <div className="space-y-4">
      <button
        className="w-full rounded-2xl px-4 py-3 text-sm font-semibold"
        style={{background:"var(--accent)", color:"var(--accentText)"}}
        onClick={() => signIn("github", { callbackUrl: "/me/following" })}
      >
        Continue with GitHub
      </button>

      <div className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
        <div className="text-xs tracking-[.18em] uppercase" style={{color:"var(--dim)"}}>Magic link</div>
        <form className="mt-3 space-y-3" onSubmit={sendMagicLink}>
          <input
            value={email}
            onChange={(e)=>setEmail(e.target.value)}
            placeholder="you@domain.com"
            type="email"
            required
            className="w-full rounded-xl border px-3 py-3 text-sm"
            style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}}
          />
          <button
            type="submit"
            className="w-full rounded-2xl border px-4 py-3 text-sm font-semibold"
            style={{borderColor:"var(--border)", background:"var(--panel)"}}
          >
            Email me a link
          </button>
        </form>
        {sent ? <div className="mt-3 text-sm" style={{color:"var(--muted)"}}>Check your inbox.</div> : null}
      </div>
    </div>
  );
}
