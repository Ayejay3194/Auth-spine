
/**
 * IAU 2006 Precession (P03)
 * IAU 2000B Nutation
 */

export function precessionIAU2006(ttCenturies: number): number[][] {
  throw new Error("IAU 2006 model not implemented");
}

export function nutationIAU2000B(ttCenturies: number): number[][] {
  throw new Error("IAU 2000B model not implemented");
}
