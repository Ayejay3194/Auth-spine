import { ingestResiduals } from "../jobs/ingest.js";
import { computeFeatures } from "../jobs/compute.js";
import { snapshotDay } from "../jobs/snapshot.js";

function arg(name: string, fallback?: string) {
  const idx = process.argv.indexOf(`--${name}`);
  return idx >= 0 ? process.argv[idx + 1] : fallback;
}

async function main() {
  const cmd = process.argv[2];

  const root = arg("root", "./warehouse")!;
  const dayISO = arg("day", new Date().toISOString().slice(0, 10))!;
  const dataset = arg("dataset", "de440_residuals")!;
  const ver = arg("ver", "v1")!;
  const part = Number(arg("part", "1"));

  if (cmd === "ingest") {
    const input = arg("input");
    if (!input) throw new Error("Missing --input <file.jsonl>");

    const out = await ingestResiduals({
      cfg: { root, dataset, datasetVersion: ver },
      dayISO,
      inputJsonl: input,
      part,
    });

    console.log(out);
    return;
  }

  if (cmd === "compute") {
    const outDataset = arg("outDataset", `${dataset}_features`)!;
    const outVer = arg("outVer", "v1")!;

    const out = await computeFeatures({
      input: { cfg: { root, dataset, datasetVersion: ver }, dayISO, part },
      output: { cfg: { root, dataset: outDataset, datasetVersion: outVer }, dayISO, part },
    });

    console.log(out);
    return;
  }

  if (cmd === "snapshot") {
    const target = arg("target", "./snapshots")!;
    const out = await snapshotDay({
      cfg: { root, dataset, datasetVersion: ver },
      dayISO,
      targetDir: target,
    });
    console.log(out);
    return;
  }

  console.log(`Unknown cmd: ${cmd}
Commands:
  ingest   --input file.jsonl --dataset X --ver v1 --day YYYY-MM-DD
  compute  --dataset X --ver v1 --outDataset Y --outVer v1 --day YYYY-MM-DD
  snapshot --dataset X --ver v1 --day YYYY-MM-DD --target ./snapshots
`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
