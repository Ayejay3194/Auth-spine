import type { AuditStore } from "@suite/core-audit";
import type { WebhookDeliveryEngine, WebhookEndpoint, WebhookStore, WebhookDelivery } from "@suite/modules-webhooks";
import { HmacSha256Signer } from "@suite/adapters-webhooks-hmac";

export class InMemoryWebhookStore implements WebhookStore {
  private endpoints: WebhookEndpoint[] = [];
  private deliveries: WebhookDelivery[] = [];

  async addEndpoint(ep: Omit<WebhookEndpoint,"id">): Promise<WebhookEndpoint> {
    const created: WebhookEndpoint = { ...ep, id: `wh_${Math.random().toString(16).slice(2)}` };
    this.endpoints.push(created);
    return created;
  }
  async listEndpoints(ownerId: string): Promise<WebhookEndpoint[]> {
    return this.endpoints.filter(e => e.ownerId === ownerId);
  }
  async logDelivery(d: Omit<WebhookDelivery,"id"|"createdAt"|"updatedAt">): Promise<WebhookDelivery> {
    const now = new Date().toISOString();
    const row: WebhookDelivery = { ...d, id:`wd_${Math.random().toString(16).slice(2)}`, createdAt: now, updatedAt: now };
    this.deliveries.push(row);
    return row;
  }
  async listDeliveries(endpointId: string, limit: number = 50): Promise<WebhookDelivery[]> {
    return this.deliveries.filter(d => d.endpointId === endpointId).slice(-limit).reverse();
  }
}

export class FetchWebhookDeliveryEngine implements WebhookDeliveryEngine {
  private signer = new HmacSha256Signer();
  constructor(private store: WebhookStore, private audit: AuditStore) {}

  async deliver(endpoint: WebhookEndpoint, event: string, payload: unknown): Promise<WebhookDelivery> {
    const body = JSON.stringify({ event, payload });
    const ts = new Date().toISOString();
    const sig = this.signer.sign(endpoint.secret, body, ts);

    let status: WebhookDelivery["status"] = "sent";
    let lastError: string | undefined;

    try {
      const res = await fetch(endpoint.url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Webhook-Timestamp": ts,
          "X-Webhook-Signature": sig,
        },
        body,
      });
      if (!res.ok) {
        status = "failed";
        lastError = `HTTP ${res.status}`;
      }
    } catch (e) {
      status = "failed";
      lastError = String(e);
    }

    const logged = await this.store.logDelivery({
      endpointId: endpoint.id,
      event,
      payload,
      attempt: 1,
      status,
      lastError,
    });

    await this.audit.append({
      actor: { actorType: "system" },
      action: status === "sent" ? "webhook.delivery.sent" : "webhook.delivery.failed",
      targetType: "webhookEndpoint",
      targetId: endpoint.id,
      metadata: { event, status, lastError },
    });

    return logged;
  }
}
