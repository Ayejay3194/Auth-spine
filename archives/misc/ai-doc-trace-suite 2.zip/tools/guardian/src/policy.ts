import path from "node:path";
import { readFile } from "node:fs/promises";
import type { Policy } from "./types.js";
export async function loadPolicy(root: string): Promise<Policy> {
  const fp = path.join(root, ".guardian", "policy.json");
  const raw = await readFile(fp, "utf-8");
  return JSON.parse(raw) as Policy;
}
