# Security & Reliability Test Patterns

## IDOR (Insecure Direct Object Reference)
- Create User A and User B
- Create resource for User A
- Attempt to fetch/update/delete that resource using User B token
- Expect 403/404 (never 200)

## Auth bypass
- Hit protected endpoints without auth
- Expect 401 always

## Session invalidation
- Login -> get session
- Logout -> session invalid
- Password change -> all sessions invalid (except current if you allow)

## Payments webhook idempotency
- Send same webhook event twice
- Expect second processing is no-op and does not double charge/fulfill

## Multi-tenant isolation
- Tenant A creates listing
- Tenant B attempts access by ID
- Expect denied

## Cron duplication
- Trigger cron twice concurrently
- Expect one acquires lock, other exits cleanly
