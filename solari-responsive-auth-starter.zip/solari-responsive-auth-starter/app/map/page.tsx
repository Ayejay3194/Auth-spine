"use client";
import { Protected } from "@/components/auth/Protected";
import { Shell } from "@/components/layout/Shell";
import { MapCanvas } from "@/components/map/MapCanvas";

export default function MapPage() {
  return (
    <Protected>
      <Shell route="map">
        <div className="glass rounded-xl2 p-5">
          <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Map</div>
          <h2 className="mt-2 text-3xl font-black">Full map area</h2>
          <p className="mt-2 text-white/70 max-w-2xl">
            On this route, the right rail swaps to a feed/quick-check (not another map).
          </p>
          <div className="mt-4">
            <MapCanvas />
          </div>
        </div>
      </Shell>
    </Protected>
  );
}
