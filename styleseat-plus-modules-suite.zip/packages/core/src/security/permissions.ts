import type { ID, Result } from "../shared/types.js";

export type Role = "owner" | "admin" | "manager" | "staff" | "stylist" | "assistant" | "client" | "support";
export type Scope =
  | "booking.read" | "booking.write" | "payments.read" | "payments.write"
  | "marketing.read" | "marketing.write" | "analytics.read"
  | "team.read" | "team.write"
  | "webhooks.read" | "webhooks.write"
  | "subscriptions.read" | "subscriptions.write"
  | "admin.moderation" | "admin.audit";

export type Principal = { userId: ID; businessId: ID; role: Role; scopes?: Scope[] };

const roleScopes: Record<Role, Scope[]> = {
  owner: ["booking.read","booking.write","payments.read","payments.write","marketing.read","marketing.write","analytics.read","team.read","team.write","webhooks.read","webhooks.write","subscriptions.read","subscriptions.write","admin.moderation","admin.audit"],
  admin: ["booking.read","booking.write","payments.read","payments.write","marketing.read","marketing.write","analytics.read","team.read","team.write","webhooks.read","webhooks.write","subscriptions.read","subscriptions.write","admin.moderation","admin.audit"],
  manager: ["booking.read","booking.write","payments.read","marketing.read","marketing.write","analytics.read","team.read","team.write"],
  staff: ["booking.read","booking.write","marketing.read"],
  stylist: ["booking.read","booking.write","payments.read","marketing.read","analytics.read","team.read"],
  assistant: ["booking.read","booking.write"],
  client: ["booking.read","booking.write"],
  support: ["booking.read","payments.read","admin.audit","admin.moderation"]
};

export function hasScope(p: Principal, scope: Scope): boolean {
  const fromRole = roleScopes[p.role] ?? [];
  const extra = p.scopes ?? [];
  return fromRole.includes(scope) || extra.includes(scope);
}

export function requireScope(p: Principal, scope: Scope): Result<true> {
  return hasScope(p, scope) ? { ok: true, data: true } : { ok: false, error: { code: "FORBIDDEN", message: `Missing scope: ${scope}` } };
}
