import type { EntitySpan, NLUModel } from "../types";

const emailRe = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i;
const numberRe = /\b\d+(?:\.\d+)?\b/g;

export function regexEntities(_model: NLUModel, text: string): EntitySpan[] {
  const out: EntitySpan[] = [];
  const m = text.match(emailRe);
  if (m && m.index != null) {
    out.push({ entity: "email", value: m[0], start: m.index, end: m.index + m[0].length, source: "regex" });
  }
  for (const m2 of text.matchAll(numberRe)) {
    const v = m2[0];
    const start = m2.index ?? 0;
    out.push({ entity: "number", value: v, start, end: start + v.length, normalized: Number(v), source: "regex" });
  }
  return out;
}
