Support ticketing routes under /api/support/tickets/*
