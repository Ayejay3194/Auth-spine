import time

class SessionStore:
    def __init__(self, ttl_seconds: int = 3600):
        self.ttl = ttl_seconds
        self._mem: dict[str, tuple[float, dict]] = {}

    def get(self, session_id: str):
        now = time.time()
        item = self._mem.get(session_id)
        if not item:
            return None
        ts, state = item
        if now - ts > self.ttl:
            self._mem.pop(session_id, None)
            return None
        return state

    def set(self, session_id: str, state: dict):
        self._mem[session_id] = (time.time(), state)
