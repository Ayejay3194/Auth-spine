import type { GeoReceipt } from "./types.js";

export function makeTraceId(prefix = "geo"): string {
  // good enough for receipts; swap with ULID/UUID if you want
  const r = Math.random().toString(16).slice(2);
  const t = Date.now().toString(16);
  return `${prefix}_${t}_${r}`;
}

export function baseReceipt(op: GeoReceipt["op"], key: string, providerName: string, policy: GeoReceipt["policy"]): GeoReceipt {
  return {
    traceId: makeTraceId(),
    at: new Date().toISOString(),
    op,
    cache: { hitL1: false, hitL2: false, wroteL1: false, wroteL2: false },
    key,
    provider: { name: providerName, ms: 0 },
    policy,
    outcome: "error",
  };
}
