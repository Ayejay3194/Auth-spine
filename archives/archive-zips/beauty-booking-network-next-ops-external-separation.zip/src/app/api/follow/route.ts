import { prisma } from "@/lib/prisma";
import { logEvent } from "@/lib/events";
import { auth } from "@/lib/auth";
import { z } from "zod";

const Body = z.object({ stylistId: z.string(), action: z.enum(["follow","unfollow"]) });

export async function POST(req: Request){
  const session = await auth();
  if(!session?.user?.email) return new Response("Unauthorized", { status: 401 });

  const { stylistId, action } = Body.parse(await req.json());
  const user = await prisma.user.findUnique({ where:{ email: session.user.email } });
  if(!user) return new Response("User not found", { status: 404 });

  if(action === "follow"){
    await logEvent({ actorUserId: user.id, entityType: "STYLIST", entityId: stylistId, name: "FOLLOWED", props: {} });
    await prisma.follow.upsert({
      where:{ followerUserId_stylistId: { followerUserId: user.id, stylistId } },
      update:{},
      create:{ followerUserId: user.id, stylistId },
    });
  } else {
    await logEvent({ actorUserId: user.id, entityType: "STYLIST", entityId: stylistId, name: "UNFOLLOWED", props: {} });
    await prisma.follow.deleteMany({ where:{ followerUserId: user.id, stylistId } });
  }

  const count = await prisma.follow.count({ where:{ stylistId } });
  return Response.json({ ok:true, count });
}
