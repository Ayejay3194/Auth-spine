export function normalize(s: string): string {
  return s.toLowerCase().replace(/\s+/g, " ").trim();
}

export function clamp01(n: number): number {
  return Math.max(0, Math.min(1, n));
}

export function pickOne<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function unique<T>(arr: T[]): T[] {
  return Array.from(new Set(arr));
}
