// automation tools.ts
