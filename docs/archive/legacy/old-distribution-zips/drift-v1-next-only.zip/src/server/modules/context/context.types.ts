export type BookingSessionStage = "NEW" | "AWAITING_SLOT_CHOICE" | "AWAITING_DEPOSIT";

export type ProposedSlot = { label: string; startAt: string; endAt: string };

export type BookingSession = {
  phoneE164: string;
  stage: BookingSessionStage;
  proposedSlots?: ProposedSlot[];
  pendingSlot?: ProposedSlot;
  serviceId?: string;
  cardOnFile?: boolean;
  updatedAt: string;
};
