SOFT LANGUAGE ENGINE
====================

Context-based tone:
- first issue: empathetic
- repeat issue: firm, calm
- VIP: reassuring
- staff: direct, professional

No policy quotes in first response.
