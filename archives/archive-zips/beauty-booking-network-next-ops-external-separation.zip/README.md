# Beauty Booking Network (Next.js + Prisma)

This is the start of the architecture you described:
- **Stylist = portable identity** (`/@slug` is their "website")
- **Salon = org layer** (`/salons/[slug]` directory)
- **Booking is behind the portfolio** (drawer opens preselected)
- **Approval rules** live on SalonMembership.settings
- **Following** exists (`/me/following` demo)

## Run
```bash
npm install
cp .env.example .env
# set DATABASE_URL
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

## Demo URLs
- Home: /
- Discover: /discover
- Salons: /salons
- Salon: /salons/luxe-salon
- Stylist sites: /@jade, /@noor
- Following: /me/following

## Notes
- Availability is UTC-based for demo simplicity.
- Auth is not wired yet. Demo "client" is client@demo.com.


## Auth (Magic link + OAuth)
- OAuth uses `GITHUB_ID` and `GITHUB_SECRET`.
- Magic link uses `EMAIL_SERVER` and `EMAIL_FROM`.
- Sign in at `/auth/sign-in`.


## Studio + Salon Admin
- Stylist studio: `/studio` (sign in as jade@demo.com or noor@demo.com)
- Salon admin: `/salon-admin/luxe-salon` (sign in as owner@demo.com)
- Seed includes a pending booking for Noor to approve.


## Pattern Intelligence
- Event log: POST `/api/events`
- Compute features/scores: `npm run patterns:compute`
- Console: `/admin/patterns` (owner@demo.com)


## Optional scikit-learn sidecar
- Service lives in `ml_service/` (FastAPI + scikit-learn)
- Start it: `cd ml_service && pip install -r requirements.txt && uvicorn app:app --reload --port 8001`
- Train: `curl -X POST http://localhost:8001/train/no_show`
- Next API proxy: POST `/api/patterns/no-show`
- Compose: `docker compose -f docker-compose.ml.yml up --build`


## Host-based separation (internal vs external)
Set these env vars:
- `APP_HOST` public host
- `OPS_HOST` internal ops host
- `STUDIO_HOST` optional studio host

Middleware blocks ops routes (`/ops`, `/admin`, `/salon-admin`, `/api/ops/*`) unless the request host matches `OPS_HOST`.

### Local dev
Add to `/etc/hosts`:
- `127.0.0.1 app.localhost`
- `127.0.0.1 ops.localhost`

Then visit:
- Public: `http://app.localhost:3000`
- Ops: `http://ops.localhost:3000/ops`
