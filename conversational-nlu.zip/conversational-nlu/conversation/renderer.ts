// Turns a decision into a user-facing response.
// Replace with templates, localization, channel-specific formatting, etc.
export function render(decision, state) {
  if (!decision || decision.action === "fallback") {
    return "Sorry, I didn’t catch that. Can you rephrase?";
  }
  return `OK: ${decision.action}`;
}
