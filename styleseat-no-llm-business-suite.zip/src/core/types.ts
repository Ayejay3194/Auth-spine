export type UserId = string;
export type Role = "owner" | "staff" | "assistant" | "accountant" | "admin" | "system";

export interface AgentContext {
  userId: UserId;
  role: Role;
  businessId: string;
  locale?: string;
  timezone?: string;
  channel?: "web" | "mobile" | "cli";
}

export interface AgentReply {
  text: string;
  done?: boolean;
  ui?: { type: "form" | "choices" | "table" | "calendar" | "link"; data: unknown };
}

export interface AuditEvent {
  at: Date;
  businessId: string;
  actorId: UserId;
  role: Role;
  type:
    | "intent.detected"
    | "entity.extracted"
    | "slot.asked"
    | "slot.filled"
    | "policy.blocked"
    | "tool.called"
    | "tool.result"
    | "tool.error"
    | "flow.completed"
    | "flow.failed";
  details: Record<string, unknown>;
}

export interface AuditLogger { write(ev: AuditEvent): Promise<void>; }
export interface Clock { now(): Date; }

export interface Span { name: string; start: number; end?: number; meta?: Record<string, unknown>; }
export interface Tracer { start(name: string, meta?: Record<string, unknown>): Span; end(span: Span, meta?: Record<string, unknown>): void; }
