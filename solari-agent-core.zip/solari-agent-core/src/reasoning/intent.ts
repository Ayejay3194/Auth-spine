import { IntentResult, RiskContext } from "../types";
import { detectRiskContext } from "../governance/risk";

export function classifyIntent(userText: string): IntentResult {
  const risk: RiskContext = detectRiskContext(userText);

  // minimalist intent detection; replace with your own classifier
  const t = userText.toLowerCase();
  let intent = "general";
  if (/(build|create|generate|zip)/.test(t)) intent = "build_artifact";
  else if (/(explain|why|how)/.test(t)) intent = "explain";
  else if (/(fix|bug|error)/.test(t)) intent = "debug";

  const trigger =
    /(again|repeat)/.test(t) ? "repetition" :
    /(confus|don’t get)/.test(t) ? "confusion" :
    /(hurry|now|asap)/.test(t) ? "impatience" :
    /(vague|whatever)/.test(t) ? "vague_question" :
    "analysis";

  const confidence = intent === "general" ? 0.65 : 0.8;

  return { intent, trigger, confidence, risk };
}
