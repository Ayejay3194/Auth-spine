import { GOLDEN_VECTORS } from "./vectors";

/**
 * Plug your real engine/orchestrator into `runOne`.
 * This file is intentionally generic.
 */
export async function runGoldenVectors(runOne: (input: any) => Promise<any>) {
  const results = [];
  for (const v of GOLDEN_VECTORS) {
    const got = await runOne(v.input);
    results.push({ name: v.name, expected: v.expected, got });
  }
  return results;
}
