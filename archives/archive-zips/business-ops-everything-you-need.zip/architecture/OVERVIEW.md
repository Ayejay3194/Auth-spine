System architecture, data flow, and service boundaries.
