EXECUTIVE SECURITY DASHBOARD

KPIs:
- Risk score (trend)
- Open critical vulnerabilities
- Mean time to detect/respond
- Compliance coverage
- Incident count (30/90 days)

Audience:
- Founders
- Board
- Investors

Rule:
No raw logs. Only signals.