INSTANT PAYOUT ELIGIBILITY
=========================

Required:
- verified identity
- verified bank account
- minimum account age
- no recent chargebacks
- balance above minimum

Limits:
- per-transaction max
- daily max
- weekly max
- platform fee applied

Failure -> fallback to ACH.
