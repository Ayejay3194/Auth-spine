## What changed
- 

## Why
- 

## Risk category (check all that apply)
- [ ] Auth/session changes
- [ ] Authorization/RLS changes
- [ ] Payments/webhooks
- [ ] File uploads/storage
- [ ] Data model/migrations
- [ ] User messaging/notifications

## Security checklist (must be YES)
- [ ] No secrets in code or logs
- [ ] Server-side auth enforced on affected endpoints
- [ ] Authorization checks added/updated (owner/role)
- [ ] RLS policies added/updated (if Supabase tables touched)
- [ ] Input validation added/updated
- [ ] Rate limits considered (auth/webhooks)

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] Manual test notes included
