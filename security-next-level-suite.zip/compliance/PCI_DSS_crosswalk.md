PCI DSS CROSSWALK

Covers:
- Cardholder data protection
- Network segmentation
- Logging & monitoring
- Vulnerability management