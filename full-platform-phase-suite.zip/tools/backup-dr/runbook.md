DR Runbook
1) Freeze writes if needed
2) Restore DB snapshot
3) Restore file pointers (if any)
4) Rebuild search index (queue job)
5) Run smoke + E2E tests
