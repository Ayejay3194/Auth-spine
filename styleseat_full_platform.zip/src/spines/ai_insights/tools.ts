// ai_insights tools.ts
