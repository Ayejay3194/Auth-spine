import { NextRequest, NextResponse } from 'next/server'
import { AuthError, ErrorCode } from '@auth-spine/core'
import { verifyToken, type JwtPayload } from './index'

export const AUTH_COOKIE_NAME = 'auth_spine_token'

export function getTokenFromRequest(req: NextRequest): string | null {
  // Prefer cookie
  const cookie = req.cookies.get(AUTH_COOKIE_NAME)?.value
  if (cookie) return cookie

  // Fallback: Authorization Bearer
  const auth = req.headers.get('authorization') || ''
  const m = auth.match(/^Bearer\s+(.+)$/i)
  return m ? m[1] : null
}

export async function getUserFromRequest(req: NextRequest): Promise<JwtPayload> {
  const token = getTokenFromRequest(req)
  if (!token) throw new AuthError('Missing auth token', ErrorCode.AUTH_UNAUTHORIZED)
  return await verifyToken(token)
}

export function setAuthCookie(res: NextResponse, token: string, opts?: { maxAgeSeconds?: number }) {
  const maxAge = opts?.maxAgeSeconds ?? 60 * 60 * 24 * 7 // 7 days
  res.cookies.set(AUTH_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge,
  })
}

export function clearAuthCookie(res: NextResponse) {
  res.cookies.set(AUTH_COOKIE_NAME, '', {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 0,
  })
}

export function withAuth<T>(
  handler: (req: NextRequest, ctx: { user: JwtPayload }) => Promise<NextResponse> | NextResponse
) {
  return async (req: NextRequest) => {
    const user = await getUserFromRequest(req)
    return handler(req, { user })
  }
}

export function requireRole(role: string, handler: (req: NextRequest, ctx: { user: JwtPayload }) => Promise<NextResponse> | NextResponse) {
  return withAuth(async (req, ctx) => {
    const userRole = (ctx.user.role || '').toUpperCase()
    if (userRole !== role.toUpperCase()) {
      throw new AuthError('Forbidden', ErrorCode.AUTH_UNAUTHORIZED)
    }
    return handler(req, ctx)
  })
}
