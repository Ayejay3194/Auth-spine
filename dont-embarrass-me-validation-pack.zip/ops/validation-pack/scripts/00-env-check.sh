#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CFG="$ROOT/configs/endpoints.json"

BASE_URL="${TARGET_BASE_URL:-http://localhost:3000}"
echo "TARGET_BASE_URL=$BASE_URL"
mkdir -p "$ROOT/out"
echo "$BASE_URL" > "$ROOT/out/target_base_url.txt"

node -e "JSON.parse(require('fs').readFileSync('$CFG','utf8')); console.log('✅ endpoints.json valid JSON')"
