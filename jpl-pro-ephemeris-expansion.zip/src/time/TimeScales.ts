
/**
 * Time scale conversions
 * UTC ↔ TAI ↔ TT ↔ TDB
 * Leap seconds are versioned and audited.
 */

export function utcToTAI(utc: Date): number {
  throw new Error("Leap second table required");
}

export function taiToTT(taiSeconds: number): number {
  return taiSeconds + 32.184;
}

export function ttToTDB(ttSeconds: number): number {
  throw new Error("Relativistic TT→TDB not implemented");
}
