# Troubleshooting Auditor (TypeScript)

A local auditing module + CLI that checks the most common "my TS website is broken" causes
and produces a **report** (Markdown or JSON).

## What it audits
- TypeScript config traps (include/exclude, module mismatches, etc)
- package.json scripts + lockfile + Node engine hints
- .env presence + placeholder/empty vars + public prefix hints
- Framework heuristics (Next.js / Vite) for common prod failures
- Build artifacts (dist/.next/build), public assets, basePath/base hints
- Optional command runner: typecheck/build/lint/preview (captures output)
- Optional endpoint checks (GET URLs you provide)

## Install & run (inside your repo)
```bash
mkdir -p tools && cp -R troubleshooting-auditor tools/troubleshooting-auditor
cd tools/troubleshooting-auditor
npm i
npm run build

# run against repo root
node dist/cli.js --root ../../ --format md --out ../../audit-report.md
```

## CLI
```bash
ts-audit --root . --format md --out audit.md
ts-audit --root . --format json --out audit.json
ts-audit --root . --run typecheck --run build --run lint
ts-audit --root . --endpoints https://example.com/health,https://example.com/api/ping
```

## Safety
- Read-only checks by default.
- If you pass `--run ...`, it executes commands in your repo and records outputs.

## Extend
Add a new auditor in `src/auditors/` and register it in `src/runAudit.ts`.
