import type { EphemerisEngine, ChartRequest } from "./engine.js";
import { CONTRACT_VERSION, CANONICAL_VERSION } from "../contract/version.js";

function degToSign(lon: number) {
  const signs = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"];
  const idx = Math.floor(((lon % 360) + 360) % 360 / 30);
  const deg = ((lon % 30) + 30) % 30;
  return { sign: signs[idx], degInSign: deg };
}

/**
 * Deterministic fake engine (for golden harness + pipeline proof).
 * Replace with Swiss Ephemeris adapter later. The contract doesn't care.
 */
export class MockEngine implements EphemerisEngine {
  readonly engineId = "mock-engine@1.0.0";

  async computeNatal(req: ChartRequest) {
    // Use a stable seed derived from input.
    const seed = [...req.dobUtc, `${req.geo.lat}`, `${req.geo.lon}`, req.houseSystem, req.zodiac].join("|");
    let h = 2166136261;
    for (let i = 0; i < seed.length; i++) h = Math.imul(h ^ seed.charCodeAt(i), 16777619);

    function rand() {
      // xorshift-ish
      h ^= h << 13; h ^= h >>> 17; h ^= h << 5;
      return ((h >>> 0) % 1_000_000) / 1_000_000;
    }

    const bodyIds = ["Sun","Moon","Mercury","Venus","Mars","Jupiter","Saturn","Uranus","Neptune","Pluto","MeanNode","Chiron","Fortune","Vertex"] as const;

    const bodies = bodyIds.map((id, idx) => {
      const lon = (rand() * 360 + idx * 7.13) % 360;
      const { sign, degInSign } = degToSign(lon);
      return {
        id,
        lon,
        speedLon: (rand() * 2 - 1),
        retrograde: rand() < 0.2,
        sign,
        degInSign,
        house: ((idx % 12) + 1),
      };
    });

    const houses = Array.from({ length: 12 }, (_, i) => {
      const lon = (i * 30 + rand() * 5) % 360;
      const { sign, degInSign } = degToSign(lon);
      return { house: i + 1, lon, sign, degInSign };
    });

    const angles = [
      (() => { const { sign, degInSign } = degToSign( (houses[0].lon + 0.0) % 360 ); return { id: "ASC" as const, lon: houses[0].lon, sign, degInSign }; })(),
      (() => { const { sign, degInSign } = degToSign( (houses[9].lon + 0.0) % 360 ); return { id: "MC" as const, lon: houses[9].lon, sign, degInSign }; })(),
    ];

    return {
      version: CONTRACT_VERSION,
      chartType: "natal" as const,
      houseSystem: req.houseSystem,
      zodiac: req.zodiac,
      ayanamsa: req.ayanamsa,
      input: {
        dobUtc: req.dobUtc,
        geo: { ...req.geo },
      },
      bodies,
      houses,
      angles,
      aspects: [],
      extras: {},
      meta: {
        engineId: this.engineId,
        flags: req.flags ?? [],
        engineCommit: undefined,
        computedAtUtc: new Date().toISOString(),
        canonicalVersion: CANONICAL_VERSION,
      },
    };
  }
}
