import { beforeAll, beforeEach, afterAll, vi } from "vitest";

beforeAll(() => {
  process.env.NODE_ENV = "test";

  process.env.JWT_SECRET ??= "test-jwt-secret-key-at-least-32-characters-long";
  process.env.SESSION_SECRET ??= "test-session-secret-key";
  process.env.DATABASE_URL ??= "postgresql://test:test@localhost:5432/test";
  process.env.REDIS_URL ??= "redis://localhost:6379";
});

// Make time deterministic in unit tests.
// E2E tests can opt-out by calling `vi.useRealTimers()`.
beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2024-01-15T12:00:00.000Z"));
});

afterAll(() => {
  vi.useRealTimers();
});