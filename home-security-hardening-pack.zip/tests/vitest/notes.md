If your Vitest integration tests currently expect `/api/metrics` or `/swagger` to be public,
change them to:
- use a metrics token header (Bearer) OR
- skip in production (`NODE_ENV=production`)

The hardening pack is designed so prod is not a recon buffet.
