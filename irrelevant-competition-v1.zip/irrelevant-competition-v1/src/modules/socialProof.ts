export class SocialProofEngine {
  summary(): string[] {
    return ["Popular time slot", "High rebooking rate"];
  }
}
