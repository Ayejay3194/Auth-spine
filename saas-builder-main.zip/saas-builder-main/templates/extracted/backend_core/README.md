# Backend Core
API, auth, DB, infra templates.