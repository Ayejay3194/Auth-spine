import { deriveTenantContext } from "../../platform/tenant/context";
import { audit } from "../observability/audit";

export async function tenantGuard(req: any) {
  const ctx = await deriveTenantContext({ headers: req.headers, ip: req.ip, url: req.url });

  // Defensive: ensure context is attached for downstream checks
  (req as any).tenant = ctx;

  await audit({
    event: "tenant_context_derived",
    tenantId: ctx.tenantId,
    actorId: ctx.userId,
    requestId: ctx.requestId,
    meta: { plan: ctx.plan, region: ctx.region }
  });

  return ctx;
}
