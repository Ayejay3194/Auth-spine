import type { AgentContext } from "../runtimeTypes.js";
import type { SessionStore } from "../storage/sessionStore.js";

export class SimplePolicyEngine {
  constructor(
    private rateStore: SessionStore<{ count: number }>,
    private cfg: {
      allow: Record<string, string[]>;
      rate: { windowSeconds: number; max: number };
      confirmIntents: string[];
    }
  ) {}

  async check(ctx: AgentContext, intent: string): Promise<{ allow: boolean; reason?: string; requireConfirm?: boolean }> {
    const role = ctx.role;
    const allowed = this.cfg.allow[String(role)] ?? [];
    if (!allowed.includes(intent)) return { allow: false, reason: "Role not allowed for this action." };

    // rate limit (per business+user)
    const key = `rate:${ctx.businessId}:${ctx.userId}`;
    const cur = (await this.rateStore.get(key)) ?? { count: 0 };
    const next = cur.count + 1;
    await this.rateStore.set(key, { count: next }, this.cfg.rate.windowSeconds);
    if (next > this.cfg.rate.max) return { allow: false, reason: "Rate limit exceeded." };

    return { allow: true, requireConfirm: this.cfg.confirmIntents.includes(intent) };
  }
}
