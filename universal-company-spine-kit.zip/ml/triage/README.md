Triage scorer template
======================

Use this for:
- support ticket priority
- incident priority
- moderation queue priority

Labels should be outcomes like:
- escalated (1/0)
- resolved_within_sla (1/0)
