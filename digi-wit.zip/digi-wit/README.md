# digi-wit

A strict, boring, deterministic wrapper around Wit.ai:
- parses user text into `{ intent, entities }`
- validates against Zod schemas
- enforces a confidence floor
- emits receipts for audit/debug

This is a **parser** module. It does not execute actions.

## Install
```bash
pnpm add @solari/digi-wit zod
# or npm/yarn
```

## Quick use
```ts
import { DigiWitRouter, builtInIntents } from "@solari/digi-wit";

const router = new DigiWitRouter({
  accessToken: process.env.WIT_SERVER_TOKEN!,
  confidenceFloor: 0.85,
  intents: builtInIntents,
  receiptSink: (r) => console.log(JSON.stringify(r)),
});

const out = await router.parseAndValidate({
  text: "show me my transits for next week",
  userId: "u_123",
  requestId: "req_abc",
});

if (!out.ok) {
  console.log(out.reason);
} else {
  // deterministic payload for your system router
  console.log(out.intent, out.payload);
}
```

## Why receipts
If something breaks, you want proof of:
- raw input (hashed)
- Wit model + version metadata
- parsed entities
- schema validation result
- acceptance or refusal reason

This is how you avoid doing this over again.
