# Astro Marketplace Contract Kit

You asked for a format that’s basically “proof from breaking”. Humans are chaotic, so we do it with **contracts + hashes**.

This repo gives you:

- **ChartDataV1**: strict JSON shape for all chart outputs
- **canonicalizeChart**: stable canonical string (sorted keys, normalized numbers)
- **computeChartIntegrity**: SHA-256 hash of that canonical string
- **formatChartLikeSolarFire**: consistent plain-text export for debugging/support
- **validateChartData**: catches common “AI refactor” damage (missing fields, bad coords)

## Quick start

```bash
pnpm i   # or npm i / yarn
pnpm test
pnpm gen:sample
```

Outputs:
- `fixtures/sample.chart.v1.json` (input)
- `fixtures/sample.output.txt` (generated)

## The rule that stops refactors from breaking you

**Never** compare raw objects. Always compare:

1) `canonicalizeChart(chart)`
2) `computeChartIntegrity(chart).hashHex`

If the hash changes, something real changed. If not, ignore the noise.

## Integrate into your engine

- After computing a chart, run `validateChartData(chart)`.
- Store `chartData` and `integrity.hashHex`.
- On any future recalculation or migration, re-hash and compare.

