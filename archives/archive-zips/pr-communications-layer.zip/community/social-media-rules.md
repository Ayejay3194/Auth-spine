SOCIAL MEDIA RULES
==================

Rules:
- No arguing publicly
- No subtweets
- No reactive posting
- Route issues to support

Goal:
Trust, not virality.
