import crypto from "node:crypto";
import { BookingProvider, Slot, Booking } from "../booking/types.js";

function iso(d: Date) { return d.toISOString().slice(0,16); }

export class BookingProviderMock implements BookingProvider {
  private bookings: Booking[] = [];
  private slots: Slot[] = [];

  constructor() {
    const now = new Date();
    for (let i=1;i<=10;i++) {
      const d = new Date(now);
      d.setDate(d.getDate()+i);
      d.setHours(18,0,0,0);
      this.slots.push({ slotId: "sl_" + crypto.randomBytes(3).toString("hex"), startISO: iso(d), durationMin: 60, providerId: "p1" });
      d.setHours(19,0,0,0);
      this.slots.push({ slotId: "sl_" + crypto.randomBytes(3).toString("hex"), startISO: iso(d), durationMin: 60, providerId: "p1" });
    }
  }

  async findAvailableSlots(input: { service: string; dateISO?: string; partOfDay?: string; durationMin: number }): Promise<Slot[]> {
    let s = this.slots.filter(x => x.durationMin === input.durationMin);
    if (input.dateISO) s = s.filter(x => x.startISO.startsWith(input.dateISO));
    if (input.partOfDay === "evening") s = s.filter(x => Number(x.startISO.slice(11,13)) >= 17);
    return s.slice(0, 8);
  }

  async createBooking(input: { userId: string; slotId: string; service: string; contactMethod: "video" | "phone" | "chat"; notes?: string }): Promise<Booking> {
    const bk: Booking = { bookingId: "bk_" + crypto.randomBytes(3).toString("hex"), slotId: input.slotId, service: input.service, contactMethod: input.contactMethod, notes: input.notes, status: "confirmed" };
    this.bookings.push(bk);
    return bk;
  }

  async rescheduleBooking(input: { userId: string; bookingId: string; newSlotId: string }): Promise<Booking> {
    const b = this.bookings.find(x => x.bookingId === input.bookingId);
    if (!b) throw new Error("Booking not found");
    b.slotId = input.newSlotId;
    return b;
  }

  async cancelBooking(input: { userId: string; bookingId: string; reason?: string }): Promise<Booking> {
    const b = this.bookings.find(x => x.bookingId === input.bookingId);
    if (!b) throw new Error("Booking not found");
    b.status = "canceled";
    return b;
  }

  async listBookings(input: { userId: string }): Promise<Booking[]> {
    return this.bookings;
  }
}
