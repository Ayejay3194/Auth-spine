import type { ID } from "@suite/core";

/**
 * WebAuthn: browser + server verification. This defines types and store boundary.
 * Plug in @simplewebauthn/server for full attestation + assertions.
 */
export type WebAuthnCredential = { id: ID; userId: ID; publicKey: string; counter: number; transports?: string[] };

export interface WebAuthnStore {
  list(userId: ID): Promise<WebAuthnCredential[]>;
  add(cred: WebAuthnCredential): Promise<void>;
  updateCounter(id: ID, counter: number): Promise<void>;
}
