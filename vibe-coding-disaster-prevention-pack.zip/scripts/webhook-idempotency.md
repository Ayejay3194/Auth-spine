# Webhook Idempotency Recipe
1) Extract provider delivery id (event.id / stripe-event-id)
2) Insert into `webhook_deliveries` with UNIQUE constraint
3) If conflict -> return 200/409 (provider dependent), do nothing
4) Process event with upsert or guarded transitions
