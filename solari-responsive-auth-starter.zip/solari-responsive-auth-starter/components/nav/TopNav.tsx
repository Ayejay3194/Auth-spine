"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/components/auth/AuthContext";

const links = [
  { href: "/map", label: "Map" },
  { href: "/inbox", label: "Inbox" },
  { href: "/boards", label: "Boards" },
  { href: "/profile", label: "Me" },
  { href: "/natal", label: "Natal" },
  { href: "/hd", label: "HD" }
];

export function TopNav() {
  const path = usePathname();
  const { user, login, logout } = useAuth();

  return (
    <div className="sticky top-0 z-50 border-b border-white/10 bg-bg1/70 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="font-black tracking-[0.28em] text-gold">SOLARI</Link>

        <nav className="hidden md:flex items-center gap-4 text-sm font-semibold text-white/80">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className={path === l.href ? "text-white" : "hover:text-white"}>
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <div className="hidden sm:block text-xs text-white/60">{user ? user.email : "signed out"}</div>
          {user ? (
            <button className="pill" onClick={logout}>Logout</button>
          ) : (
            <button className="pill" onClick={() => login()}>Login</button>
          )}
        </div>
      </div>

      <div className="md:hidden border-t border-white/10">
        <div className="mx-auto flex max-w-6xl justify-between px-4 py-2 text-xs font-semibold text-white/75">
          {links.slice(0, 4).map((l) => (
            <Link key={l.href} href={l.href} className={path === l.href ? "text-white" : ""}>
              {l.label}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
