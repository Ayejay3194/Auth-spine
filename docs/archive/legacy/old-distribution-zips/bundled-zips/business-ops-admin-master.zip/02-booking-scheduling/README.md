# 02-booking-scheduling

Time coordination, availability, capacity, conflicts.
