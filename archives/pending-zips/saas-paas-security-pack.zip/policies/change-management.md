# Change Management (SaaS)
- PR reviews required
- CI security gates required
- Feature flags for risky changes
- Rollback plan for every release
- Emergency changes logged and reviewed within 24h
