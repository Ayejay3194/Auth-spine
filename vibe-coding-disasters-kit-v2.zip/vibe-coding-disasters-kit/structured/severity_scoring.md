# Severity scoring

- CRITICAL: likely breach/account takeover/cross-user data leak/payment fraud.
- HIGH: exploitable or severe reliability issue.
- MEDIUM: quality/perf/maintainability issue.

Tune per your risk tolerance.
