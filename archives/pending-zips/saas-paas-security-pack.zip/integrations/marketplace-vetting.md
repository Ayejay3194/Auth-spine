# Integration marketplace vetting (starter)
- Developer verification (email/domain)
- OAuth scopes minimized + reviewed
- Static analysis of integration code (if hosted)
- Abuse monitoring per integration
- Immediate suspend capability
- Deprecation process + notices
