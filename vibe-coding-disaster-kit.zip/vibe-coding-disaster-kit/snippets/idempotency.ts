// idempotency.ts (server-side pattern)
// Store idempotency keys with a unique constraint: (tenant_id, key)
// Return the same result for retries.
export async function withIdempotency<T>(
  key: string,
  run: () => Promise<T>,
  store: {
    get: (key: string) => Promise<T | null>;
    set: (key: string, value: T) => Promise<void>;
  }
): Promise<T> {
  const existing = await store.get(key);
  if (existing) return existing;
  const result = await run();
  await store.set(key, result);
  return result;
}
