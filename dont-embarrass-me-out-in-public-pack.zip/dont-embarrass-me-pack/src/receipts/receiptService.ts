import type { RequestContext } from "../runtime/types";
import { createReceipt, verifyReceipt } from "./receipt";
import type { ReceiptStore } from "./receiptStore";

export class ReceiptService {
  constructor(private store: ReceiptStore) {}

  async issue(ctx: RequestContext, args: {
    action: string;
    entityType: string;
    entityId: string;
    payload: unknown;
    status: "validated" | "approved" | "rejected";
  }) {
    const last = await this.store.latest(ctx.tenantId);
    const r = createReceipt({
      ctx,
      action: args.action,
      entityType: args.entityType,
      entityId: args.entityId,
      payload: args.payload,
      status: args.status,
      prevHash: last?.chainHash
    });
    await this.store.append(r);
    return r;
  }

  async verify(id: string) {
    const r = await this.store.get(id);
    if (!r) return { ok: false, tampered: false, missing: true };
    const v = verifyReceipt(r);
    return { ok: v.ok, tampered: v.tampered, receipt: r };
  }
}
