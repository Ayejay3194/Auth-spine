import React from "react";
export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <h1>NLU Admin</h1>
      <p>Go to <a href="/admin/nlu" style={{ color: "#7aa2ff" }}>/admin/nlu</a></p>
    </main>
  );
}
