import path from "node:path";
import fs from "node:fs/promises";
import { Table as ArrowTable, Vector, Float64Vector, Utf8Vector, Int32Vector, BoolVector } from "apache-arrow";
import { LakeConfig, dataRoot } from "../io/paths.js";
import { readParquetToArrowTable, writeArrowTableToParquet } from "../io/parquetArrow.js";
import { sha256File } from "../io/hash.js";
import { resolveFilesAtCommit, commitWrite } from "../delta/log.js";
import { FileRef } from "../delta/types.js";

function vectorToArray(v: Vector): any[] {
  const out = new Array(v.length);
  for (let i = 0; i < v.length; i++) out[i] = v.get(i);
  return out;
}

function makeVector(arr: any[]): Vector {
  if (arr.every(x => typeof x === "number" || x == null)) return Float64Vector.from(arr.map(x => (x == null ? NaN : x)));
  if (arr.every(x => typeof x === "boolean" || x == null)) return BoolVector.from(arr.map(x => !!x));
  if (arr.every(x => Number.isInteger(x) || x == null)) return Int32Vector.from(arr.map(x => (x == null ? 0 : x)));
  return Utf8Vector.from(arr.map(x => (x == null ? "" : String(x))));
}

/**
 * Compile a training snapshot from a specific commit of an input table.
 * Output is written as a single snapshot parquet and committed to the output table log.
 */
export async function compileTrainingSnapshotFromCommit(args: {
  cfg: LakeConfig;
  input: { table: string; tableVersion: string; commitId: string; schemaVersion: string };
  output: { table: string; tableVersion: string; schemaVersion: string };
  generator: string;
  expectedHead?: string | null;
}): Promise<{ snapshotPath: string; commitId: string; rows: number }> {
  const files: FileRef[] = await resolveFilesAtCommit(args.cfg, args.input.table, args.input.tableVersion, args.input.commitId);
  if (!files.length) throw new Error("No files resolved at commit");

  const absFiles = files.map(f => path.join(args.cfg.root, f.path));
  const tables: ArrowTable[] = [];
  for (const f of absFiles) tables.push(await readParquetToArrowTable(f));

  const colNames = new Set<string>();
  for (const t of tables) t.schema.fields.forEach(f => colNames.add(f.name));
  const cols = [...colNames].sort();

  const outCols: Record<string, any[]> = {};
  for (const c of cols) outCols[c] = [];

  for (const t of tables) {
    for (const c of cols) {
      const v = t.getChild(c);
      const arr = v ? vectorToArray(v) : new Array(t.numRows).fill(null);
      outCols[c].push(...arr);
    }
  }

  const vectors: Record<string, Vector> = {};
  for (const c of cols) vectors[c] = makeVector(outCols[c]);
  const outTable = ArrowTable.new(vectors);

  const outDir = dataRoot(args.cfg, args.output.table, args.output.tableVersion);
  await fs.mkdir(outDir, { recursive: true });
  const snapshotPath = path.join(outDir, "snapshot.parquet");

  await writeArrowTableToParquet(snapshotPath, outTable, {
    compression: "zstd",
    metadata: {
      table: args.output.table,
      tableVersion: args.output.tableVersion,
      schemaVersion: args.output.schemaVersion,
      compiledFrom: `${args.input.table}@${args.input.tableVersion}#${args.input.commitId}`
    }
  });

  const rel = path.relative(args.cfg.root, snapshotPath);
  const sha = await sha256File(snapshotPath);

  const commit = await commitWrite(args.cfg, {
    table: args.output.table,
    tableVersion: args.output.tableVersion,
    schemaVersion: args.output.schemaVersion,
    add: [{ path: rel, sha256: sha, rows: outTable.numRows }],
    generator: args.generator,
    message: "compile training snapshot",
    tags: ["training", "snapshot"],
    expectedHead: args.expectedHead
  });

  return { snapshotPath, commitId: commit.id, rows: outTable.numRows };
}
