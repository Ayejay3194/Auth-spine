# Stub intent classifier (keyword scoring).
# Swap with your trained scikit model from the PRO kit and keep the same output shape.

DEFAULT_INTENTS = [
    ("book_appointment", ["book", "appointment", "schedule", "reserve"]),
    ("cancel_appointment", ["cancel", "reschedule", "move"]),
    ("price_quote", ["price", "cost", "how much"]),
    ("hours", ["hours", "open", "close"]),
    ("smalltalk.greeting", ["hi", "hello", "hey"]),
    ("smalltalk.thanks", ["thanks", "thank you"]),
    ("smalltalk.bye", ["bye", "goodbye", "later"]),
]

def _score(text: str, keywords: list[str]) -> float:
    t = text.lower()
    hits = sum(1 for k in keywords if k in t)
    return hits / max(1, len(keywords))

class IntentClassifier:
    def predict(self, text: str) -> list[dict]:
        scored = []
        for name, kws in DEFAULT_INTENTS:
            s = _score(text, kws)
            if s > 0:
                scored.append({"name": name, "confidence": round(min(0.99, 0.2 + 0.8*s), 3)})
        scored.sort(key=lambda x: x["confidence"], reverse=True)
        return scored[:3] if scored else [{"name":"fallback", "confidence":0.2}]
