// Edge Function: signed upload URL + path enforcement (skeleton)
//
// This is a scaffold. You must wire in your auth + tenant checks and use supabase storage signed upload APIs.

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

serve(async (req) => {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  // TODO: verify JWT, extract user + tenant context
  const { path, bucket, contentType } = await req.json().catch(() => ({}));

  if (!bucket || !path) return json({ error: "missing_bucket_or_path" }, 400);

  // TODO: enforce path regex, e.g. `${tenantId}/${userId}/...`
  // TODO: generate signed upload URL using Supabase Storage
  // const signed = await supabase.storage.from(bucket).createSignedUploadUrl(path);

  return json({
    ok: true,
    bucket,
    path,
    note: "Wire Supabase client + createSignedUploadUrl here and enforce tenant/user path constraints.",
    contentType: contentType ?? "application/octet-stream",
  });
});
