import crypto from "node:crypto";

export function generateBackupCodes(count=10): string[] {
  return Array.from({ length: count }).map(() => crypto.randomBytes(4).toString("hex"));
}

export function hashCode(code: string): string {
  return crypto.createHash("sha256").update(code).digest("hex");
}

export function consumeCode(hashedCodes: Set<string>, code: string): boolean {
  const h = hashCode(code);
  if (!hashedCodes.has(h)) return false;
  hashedCodes.delete(h);
  return true;
}
