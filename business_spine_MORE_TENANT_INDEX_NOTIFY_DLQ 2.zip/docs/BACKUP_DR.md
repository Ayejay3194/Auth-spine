# Backup & Disaster Recovery
Included:
- ops/backup/pg_backup.sh
- ops/backup/pg_restore.sh

Recommended:
- nightly dumps
- 7-30 day retention
- encrypted storage
- quarterly restore drills
