# Vibe Coding Life Program

This pack is a full transformation kit:

- How to set up your dev environment
- How to run the starter apps (Next.js / Prisma)
- 90-day path from beginner → shipping
- 12-month growth ladder
- Money lanes (freelance, templates, SaaS, job)
- Daily and weekly routines
- Exact prompts and workflows for GPT, chat.z.ai, Claude + Cursor/Windsurf

This assumes you ALSO have:
- A Next.js starter repo (e.g. your Ultimate SaaS Starter)
- The Vibe Coding Manual (ideation → pre-code → GLM → Claude)

Start with `program/00-start-here.md`.
