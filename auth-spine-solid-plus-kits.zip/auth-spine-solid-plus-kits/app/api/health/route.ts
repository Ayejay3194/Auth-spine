import { logger } from "@/lib/logger";

async function checkDatabase() {
  // placeholder check; replace with prisma query
  return { name: "database", status: "ok" as const };
}
async function checkRedis() {
  return { name: "redis", status: "ok" as const };
}
async function checkExternal() {
  return { name: "external", status: "ok" as const };
}

export async function GET() {
  const checks = await Promise.all([checkDatabase(), checkRedis(), checkExternal()]);
  const healthy = checks.every((c) => c.status === "ok");
  const body = { status: healthy ? "healthy" : "degraded", checks, timestamp: new Date().toISOString() };
  if (!healthy) logger.warn("Health degraded", body);
  return Response.json(body, { status: healthy ? 200 : 503 });
}
