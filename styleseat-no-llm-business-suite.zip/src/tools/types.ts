import { AgentContext } from "../core/types.js";

export interface ToolResult<T = unknown> {
  ok: boolean;
  data?: T;
  error?: { code: string; message: string };
}

export interface Tool<TInput, TOutput> {
  id: string;
  description: string;
  validate: (input: TInput) => void;
  run: (ctx: AgentContext, input: TInput) => Promise<ToolResult<TOutput>>;
  timeoutMs?: number;
  retries?: number;
}

export interface ToolRegistry {
  get(id: string): Tool<any, any>;
  list(): Tool<any, any>[];
}
