# Runbook

- If everything returns fallback: check `nlu/classifier.ts` and the confidence threshold in `nlu/validators.ts`.
- If state seems wrong: inspect `conversation/stateStore.ts` (swap for Redis/Postgres/etc).
- Receipts: `conversation/receipts.ts` prints JSON to stdout.
