/**
 * Micro-timing makes assistants feel less robotic.
 * Use sparingly. Too much delay feels broken.
 */
export async function humanDelay(min = 200, max = 600) {
  const ms = Math.floor(Math.random() * (max - min + 1)) + min;
  await new Promise((r) => setTimeout(r, ms));
}
