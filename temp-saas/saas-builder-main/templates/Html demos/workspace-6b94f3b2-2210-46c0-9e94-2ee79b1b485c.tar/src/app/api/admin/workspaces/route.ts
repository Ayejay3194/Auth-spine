import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/permissions'

// GET /api/admin/workspaces - Get all workspaces
export async function GET(request: NextRequest) {
  const handler = requireAdmin(async (req: Request) => {
    try {
      const workspaces = await db.workspace.findMany({
        include: {
          owner: {
            select: {
              name: true,
              email: true
            }
          },
          _count: {
            select: {
              members: true,
              projects: true
            }
          },
          subscription: {
            include: {
              plan: true
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        }
      })

      return NextResponse.json({
        success: true,
        data: workspaces
      })
    } catch (error) {
      console.error('Failed to fetch workspaces:', error)
      return NextResponse.json(
        { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch workspaces' } },
        { status: 500 }
      )
    }
  })

  return handler(request, { user: { isAdmin: true } })
}