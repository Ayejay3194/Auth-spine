export type NLUIntent = {
  name: string;
  examples: string[];
};

export type NLUEntity = {
  name: string;
  values: string[];
};

export type NLUModel = {
  version: number;
  intents: NLUIntent[];
  entities: NLUEntity[];
};

export type IntentResult = {
  name: string;
  confidence: number;
  score: number;
};

export type ExtractedEntity = {
  entity: string;
  value: string;
  start: number;
  end: number;
};

export type NLUResult = {
  text: string;
  intent: IntentResult;
  entities: ExtractedEntity[];
};
