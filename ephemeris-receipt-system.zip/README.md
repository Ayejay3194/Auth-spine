# Ephemeris Receipt System (Source-of-Truth Kit)

This kit makes every ephemeris calculation **provable, reproducible, and tamper-evident**.

## What it does
- Canonical output + stable hashing
- Receipts with provenance (kernel/time/IAU/build)
- Append-only hash-chain ledger with HMAC signatures
- Verifier CLI + golden-vector gate hook

## Quick start
```bash
npm i
npm run build
# create a receipt (writes to ./receipts/ledger.jsonl)
npm run receipt:create -- --input ./examples/input.json --output ./examples/output.json
# verify integrity
npm run receipt:verify -- --ledger ./receipts/ledger.jsonl
```
