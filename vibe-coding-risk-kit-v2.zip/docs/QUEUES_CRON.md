# Queues, Jobs, Cron Checklist

## Queues/Workers
- [ ] Jobs are idempotent
- [ ] Retries have backoff + max attempts
- [ ] Dead letter queue exists
- [ ] Job status tracked + inspectable
- [ ] External API calls have timeouts + circuit breaker

## Cron
- [ ] Distributed lock to prevent double execution
- [ ] Timezone explicitly set (and DST understood)
- [ ] Overlap prevention (skip if previous run active)
- [ ] Execution history logged + alerted on failure
