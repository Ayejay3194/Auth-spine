#!/usr/bin/env bash
set -euo pipefail
# TODO: restore drill
