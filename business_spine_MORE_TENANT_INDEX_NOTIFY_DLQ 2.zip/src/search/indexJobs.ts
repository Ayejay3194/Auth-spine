import { reportQueue } from "@/src/queue/queues";
import { upsertProvider, ensureProviderIndex } from "./providerIndex";

export async function enqueueProviderIndex(input: { tenantId: string; provider: any }) {
  await reportQueue.add("index_provider", input, { attempts: 5, backoff: { type: "exponential", delay: 1000 } });
}

export async function handleIndexJob(job: any) {
  if (job.name === "index_provider") {
    await ensureProviderIndex();
    const { tenantId, provider } = job.data;
    await upsertProvider({
      id: provider.id,
      tenantId,
      name: provider.name,
      bio: provider.bio,
      specialties: provider.specialties ?? [],
      location: provider.location,
      rating: provider.rating,
    });
    return { ok: true };
  }
  if (job.name === "reindex_all_providers") {
    await ensureProviderIndex();
    // TODO: fetch all providers from DB and upsert
    return { ok: true, todo: "Fetch providers from DB and upsert in batches" };
  }
  return null;
}
