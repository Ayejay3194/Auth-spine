import type { EmailPort, EmailType } from '@spine/auth-core';
export class ConsoleEmail implements EmailPort { sent:{to:string;type:EmailType;payload:Record<string,unknown>}[]=[]; async send(to,type,payload){ this.sent.push({to,type,payload}); console.log(`[email] to=${to} type=${type} payload=${JSON.stringify(payload)}`);} }
