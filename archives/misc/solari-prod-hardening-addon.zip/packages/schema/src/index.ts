import { z } from "zod";

/**
 * Canonical node ID format:
 *   <domain>:<kind>:<slug>[:<subslug>]
 * Examples:
 *   hd:gate:1
 *   hd:type:generator
 *   biz:policy:no-show
 *   astro:decan:aries:1
 */
export const NodeId = z.string().regex(/^[a-z0-9-]+:[a-z0-9-]+:[a-z0-9-]+(?::[a-z0-9-]+){0,3}$/i, "Invalid node id");

export const Provenance = z.object({
  source: z.enum(["book","site","internal_synthesis","user_uploaded","dataset"]).default("internal_synthesis"),
  title: z.string().optional(),
  author: z.string().optional(),
  edition: z.string().optional(),
  url: z.string().url().optional(),
  pageRange: z.string().optional(), // "p. 12-14"
  license: z.string().optional(),
  extractedAt: z.string().datetime().optional()
});

export const Node = z.object({
  id: NodeId,
  kind: z.string(),           // "hd:gate", "biz:policy", "astro:aspect"
  title: z.string(),
  summary: z.string().optional(),
  body: z.string().optional(),
  tags: z.array(z.string()).default([]),
  aliases: z.array(z.string()).default([]),
  links: z.array(NodeId).default([]), // edges to other nodes
  version: z.string().optional(),      // dataset version
  provenance: Provenance.optional(),
});

export type Node = z.infer<typeof Node>;
export type Provenance = z.infer<typeof Provenance>;

export const AuditFinding = z.object({
  level: z.enum(["info","warn","error"]),
  code: z.string(),
  message: z.string(),
  nodeId: NodeId.optional(),
  meta: z.record(z.any()).optional()
});
export type AuditFinding = z.infer<typeof AuditFinding>;
