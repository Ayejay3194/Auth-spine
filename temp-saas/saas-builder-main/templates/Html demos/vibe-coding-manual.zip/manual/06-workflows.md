# Example End-to-End Workflows

## Workflow A – New Feature

1. Use the ideation prompt to define:
   - feature goal
   - user story
   - UX flow
2. Write a short spec in `docs/features/<feature-name>.md`.
3. In the IDE:
   - Ask the code model to scaffold:
     - a route in Next.js
     - a layout
     - a base component
4. Implement data model changes with Prisma (if needed).
5. Use Tailwind + your chosen component library to style it.
6. Use refactor prompts to:
   - clean up the component tree
   - extract hooks
   - ensure reusability.

## Workflow B – Cleanup and Hardening

1. Run the app and identify:
   - slow pages
   - complex components
   - duplicated patterns
2. Use the refactor prompts to:
   - simplify complex components
   - unify styling
   - move logic into hooks.
3. Add tests for the core logic where it makes sense.
4. Update `INTEGRATION_LOG.md` or `CHANGELOG.md` with what changed.
