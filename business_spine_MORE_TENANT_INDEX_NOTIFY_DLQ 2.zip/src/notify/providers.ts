import type { Notification } from "./types";

export interface EmailProvider { send(input: { to: string; subject: string; text: string }): Promise<void>; }
export interface SMSProvider { send(input: { to: string; text: string }): Promise<void>; }
export interface PushProvider { send(input: { to: string; title: string; body: string }): Promise<void>; }

export type NotifyProviders = { email: EmailProvider; sms: SMSProvider; push: PushProvider };

export const ConsoleEmail: EmailProvider = { async send(i){ console.log("[email]", i.to, i.subject, i.text); } };
export const ConsoleSMS: SMSProvider = { async send(i){ console.log("[sms]", i.to, i.text); } };
export const ConsolePush: PushProvider = { async send(i){ console.log("[push]", i.to, i.title, i.body); } };

export async function deliver(providers: NotifyProviders, n: Notification, rendered: { subject?: string; text: string }) {
  if (n.channel === "email") return providers.email.send({ to: n.to, subject: rendered.subject ?? "Notification", text: rendered.text });
  if (n.channel === "sms") return providers.sms.send({ to: n.to, text: rendered.text });
  return providers.push.send({ to: n.to, title: rendered.subject ?? "Notification", body: rendered.text });
}
