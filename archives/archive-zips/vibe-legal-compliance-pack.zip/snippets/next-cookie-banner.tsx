import React from "react";

type Consent = {
  preferences: boolean;
  analytics: boolean;
  marketing: boolean;
};

const STORAGE_KEY = "bb_consent_v1";

function loadConsent(): Consent | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Consent) : null;
  } catch {
    return null;
  }
}

function saveConsent(consent: Consent) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(consent));
  // TODO: POST to /api/consent to store proof server-side (recommended).
}

export function CookieBanner() {
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    const existing = loadConsent();
    if (!existing) setOpen(true);
  }, []);

  if (!open) return null;

  const acceptAll = () => {
    saveConsent({ preferences: true, analytics: true, marketing: true });
    setOpen(false);
  };

  const reject = () => {
    saveConsent({ preferences: false, analytics: false, marketing: false });
    setOpen(false);
  };

  const manage = () => {
    // For real apps: open a modal with toggles.
    saveConsent({ preferences: true, analytics: false, marketing: false });
    setOpen(false);
  };

  return (
    <div style={{
      position: "fixed", left: 16, right: 16, bottom: 16,
      background: "#111", color: "white", borderRadius: 16,
      padding: 16, display: "flex", gap: 12, alignItems: "center",
      justifyContent: "space-between", zIndex: 9999
    }}>
      <div style={{ maxWidth: 680 }}>
        <div style={{ fontWeight: 600 }}>Cookies</div>
        <div style={{ opacity: 0.85, fontSize: 14 }}>
          We use essential cookies to run the site. Optional analytics/marketing cookies are off until you choose.
        </div>
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <button onClick={reject}>Reject</button>
        <button onClick={manage}>Preferences</button>
        <button onClick={acceptAll}>Accept all</button>
      </div>
    </div>
  );
}
