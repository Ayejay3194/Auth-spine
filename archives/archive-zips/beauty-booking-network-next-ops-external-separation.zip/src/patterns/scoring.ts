import { prisma } from "@/lib/prisma";

const clamp = (x:number, lo:number, hi:number) => Math.max(lo, Math.min(hi, x));

export async function scoreNoShowRisk(clientUserId: string) {
  const feats = await prisma.entityFeatures.findUnique({ where:{ entityType_entityId: { entityType:"USER", entityId: clientUserId } } }).catch(()=>null);
  const f:any = feats?.features ?? {};
  const bookings = Number(f.bookings_90d ?? 0);
  const cancels = Number(f.cancels_90d ?? 0);
  const noShows = Number(f.no_shows_365d ?? 0);

  let risk = 0.15;
  if(bookings > 0) risk += (cancels / Math.max(1, bookings)) * 0.35;
  risk += clamp(noShows * 0.15, 0, 0.6);

  return clamp(risk, 0, 0.95);
}

export async function scoreDemandIndexForStylist(stylistId: string) {
  const now = new Date();
  const since14 = new Date(now); since14.setDate(since14.getDate() - 14);

  const confirmed14 = await prisma.booking.count({ where:{ stylistId, status:"CONFIRMED", createdAt:{ gte: since14 } } });
  const created14 = await prisma.booking.count({ where:{ stylistId, createdAt:{ gte: since14 } } });

  const ratio = created14 ? confirmed14 / created14 : 0;
  const volumeBoost = clamp(created14 / 20, 0, 1);

  return clamp(0.2 + ratio * 0.6 + volumeBoost * 0.2, 0, 1);
}

export function priceMultiplierFromDemand(demandIndex: number) {
  return clamp(0.95 + demandIndex * 0.30, 0.9, 1.3);
}
