import test from "node:test";
import assert from "node:assert/strict";
import { parseDateTime } from "../nlu/datetime.js";
import { IntentDetector } from "../nlu/intents.js";

test("date parsing handles next tuesday evening", () => {
  const now = new Date("2025-12-13T12:00:00Z");
  const dt = parseDateTime("next tuesday evening", now);
  assert.ok(dt.dateISO);
  assert.equal(dt.partOfDay, "evening");
});

test("intent detector can match booking", () => {
  const d = new IntentDetector([{ intent: "booking.create", any: ["book"], all: [] }], [{ intent: "booking.create", utterance: "book appointment" }], { minScore: 0.2 });
  const r = d.detect("book me");
  assert.equal(r.intent, "booking.create");
});
