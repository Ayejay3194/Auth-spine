# Deployment Checklist (print it if you’re allergic to outages)

## Before deploy
- [ ] CI green on main
- [ ] Migrations reviewed + staged
- [ ] Env vars present + validated
- [ ] Secrets not rotated mid-deploy unless planned
- [ ] Sentry/monitoring release created (if used)

## During deploy
- [ ] Deploy app
- [ ] Run migrations (or automated)
- [ ] Verify health endpoint
- [ ] Smoke test auth (signup/login/logout), critical flows

## After deploy
- [ ] Monitor error rate + latency for 30 minutes
- [ ] Verify background jobs/cron
- [ ] Confirm webhook deliveries (if any)
- [ ] If bad: rollback using documented steps
