# Vibe Coding Disasters Kit

Because “move fast and break things” is cute until you’re the one doing incident response.

## Contents
- `VIBE_CODING_DISASTERS.md`: master checklist
- `modules/`: split-by-area checklists
- `structured/`: JSON + JSONL risk register for building UI/workflows
- `templates/`: PR/release/CI guardrails

## Quick use
1) Drop `templates/PR_CHECKLIST.md` into your repo.
2) Make PRs fail if any CRITICAL/HIGH item applies and isn’t addressed.
3) Use `structured/risk_register.json` to generate an internal “preflight” checklist UI.
