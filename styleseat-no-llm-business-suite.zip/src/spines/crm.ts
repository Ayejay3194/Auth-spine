import { FlowDefinition } from "../flows/types.js";
import { Tool } from "../tools/types.js";
import { CRMProvider } from "../providers/types.js";

export function crmSpine(opts: { provider: CRMProvider }) {
  const { provider } = opts;

  const tools: Tool<any, any>[] = [
    {
      id: "crm.findClient",
      description: "Find client by query",
      validate: (i) => { if (!i.query || i.query.length < 2) throw new Error("Need a name/email"); },
      run: async (_ctx, input) => ({ ok: true, data: { client: await provider.findClient({ query: input.query }) } }),
      timeoutMs: 2500,
    },
    {
      id: "crm.addNote",
      description: "Add note to client",
      validate: (i) => { if (!i.clientId) throw new Error("Missing clientId"); if (!i.note) throw new Error("Missing note"); },
      run: async (_ctx, input) => { await provider.addNote({ clientId: input.clientId, note: input.note }); return { ok: true, data: { ok: true } }; },
      timeoutMs: 2500,
    },
    {
      id: "crm.tagClient",
      description: "Tag client",
      validate: (i) => { if (!i.clientId) throw new Error("Missing clientId"); if (!i.tag) throw new Error("Missing tag"); },
      run: async (_ctx, input) => { await provider.tagClient({ clientId: input.clientId, tag: input.tag }); return { ok: true, data: { ok: true } }; },
      timeoutMs: 2500,
    },
    {
      id: "crm.history",
      description: "Client history",
      validate: (i) => { if (!i.clientId) throw new Error("Missing clientId"); },
      run: async (_ctx, input) => ({ ok: true, data: await provider.history({ clientId: input.clientId }) }),
      timeoutMs: 2500,
    },
  ];

  const flows: FlowDefinition[] = [
    {
      intent: "crm.find_client",
      slots: [{ name: "query", required: true, fromEntity: (e) => e.find(x => x.type === "email")?.value ?? e.find(x => x.type === "phone")?.value ?? null }],
      steps: () => [
        { ask: { slot: "query", prompt: "Client name/email/phone?", hint: "client@email.com" } },
        { call: { toolId: "crm.findClient", inputFromSlots: (s) => ({ query: s.query }) } },
        { done: { message: "Found client (if they exist)." } },
      ],
    },
    {
      intent: "crm.add_note",
      slots: [{ name: "clientId", required: true }, { name: "note", required: true }],
      steps: () => [
        { ask: { slot: "clientId", prompt: "Client ID?", hint: "cl_123" } },
        { ask: { slot: "note", prompt: "Note to add?", hint: "Prefers evenings" } },
        { call: { toolId: "crm.addNote", inputFromSlots: (s) => ({ clientId: s.clientId, note: s.note }) } },
        { done: { message: "Note saved." } },
      ],
    },
    {
      intent: "crm.tag_client",
      slots: [{ name: "clientId", required: true }, { name: "tag", required: true, fromEntity: (e) => e.find(x => x.type === "tag")?.value ?? null }],
      steps: () => [
        { ask: { slot: "clientId", prompt: "Client ID?", hint: "cl_123" } },
        { ask: { slot: "tag", prompt: "Tag?", hint: "vip" } },
        { call: { toolId: "crm.tagClient", inputFromSlots: (s) => ({ clientId: s.clientId, tag: s.tag }) } },
        { done: { message: "Tagged." } },
      ],
    },
  ];

  return { tools, flows };
}
