import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, listFiles } from "../utils/fs.js";
import { detectFramework } from "./framework.js";

function normalizeRoute(p: string) {
  // Convert filesystem route fragments to URL-ish routes (best-effort)
  // app/foo/bar/page.tsx -> /foo/bar
  // pages/foo/bar.tsx -> /foo/bar
  // pages/index.tsx -> /
  const clean = p.replace(/\\/g, "/");
  let route = clean;

  route = route.replace(/^.*\/(app|pages)\//, "/");
  route = route.replace(/\/(page|index)\.(tsx|ts|jsx|js)$/, "/");
  route = route.replace(/\.(tsx|ts|jsx|js)$/, "/");
  route = route.replace(/\[\.\.\.(.*?)\]/g, ":$1*");
  route = route.replace(/\[(.*?)\]/g, ":$1");
  route = route.replace(/\/+/g, "/");
  if (!route.startsWith("/")) route = "/" + route;
  if (route.endsWith("/") && route !== "/") route = route.slice(0, -1);
  return route;
}

export function auditRoutes(root: string): AuditSection {
  const section: AuditSection = { id: "routes", title: "Route Crawl (Refresh 404)", findings: [] };
  const { framework } = detectFramework(root);

  const routes: string[] = [];

  if (framework === "next") {
    const appDir = path.join(root, "app");
    const pagesDir = path.join(root, "pages");

    if (exists(appDir)) {
      const files = listFiles(appDir, { max: 6000 });
      for (const f of files) {
        if (/\/page\.(tsx|ts|jsx|js)$/.test(f.replace(/\\/g,"/"))) routes.push(normalizeRoute(f));
      }
    }

    if (exists(pagesDir)) {
      const files = listFiles(pagesDir, { max: 6000 });
      for (const f of files) {
        const n = f.replace(/\\/g,"/");
        if (!/\.(tsx|ts|jsx|js)$/.test(n)) continue;
        if (n.includes("/api/")) continue;
        routes.push(normalizeRoute(f));
      }
    }

    const uniq = Array.from(new Set(routes)).sort();
    section.findings.push({
      id: "routes.next.list",
      title: `Discovered ${uniq.length} route files (best-effort)`,
      severity: "INFO",
      details: "This helps debug route refresh failures and missing pages in production.",
      evidence: { routes: uniq.slice(0, 250), truncated: uniq.length > 250 },
    });

    // Next usually handles routing at server level; but if deployed as static export, deep links can still break
    const hasOut = exists(path.join(root, "out"));
    if (hasOut) {
      section.findings.push({
        id: "routes.next.staticExport",
        title: "Static export detected (out/ folder exists)",
        severity: "WARN",
        details: "If you export Next statically, deep links can 404 without host rewrites.",
        fix: "Configure host rewrites for SPA-like behavior or avoid static export for dynamic routes.",
        evidence: { outFolder: True },
      });
    }

    return section;
  }

  // Non-Next: basic SPA signals
  const indexHtml = path.join(root, "index.html");
  if (exists(indexHtml)) {
    section.findings.push({
      id: "routes.spa.detected",
      title: "index.html found (likely SPA)",
      severity: "INFO",
      details: "If this is an SPA, refresh 404 issues depend on host rewrites.",
      fix: "Ensure you have a catch-all rewrite to index.html in your hosting config.",
    });
  } else {
    section.findings.push({
      id: "routes.none",
      title: "No route structure detected",
      severity: "INFO",
      details: "This auditor currently crawls Next routes or flags SPA index.html presence.",
    });
  }

  return section;
}
