import Link from "next/link";
import { Container } from "@/components/Container";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { MLNoShowCard } from "./mlCard";

export default async function PatternsAdmin(){
  const session = await auth();
  if(!session?.user?.email){
    return (
      <main className="py-10"><Container>
        <div className="rounded-[28px] border p-8" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
          <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Pattern Console</div>
          <h1 className="serif mt-2 text-3xl">Sign in.</h1>
          <div className="mt-6"><Link href="/auth/sign-in" className="rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>Sign in</Link></div>
        </div>
      </Container></main>
    );
  }

  const user = await prisma.user.findUnique({ where:{ email: session.user.email } });
  if(!user || !["OWNER","MANAGER","ADMIN"].includes(user.role)){
    return <main className="py-10"><Container>Not authorized.</Container></main>;
  }

  const latestScores = await prisma.entityScore.findMany({ orderBy:{ computedAt:"desc" }, take: 50 });

  return (
    <main className="py-10">
      <Container>
        <div className="flex items-end justify-between gap-4">
          <div>
            <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Pattern Console</div>
            <h1 className="serif mt-2 text-3xl">Scores (latest 50)</h1>
            <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>Run <code>npm run patterns:compute</code> to refresh.</div>
          </div>
          <Link href="/salon-admin/luxe-salon" className="rounded-2xl border px-5 py-3 text-sm font-semibold" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
            Salon admin →
          </Link>
        </div>

        <div className="mt-6">
          <MLNoShowCard />
        </div>

        <div className="mt-6 space-y-2">
          {latestScores.map(s => (
            <div key={s.id} className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-sm font-semibold">{s.scoreType}</div>
                <div className="text-xs" style={{color:"var(--dim)"}}>{new Date(s.computedAt).toLocaleString()} · {s.scopeKey}</div>
              </div>
              <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>
                {s.entityType}:{s.entityId} → <span className="font-semibold" style={{color:"var(--text)"}}>{s.scoreValue.toFixed(3)}</span>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </main>
  );
}
