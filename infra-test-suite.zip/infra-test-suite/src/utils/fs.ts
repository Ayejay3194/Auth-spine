import fs from "node:fs";
import path from "node:path";
import { globSync } from "glob";

export function readText(p: string): string | null {
  try { return fs.readFileSync(p, "utf-8"); } catch { return null; }
}

export function exists(p: string): boolean {
  try { fs.accessSync(p); return true; } catch { return false; }
}

export function findFiles(root: string, patterns: string[]): string[] {
  const out = new Set<string>();
  for (const pat of patterns) {
    for (const p of globSync(pat, { cwd: root, nodir: true, dot: true })) {
      out.add(path.join(root, p));
    }
  }
  return [...out];
}

export function rel(root: string, p: string): string {
  return path.relative(root, p).replace(/\\/g, "/");
}
