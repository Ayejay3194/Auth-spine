import type { RealtimeAdapter } from "@suite/modules-notifications";

export class ConsoleRealtimeAdapter implements RealtimeAdapter {
  async publish(userId: string, payload: unknown) {
    console.log(`\n[REALTIME] user=${userId}`, JSON.stringify(payload));
  }
}
