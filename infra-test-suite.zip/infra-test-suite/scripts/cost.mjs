import { section, ok, fail, readJson, exists, parseYaml, findFiles } from "./_util.mjs";

const cfg = readJson("./infra.config.json");
const requiredTags = new Set((cfg.policy?.required_tags ?? []).map(String));

section("Tagging policy checks (IaC metadata)");
let offenders = [];

for(const dir of (cfg.paths.terraform ?? [])){
  if(!exists(dir)) continue;
  const tf = findFiles(dir, [".tf"]);
  for(const f of tf){
    // cheap heuristic: ensure required tags mentioned somewhere
    const t = (await import("node:fs")).default.readFileSync(f,"utf-8");
    for(const tag of requiredTags){
      if(!t.includes(tag)) { offenders.push({file:f, missing:tag}); break; }
    }
  }
}

if(offenders.length){
  console.log("Files that may be missing required cost tags (heuristic):");
  for(const o of offenders.slice(0,30)) console.log(`- ${o.file} (missing ${o.missing})`);
  fail("Cost tagging policy violated (or your tagging is centralized somewhere else). Fix or tune the heuristic.");
} else {
  ok("Cost tagging heuristic passed");
}

section("Budget/alert config presence (placeholders are not enough)");
const budgetDocs = ["./cost/budgets.md", "./cost/alerts.md"];
const missing = budgetDocs.filter(p=>!exists(p));
if(missing.length){
  for(const m of missing) console.log("Missing: " + m);
  fail("Cost governance docs missing. Cloud bills do not care about your feelings.");
} else {
  ok("Cost governance docs exist");
}
