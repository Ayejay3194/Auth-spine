CREATE TABLE IF NOT EXISTS auth_ops_logs (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  tenant_id TEXT,
  user_id TEXT,
  provider TEXT
);

CREATE INDEX IF NOT EXISTS idx_auth_ops_logs_occurred_at
  ON auth_ops_logs (occurred_at DESC);

CREATE INDEX IF NOT EXISTS idx_auth_ops_logs_type
  ON auth_ops_logs (type);
