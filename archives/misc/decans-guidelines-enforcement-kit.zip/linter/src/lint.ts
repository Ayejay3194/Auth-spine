import fs from "node:fs";
import path from "node:path";

type Rules = {
  forbidden_phrases: string[];
  soft_warnings: { absolute_words: string[]; prophecy_words: string[] };
  tiers: { tier: string; min_words: number; max_words: number }[];
};

function countWords(text: string): number {
  return (text.trim().match(/\S+/g) ?? []).length;
}

function findMatches(textLower: string, needles: string[]) {
  const hits: { needle: string; count: number }[] = [];
  for (const n of needles) {
    const re = new RegExp(n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g");
    const m = textLower.match(re);
    if (m && m.length) hits.push({ needle: n, count: m.length });
  }
  return hits;
}

function main() {
  const input = process.argv[2];
  const tier = process.argv[3] ?? "Free";
  if (!input) {
    console.error("Usage: npm run dev -- <path-to-text-file> <Tier>");
    process.exit(1);
  }

  const rulesPath = path.resolve(process.cwd(), "..", "rules.json");
  const rules = JSON.parse(fs.readFileSync(rulesPath, "utf-8")) as Rules;

  const text = fs.readFileSync(path.resolve(input), "utf-8");
  const wc = countWords(text);
  const tierRule = rules.tiers.find(t => t.tier === tier) ?? rules.tiers[0];

  const textLower = text.toLowerCase();

  const forbiddenHits = findMatches(textLower, rules.forbidden_phrases.map(s => s.toLowerCase()));
  const absoluteHits = findMatches(textLower, rules.soft_warnings.absolute_words.map(s => s.toLowerCase()));
  const prophecyHits = findMatches(textLower, rules.soft_warnings.prophecy_words.map(s => s.toLowerCase()));

  const errors: string[] = [];
  const warnings: string[] = [];

  if (wc < tierRule.min_words || wc > tierRule.max_words) {
    warnings.push(`Word count ${wc} is outside ${tier} target range (${tierRule.min_words}-${tierRule.max_words}).`);
  }

  if (forbiddenHits.length) {
    for (const h of forbiddenHits) errors.push(`Forbidden phrase: "${h.needle}" x${h.count}`);
  }

  if (absoluteHits.length) {
    for (const h of absoluteHits) warnings.push(`Absolute language: "${h.needle}" x${h.count}`);
  }

  if (prophecyHits.length) {
    for (const h of prophecyHits) warnings.push(`Prophecy-ish phrasing: "${h.needle}" x${h.count}`);
  }

  const result = { tier, word_count: wc, errors, warnings };

  console.log(JSON.stringify(result, null, 2));

  process.exit(errors.length ? 2 : 0);
}

main();
