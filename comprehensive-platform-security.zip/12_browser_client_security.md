BROWSER & CLIENT-SIDE SECURITY

Covers:
- Security headers
- CSP
- Client-side attack prevention