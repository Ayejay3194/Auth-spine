KILL SWITCHES
=============

These are sacred.

GLOBAL
------
- Disable bookings
- Disable payments
- Freeze payroll
- Pause notifications
- Lock admin writes

REQUIREMENTS
------------
- One click
- Logged
- Reversible
- Permission-gated

If you’re scared to press it, it’s working.
