TENANT OFFBOARDING & DATA DELETION

Account Cancellation
- Self-service cancellation + confirmation
- End-of-period vs immediate behavior
- Refund + proration correctness
- Retention window communication
- Reactivation window
- Suspension before deletion
- Cancellation audit logging

Data Deletion
- Hard delete vs anonymization rules
- Cascading deletion across services
- Backup deletion schedule (after retention)
- CDN purge, search index deletion, analytics deletion
- Third-party deletion coordination
- Deletion verification + certificate (enterprise)
- Irreversible recovery after deletion
