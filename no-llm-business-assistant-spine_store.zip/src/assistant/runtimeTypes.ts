import type { Role } from "../core/types.js";

export type AgentContext = {
  businessId: string;
  userId: string;
  role: Role | "system";
  timezone?: string;
  locale?: string;
  channel?: "web" | "chat" | "api" | "cmdk";
};

export type Clock = { now: () => Date };

export type AuditEvent = {
  businessId: string;
  actorId: string;
  role: string;
  type: string;
  at: Date;
  details: Record<string, unknown>;
};

export interface AuditLogger {
  write(ev: AuditEvent): Promise<void>;
}

export type AssistantState = {
  pendingConfirm?: { token: string; lastText: string };
};

export type AssistantReply = {
  text: string;
  ui?: any;
  done?: boolean;
};

export type AssistantHandleResult = {
  state: AssistantState;
  reply: AssistantReply;
};
