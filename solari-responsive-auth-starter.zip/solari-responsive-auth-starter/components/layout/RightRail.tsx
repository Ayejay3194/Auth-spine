"use client";
import Link from "next/link";

export function RightRail({ route }: { route: string }) {
  const isMap = route === "map";

  return (
    <aside className="lg:sticky lg:top-20 lg:h-[calc(100vh-6rem)]">
      {!isMap ? <MiniMapCard /> : <FeedCard />}
      <div className="mt-4 glass rounded-xl2 p-4">
        <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Now</div>
        <div className="mt-3 flex flex-wrap gap-2 text-xs text-white/70">
          <span className="pill">Route: {route}</span>
          <span className="pill">Rail: {isMap ? "feed" : "mini-map"}</span>
        </div>
      </div>
    </aside>
  );
}

function MiniMapCard() {
  return (
    <div className="glass rounded-xl2 p-4">
      <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Mini map</div>
      <div className="mt-3 h-44 rounded-2xl border border-white/10 bg-white/5 relative overflow-hidden">
        <Pin x="28%" y="38%" />
        <Pin x="56%" y="52%" dim />
        <Pin x="72%" y="30%" dim />
      </div>
      <div className="mt-3 text-xs text-white/60">
        Shows on non-map pages. Rail should not mirror the current page.
      </div>
    </div>
  );
}

function FeedCard() {
  return (
    <div className="glass rounded-xl2 p-4">
      <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Quick check feed</div>
      <div className="mt-3 grid gap-2">
        <Item title="Inbox" sub="3 unread + clinic update" href="/inbox" />
        <Item title="Boards" sub="2 new posts in radius" href="/boards" />
        <Item title="Me" sub="preferences: safety + visibility" href="/profile" />
        <Item title="Signals" sub="Glow medium • Radius 1.5mi" href="/map" />
      </div>
      <div className="mt-3 text-xs text-white/60">
        Shows on map only. Not another map.
      </div>
    </div>
  );
}

function Pin({ x, y, dim }: { x: string; y: string; dim?: boolean }) {
  return (
    <div
      className={"absolute h-2.5 w-2.5 rounded-full bg-yellow-100 shadow-[0_0_0_6px_rgba(231,199,118,.18),0_0_22px_rgba(231,199,118,.45)] " + (dim ? "opacity-70" : "")}
      style={{ left: x, top: y, transform: "translate(-50%,-50%)" }}
    />
  );
}

function Item({ title, sub, href }: { title: string; sub: string; href: string }) {
  return (
    <Link href={href} className="rounded-2xl border border-white/10 bg-white/5 p-3 hover:bg-white/10 transition">
      <div className="font-extrabold text-sm">{title}</div>
      <div className="text-xs text-white/60 mt-0.5">{sub}</div>
    </Link>
  );
}
