import SwiftUI

struct CupertinoBlankState: View {
    var body: some View {
        VStack(spacing: 12) {
            Text("⎯").font(.system(size: 22))
            Text("Nothing here yet").font(.headline)
            Text("Waiting for data.").font(.subheadline).foregroundStyle(.secondary)
            Button("Get Started") {}
                .buttonStyle(.borderedProminent)
        }
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }
}
