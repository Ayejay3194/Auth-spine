import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export function sha256(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

export function randomId(prefix = ""): string {
  return prefix + randomBytes(16).toString("hex");
}

export function verifyHash(plain: string, hash: string): boolean {
  const computed = sha256(plain);
  const a = Buffer.from(computed);
  const b = Buffer.from(hash);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}
