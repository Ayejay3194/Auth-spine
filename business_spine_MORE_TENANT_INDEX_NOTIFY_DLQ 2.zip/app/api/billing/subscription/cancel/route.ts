import { z } from "zod";
import { api } from "@/src/core/api";
import { prisma } from "@/lib/prisma";
import { getActor } from "@/src/core/auth";

const Q = z.object({ subscriptionId: z.string() });
export async function POST(req: Request) {
  return api(async () => {
    const actor = getActor(req);
    const body = Q.parse(await req.json());
    const sub = await prisma.subscription.findUnique({ where: { id: body.subscriptionId } });
    if (!sub || sub.userId !== actor.userId) return { error: "not_found" };
    await prisma.subscription.update({ where: { id: sub.id }, data: { status: "canceled" } });
    return { ok: true };
  });
}
