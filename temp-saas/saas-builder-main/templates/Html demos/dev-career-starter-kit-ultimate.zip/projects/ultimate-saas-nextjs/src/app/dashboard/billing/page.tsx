export default function BillingPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Billing</h1>
      <p className="text-sm text-slate-300">
        This page is wired for Stripe integration. Your tasks:
      </p>
      <ul className="list-disc pl-5 text-sm text-slate-300 space-y-1">
        <li>Show current plan from the Subscription model.</li>
        <li>Add a button to start a checkout session.</li>
        <li>Add a button to open the Stripe customer portal.</li>
      </ul>
    </div>
  );
}
