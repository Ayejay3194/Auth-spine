import { test, expect } from '@playwright/test';

/**
 * End-to-end tests for complete user flows
 */

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

test.describe('User Journey E2E Tests', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(BASE_URL);
  });

  test('homepage loads successfully', async ({ page }) => {
    await expect(page).toHaveTitle(/Auth-Spine Platform/);

    const heading = page.locator('h1');
    await expect(heading).toContainText('Auth-Spine Platform');

    const featureCards = page.locator('div').filter({ hasText: /Core Platform|Operations Spine|AI Assistant/ });
    await expect(featureCards.first()).toBeVisible();
  });

  test('dashboard navigation works', async ({ page }) => {
    await page.click('text=Dashboard');
    await expect(page).toHaveURL(/dashboard/);

    const content = page.locator('main');
    await expect(content).toBeVisible();
  });

  test('API documentation is accessible', async ({ page }) => {
    await page.click('text=API Documentation');
    await expect(page).toHaveURL(/swagger/);

    const swagger = page.locator('#swagger-ui');
    await expect(swagger).toBeVisible({ timeout: 10000 });
  });

  test('operations panel is accessible', async ({ page }) => {
    await page.goto(`${BASE_URL}/admin/auth-ops`);
    const panel = page.locator('main');
    await expect(panel).toBeVisible();
  });

  test('metrics endpoint returns data', async ({ page }) => {
    const response = await page.goto(`${BASE_URL}/api/metrics`);

    expect(response?.status()).toBe(200);

    const contentType = response?.headers()['content-type'];
    expect(contentType).toContain('text/plain');

    const body = await response?.text();
    expect(body).toContain('# HELP');
    expect(body).toContain('# TYPE');
  });

  test('responsive design works on mobile', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 });

    const heading = page.locator('h1');
    await expect(heading).toBeVisible();

    const featureGrid = page.locator('div.grid');
    await expect(featureGrid).toBeVisible();
  });

  test('quick links are functional', async ({ page }) => {
    const links = [
      { text: 'Dashboard', url: /dashboard/ },
      { text: 'Operations Panel', url: /admin\/auth-ops/ },
    ];

    for (const link of links) {
      await page.goto(BASE_URL);
      await page.click(`text=${link.text}`);
      await expect(page).toHaveURL(link.url);
    }
  });
});

test.describe('Authentication Flow E2E', () => {
  test('login page should be accessible', async ({ page }) => {
    // Note: if your auth is API-only, replace with your real login UI route.
    await page.goto(`${BASE_URL}/api/auth/login`);

    const response = await page.waitForResponse(/auth\/login/);
    expect(response.status()).toBeLessThan(500);
  });
});

test.describe('Performance Tests', () => {
  test('homepage loads within acceptable time', async ({ page }) => {
    const start = Date.now();

    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');

    const loadTime = Date.now() - start;
    expect(loadTime).toBeLessThan(3000);
  });

  test('API requests respond quickly', async ({ page }) => {
    const start = Date.now();

    const response = await page.goto(`${BASE_URL}/api/metrics`);

    const responseTime = Date.now() - start;

    expect(response?.status()).toBe(200);
    expect(responseTime).toBeLessThan(1000);
  });
});
