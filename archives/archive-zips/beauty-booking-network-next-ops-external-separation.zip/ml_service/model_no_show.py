import os
import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression

MODEL_DIR = os.environ.get("MODEL_DIR", "./models")
os.makedirs(MODEL_DIR, exist_ok=True)
MODEL_PATH = os.path.join(MODEL_DIR, "no_show_logreg.joblib")

FEATURES = ["bookings_90d", "cancels_90d", "no_shows_365d"]

def train(df):
  X = df[FEATURES].fillna(0).astype(float).values
  y = df["label"].astype(int).values

  if len(np.unique(y)) < 2:
    joblib.dump({"model": None, "fallback_risk": float(y.mean()) if len(y) else 0.15}, MODEL_PATH)
    return {"ok": True, "note": "insufficient label diversity, stored fallback"}

  model = LogisticRegression(max_iter=1000)
  model.fit(X, y)
  joblib.dump({"model": model, "fallback_risk": 0.15}, MODEL_PATH)
  return {"ok": True, "classes": model.classes_.tolist()}

def load():
  if not os.path.exists(MODEL_PATH):
    return {"model": None, "fallback_risk": 0.15}
  return joblib.load(MODEL_PATH)

def score(features: dict) -> float:
  blob = load()
  model = blob.get("model")
  if model is None:
    return float(blob.get("fallback_risk", 0.15))
  x = np.array([[float(features.get(k, 0)) for k in FEATURES]])
  p = model.predict_proba(x)[0][1]
  return float(p)
