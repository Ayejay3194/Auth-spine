import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { db } from '@/lib/db'
import { ROLE_PERMISSIONS } from '@/lib/permissions'

// GET /api/workspaces/active - Get active workspace
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
        { status: 401 }
      )
    }

    // Get user's first workspace as default active workspace
    const membership = await db.workspaceMember.findFirst({
      where: {
        userId: session.user.id
      },
      include: {
        workspace: true
      },
      orderBy: {
        joinedAt: 'asc'
      }
    })

    if (!membership) {
      return NextResponse.json(
        { success: false, error: { code: 'NO_WORKSPACE', message: 'No workspaces found' } },
        { status: 404 }
      )
    }

    const permissions = ROLE_PERMISSIONS[membership.role]

    return NextResponse.json({
      success: true,
      data: {
        workspace: membership.workspace,
        membership,
        permissions
      }
    })
  } catch (error) {
    console.error('Failed to get active workspace:', error)
    return NextResponse.json(
      { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to get active workspace' } },
      { status: 500 }
    )
  }
}