export const toolRegistry = new Map<string, Function>();
