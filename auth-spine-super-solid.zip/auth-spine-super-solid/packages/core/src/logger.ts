import pino from 'pino'
import type { AppError } from './errors.js'

const transport =
  process.env.NODE_ENV === 'development'
    ? { target: 'pino-pretty', options: { colorize: true } }
    : undefined

const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  transport: transport as any,
})

export const log = {
  error: (error: Error | AppError, context?: Record<string, any>) => {
    const base: any = {
      message: error.message,
      stack: error.stack,
      ...context,
    }
    if ((error as any).code) base.code = (error as any).code
    if ((error as any).statusCode) base.statusCode = (error as any).statusCode
    if ((error as any).details) base.details = (error as any).details
    logger.error(base)
  },
  warn: (message: string, context?: Record<string, any>) => logger.warn({ message, ...context }),
  info: (message: string, context?: Record<string, any>) => logger.info({ message, ...context }),
  debug: (message: string, context?: Record<string, any>) => logger.debug({ message, ...context }),
}
