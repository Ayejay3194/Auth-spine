# MOBILE-SPECIFIC DISASTERS

## Mobile App Issues

- [ ] App crashes frequently
- [ ] Memory leaks on mobile
- [ ] Battery drain excessive
- [ ] Data usage excessive
- [ ] Offline mode not working
- [ ] Poor network handling
- [ ] Not caching data
- [ ] Images not optimized for mobile
- [ ] Videos auto-playing on cellular
- [ ] Background sync draining battery
- [ ] Location tracking always on
- [ ] Push notifications too frequent
- [ ] Deep links not working
- [ ] Universal links broken
- [ ] App store description outdated
- [ ] Screenshots outdated
- [ ] No app rating prompts
- [ ] Negative reviews not addressed

## Platform-Specific Problems

- [ ] iOS and Android inconsistent
- [ ] Platform-specific bugs
- [ ] Not using native UI patterns
- [ ] Android back button broken
- [ ] iOS swipe gestures broken
- [ ] Safe area not respected
- [ ] Notch issues on iPhone
- [ ] Keyboard covering inputs
- [ ] Status bar issues
- [ ] Navigation bar issues
- [ ] Split screen not supported
- [ ] iPad layout broken
- [ ] Tablet UI not optimized
- [ ] Rotation issues
- [ ] Dark mode not implemented
- [ ] Dark mode broken

---
