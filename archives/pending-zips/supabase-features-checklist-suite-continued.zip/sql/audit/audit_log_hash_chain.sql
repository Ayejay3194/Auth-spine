-- Audit log table with optional hash chaining (tamper-evident-ish)
create table if not exists audit_log (
  id bigserial primary key,
  occurred_at timestamptz not null default now(),
  actor_id uuid null,
  actor_role text null,
  ip inet null,
  user_agent text null,
  tenant_id uuid null,
  action text not null,
  entity text null,
  entity_id text null,
  details jsonb not null default '{}'::jsonb,
  prev_hash text null,
  entry_hash text null
);

create index if not exists audit_log_tenant_time_idx on audit_log (tenant_id, occurred_at desc);
create index if not exists audit_log_action_time_idx on audit_log (action, occurred_at desc);

-- Hash chaining: compute entry_hash = sha256(prev_hash || canonical_fields)
-- Requires pgcrypto extension for digest().
create or replace function audit_compute_hash()
returns trigger
language plpgsql
as $$
declare
  prev text;
  material text;
begin
  select entry_hash into prev from audit_log order by id desc limit 1;
  new.prev_hash := prev;

  material :=
    coalesce(new.prev_hash,'') || '|' ||
    coalesce(new.actor_id::text,'') || '|' ||
    coalesce(new.actor_role,'') || '|' ||
    coalesce(new.ip::text,'') || '|' ||
    coalesce(new.user_agent,'') || '|' ||
    coalesce(new.tenant_id::text,'') || '|' ||
    coalesce(new.action,'') || '|' ||
    coalesce(new.entity,'') || '|' ||
    coalesce(new.entity_id,'') || '|' ||
    coalesce(new.details::text,'');

  new.entry_hash := encode(digest(material, 'sha256'), 'hex');
  return new;
end;
$$;

drop trigger if exists audit_log_hash_trg on audit_log;
create trigger audit_log_hash_trg
before insert on audit_log
for each row execute function audit_compute_hash();
