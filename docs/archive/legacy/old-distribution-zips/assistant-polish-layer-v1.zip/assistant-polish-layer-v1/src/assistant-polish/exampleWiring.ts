import type { PolishState } from "./types";
import { humanDelay } from "./humanDelay";
import { maybeAcknowledge } from "./ack";
import { sanitizeCopy } from "./sanitize";
import { finalizeReply } from "./finalize";

/**
 * Example: wrap your existing reply function.
 * Call this at the edge where you send the assistant message.
 */
export async function polishReply(state: PolishState, rawReply: string) {
  // 1) micro delay (optional)
  await humanDelay(200, 550);

  // 2) add short acknowledgment sometimes
  const ack = maybeAcknowledge(state, 0.35);

  // 3) sanitize corporate bot phrases
  let out = sanitizeCopy(ack + rawReply);

  // 4) remove end-of-turn filler
  out = finalizeReply(out);

  state.lastAssistantText = out;
  return out;
}
