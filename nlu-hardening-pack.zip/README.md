# NLU Hardening Pack

## What this is
A production-safe NLU system:
- Client UI calls server
- Server calls Anthropic securely
- Strict JSON output
- Trace IDs for auditing

## Setup
1. Add ANTHROPIC_API_KEY to env
2. Drop into Next.js app router
3. Import classifyNLU on client

## Guarantees
- No API key leaks
- JSON-safe parsing
- Fail-closed responses
