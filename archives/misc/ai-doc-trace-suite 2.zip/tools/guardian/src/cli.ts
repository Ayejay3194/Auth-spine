#!/usr/bin/env node
import path from "node:path";
import { writeFile } from "node:fs/promises";
import { createManifest, saveManifest, loadManifest } from "./manifest.js";
import { diffManifests } from "./diff.js";
import { loadPolicy } from "./policy.js";
import { enforce as enforcePolicy } from "./enforce.js";
import { buildMarkdownReport } from "./report.js";

function usage() {
  console.log(`guardian <cmd>

scan      Create/overwrite .guardian/manifest.json
diff      Compare last manifest to current state (prints JSON)
report    Write .guardian/report.md based on current diff
enforce   Fail if policy violations are detected
selftest  Quick sanity checks
`);
}

async function main() {
  const root = process.cwd();
  const cmd = process.argv[2];
  if (!cmd) { usage(); process.exit(1); }

  try {
    if (cmd === "scan") {
      const m = await createManifest(root);
      const fp = await saveManifest(root, m);
      console.log(`Wrote manifest: ${fp}`);
      return;
    }

    if (cmd === "selftest") {
      const p = await loadPolicy(root);
      if (!p.protected?.length) throw new Error("policy.protected empty");
      const m = await createManifest(root);
      await saveManifest(root, m);
      console.log("Selftest OK");
      return;
    }

    const policy = await loadPolicy(root);
    const before = await loadManifest(root);
    const after = await createManifest(root);
    const diff = diffManifests(before, after);

    if (cmd === "diff") {
      console.log(JSON.stringify(diff, null, 2));
      return;
    }

    if (cmd === "report") {
      const md = buildMarkdownReport(diff, policy);
      const outPath = path.join(root, policy.synopsisOutput);
      await writeFile(outPath, md);
      console.log(`Wrote report: ${outPath}`);
      return;
    }

    if (cmd === "enforce") {
      const violations = await enforcePolicy(root, policy, diff);
      if (policy.requireSynopsis) {
        const md = buildMarkdownReport(diff, policy);
        const outPath = path.join(root, policy.synopsisOutput);
        await writeFile(outPath, md);
      }
      if (violations.length) {
        console.error(`Policy violations (${violations.length}):`);
        for (const vi of violations) console.error(`- [${vi.code}] ${vi.message}`);
        process.exit(1);
      }
      console.log("Enforce: OK");
      return;
    }

    usage();
    process.exit(1);
  } catch (e: any) {
    console.error(`guardian failed: ${e?.message ?? e}`);
    process.exit(1);
  }
}

main();
