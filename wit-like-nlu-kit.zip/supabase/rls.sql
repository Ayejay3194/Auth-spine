alter table nlu_examples enable row level security;
alter table nlu_parse_logs enable row level security;

create policy "nlu_examples_read" on nlu_examples
for select to authenticated using (true);

create policy "nlu_examples_write" on nlu_examples
for insert to authenticated with check (true);

create policy "nlu_logs_write" on nlu_parse_logs
for insert to authenticated with check (true);

create policy "nlu_logs_read" on nlu_parse_logs
for select to authenticated using (true);
