PRODUCT INTENT REGISTRY
=======================

Every feature/change must reference an intent entry.

Fields:
- intent_id
- feature_name
- primary_user
- problem_solved
- problem_not_solved
- misuse_cases
- success_definition
- failure_definition
- owner
- created_at
- reviewed_at
