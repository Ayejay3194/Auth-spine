# Terms of Service (Template)

**Last updated:** {{DATE}}

## 1. Who we are
This platform is operated by **{{COMPANY_NAME}}** (“Company”, “we”, “us”).  
Contact: {{CONTACT_EMAIL}}. Address: {{COMPANY_ADDRESS}}.

## 2. What this is
We provide a booking + portfolio platform for beauty professionals and their clients (“Service”).

## 3. Eligibility
You must be at least **{{MIN_AGE}}** years old to use the Service. If you use the Service on behalf of a business, you represent you have authority to bind it.

## 4. Accounts
You are responsible for:
- maintaining accurate account information
- safeguarding credentials
- all activity under your account

We may suspend accounts for suspected fraud, abuse, or policy violations.

## 5. User content
You keep ownership of content you upload (photos, text, portfolios), but you grant us a license to host, display, and distribute it as needed to operate the Service.

You represent you have rights to upload what you upload.

## 6. Bookings, payments, cancellations
### Booking flow
Bookings may be confirmed instantly or require approval based on stylist/salon settings.

### Payments
Payments are processed by our payment processor(s) (e.g., {{PAYMENT_PROCESSOR}}). We do not store full card numbers.

### Fees
Platform fees, commissions, and payout timing are disclosed at checkout and in your dashboard.

### Cancellations & refunds
Cancellation/refund rules may vary by stylist/salon. The policy shown at booking applies.

## 7. Prohibited use (summary)
You may not:
- break laws, violate rights, or post illegal content
- harass, exploit, or impersonate others
- attempt to access accounts/data you don’t own
- scrape or reverse engineer the Service
- upload malware or malicious files

Full details in the Acceptable Use Policy.

## 8. Intellectual property
The Service, software, and branding are owned by Company (excluding user content).

## 9. Disclaimers
The Service is provided “as is” and “as available”, except where prohibited by law.

## 10. Limitation of liability
To the maximum extent permitted by law, Company will not be liable for indirect or consequential damages. Liability caps: {{LIABILITY_CAP}}.

## 11. Indemnification
You agree to defend and indemnify Company from claims arising from your content, conduct, or bookings.

## 12. Termination
You can stop using the Service at any time. We may suspend/terminate access for violations or risk.

## 13. Changes
We may update these terms and will provide notice as required. Continued use after effective date means acceptance.

## 14. Governing law & disputes
Governing law: {{JURISDICTION}}. Venue: {{VENUE}}.  
Dispute resolution: {{ARBITRATION_OR_COURT}}.

## 15. Contact
Questions: {{CONTACT_EMAIL}}
