import type { AuditStore } from "@suite/core-audit";

export type WebhookEndpoint = {
  id: string;
  ownerId: string;
  url: string;
  secret: string;
  events: string[];
  active: boolean;
};

export type WebhookDelivery = {
  id: string;
  endpointId: string;
  event: string;
  payload: unknown;
  attempt: number;
  status: "pending" | "sent" | "failed";
  lastError?: string;
  createdAt: string;
  updatedAt: string;
};

export interface WebhookSigner {
  sign(secret: string, body: string, ts: string): string;
  verify(secret: string, body: string, ts: string, sig: string): boolean;
}

export interface WebhookStore {
  addEndpoint(ep: Omit<WebhookEndpoint,"id">): Promise<WebhookEndpoint>;
  listEndpoints(ownerId: string): Promise<WebhookEndpoint[]>;
  logDelivery(d: Omit<WebhookDelivery,"id"|"createdAt"|"updatedAt">): Promise<WebhookDelivery>;
  listDeliveries(endpointId: string, limit?: number): Promise<WebhookDelivery[]>;
}

export interface WebhookDeliveryEngine {
  deliver(endpoint: WebhookEndpoint, event: string, payload: unknown): Promise<WebhookDelivery>;
}

export class WebhookService {
  constructor(private store: WebhookStore, private engine: WebhookDeliveryEngine, private audit: AuditStore) {}

  async createEndpoint(ownerId: string, ep: Omit<WebhookEndpoint,"id"|"ownerId">) {
    const created = await this.store.addEndpoint({ ...ep, ownerId });
    await this.audit.append({ actor:{ actorType:"user", userId: ownerId }, action:"webhook.endpoint.created", targetType:"webhookEndpoint", targetId: created.id, metadata: { url: created.url, events: created.events } });
    return created;
  }

  async emit(ownerId: string, event: string, payload: unknown) {
    const endpoints = (await this.store.listEndpoints(ownerId)).filter(e => e.active && e.events.includes(event));
    const deliveries: WebhookDelivery[] = [];
    for (const ep of endpoints) deliveries.push(await this.engine.deliver(ep, event, payload));
    return deliveries;
  }
}
