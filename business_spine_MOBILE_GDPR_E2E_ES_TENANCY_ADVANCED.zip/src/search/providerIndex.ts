import { es } from "./esClient";
import { INDEX_PROVIDERS } from "./indexes";

export type ProviderDoc = {
  id: string;
  tenantId: string;
  name: string;
  bio?: string;
  specialties?: string[];
  location?: { lat: number; lon: number };
  rating?: number;
};

export async function ensureProviderIndex() {
  const client = es();
  const exists = await client.indices.exists({ index: INDEX_PROVIDERS });
  if (exists) return;
  await client.indices.create({
    index: INDEX_PROVIDERS,
    mappings: { properties: {
      tenantId: { type: "keyword" },
      name: { type: "text" },
      bio: { type: "text" },
      specialties: { type: "keyword" },
      location: { type: "geo_point" },
      rating: { type: "float" },
    }},
  });
}

export async function upsertProvider(doc: ProviderDoc) {
  await es().index({ index: INDEX_PROVIDERS, id: doc.id, document: doc });
}

export async function searchProviders(input: { tenantId: string; q: string; size?: number }) {
  const res = await es().search({
    index: INDEX_PROVIDERS,
    size: input.size ?? 20,
    query: {
      bool: {
        filter: [{ term: { tenantId: input.tenantId } }],
        must: input.q
          ? [{ multi_match: { query: input.q, fields: ["name^3", "specialties^2", "bio"] } }]
          : [{ match_all: {} }],
      },
    },
  });
  return res.hits.hits.map(h => ({ id: h._id, ...(h._source as any) }));
}
