import { RiskContext } from "../types";

export function detectRiskContext(text: string): RiskContext {
  const t = text.toLowerCase();
  if (/(suicide|self-harm|kill myself)/.test(t)) return "risk_sensitive";
  if (/(diagnos|symptom|medication|doctor|pain)/.test(t)) return "medical";
  if (/(lawsuit|attorney|legal advice|court)/.test(t)) return "legal";
  if (/(funeral|grief|passed away)/.test(t)) return "grief";
  if (/(panic attack|can’t breathe|panic)/.test(t)) return "panic";
  if (/(trauma|abuse|assault)/.test(t)) return "trauma";
  return "none";
}
