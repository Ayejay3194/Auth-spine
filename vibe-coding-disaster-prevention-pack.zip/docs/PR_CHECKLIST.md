# PR Checklist (paste into PRs)

## Security
- [ ] No secrets committed (secret scan passes)
- [ ] AuthZ enforced server-side (not just UI)
- [ ] Inputs validated (schema validation)
- [ ] No dangerouslySetInnerHTML with user content
- [ ] RLS enabled + policies updated for any new tables

## Data & DB
- [ ] Migrations included (no manual prod edits)
- [ ] Indexes added for new query paths
- [ ] Pagination on list endpoints
- [ ] Transactions used for multi-step operations

## UX
- [ ] Loading state
- [ ] Error state
- [ ] Mobile sanity check
- [ ] Keyboard nav for dialogs/forms

## Ops
- [ ] Logs are structured + redacted
