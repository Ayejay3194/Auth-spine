# Business Spine Test Harness (Hardened)

This is a cleaned-up, deterministic test + validation harness for your Business Spine.
It fixes the main problems in your pasted script:
- Mixed module systems (ESM `import` + `require.main`)
- Flaky time usage (`new Date()` everywhere)
- Absolute paths baked into tests
- "Benchmarks" living inside unit tests
- Starting a real server without guaranteed teardown
- CORS origin mismatch / port reuse / no port discovery

## What’s inside
- `tests/e2e/api.e2e.test.ts` — real HTTP smoke tests (start server, hit endpoints, shutdown)
- `tests/unit/rbac.middleware.test.ts` — isolated RBAC tests (Vitest)
- `tests/unit/routing.test.ts` — route registry assertions (no network)
- `tests/unit/org.structure.test.ts` — directory structure checks (relative to repo root)
- `tests/unit/final.validator.test.ts` — turns your “FinalValidator” into deterministic tests
- `tests/bench/perf.bench.ts` — benchmarks gated behind `RUN_PERF=1`
- `tests/helpers/testServer.ts` — shared start/stop helpers (with random available port)
- `vitest.setup.ts` — environment + time freeze helpers

## How to run
1) Install deps:
```bash
npm i -D vitest @types/node
```

2) Add scripts:
```json
{
  "scripts": {
    "test": "vitest run",
    "test:watch": "vitest",
    "test:perf": "RUN_PERF=1 vitest run tests/bench/perf.bench.ts"
  }
}
```

3) Add Vitest config (optional but recommended):
```ts
// vitest.config.ts
import { defineConfig } from "vitest/config";
export default defineConfig({
  test: {
    environment: "node",
    setupFiles: ["./vitest.setup.ts"],
    testTimeout: 30000
  }
});
```

## Assumptions
- Your build output exports: `createBusinessSpine`, `startServer`, `ApiServer` from `../dist/index.js`
- `spine.shutdown()` exists (or you can adapt `stopSpine()` in helper)
- Your server exposes: `/health`, `/api/chat`, `/api/intent`, `/api/suggestions`, `/api/system/info`

If any names differ, update `tests/helpers/testServer.ts` once and the rest stays stable.