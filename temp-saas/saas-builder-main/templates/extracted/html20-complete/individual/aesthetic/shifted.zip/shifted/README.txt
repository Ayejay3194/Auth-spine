Shifted – HTML Template

Description
----------
Hero-focused storytelling page.
Audience: Offer / funnel

This is a simple, responsive HTML/CSS template designed for easy editing and use on static hosting (Netlify, Vercel, GitHub Pages, etc.).
All layout and styling are contained in `index.html` and `assets/css/style.css`, with a very small script in `assets/js/script.js` for optional enhancements.

How to edit
-----------
1. Open `index.html` in any code editor.
2. Replace placeholder text in the hero, About, Sections, and Contact areas with your own content.
3. Search for comments and labels if you need guidance on what to edit.
4. Update the email, social handle, and location in the Contact section.
5. To change colors or fonts, edit `assets/css/style.css`:
   - Look at the `body { ... }` CSS variables near the top for colors.
   - Add or change `font-family` declarations if you want a different typography setup.

How to use
----------
- You can upload this folder to your web host as-is.
- If using a static host, make sure `index.html` is at the root of the deployed directory.
- If you embed a form or external widget, paste its embed code into the Contact section.

License
-------
You may use and modify this template for personal or commercial projects.
You may include it in client work or use it as part of a digital product, subject to your own shop policies.
Please do not resell the raw files without meaningful changes.
