import { describe, it, expect } from "vitest";
import { BASE_URL, TEST } from "../tools/config";
import { http } from "../tools/http";
import { ensureTenant, loginUser, authHeaders } from "../tools/auth";

/**
 * This suite checks behaviors that often get "forgotten":
 * - logout actually revokes
 * - tokens aren't accepted after logout (if you do server-side revocation)
 * - sessions list doesn't leak device metadata
 */
describe("security: token/session behaviors", () => {
  it("logout revokes session (if /api/auth/logout exists)", async () => {
    await ensureTenant(TEST.tenants.a);
    const token = await loginUser(TEST.users.a);

    // Call logout if endpoint exists
    const logout = await http("POST", `${BASE_URL}/api/auth/logout`, { headers: await authHeaders(token) });
    if (logout.status === 404) {
      // Your API might use /auth/logout instead
      const logout2 = await http("POST", `${BASE_URL}/auth/logout`, { headers: await authHeaders(token) });
      if (logout2.status === 404) {
        // No logout endpoint: that's a product decision, but it means token revocation is probably "delete token on client"
        expect(true).toBe(true);
        return;
      }
    }

    // After logout, /api/auth/me should reject (if it exists)
    const me = await http("GET", `${BASE_URL}/api/auth/me`, { headers: await authHeaders(token) });
    if (me.status !== 404) {
      expect([401, 403]).toContain(me.status);
    } else {
      // Alternative endpoint
      const me2 = await http("GET", `${BASE_URL}/auth/me`, { headers: await authHeaders(token) });
      if (me2.status !== 404) expect([401, 403]).toContain(me2.status);
    }
  });

  it("tokens should not be trivially forgeable (heuristic)", async () => {
    await ensureTenant(TEST.tenants.a);
    const token = await loginUser(TEST.users.a);

    // Heuristic: JWT has 2 dots. If you aren't using JWT, fine, but then you must have server-side lookup.
    const isJwtLike = token.split(".").length === 3;
    // If it's base64 JSON or similar, it's suspicious.
    const looksLikeBase64Json = (() => {
      try {
        const maybe = Buffer.from(token, "base64").toString("utf8");
        return maybe.trim().startsWith("{") && maybe.includes("user");
      } catch { return false; }
    })();

    // Don't hard-fail JWT vs non-JWT, but hard-fail obviously forgeable tokens.
    expect(looksLikeBase64Json).toBe(false);
    expect(typeof isJwtLike).toBe("boolean");
  });
});
