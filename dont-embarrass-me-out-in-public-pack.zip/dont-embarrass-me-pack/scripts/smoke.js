/* Minimal smoke checks. This is intentionally dumb and fast. */
import fs from "fs";

const required = [
  "JWT_SECRET",
  "AUDIT_SECRET",
  "FEATURE_FLAG_DEFAULTS"
];

let ok = true;
for (const k of required) {
  if (!process.env[k] || String(process.env[k]).length < 10) {
    console.error(`Missing/weak env: ${k}`);
    ok = false;
  }
}

if (!fs.existsSync("./src/security/policy.ts")) {
  console.error("Missing hardening sources (src/security/policy.ts)");
  ok = false;
}

if (!ok) process.exit(1);
console.log("Smoke checks passed.");
