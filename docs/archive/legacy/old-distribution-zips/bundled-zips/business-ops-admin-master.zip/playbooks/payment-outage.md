PAYMENT OUTAGE
--------------
1. Disable new payments
2. Notify admin
3. Notify users
4. Reconcile after recovery
