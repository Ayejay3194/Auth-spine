# Security Pack: Internal vs External + Platform Hardening (Next.js)

This is a **drop-in security kit** for your beauty booking platform.
It includes:
- Separation controls (public vs studio vs ops)
- RBAC/ABAC patterns
- Headers/CSP templates
- Rate limiting + brute force protection patterns
- Audit logging + PII access logging patterns
- Incident response playbooks + runbooks
- CI security gates (SAST, deps scan, secret scan, SBOM)
- Threat model + data flow templates
- Compliance evidence folder structure (SOC2-ready vibes)

> This pack is **implementation-ready templates + code snippets**, not a magic spell.

## Folder map
- `/policies` security policies + procedures
- `/architecture` diagrams + data flow + threat model templates
- `/app` copy/paste code for Next.js (middleware, headers, guards, rate limit)
- `/infra` reverse proxy + WAF notes + network segmentation templates
- `/cicd` GitHub Actions security workflows
- `/runbooks` incident response, on-call, breach, DR
- `/checklists` build + release + vendor checklists
- `/evidence` starter evidence collection structure

## Quick start
1) Pick your separation model:
- `app.<domain>` (public)
- `studio.<domain>` (stylist)
- `ops.<domain>` (internal)

2) Copy these into your Next app:
- `app/next/security-headers.ts`
- `app/next/middleware-host-separation.ts`
- `app/next/rbac.ts`
- `app/next/rate-limit.ts`
- `app/next/csrf.ts`
- `app/next/audit.ts`

3) Add CI workflows from `/cicd/github-actions/`.

4) Run the go-live checklist in `/checklists/go-live.md`.
