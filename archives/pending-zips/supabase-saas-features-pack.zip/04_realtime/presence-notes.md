# Presence in Supabase Realtime
- Use Realtime Presence (channels) for "online/typing"
- Persist "last_seen" in DB for durable state
- Ghost cleanup: TTL job updates stale presence

E2E encryption is client-side only.
