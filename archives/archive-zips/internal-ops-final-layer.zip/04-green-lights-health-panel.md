GREEN LIGHTS PANEL
==================

This is the “nothing is on fire” screen.

Indicators:
-----------
🟢 Payments: processing normally
🟢 Payroll: next run scheduled
🟢 Scheduling: no conflicts detected
🟢 Inventory: above reorder thresholds
🟢 Notifications: within limits
🟢 Integrations: healthy

Rules:
------
- No charts
- No scrolling
- Red means action required
- Green means stop touching things

This panel is for owners, not analysts.
