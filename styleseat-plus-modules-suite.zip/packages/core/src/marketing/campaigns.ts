import type { ID, ISODateTime, Result } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type Channel = "email" | "sms" | "push";

export type Template = { id: ID; name: string; subject?: string; body: string; previewText?: string; channel: Channel };

export type Campaign = {
  id: ID;
  businessId: ID;
  name: string;
  channel: Channel;
  templateId: ID;
  segmentId: ID;
  enabled: boolean;
};

export type SendEvent = {
  id: ID;
  campaignId: ID;
  businessId: ID;
  channel: Channel;
  toId: ID; // clientId
  at: ISODateTime;
  status: "sent" | "failed";
  error?: string;
};

export interface Messenger {
  send(channel: Channel, toId: ID, template: Template, vars: Record<string, any>): Promise<Result<true>>;
}

export class CampaignService {
  private campaigns: Campaign[] = [];
  private templates: Template[] = [];
  private sends: SendEvent[] = [];

  createTemplate(t: Omit<Template,"id">): Template { const tt = { ...t, id: cuid("tpl") }; this.templates.push(tt); return tt; }
  listTemplates(channel?: Channel) { return channel ? this.templates.filter(t => t.channel === channel) : [...this.templates]; }

  createCampaign(c: Omit<Campaign,"id">): Campaign { const cc = { ...c, id: cuid("cmp") }; this.campaigns.push(cc); return cc; }
  listCampaigns(businessId: ID) { return this.campaigns.filter(c => c.businessId === businessId); }

  async runCampaign(input: { campaignId: ID; audience: ID[]; at: ISODateTime; vars?: Record<string, any> }, messenger: Messenger): Promise<Result<{ sent: number; failed: number }>> {
    const c = this.campaigns.find(x => x.id === input.campaignId);
    if (!c) return { ok: false, error: { code: "NOT_FOUND", message: "Campaign not found" } };
    if (!c.enabled) return { ok: false, error: { code: "DISABLED", message: "Campaign disabled" } };
    const tpl = this.templates.find(t => t.id === c.templateId);
    if (!tpl) return { ok: false, error: { code: "TEMPLATE_MISSING", message: "Template missing" } };

    let sent=0, failed=0;
    for (const toId of input.audience) {
      const res = await messenger.send(c.channel, toId, tpl, input.vars ?? {});
      const ev: SendEvent = { id: cuid("snd"), campaignId: c.id, businessId: c.businessId, channel: c.channel, toId, at: input.at, status: res.ok ? "sent" : "failed", error: res.ok ? undefined : res.error.message };
      this.sends.push(ev);
      res.ok ? sent++ : failed++;
    }
    return { ok: true, data: { sent, failed } };
  }

  listSends(businessId: ID, limit=200) { return this.sends.filter(s => s.businessId === businessId).slice(-limit).reverse(); }
}
