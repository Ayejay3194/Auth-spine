import fs from "node:fs/promises";
import path from "node:path";
import { Table as ArrowTable, Float64Vector } from "apache-arrow";
import { writeArrowTableToParquet } from "../io/parquetArrow.js";
import { writeMetrics } from "../metrics/metrics.js";
import { LakeConfig, datasetBase } from "../io/paths.js";

async function seed(cfg: LakeConfig) {
  const dir = datasetBase(cfg, "training_residuals", "v1");
  await fs.mkdir(dir, { recursive: true });
  const file = path.join(dir, "snapshot.parquet");
  const t = ArrowTable.new({
    err_mag: Float64Vector.from([0.2,0.4,0.55,0.9,1.2,2.2,0.7,0.3,1.8]),
  });
  await writeArrowTableToParquet(file, t, { compression: "zstd" });
  return file;
}

async function run() {
  const cfg = { root: "./lake" };
  const file = await seed(cfg);

  const res = await writeMetrics({
    cfg,
    input: { dataset: "training_residuals", version: "v1", file },
    output: { dataset: "training_residuals_metrics", version: "v1", schemaVersion: "1" },
    histograms: [{ col: "err_mag", bins: 6, min: 0, max: 3 }],
    generator: "writeMetrics@local"
  });

  console.log(res);
}

run().catch((e) => { console.error(e); process.exit(1); });
