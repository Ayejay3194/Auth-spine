import type { NextApiRequest, NextApiResponse } from "next";
import { envBool, isProd } from "../../lib/security/env";

// Gate OpenAPI in prod unless explicitly allowed
export default function handler(_req: NextApiRequest, res: NextApiResponse) {
  if (isProd() && !envBool(process.env.ALLOW_PUBLIC_OPENAPI, false)) {
    res.status(404).json({ error: "Not found" });
    return;
  }

  // Replace with your real OpenAPI generator/output
  res.status(200).json({
    openapi: "3.0.0",
    info: { title: "API", version: "0.0.0" },
    paths: {}
  });
}
