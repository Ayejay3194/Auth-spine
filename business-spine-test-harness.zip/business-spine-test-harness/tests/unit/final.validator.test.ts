import { describe, test, expect } from "vitest";

describe("Final validator (deterministic)", () => {
  test("spine initializes, loads expected spines, exposes tools", async () => {
    const { createBusinessSpine } = await import("../../dist/index.js");

    const spine = await createBusinessSpine({
      tenantId: "validation-tenant"
    });

    try {
      const spines = spine.getSpines?.() ?? [];
      const names = spines.map((s: any) => s.name);

      // Use invariants instead of exact lists if you expect growth.
      const mustHave = ["booking", "crm"];
      for (const req of mustHave) {
        expect(names.includes(req)).toBe(true);
      }

      const tools = spine.getTools?.() ?? spine.tools ?? {};
      expect(Object.keys(tools).length).toBeGreaterThan(0);
    } finally {
      await spine.shutdown?.();
    }
  });

  test("intent detection returns ranked intents with a spine", async () => {
    const { createBusinessSpine } = await import("../../dist/index.js");
    const spine = await createBusinessSpine({ tenantId: "validation-tenant" });

    try {
      const ctx = {
        actor: { userId: "test", role: "admin" as const },
        tenantId: "validation-tenant",
        nowISO: new Date("2024-01-15T12:00:00.000Z").toISOString()
      };

      const detect = spine.getOrchestrator?.().detect ?? spine.orchestrator?.detect;
      expect(typeof detect).toBe("function");

      const intents = detect("book appointment", ctx) ?? [];
      expect(Array.isArray(intents)).toBe(true);
      if (intents.length) {
        expect(intents[0]).toHaveProperty("spine");
      }
    } finally {
      await spine.shutdown?.();
    }
  });
});