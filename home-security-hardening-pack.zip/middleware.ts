import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { buildSecurityHeaders } from "./src/lib/security/headers";
import { envBool, envList, isProd, safeEqual } from "./src/lib/security/env";

const SWAGGER_PATHS = ["/swagger", "/api/openapi.json"];
const METRICS_PATHS = ["/api/metrics", "/metrics"];

function isAllowedByIp(req: NextRequest, allowlist: string[]) {
  if (!allowlist.length) return false;
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.ip ||
    "";
  return allowlist.includes(ip);
}

function deny(status = 404) {
  return new NextResponse("Not found", { status });
}

export function middleware(req: NextRequest) {
  const url = req.nextUrl;
  const pathname = url.pathname;

  // Always set security headers
  const res = NextResponse.next();
  for (const [k, v] of buildSecurityHeaders()) res.headers.set(k, v);

  // Block swagger/openapi in production unless explicitly allowed
  if (SWAGGER_PATHS.some((p) => pathname === p || pathname.startsWith(p + "/"))) {
    if (isProd()) {
      const allowSwagger = envBool(process.env.ALLOW_PUBLIC_SWAGGER, false);
      const allowOpenapi = envBool(process.env.ALLOW_PUBLIC_OPENAPI, false);

      const isSwagger = pathname.startsWith("/swagger");
      const isOpenapi = pathname.startsWith("/api/openapi.json");

      if ((isSwagger && !allowSwagger) || (isOpenapi && !allowOpenapi)) {
        return deny(404);
      }
    }
  }

  // Metrics should not be public. Gate by token OR IP allowlist.
  if (METRICS_PATHS.some((p) => pathname === p)) {
    const allowIps = envList(process.env.METRICS_IP_ALLOWLIST);
    const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
    const expected = process.env.METRICS_TOKEN ?? "";

    const okByIp = isAllowedByIp(req, allowIps);
    const okByToken = expected && token && safeEqual(token, expected);

    if (!okByIp && !okByToken) {
      return deny(404);
    }
  }

  return res;
}

export const config = {
  matcher: [
    /*
      Apply to all routes except:
      - Next.js internals
      - static assets
    */
    "/((?!_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml).*)",
  ],
};
