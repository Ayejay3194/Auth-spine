import { describe, it, expect } from "vitest";
import { BASE_URL } from "../tools/config";
import { http } from "../tools/http";

describe("security: baseline health", () => {
  it("GET /health returns ok", async () => {
    const r = await http("GET", `${BASE_URL}/health`);
    expect([200, 204]).toContain(r.status);
  });

  it("GET /api/health returns ok (if present)", async () => {
    const r = await http("GET", `${BASE_URL}/api/health`);
    // allow 404 if your app only has /health
    expect([200, 204, 404]).toContain(r.status);
  });
});
