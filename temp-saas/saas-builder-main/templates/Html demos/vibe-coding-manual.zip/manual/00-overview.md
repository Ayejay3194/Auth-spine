# Vibe Coding: Overview

Goal:
Use AI tools as collaborators so you can design, build, and refactor modern frontend apps quickly without losing control of the architecture.

The core loop:

1. **Idea & product shape**  
   Use a general-purpose chat model (e.g. GPT) to:
   - Brainstorm product and features.
   - Define user stories, screens, and flows.
   - Rough out the data model and API contracts.

2. **System intake & zip structuring**  
   Use GLM / chat.z.ai as a "zip librarian":
   - Feed it file trees and key files from existing or starter repos.
   - Let it summarize, classify, and propose a modular structure.
   - Get a manifest describing the system.

3. **Implementation & refactor**  
   Use Claude/code-focused models inside Windsurf or Cursor:
   - Generate components, layouts, hooks, and API handlers.
   - Refactor code for clarity and separation of concerns.
   - Add tests and clean up technical debt incrementally.

4. **UI stack alignment**  
   Use a consistent frontend stack:
   - React + Next.js
   - TailwindCSS
   - DaisyUI or MUI or shadcn/ui (pick one primary component layer per app)
   - lucide-react for icons
   - React Context for global state where needed

5. **Keep it clean**  
   Use the included prompts for:
   - Refactoring components.
   - Extracting hooks.
   - Simplifying complex JSX.
   - Standardizing layout and UI patterns.
   - Enforcing a design system.

The rest of this manual walks through each step with ready-made prompts.
