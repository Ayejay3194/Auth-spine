import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { z } from "zod";

const Create = z.object({
  name: z.string().min(1),
  durationMin: z.number().int().min(15).max(600),
  basePriceCents: z.number().int().min(0).max(200000),
  category: z.string().optional(),
});

async function getStylistId(){
  const session = await auth();
  if(!session?.user?.email) return null;
  const user = await prisma.user.findUnique({ where:{ email: session.user.email }, include:{ stylistProfile:true } });
  return user?.stylistProfile?.id ?? null;
}

export async function GET(){
  const stylistId = await getStylistId();
  if(!stylistId) return new Response("Unauthorized", { status:401 });
  const services = await prisma.serviceTemplate.findMany({ where:{ stylistId }, orderBy:{ createdAt:"desc" } });
  return Response.json({ services });
}

export async function POST(req: Request){
  const stylistId = await getStylistId();
  if(!stylistId) return new Response("Unauthorized", { status:401 });
  const data = Create.parse(await req.json());
  const created = await prisma.serviceTemplate.create({
    data: { stylistId, name:data.name, durationMin:data.durationMin, basePriceCents:data.basePriceCents, category:data.category || null }
  });
  return Response.json({ service: created });
}
