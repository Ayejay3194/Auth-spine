import { AgentContext } from "../core/types.js";

export interface PolicyDecision {
  ok: boolean;
  code?: "RATE_LIMIT" | "FORBIDDEN" | "CONFIRM_REQUIRED";
  message?: string;
  meta?: Record<string, unknown>;
}

export interface PolicyEngine {
  checkTool(ctx: AgentContext, toolId: string, meta?: Record<string, unknown>): Promise<PolicyDecision>;
  checkFlowCommit(ctx: AgentContext, intent: string, meta?: Record<string, unknown>): Promise<PolicyDecision>;
}
