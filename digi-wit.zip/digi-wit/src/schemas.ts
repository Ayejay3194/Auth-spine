import { z } from "zod";
import type { IntentMap } from "./types.js";

/**
 * Built-in intent specs. Keep these minimal and strict.
 * You can supply your own intents map in DigiWitRouter.
 */

// Common entity helpers
export const zUuid = z.string().uuid();
export const zIsoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Expected YYYY-MM-DD");
export const zRange = z.enum(["day", "week", "month", "year"]);
export const zChartType = z.enum(["natal", "synastry", "transit", "solar_return"]);

export const builtInIntents: IntentMap = {
  get_transits: {
    name: "get_transits",
    schema: z.object({
      chartId: zUuid,
      range: zRange.default("week"),
      startDate: zIsoDate.optional(),
      endDate: zIsoDate.optional(),
    }).strict(),
  },

  calculate_chart: {
    name: "calculate_chart",
    schema: z.object({
      chartType: zChartType.default("natal"),
      dateTimeUtc: z.string().datetime(),
      lat: z.number().min(-90).max(90),
      lon: z.number().min(-180).max(180),
      houseSystem: z.string().min(1).max(32).default("placidus"),
      zodiac: z.enum(["tropical", "sidereal"]).default("tropical"),
    }).strict(),
  },

  export_chart_pdf: {
    name: "export_chart_pdf",
    schema: z.object({
      chartId: zUuid,
      style: z.enum(["modern", "traditional", "print"]).default("modern"),
    }).strict(),
  },

  compare_synastry: {
    name: "compare_synastry",
    schema: z.object({
      chartIdA: zUuid,
      chartIdB: zUuid,
      method: z.enum(["synastry", "composite", "davison"]).default("synastry"),
    }).strict(),
  },
};
