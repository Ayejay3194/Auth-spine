import type { NextRequest } from "next/server";
import { withRequestId } from "./middleware/requestId";

/**
 * Add correlation IDs for every request.
 * This makes ops investigations way faster.
 */
export function middleware(req: NextRequest) {
  const { response } = withRequestId(req);
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
