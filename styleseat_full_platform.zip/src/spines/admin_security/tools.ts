// admin_security tools.ts
