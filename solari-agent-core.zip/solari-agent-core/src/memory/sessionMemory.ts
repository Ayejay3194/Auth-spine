export interface SessionMemory {
  usedToneIds: Set<string>;
  lastIntensities: number[];
  sarcasmLock: boolean;
  tolerance: number; // 0..1
}

export function newSessionMemory(): SessionMemory {
  return { usedToneIds: new Set(), lastIntensities: [], sarcasmLock: false, tolerance: 0.6 };
}

export function recordTone(session: SessionMemory, ids: string[], intensities: number[]) {
  ids.forEach(id => session.usedToneIds.add(id));
  intensities.forEach(i => session.lastIntensities.push(i));
  if (session.lastIntensities.length > 8) session.lastIntensities.splice(0, session.lastIntensities.length - 8);
}
