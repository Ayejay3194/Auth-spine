import { describe, it, expect } from "vitest";

describe("Full auth flow", () => {
  it("placeholder", async () => {
    expect(true).toBe(true);
  });
});
