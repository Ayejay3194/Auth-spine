export type LogLevel = "debug" | "info" | "warn" | "error";

export function createLogger(level: LogLevel = (process.env.LOG_LEVEL as LogLevel) || "info") {
  const rank: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40 };
  const min = rank[level] ?? 20;

  function log(lvl: LogLevel, msg: string, meta?: any) {
    if ((rank[lvl] ?? 99) < min) return;
    const out = { ts: new Date().toISOString(), level: lvl, msg, ...(meta ? { meta } : {}) };
    // Structured JSON for ELK.
    console.log(JSON.stringify(out));
  }

  return {
    debug: (m: string, meta?: any) => log("debug", m, meta),
    info:  (m: string, meta?: any) => log("info", m, meta),
    warn:  (m: string, meta?: any) => log("warn", m, meta),
    error: (m: string, meta?: any) => log("error", m, meta),
  };
}
