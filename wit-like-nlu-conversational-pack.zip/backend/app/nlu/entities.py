import re
from rapidfuzz import process, fuzz

SERVICES = {"haircut":["cut","trim","haircut"], "color":["color","dye","highlights","balayage"], "manicure":["nails","manicure"]}
STYLISTS = {"alex":["alex","alexis"], "mia":["mia","mya"]}

TIME_RE = re.compile(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b", re.I)
DATE_WORDS = {"today":"today", "tomorrow":"tomorrow"}

def _best_match(text: str, mapping: dict):
    choices = []
    for canonical, syns in mapping.items():
        for s in syns:
            choices.append((s, canonical))
    found = process.extractOne(text.lower(), [c[0] for c in choices], scorer=fuzz.WRatio)
    if not found:
        return None
    term, score, idx = found
    if score < 86:
        return None
    return choices[idx][1], score/100.0

class EntityExtractor:
    def extract(self, text: str) -> list[dict]:
        ents = []
        t = text.lower()

        sm = _best_match(t, SERVICES)
        if sm:
            val, conf = sm
            ents.append({"name":"service","value":val,"confidence":round(conf,3)})

        st = _best_match(t, STYLISTS)
        if st:
            val, conf = st
            ents.append({"name":"stylist","value":val,"confidence":round(conf,3)})

        m = TIME_RE.search(t)
        if m:
            hour = int(m.group(1)); minute = int(m.group(2) or 0); ampm = (m.group(3) or "").lower()
            ents.append({"name":"time","value":{"hour":hour,"minute":minute,"ampm":ampm},"confidence":0.9})

        for w, v in DATE_WORDS.items():
            if w in t:
                ents.append({"name":"date","value":v,"confidence":0.8})

        return ents
