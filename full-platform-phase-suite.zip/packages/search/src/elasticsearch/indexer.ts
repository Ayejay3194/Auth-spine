import type { ID } from "@suite/core";
import type { ElasticsearchClient } from "./client.js";

export type IndexDoc = { id: ID; tenantId: ID; type: string; body: any };

export class Indexer {
  constructor(private es: ElasticsearchClient) {}

  async upsert(doc: IndexDoc) {
    await this.es.index(this.indexName(doc.tenantId, doc.type), doc.id, { ...doc.body, tenantId: doc.tenantId, type: doc.type });
  }

  async bulkUpsert(docs: IndexDoc[]) {
    const ops = docs.flatMap(d => [
      { index: { _index: this.indexName(d.tenantId, d.type), _id: d.id } },
      { ...d.body, tenantId: d.tenantId, type: d.type }
    ]);
    await this.es.bulk(ops);
  }

  async search(tenantId: ID, type: string, q: string) {
    return this.es.search(this.indexName(tenantId, type), {
      query: { multi_match: { query: q, fields: ["name^3", "title^2", "description", "tags"] } }
    });
  }

  private indexName(tenantId: ID, type: string) { return `${tenantId}_${type}`.toLowerCase(); }
}
