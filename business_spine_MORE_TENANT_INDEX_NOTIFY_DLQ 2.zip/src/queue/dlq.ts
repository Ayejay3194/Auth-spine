/**
 * Dead-letter queue pattern:
 * - On permanent failure, write a DLQ record to DB or a separate queue.
 * This is a stub so you can standardize behavior.
 */
export async function writeDLQ(input: { tenantId?: string; jobName: string; payload: any; error: string }) {
  console.error("[DLQ]", input.jobName, input.error);
  // TODO: persist to DB table DeadLetterEvent (tenantId, jobName, payload, error, at)
}
