# ml-spine-delta-lite

A **Delta-ish** commit log for a Parquet lake. Not real Delta Lake, but it gives you the key behaviors:
- append-only commit log per table (dataset+version)
- optimistic concurrency via `expectedHead` (prevents silent clobber)
- time travel reads by commit id (or "latest")
- explicit schema version + file hashes in commits

This is designed for your ML spine: auditable datasets, deterministic training snapshots, and reproducible metrics.

## Run demos
```bash
npm i
npm run dev:write
npm run dev:read
npm run dev:compile
```

## What this is (and isn't)
- ✅ Commit journal + time travel + conflict detection (single-process safe; best-effort multi-process)
- ✅ Parquet as immutable data files
- ✅ Explicit manifests inside commits
- ❌ Full Delta Lake protocol
- ❌ ACID across distributed writers
- ❌ Automatic compaction / vacuum (you can add later)

If you want full Delta, you use Delta Lake / Iceberg / Hudi. If you want **control + simplicity** in TS, this is your lane.
