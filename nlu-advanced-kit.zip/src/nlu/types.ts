export type ID = string;

export type IntentName = string;
export type EntityName = string;

export type Confidence = number; // 0..1

export type EntitySpan = {
  entity: EntityName;
  value: string;
  start: number;
  end: number;
  normalized?: unknown;
  source?: "regex" | "dictionary" | "llm" | "memory";
};

export type IntentMatch = {
  name: IntentName;
  confidence: Confidence;
  method: "keyword" | "retrieve" | "llm" | "fallback";
  reasoning?: string;
};

export type NLUResult = {
  text: string;
  intent: IntentMatch;
  entities: EntitySpan[];
  // Signals useful for dialogue:
  isQuestion?: boolean;
  language?: string;
};

export type SlotName = string;

export type SlotSpec = {
  name: SlotName;
  entity: EntityName;
  required?: boolean;
  // optional simple validation
  validate?: "nonempty" | "date" | "number";
  prompt?: string; // clarifying question hint
};

export type IntentSpec = {
  name: IntentName;
  description: string;
  examples: string[];
  slots?: SlotSpec[];
  confirmationStyle?: "auto" | "ask";
};

export type EntitySpec = {
  name: EntityName;
  description: string;
  examples: string[];
  synonyms?: Record<string, string>; // "nyc" -> "new york"
  normalizer?: "date" | "location" | "number" | "string";
};

export type NLUModel = {
  version: string;
  updatedAt: string;
  intents: IntentSpec[];
  entities: EntitySpec[];
  settings?: {
    temperature?: number;
    // thresholds
    minConfidenceToAct?: number; // default 0.55
    minConfidenceToSkipClarify?: number; // default 0.75
  };
};

export type DialogueState = {
  sessionId: string;
  activeIntent?: IntentName;
  // slots collected for the active intent:
  slots: Record<SlotName, { value: unknown; raw?: string; entity?: EntityName; confidence?: number; }>;
  // conversational context
  lastUserText?: string;
  lastIntent?: IntentName;
  lastEntities?: EntitySpan[];
  // references like "there", "that time"
  references: {
    lastLocation?: string;
    lastDate?: string; // ISO
  };
  // internal bookkeeping
  turn: number;
  updatedAt: string;
};

export type AssistantReply = {
  text: string;
  // if you want to render structured UI
  suggestions?: string[];
  debug?: Record<string, unknown>;
};

export type AnalyzeTurnInput = {
  text: string;
  sessionId: string;
  // optional model override
  model?: NLUModel;
  // if you run server-side, you can inject a persistence adapter
  persistState?: boolean;
  // debugging
  debug?: boolean;
};

export type AnalyzeTurnOutput = {
  nlu: NLUResult;
  state: DialogueState;
  reply: AssistantReply;
};
