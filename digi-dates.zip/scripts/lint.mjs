import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) out.push(...walk(p));
    else out.push(p);
  }
  return out;
}

const files = walk(new URL("../src", import.meta.url).pathname).filter(f => f.endsWith(".ts"));
let ok = true;

for (const f of files) {
  const s = readFileSync(f, "utf8");
  if (s.includes("Date.parse(")) {
    console.error("Avoid Date.parse for user input:", f);
    ok = false;
  }
}

if (!ok) process.exit(1);
console.log("digi-dates lint: ok");
