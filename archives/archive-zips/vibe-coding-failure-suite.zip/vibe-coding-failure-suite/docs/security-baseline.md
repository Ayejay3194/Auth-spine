# Security Baseline (Minimum Bar)

If you skip these, you are not “moving fast”. You are just generating vulnerabilities faster.

## Auth/AuthZ
- Server-enforce authorization. Frontend checks are vibes, not security.
- Short-lived access tokens + refresh rotation.
- MFA for admins.
- Rate limit login, signup, password reset.

## Data access
- Enable RLS on every table by default.
- Default deny: start with no access, then open the minimum.
- Never ship the service role key to the client. Ever.

## Input/output
- Validate inputs server-side (schema validation).
- Encode output; never trust user content in HTML.
- Parameterize queries.

## Secrets
- `.env` never committed. Rotate keys after exposure.
- Separate dev/stage/prod keys.
- Use least-privilege API keys.

## File uploads
- Enforce type + size.
- Sanitize names/paths.
- Store outside webroot.
- Scan for malware if you accept public uploads.

## Observability
- Centralized logs.
- Redact tokens/PII.
- Alert on auth anomalies and 5xx spikes.
