
export type ModerationAction =
  | "hide_listing"
  | "remove_review"
  | "limit_account"
  | "suspend_account";

export interface ModerationLog {
  targetId: string;
  action: ModerationAction;
  reason: string;
  at: string;
}

export class ModerationSpine {
  async act(targetId: string, action: ModerationAction, reason: string): Promise<ModerationLog> {
    return { targetId, action, reason, at: new Date().toISOString() };
  }
}
