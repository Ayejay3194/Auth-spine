import { Container } from "@/components/Container";
import { prisma } from "@/lib/prisma";
import { BookButton } from "./ui";
import { FollowButton } from "./FollowButton";
import { ViewPing } from "./viewPing";

export default async function StylistPage({ params }:{ params:{ slug:string } }){
  const stylist = await prisma.stylistProfile.findUnique({
    where:{ slug: params.slug },
    include:{
      services: true,
      memberships: { where:{ status:"ACTIVE" }, include:{ salon:true }, orderBy:{ effectiveFrom:"desc" }, take: 1 }
    }
  });
  if(!stylist || !stylist.isActive) return <main className="py-10"><Container>Not found.</Container></main>;

  const membership = stylist.memberships[0] || null;
  const salon = membership?.salon || null;
  const settings: any = membership?.settings || {};
  const gallery: string[] = Array.isArray(stylist.gallery) ? (stylist.gallery as any) : [];

  return (
    <main className="py-10">
      <Container>
        <div className="overflow-hidden rounded-[28px] border" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
          <div className="relative h-[420px] w-full">
            <div className="absolute inset-0" style={{backgroundImage:`linear-gradient(to top, color-mix(in srgb, var(--bg) 82%, transparent), transparent), url(${stylist.heroUrl||stylist.avatarUrl||""})`, backgroundSize:"cover", backgroundPosition:"center"}}/>
            <div className="absolute inset-0" style={{background:"linear-gradient(to top, color-mix(in srgb, var(--bg) 70%, transparent), transparent 55%)"}}/>
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Portfolio</div>
              <h1 className="serif mt-2 text-4xl">{stylist.displayName}</h1>
              <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>
                {stylist.title || "Stylist"} · {salon ? salon.name : "Independent"} {salon ? `· ★ ${salon.rating.toFixed(1)}` : ""}
              </div>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <FollowButton stylistId={stylist.id} />
                <BookButton stylistId={stylist.id} stylistName={stylist.displayName} />
                {settings.requireApprovalForNewClients ? (
                  <div className="rounded-2xl border px-4 py-3 text-xs tracking-[.16em] uppercase" style={{borderColor:"var(--border)", background:"var(--panel2)", color:"var(--dim)"}}>
                    Some bookings require approval
                  </div>
                ) : null}
              </div>
            </div>
          </div>

          <div className="p-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>About</div>
                <p className="mt-2 text-sm leading-relaxed" style={{color:"var(--muted)"}}>{stylist.bio || "Luxury results with a calm appointment experience."}</p>
              </div>
              <div>
                <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Services</div>
                <div className="mt-3 grid gap-2">
                  {stylist.services.map(s => (
                    <div key={s.id} className="flex items-center justify-between rounded-2xl border px-4 py-3" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
                      <div>
                        <div className="text-sm font-semibold">{s.name}</div>
                        <div className="text-xs" style={{color:"var(--dim)"}}>{s.durationMin} min</div>
                      </div>
                      <div className="text-sm font-semibold">${Math.round(s.basePriceCents/100)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-10 flex items-end justify-between gap-4">
              <div>
                <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Work</div>
                <h2 className="serif mt-2 text-2xl">Recent looks</h2>
              </div>
              <div className="text-sm" style={{color:"var(--muted)"}}>Book behind the portfolio. As it should be.</div>
            </div>

            <div className="mt-4 grid gap-3 md:grid-cols-3">
              {gallery.slice(0,9).map((src, i) => (
                <div key={i} className="aspect-[4/5] overflow-hidden rounded-2xl border" style={{borderColor:"var(--border)", background:"var(--panel)"}}>
                  <div className="h-full w-full" style={{backgroundImage:`url(${src})`, backgroundSize:"cover", backgroundPosition:"center"}}/>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </main>
  );
}
