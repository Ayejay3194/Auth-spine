export type Slot = { slotId: string; startISO: string; durationMin: number };
export type Booking = { bookingId: string; slotId: string; service: string; status: string };
export type Client = { clientId: string; name: string; email?: string; phone?: string; tags: string[]; notes: string[] };
export type Invoice = { invoiceId: string; clientId: string; amount: number; status: string };
export type Promo = { code: string; percentOff: number; active: boolean };
export type Referral = { code: string; referrerClientId: string; uses: number };
export type KPI = { key: string; value: number; unit?: string };
export type Task = { taskId: string; title: string; status: string };

export interface BookingProvider {
  findSlots(input: { dateISO?: string; durationMin: number; service?: string; userId: string }): Promise<Slot[]>;
  createBooking(input: { userId: string; slotId: string; service: string }): Promise<Booking>;
  cancelBooking(input: { bookingId: string }): Promise<Booking>;
  listBookings(input: { userId: string }): Promise<Booking[]>;
}

export interface CRMProvider {
  findClient(input: { query: string }): Promise<Client | null>;
  addNote(input: { clientId: string; note: string }): Promise<void>;
  tagClient(input: { clientId: string; tag: string }): Promise<void>;
  history(input: { clientId: string }): Promise<{ bookings: Booking[]; invoices: Invoice[] }>;
}

export interface PaymentsProvider {
  createInvoice(input: { clientId: string; amount: number }): Promise<Invoice>;
  refund(input: { invoiceId: string; amount?: number }): Promise<Invoice>;
  applyCredit(input: { clientId: string; amount: number }): Promise<void>;
}

export interface MarketingProvider {
  createPromo(input: { code: string; percentOff: number; expiresISO?: string }): Promise<Promo>;
  endPromo(input: { code: string }): Promise<Promo>;
  referralStatus(input: { code: string }): Promise<Referral | null>;
  sendCampaign(input: { segment: string; message: string }): Promise<{ sent: number }>;
}

export interface AnalyticsProvider {
  kpis(input: { businessId: string; userId: string }): Promise<KPI[]>;
  exportReport(input: { report: string; format: "csv" | "json" }): Promise<{ url: string }>;
}

export interface OpsProvider {
  createTask(input: { title: string }): Promise<Task>;
  listTasks(input: {}): Promise<Task[]>;
  markDone(input: { taskId: string }): Promise<Task>;
  startChecklist(input: { name: "open" | "close" }): Promise<{ steps: string[] }>;
}

export interface AdminProvider {
  showAudit(input: { limit: number }): Promise<{ at: string; type: string; details: any }[]>;
  manageRole(input: { targetUserId: string; role: string }): Promise<{ ok: boolean }>;
  gdprExport(input: { userId: string }): Promise<{ url: string }>;
}

// --- Store extensions (inventory + fulfillment) ---
export type Product = { productId: string; sku: string; name: string; price: number; active: boolean; stockQty?: number };
export type StockMovement = { movementId: string; productId: string; delta: number; reason: string; atISO: string };
export type Order = { orderId: string; status: string; total: number; currency: string; createdISO: string };
export type Shipment = { shipmentId: string; orderId: string; carrier?: string; tracking?: string; status: string; createdISO: string };

export interface InventoryProvider {
  listProducts(input: { query?: string; limit?: number }): Promise<Product[]>;
  createProduct(input: { sku: string; name: string; price: number; active?: boolean }): Promise<Product>;
  updateStock(input: { productId: string; delta: number; reason: string }): Promise<StockMovement>;
  getStock(input: { productId: string }): Promise<{ productId: string; stockQty: number }>;
  lowStock(input: { threshold: number; limit?: number }): Promise<{ productId: string; sku: string; name: string; stockQty: number }[]>;
}

export interface FulfillmentProvider {
  listOrders(input: { status?: string; limit?: number }): Promise<Order[]>;
  getOrder(input: { orderId: string }): Promise<Order | null>;
  createShipment(input: { orderId: string; carrier?: string; serviceLevel?: string }): Promise<Shipment>;
  addTracking(input: { shipmentId: string; carrier: string; tracking: string }): Promise<Shipment>;
  markDelivered(input: { shipmentId: string }): Promise<Shipment>;
}

// --- Drift Date Booking (dating app) extensions ---
export type DateIdea = { ideaId: string; title: string; category: string; estCost?: number; tags?: string[] };
export type Venue = { venueId: string; name: string; category: string; neighborhood?: string; lat?: number; lon?: number; priceLevel?: number };
export type Reservation = { reservationId: string; venueId: string; startISO: string; partySize: number; status: string; confirmationCode?: string };
export type DateRequest = {
  dateRequestId: string;
  matchId: string;
  proposerUserId: string;
  inviteeUserId: string;
  title: string;
  category: string;
  budget?: number;
  windowStartISO?: string;
  windowEndISO?: string;
  proposedStartISO?: string;
  status: "draft"|"proposed"|"awaiting_acceptance"|"accepted"|"reserved"|"confirmed"|"cancelled"|"expired"|"completed";
  createdISO: string;
};

export type SafetyRules = {
  shareExactLocationAt?: "never"|"checkin"|"time";
  shareAtISO?: string;
  checkinTimerMin?: number;
  emergencyContactEnabled?: boolean;
};

export interface VenueProvider {
  searchVenues(input: { query?: string; category?: string; neighborhood?: string; lat?: number; lon?: number; radiusKm?: number; limit?: number }): Promise<Venue[]>;
}

export interface DateProvider {
  createDateRequest(input: { matchId: string; proposerUserId: string; inviteeUserId: string; title: string; category: string; budget?: number; proposedStartISO?: string; windowStartISO?: string; windowEndISO?: string; partySize?: number }): Promise<DateRequest>;
  getDateRequest(input: { dateRequestId: string }): Promise<DateRequest | null>;
  acceptDateRequest(input: { dateRequestId: string; actorUserId: string }): Promise<DateRequest>;
  declineDateRequest(input: { dateRequestId: string; actorUserId: string; reason?: string }): Promise<DateRequest>;
  cancelDateRequest(input: { dateRequestId: string; actorUserId: string }): Promise<DateRequest>;
  setProposedTime(input: { dateRequestId: string; actorUserId: string; proposedStartISO: string }): Promise<DateRequest>;
}

export interface ReservationProvider {
  createReservation(input: { dateRequestId: string; venueId: string; startISO: string; partySize: number }): Promise<Reservation>;
  cancelReservation(input: { reservationId: string }): Promise<Reservation>;
}

export interface SafetyProvider {
  setSafetyRules(input: { matchId: string; userId: string; rules: SafetyRules }): Promise<{ ok: true }>;
  getSafetyRules(input: { matchId: string; userId: string }): Promise<SafetyRules | null>;
  checkIn(input: { dateRequestId: string; userId: string }): Promise<{ ok: true; atISO: string }>;
}
