import { createDigiGeo, InMemoryCache } from "./index.js";

async function main() {
  const geo = createDigiGeo({
    provider: {
      kind: "nominatim",
      endpoint: "https://nominatim.openstreetmap.org",
      userAgent: "digi-geo-demo/0.1 (demo@example.com)"
    },
    cache: { l1: new InMemoryCache({ maxEntries: 1000 }) },
    policy: { minConfidence: 0.55, negativeCacheTtlMs: 1000 * 60 * 5 }
  });

  const r1 = await geo.forward({ query: "New York, NY", countryCodes: ["us"], limit: 3 });
  console.log("Best:", r1.best?.label, r1.best?.point, "Receipt:", r1.receipt);

  const r2 = await geo.forward({ query: "New York, NY", countryCodes: ["us"], limit: 3 });
  console.log("Cached:", r2.receipt.cache);

  if (r1.best) {
    const rr = await geo.reverse({ point: r1.best.point });
    console.log("Reverse:", rr.best?.label, rr.receipt);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
