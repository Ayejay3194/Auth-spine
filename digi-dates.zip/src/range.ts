import { ValidationError } from "./errors.js";

export function isValidDate(d: Date): boolean {
  return d instanceof Date && Number.isFinite(d.getTime());
}

export function assertValidDate(d: Date): void {
  if (!isValidDate(d)) throw new ValidationError("Invalid Date");
}

export function compare(a: Date, b: Date): number {
  assertValidDate(a);
  assertValidDate(b);
  return a.getTime() - b.getTime();
}

export function addDaysUTC(d: Date, days: number): Date {
  assertValidDate(d);
  if (!Number.isFinite(days)) throw new ValidationError("days must be finite");
  const ms = d.getTime() + Math.trunc(days) * 86_400_000;
  return new Date(ms);
}

export function startOfDayUTC(d: Date): Date {
  assertValidDate(d);
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 0, 0, 0, 0));
}
