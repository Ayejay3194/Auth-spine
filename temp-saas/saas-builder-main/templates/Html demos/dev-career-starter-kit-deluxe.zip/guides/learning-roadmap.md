# Learning Roadmap – From Zero to "I Can Ship Stuff"

## Phase 1 – Tools & Basics

- Install Node, a package manager, Git, and an editor (VS Code / Cursor).
- Learn:
  - JS/TS fundamentals (functions, arrays, objects, async/await)
  - React basics (components, props, state)
  - Next.js basics (App Router, simple routes, server vs client components)

Milestone:
- Run the `simple-saas-nextjs` app locally.
- Change text on the homepage and add a new route.

## Phase 2 – Full Stack Muscle

- Learn Prisma:
  - schema, migrations, simple queries
- Implement a real feature:
  - `Project` model in DB
  - Create / list projects in dashboard
- Understand "request → DB → response → UI" end-to-end.

Milestone:
- You can add a new field to `Project`, migrate, and show it in the UI.

## Phase 3 – Production Mindset

- Basic error handling & validation.
- Simple logging.
- Start writing DevLogs and turning them into tickets using the prompts.

Milestone:
- You can describe what you built, why, and what can break.
