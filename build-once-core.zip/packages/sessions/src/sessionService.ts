import crypto from "node:crypto";
import { getPrisma } from "@suite/db";

export type SessionCreateInput = {
  tenantId: string;
  userId: string;
  ip?: string;
  userAgent?: string;
  deviceLabel?: string;
  ttlHours?: number;
};

export type SessionInfo = { sessionId: string; token: string; expiresAt: Date };

function sha256(s: string) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

export async function createSession(input: SessionCreateInput): Promise<SessionInfo> {
  const prisma = getPrisma();
  const token = crypto.randomBytes(32).toString("hex");
  const tokenHash = sha256(token);
  const ttl = input.ttlHours ?? 24 * 14; // 14 days default
  const expiresAt = new Date(Date.now() + ttl * 60 * 60 * 1000);

  const s = await prisma.session.create({
    data: {
      tenantId: input.tenantId,
      userId: input.userId,
      tokenHash,
      expiresAt,
      ip: input.ip,
      userAgent: input.userAgent,
      deviceLabel: input.deviceLabel,
    }
  });

  return { sessionId: s.id, token, expiresAt };
}

export async function validateSession(token: string) {
  const prisma = getPrisma();
  const tokenHash = sha256(token);
  const s = await prisma.session.findFirst({ where: { tokenHash, revokedAt: null } });
  if (!s) return null;
  if (s.expiresAt.getTime() < Date.now()) return null;

  await prisma.session.update({ where: { id: s.id }, data: { lastSeenAt: new Date() } });
  return s;
}

export async function revokeSession(sessionId: string, tenantId: string) {
  const prisma = getPrisma();
  await prisma.session.updateMany({ where: { id: sessionId, tenantId }, data: { revokedAt: new Date() } });
}

export async function revokeAllUserSessions(userId: string, tenantId: string) {
  const prisma = getPrisma();
  await prisma.session.updateMany({ where: { userId, tenantId }, data: { revokedAt: new Date() } });
}
