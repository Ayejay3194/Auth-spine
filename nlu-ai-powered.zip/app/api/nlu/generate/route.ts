import { NextResponse } from "next/server";
import { callAnthropicJSON } from "@/lib/anthropic";

export const runtime = "nodejs";

type Body = {
  prompt: string;
  intents: Array<{ name: string; description: string; examples: string[] }>;
  entities: Array<{ name: string; description: string; examples: string[] }>;
};

type JsonlLine = {
  text: string;
  intent: string;
  entities?: Array<{ entity: string; value: string }>;
};

export async function POST(req: Request) {
  const body = (await req.json()) as Body;

  const prompt = (body.prompt || "").trim();
  if (!prompt) return NextResponse.json({ error: "Missing prompt" }, { status: 400 });

  // We ask for JSON (not markdown), then we return the raw JSONL string + parsed lines.
  const system = `You generate training data for intent classification + entity extraction.
Return JSON with this shape:
{
  "jsonl": "20 lines of JSONL, one per line"
}
Rules:
- Each line must be valid JSON: {"text":"...","intent":"...","entities":[{"entity":"...","value":"..."}]}
- No markdown. No commentary. Just that JSON object.`;

  try {
    const result = await callAnthropicJSON<{ jsonl: string }>({
      system,
      user: `Generate 20 diverse training examples in JSONL format for: ${prompt}
Create realistic, varied examples with different phrasings. Include relevant intents and entities.`,
      temperature: 0.7,
      maxTokens: 4000,
    });

    const jsonl = (result.jsonl || "").trim();
    const lines = jsonl.split("\n").map(l => l.trim()).filter(Boolean);

    const parsed: JsonlLine[] = [];
    for (const line of lines) {
      try {
        parsed.push(JSON.parse(line));
      } catch {
        // skip bad lines
      }
    }

    return NextResponse.json({ jsonl, parsedCount: parsed.length, parsed });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message || "Generation failed" },
      { status: 500 }
    );
  }
}
