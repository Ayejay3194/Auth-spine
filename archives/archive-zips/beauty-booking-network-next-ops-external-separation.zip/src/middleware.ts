import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

/**
 * Host-based separation.
 * - Public host (APP_HOST): blocks internal ops surfaces
 * - Ops host (OPS_HOST): allows ops surfaces
 * - Studio host (STUDIO_HOST): optional, allows studio-only surfaces
 *
 * Dev-friendly: if none are configured, middleware is permissive.
 */
const APP_HOST = process.env.APP_HOST || "";
const OPS_HOST = process.env.OPS_HOST || "";
const STUDIO_HOST = process.env.STUDIO_HOST || "";

function hostMatches(host: string, expected: string) {
  if (!expected) return false;
  return host.toLowerCase() === expected.toLowerCase();
}

function isDev() {
  return process.env.NODE_ENV !== "production";
}

export function middleware(req: NextRequest) {
  const host = req.headers.get("host") || "";
  const path = req.nextUrl.pathname;

  // If not configured, don't brick dev.
  if (isDev() && !APP_HOST && !OPS_HOST && !STUDIO_HOST) return NextResponse.next();

  const onOps = hostMatches(host, OPS_HOST);
  const onStudio = hostMatches(host, STUDIO_HOST);
  const onApp = hostMatches(host, APP_HOST) || (!onOps && !onStudio);

  const isOpsSurface =
    path.startsWith("/ops") ||
    path.startsWith("/api/ops") ||
    path.startsWith("/admin") ||
    path.startsWith("/salon-admin");

  const isStudioSurface =
    path.startsWith("/studio") ||
    path.startsWith("/api/studio");

  // Block ops surfaces from non-ops hosts
  if (isOpsSurface && !onOps) {
    return new NextResponse("Not found", { status: 404 });
  }

  // If STUDIO_HOST is configured, enforce studio-only surfaces on it
  if (STUDIO_HOST && isStudioSurface && !onStudio) {
    return new NextResponse("Not found", { status: 404 });
  }

  // Optional: keep ops host focused
  if (onOps && onApp && path === "/") {
    const url = req.nextUrl.clone();
    url.pathname = "/ops";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
