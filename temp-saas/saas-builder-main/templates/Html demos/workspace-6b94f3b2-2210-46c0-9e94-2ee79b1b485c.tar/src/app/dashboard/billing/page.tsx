'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import { CreditCard, Check, X, Zap } from 'lucide-react'
import { useWorkspace } from '@/components/providers/workspace-provider'

interface Plan {
  id: string
  name: string
  slug: string
  price: number
  interval: string
  features: any
  isActive: boolean
}

export default function Billing() {
  const { activeWorkspace, activeMembership } = useWorkspace()
  const [plans, setPlans] = useState<Plan[]>([])
  const [selectedPlan, setSelectedPlan] = useState<string>('')
  const [isLoading, setIsLoading] = useState(false)
  const [currentSubscription, setCurrentSubscription] = useState<any>(null)

  useEffect(() => {
    fetchPlans()
    fetchCurrentSubscription()
  }, [activeWorkspace])

  const fetchPlans = async () => {
    try {
      const response = await fetch('/api/billing/plans')
      const data = await response.json()
      if (data.success) {
        setPlans(data.data)
      }
    } catch (error) {
      toast.error('Failed to fetch plans')
    }
  }

  const fetchCurrentSubscription = async () => {
    if (!activeWorkspace) return

    try {
      const response = await fetch(`/api/workspaces/${activeWorkspace.id}/subscription`)
      const data = await response.json()
      if (data.success) {
        setCurrentSubscription(data.data)
      }
    } catch (error) {
      // Subscription might not exist, which is fine
    }
  }

  const handleSubscribe = async () => {
    if (!selectedPlan || !activeWorkspace) return

    setIsLoading(true)
    try {
      const response = await fetch('/api/billing/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          planId: selectedPlan,
          workspaceId: activeWorkspace.id,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        toast.success('Subscription created successfully!')
        setCurrentSubscription(data.data)
      } else {
        toast.error(data.error?.message || 'Failed to create subscription')
      }
    } catch (error) {
      toast.error('An error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  const formatPrice = (price: number, interval: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price / 100)
  }

  const getPlanFeatures = (features: any) => {
    const defaultFeatures = {
      maxProjects: 'Unlimited',
      maxMembersPerWorkspace: 'Unlimited',
      advancedFeatures: true,
      prioritySupport: true,
      customIntegrations: true,
      apiAccess: true,
    }
    return { ...defaultFeatures, ...features }
  }

  if (!activeWorkspace) {
    return <div>Loading...</div>
  }

  if (activeMembership?.role !== 'OWNER') {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Access Restricted</h2>
        <p className="text-muted-foreground">
          Only workspace owners can manage billing settings.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Billing</h1>
        <p className="text-muted-foreground">
          Manage your workspace subscription and billing settings
        </p>
      </div>

      {/* Current Subscription */}
      {currentSubscription && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Current Subscription
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{currentSubscription.plan.name}</p>
                <p className="text-sm text-muted-foreground">
                  {formatPrice(currentSubscription.plan.price, currentSubscription.plan.interval)}/{currentSubscription.plan.interval.toLowerCase()}
                </p>
              </div>
              <Badge variant={currentSubscription.status === 'ACTIVE' ? 'default' : 'secondary'}>
                {currentSubscription.status}
              </Badge>
            </div>
            {currentSubscription.currentPeriodEnd && (
              <p className="text-sm text-muted-foreground mt-2">
                Next billing date: {new Date(currentSubscription.currentPeriodEnd).toLocaleDateString()}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Available Plans */}
      {!currentSubscription && (
        <div>
          <h2 className="text-2xl font-bold mb-6">Choose a Plan</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {plans.map((plan) => {
              const features = getPlanFeatures(plan.features)
              const isPopular = plan.slug === 'pro'

              return (
                <Card key={plan.id} className={isPopular ? 'border-primary' : ''}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {plan.name}
                      {isPopular && (
                        <Badge variant="default" className="ml-2">
                          <Zap className="h-3 w-3 mr-1" />
                          Popular
                        </Badge>
                      )}
                    </CardTitle>
                    <CardDescription>
                      {formatPrice(plan.price, plan.interval)}
                      <span className="text-sm">/{plan.interval.toLowerCase()}</span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <RadioGroup
                      value={selectedPlan}
                      onValueChange={setSelectedPlan}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value={plan.id} id={plan.id} />
                        <Label htmlFor={plan.id} className="sr-only">
                          Select {plan.name}
                        </Label>
                      </div>
                    </RadioGroup>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500" />
                        <span className="text-sm">{features.maxProjects} projects</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500" />
                        <span className="text-sm">{features.maxMembersPerWorkspace} members</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {features.advancedFeatures ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <X className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">Advanced features</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {features.prioritySupport ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <X className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">Priority support</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {features.apiAccess ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <X className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">API access</span>
                      </div>
                    </div>

                    <Button
                      className="w-full"
                      variant={isPopular ? 'default' : 'outline'}
                      onClick={() => setSelectedPlan(plan.id)}
                      disabled={selectedPlan === plan.id}
                    >
                      {selectedPlan === plan.id ? 'Selected' : `Select ${plan.name}`}
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {selectedPlan && (
            <div className="mt-6 text-center">
              <Button size="lg" onClick={handleSubscribe} disabled={isLoading}>
                {isLoading ? 'Processing...' : 'Subscribe Now'}
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Billing History */}
      <Card>
        <CardHeader>
          <CardTitle>Billing History</CardTitle>
          <CardDescription>
            View your past invoices and payments
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">No billing history available.</p>
        </CardContent>
      </Card>
    </div>
  )
}