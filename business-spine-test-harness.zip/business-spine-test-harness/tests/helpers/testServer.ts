import { setTimeout as sleep } from "node:timers/promises";
import net from "node:net";

type Spine = any;

async function getFreePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.unref();
    srv.on("error", reject);
    srv.listen(0, "127.0.0.1", () => {
      const addr = srv.address();
      if (typeof addr === "object" && addr?.port) {
        const port = addr.port;
        srv.close(() => resolve(port));
      } else {
        srv.close(() => reject(new Error("Failed to acquire a port")));
      }
    });
  });
}

export async function startSpineServer(opts?: {
  tenantId?: string;
  corsOrigins?: string[];
}): Promise<{ spine: Spine; baseUrl: string; port: number }> {
  const { createBusinessSpine, startServer } = await import("../../dist/index.js");

  const port = await getFreePort();
  const baseUrl = `http://127.0.0.1:${port}`;

  const spine = await createBusinessSpine({
    tenantId: opts?.tenantId ?? "test-tenant",
    api: {
      port,
      corsOrigins: opts?.corsOrigins ?? [baseUrl],
      rateLimit: { windowMs: 15 * 60 * 1000, max: 1000 }
    }
  });

  const server = await startServer(spine);

  // Give the server a moment to bind in case startServer is async-but-not-fully-ready.
  await sleep(50);

  // Attach a best-effort closer if startServer returns a Node server.
  (spine as any).__testServer = server;

  return { spine, baseUrl, port };
}

export async function stopSpineServer(spine: Spine): Promise<void> {
  // Prefer official shutdown hook
  if (spine?.shutdown) {
    await spine.shutdown();
    return;
  }

  // Fallback: close node http server
  const srv = (spine as any)?.__testServer;
  if (srv?.close) {
    await new Promise<void>((resolve) => srv.close(() => resolve()));
  }
}