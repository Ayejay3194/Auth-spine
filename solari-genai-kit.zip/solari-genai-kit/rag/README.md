Use docker compose to start Postgres+pgvector.
