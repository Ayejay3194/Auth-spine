export type Tone = "neutral" | "friendly" | "urgent" | "apologetic" | "firm";

export interface TonePolicyInput {
  intent: string;
  sentiment?: "pos" | "neu" | "neg";
  urgency?: "low" | "medium" | "high";
}

export function pickTone(input: TonePolicyInput): Tone {
  if (input.urgency === "high") return "urgent";
  if (input.intent === "complaint" || input.sentiment === "neg") return "apologetic";
  if (input.intent === "policy_refund" || input.intent === "policy_cancellation") return "firm";
  return "friendly";
}
