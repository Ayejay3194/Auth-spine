from fastapi import FastAPI
from pydantic import BaseModel
from .nlu.pipeline import NLUPipeline
from .dialogue.manager import DialogueManager
from .nlg.renderer import NLGRenderer
from .store.sessions import SessionStore

app = FastAPI(title="Wit-like Conversational NLU")

nlu = NLUPipeline()
sessions = SessionStore()
dialogue = DialogueManager()
nlg = NLGRenderer()

class MsgIn(BaseModel):
    session_id: str
    text: str
    user_id: str | None = None

@app.post("/v1/message")
def message(payload: MsgIn):
    state = sessions.get(payload.session_id)
    nlu_out = nlu.parse(payload.text)
    dm_out = dialogue.next(state=state, text=payload.text, nlu=nlu_out)
    resp = nlg.render(dm_out)
    sessions.set(payload.session_id, dm_out["state"])
    return {"session_id": payload.session_id, "nlu": nlu_out, "dialogue": dm_out, "response": resp}

@app.get("/health")
def health():
    return {"ok": True}
