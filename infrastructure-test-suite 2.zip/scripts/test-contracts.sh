#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

if [ -d apis/openapi ] && compgen -G "apis/openapi/*.yaml" > /dev/null; then
  log "Spectral OpenAPI lint"
  docker_run stoplight/spectral:latest lint apis/openapi/*.yaml -r configs/spectral/.spectral.yaml
else
  log "No OpenAPI specs found under apis/openapi/. Skipping."
fi
