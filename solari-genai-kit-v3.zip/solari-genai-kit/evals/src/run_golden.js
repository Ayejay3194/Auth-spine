import fetch from "node-fetch";
import fs from "fs";
import { classifyFailure, scoreConfidenceFromResponse } from "./failure_taxonomy.js";

const runtimeUrl = process.env.RUNTIME_URL || "http://localhost:7777/generate";
const modelBaseUrl = process.env.MODEL_BASE_URL || "http://localhost:8080";
const apiKey = process.env.API_KEY || undefined;

function loadJson(rel) {
  return JSON.parse(fs.readFileSync(new URL(rel, import.meta.url)));
}

const suites = [
  { name: "golden", cases: loadJson("./golden_prompts.json") },
  { name: "edge", cases: loadJson("./edge_cases.json") }
];

const resultsDir = new URL("../results/", import.meta.url);
fs.mkdirSync(resultsDir, { recursive: true });

let pass=0, fail=0, repaired=0;
const details = [];
const taxonomy = {};

for (const suite of suites) {
  for (const g of suite.cases) {
    const started = Date.now();
    const res = await fetch(runtimeUrl, {
      method:"POST",
      headers:{"content-type":"application/json"},
      body: JSON.stringify({
        mode:g.mode,
        schemaName:g.schemaName,
        modelBaseUrl,
        apiKey,
        input:g.input,
        context:g.context
      })
    });

    const body = await res.json().catch(()=>({}));
    const ms = Date.now() - started;

    const ok = !!body.ok;
    if (ok) pass++; else fail++;
    if (ok && body.repaired) repaired++;

    if (!ok) {
      const cls = classifyFailure(body, res.status);
      taxonomy[cls.code] = (taxonomy[cls.code] || 0) + 1;
    }

    const conf = scoreConfidenceFromResponse(body);

    details.push({
      suite: suite.name,
      name: g.name,
      ok,
      status: res.status,
      ms,
      repaired: !!body.repaired,
      confidence: conf,
      error: ok ? null : (body.error || "unknown"),
      schemaErrors: body.errors || null
    });

    console.log(ok ? "PASS" : "FAIL", `[${suite.name}]`, g.name, ok ? "" : (body.error || ""));
  }
}

const summary = {
  runtimeUrl,
  modelBaseUrl,
  total: pass+fail,
  pass,
  fail,
  passRate: (pass+fail) ? pass/(pass+fail) : 0,
  repaired,
  repairedRate: pass ? repaired/pass : 0,
  taxonomy,
  timestamp: new Date().toISOString(),
  details
};

const outPath = new URL("./results.json", resultsDir);
fs.writeFileSync(outPath, JSON.stringify(summary, null, 2));
console.log("wrote", outPath.pathname);
process.exit(fail ? 1 : 0);
