Backup & Disaster Recovery

- Encrypted backups
- Regular restore tests
- Immutable backups
- Defined RTO/RPO
