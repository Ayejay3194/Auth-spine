# @yourorg/data-lake (Parquet ↔ Arrow Hybrid)

This package gives you a clean compute lane:

**Parquet (storage / truth) → Arrow (in-memory compute) → Parquet (snapshots/features)**

## Install
```bash
npm i
```

## Commands

### Ingest JSONL → Parquet
```bash
npm run ingest -- --input ./data/residuals.jsonl --dataset de440_residuals --ver v1 --day 2026-02-27
```

### Compute features (Parquet → Arrow → Parquet)
```bash
npm run compute -- --dataset de440_residuals --ver v1 --outDataset de440_residual_features --outVer v1 --day 2026-02-27
```

### Snapshot day partition
```bash
npm run snapshot -- --dataset de440_residuals --ver v1 --day 2026-02-27 --target ./snapshots
```

## Notes
- Parquet partitions are immutable; write new files instead of mutating.
- Arrow is compute-only; keep it out of request paths.
- Metadata sidecars are written as `*.parquet.meta.json`.
