import { z } from "zod";
import { api } from "@/src/core/api";
import { prisma } from "@/lib/prisma";

const Q = z.object({ requestId: z.string() });

export async function POST(req: Request) {
  return api(async () => {
    const body = Q.parse(await req.json());
    const dsr = await prisma.dataSubjectRequest.findUnique({ where: { id: body.requestId } });
    if (!dsr) return { error: "not_found" };
    return { status: dsr.status, url: dsr.url ?? null, type: dsr.type };
  });
}
