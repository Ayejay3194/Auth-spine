import Link from "next/link";
import { Container } from "@/components/Container";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { StudioTabs } from "./ui";

export default async function Studio(){
  const session = await auth();
  if(!session?.user?.email){
    return (
      <main className="py-10">
        <Container>
          <div className="rounded-[28px] border p-8" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
            <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Studio</div>
            <h1 className="serif mt-2 text-3xl">Sign in.</h1>
            <p className="mt-2 text-sm" style={{color:"var(--muted)"}}>Stylists can’t manage their “website” as ghosts.</p>
            <div className="mt-6">
              <Link href="/auth/sign-in" className="rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>
                Sign in
              </Link>
            </div>
          </div>
        </Container>
      </main>
    );
  }

  const user = await prisma.user.findUnique({ where:{ email: session.user.email }, include:{ stylistProfile:true } });
  if(!user?.stylistProfile){
    return (
      <main className="py-10">
        <Container>
          <div className="rounded-[28px] border p-8" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
            <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Studio</div>
            <h1 className="serif mt-2 text-3xl">Not a stylist account.</h1>
            <p className="mt-2 text-sm" style={{color:"var(--muted)"}}>Use jade@demo.com or noor@demo.com (seeded) to see the stylist studio.</p>
          </div>
        </Container>
      </main>
    );
  }

  return (
    <main className="py-10">
      <Container>
        <div className="flex items-end justify-between gap-4">
          <div>
            <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Studio</div>
            <h1 className="serif mt-2 text-3xl">{user.stylistProfile.displayName}</h1>
            <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>Manage your portfolio, services, availability, and bookings.</div>
          </div>
          <Link href={`/@${user.stylistProfile.slug}`} className="rounded-2xl border px-5 py-3 text-sm font-semibold"
            style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
            View public page →
          </Link>
        </div>

        <div className="mt-6">
          <StudioTabs stylistId={user.stylistProfile.id} />
        </div>
      </Container>
    </main>
  );
}
