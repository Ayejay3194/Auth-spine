import Decimal from "decimal.js";

/**
 * Numeric normalization rules:
 * - decimals are rounded to fixed precision
 * - -0 becomes 0
 * - NaN/Infinity rejected upstream
 */
export function n(value: number, places = 8): number {
  if (!Number.isFinite(value)) throw new Error(`Non-finite number: ${value}`);
  const d = new Decimal(value).toDecimalPlaces(places);
  const x = d.toNumber();
  return Object.is(x, -0) ? 0 : x;
}
