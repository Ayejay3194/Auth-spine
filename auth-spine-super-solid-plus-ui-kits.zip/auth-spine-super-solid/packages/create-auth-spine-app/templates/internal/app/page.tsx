export default function Page(){return <div style={{padding:24}}>New internal app</div>}
