#!/usr/bin/env node
import { Command } from 'commander'
import prompts from 'prompts'
import chalk from 'chalk'
import fs from 'fs-extra'
import path from 'path'

const program = new Command()

type Answers = {
  projectName: string
  template: 'minimal' | 'saas' | 'internal' | 'api'
  initGit: boolean
}

program
  .name('create-auth-spine-app')
  .description('Create a new Auth-Spine application')
  .argument('[project-name]', 'Name of your project')
  .action(async (projectNameArg) => {
    console.log(chalk.cyan.bold('\nAuth-Spine App Generator\n'))

    const answers = (await prompts([
      {
        type: projectNameArg ? null : 'text',
        name: 'projectName',
        message: 'Project name (lowercase, hyphens only):',
        initial: 'my-auth-spine-app',
        validate: (value) => (/^[a-z0-9-]+$/.test(value) ? true : 'lowercase + hyphens only'),
      },
      {
        type: 'select',
        name: 'template',
        message: 'Template:',
        choices: [
          { title: 'Minimal', value: 'minimal' },
          { title: 'SaaS', value: 'saas' },
          { title: 'Internal Tool', value: 'internal' },
          { title: 'API Backend', value: 'api' },
        ],
      },
      { type: 'confirm', name: 'initGit', message: 'Init git repo?', initial: true },
    ])) as Answers

    const name = (projectNameArg || answers.projectName) as string
    const template = answers.template || 'minimal'
    const dest = path.join(process.cwd(), name)

    if (await fs.pathExists(dest)) {
      console.log(chalk.red(`\n❌ Folder already exists: ${name}\n`))
      process.exit(1)
    }

    const templateDir = path.join(__dirname, '..', 'templates', template)
    await fs.copy(templateDir, dest)

    // Replace __NAME__ in template package.json
    const pkgPath = path.join(dest, 'package.json')
    if (await fs.pathExists(pkgPath)) {
      const pkg = await fs.readJson(pkgPath)
      pkg.name = name
      await fs.writeJson(pkgPath, pkg, { spaces: 2 })
    }

    console.log(chalk.green(`\n✅ Created ${name} from ${template} template\n`))
    console.log(chalk.white(`Next:\n  cd ${name}\n  npm install\n  npm run dev\n`))
  })

program.parse()
