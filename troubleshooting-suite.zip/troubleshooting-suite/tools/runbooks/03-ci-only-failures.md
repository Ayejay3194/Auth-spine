# CI-only failures

## Usual suspects
- Node version mismatch
- missing env vars in CI
- dependency drift (no lockfile or lock not respected)
- case sensitivity differences (Linux)
- build caching issues

## Fix workflow
1) Print Node version + env snapshot in CI logs.
2) Use `npm ci` (not `npm install`) in CI.
3) Pin Node in `engines.node` + CI setup-node.
4) Run `npx tsc --noEmit` as a separate CI step for clearer failure.
