import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";

export async function GET(){
  const session = await auth();
  const user = session?.user?.email ? await prisma.user.findUnique({ where:{ email: session.user.email } }) : null;
  await requireRole(user, ["OWNER","MANAGER","ADMIN"]);
  return Response.json({ ok:true, surface:"ops" });
}
