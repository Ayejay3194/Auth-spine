import type { NextRequest } from 'next/server'
import type { NextResponse } from 'next/server'
import { log } from '../logger.js'

export function performanceMonitor(req: NextRequest) {
  const start = Date.now()
  return {
    end: (res: NextResponse) => {
      const duration = Date.now() - start
      if (duration > 1000) {
        log.warn('Slow request detected', {
          path: req.nextUrl.pathname,
          method: req.method,
          duration,
          status: (res as any).status,
        })
      }
      res.headers.set('X-Response-Time', `${duration}ms`)
      return res
    },
  }
}
