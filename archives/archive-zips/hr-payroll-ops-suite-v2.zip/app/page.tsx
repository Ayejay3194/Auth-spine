
import { getViewer } from "@/lib/auth";
import { db } from "@/lib/db";

export default async function Home() {
  const viewer = await getViewer();
  const [employeeCount, ptoPending, submittedTimesheets, draftRuns] = await Promise.all([
    db.employee.count(),
    db.ptoRequest.count({ where: { status: "PENDING" } }),
    db.timesheet.count({ where: { status: "SUBMITTED" } }),
    db.payRun.count({ where: { status: "DRAFT" } })
  ]);

  return (
    <div className="grid">
      <div className="panel">
        <h1 className="h1">HR + Payroll + Ops Suite</h1>
        <div className="h2">Viewer: {viewer.email} ({viewer.role})</div>
        <div className="kpi">
          <div className="chip">Employees: {employeeCount}</div>
          <div className="chip">PTO pending: {ptoPending}</div>
          <div className="chip">Timesheets submitted: {submittedTimesheets}</div>
          <div className="chip">Draft payroll runs: {draftRuns}</div>
        </div>
        <p className="small">V2 includes timesheets + payroll items from approved time.</p>
      </div>
    </div>
  );
}
