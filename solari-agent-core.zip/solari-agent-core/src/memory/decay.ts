import { MemoryFact } from "../types";

export function withDefaultTTL<T>(fact: MemoryFact<T>, defaultTtlDays = 30): MemoryFact<T> {
  return { ...fact, ttlDays: fact.ttlDays ?? defaultTtlDays };
}
