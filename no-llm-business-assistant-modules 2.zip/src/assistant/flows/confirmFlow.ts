import type { Flow } from "./flowTypes.js";
import type { Reply } from "../core/types.js";
import { runTool } from "../tools/registry.js";

export function makeConfirmFlow(audit: any): Flow {
  return {
    id: "confirm",
    async handle({ ctx, text, state, tools }) {
      const af = state.activeFlow;
      if (!af?.pendingAction) {
        return { state, reply: { text: "Nothing to confirm.", done: true } };
      }

      const phrase = String(af.confirmPhrase ?? "YES");
      if (text.trim().toUpperCase() !== phrase) {
        const reply: Reply = {
          text: `Type **${phrase}** to confirm, or say "cancel" to abort.`,
          done: false
        };
        if (/\bcancel\b/i.test(text)) {
          return { state: { ...state, activeFlow: undefined }, reply: { text: "Canceled.", done: true } };
        }
        return { state, reply };
      }

      const tool = tools.get(af.pendingAction.toolId);
      if (!tool) return { state, reply: { text: "Tool missing. Refusing.", done: true } };

      const res = await runTool({ tool, ctx, input: af.pendingAction.input, audit });

      return {
        state: { ...state, activeFlow: undefined },
        reply: res.ok ? { text: "Done.", done: true } : { text: `Failed: ${res.error.message}`, done: true }
      };
    }
  };
}
