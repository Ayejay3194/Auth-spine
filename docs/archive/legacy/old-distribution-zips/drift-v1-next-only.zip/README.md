# Drift V1 (Next.js only)

You asked for **Next only**: no Postgres, no Redis, no BullMQ. So this is an **infra-free** scaffold:
- SMS booking (Twilio webhook compatible)
- Booking core w/ conflict prevention + slot locking (in-memory)
- Context persistence (in-memory session state)
- Orchestration hooks (booking.created -> reminders)

## Run
```bash
npm install
npm run dev
```

## Endpoints

### Twilio inbound SMS webhook
`POST /api/sms/inbound` (x-www-form-urlencoded: `From`, `To`, `Body`)

Test:
```bash
curl -X POST "http://localhost:3000/api/sms/inbound"   -H "Content-Type: application/x-www-form-urlencoded"   --data-urlencode "From=+15551234567"   --data-urlencode "To=+15557654321"   --data-urlencode "Body=I want a haircut Thursday at 2pm"
```

### Debug booking API
- `POST /api/booking` (json) create booking
- `GET /api/booking?id=...` fetch booking

## Reality check
This is memory-only, so state resets on restart and reminders are best-effort timers.
Swap repos to Postgres/Redis + BullMQ when you’re done proving the wedge.
