import type { PrismaClient } from "@prisma/client";
import type {
  BookingProvider, CRMProvider, PaymentsProvider,
  MarketingProvider, AnalyticsProvider, OpsProvider, AdminProvider,
  Slot, Booking, Client, Invoice, Promo, Referral, KPI, Task
} from "./types.js";

// Replace the Prisma queries to match YOUR schema.
// This file is intentionally verbose because humans love confusion.

export function realProviders(prisma: PrismaClient, businessId: string) {
  const booking: BookingProvider = {
    async findSlots(input) {
      // Example shape: availabilitySlot(businessId, startISO, durationMin)
      // If you don't have an availability table yet, you need one. Sorry.
      const rows = await prisma.availabilitySlot.findMany({
        where: {
          businessId,
          durationMin: input.durationMin,
          ...(input.dateISO ? { startISO: { startsWith: input.dateISO } } : {})
        },
        take: 20
      }) as any[];

      return rows.map(r => ({ slotId: r.id, startISO: r.startISO, durationMin: r.durationMin })) as Slot[];
    },
    async createBooking(input) {
      const row = await prisma.booking.create({
        data: { businessId, userId: input.userId, slotId: input.slotId, service: input.service, status: "confirmed" }
      }) as any;
      return { bookingId: row.id, slotId: row.slotId, service: row.service, status: row.status } as Booking;
    },
    async cancelBooking(input) {
      const row = await prisma.booking.update({
        where: { id: input.bookingId },
        data: { status: "canceled" }
      }) as any;
      return { bookingId: row.id, slotId: row.slotId, service: row.service, status: row.status } as Booking;
    },
    async listBookings(input) {
      const rows = await prisma.booking.findMany({
        where: { businessId, userId: input.userId },
        take: 50,
        orderBy: { createdAt: "desc" }
      }) as any[];
      return rows.map(r => ({ bookingId: r.id, slotId: r.slotId, service: r.service, status: r.status })) as Booking[];
    }
  };

  const crm: CRMProvider = {
    async findClient(input) {
      const q = input.query.toLowerCase();
      const row = await prisma.client.findFirst({
        where: {
          businessId,
          OR: [
            { email: q },
            { phone: { contains: q } },
            { name: { contains: input.query, mode: "insensitive" } }
          ]
        }
      }) as any;
      if (!row) return null;
      return { clientId: row.id, name: row.name, email: row.email ?? undefined, phone: row.phone ?? undefined, tags: row.tags ?? [], notes: [] } as Client;
    },
    async addNote(input) {
      await prisma.clientNote.create({ data: { businessId, clientId: input.clientId, note: input.note } });
    },
    async tagClient(input) {
      const row = await prisma.client.findUnique({ where: { id: input.clientId } }) as any;
      const tags = new Set([...(row?.tags ?? []), input.tag]);
      await prisma.client.update({ where: { id: input.clientId }, data: { tags: Array.from(tags) } });
    },
    async history(input) {
      const bookings = await prisma.booking.findMany({ where: { businessId, clientId: input.clientId }, take: 50, orderBy: { createdAt: "desc" } }) as any[];
      const invoices = await prisma.invoice.findMany({ where: { businessId, clientId: input.clientId }, take: 50, orderBy: { createdAt: "desc" } }) as any[];
      return {
        bookings: bookings.map(b => ({ bookingId: b.id, slotId: b.slotId, service: b.service, status: b.status })) as Booking[],
        invoices: invoices.map(i => ({ invoiceId: i.id, clientId: i.clientId, amount: i.amount, status: i.status })) as Invoice[]
      };
    }
  };

  const payments: PaymentsProvider = {
    async createInvoice(input) {
      const row = await prisma.invoice.create({ data: { businessId, clientId: input.clientId, amount: input.amount, status: "sent" } }) as any;
      return { invoiceId: row.id, clientId: row.clientId, amount: row.amount, status: row.status } as Invoice;
    },
    async refund(input) {
      const row = await prisma.invoice.update({ where: { id: input.invoiceId }, data: { status: "refunded" } }) as any;
      return { invoiceId: row.id, clientId: row.clientId, amount: row.amount, status: row.status } as Invoice;
    },
    async applyCredit(input) {
      await prisma.clientCredit.create({ data: { businessId, clientId: input.clientId, amount: input.amount } });
    }
  };

  const marketing: MarketingProvider = {
    async createPromo(input) {
      const row = await prisma.promo.create({ data: { businessId, code: input.code, percentOff: input.percentOff, active: true } }) as any;
      return { code: row.code, percentOff: row.percentOff, active: row.active } as Promo;
    },
    async endPromo(input) {
      const row = await prisma.promo.update({ where: { code: input.code }, data: { active: false } }) as any;
      return { code: row.code, percentOff: row.percentOff, active: row.active } as Promo;
    },
    async referralStatus(input) {
      const row = await prisma.referral.findUnique({ where: { code: input.code } }) as any;
      if (!row) return null;
      return { code: row.code, referrerClientId: row.referrerClientId, uses: row.uses } as Referral;
    },
    async sendCampaign(input) {
      // Queue in DB and let a worker send. Do not do synchronous spam cannons.
      await prisma.campaign.create({ data: { businessId, segment: input.segment, message: input.message, status: "queued" } });
      return { sent: 0 };
    }
  };

  const analytics: AnalyticsProvider = {
    async kpis(_input) {
      const invoices = await prisma.invoice.findMany({ where: { businessId } }) as any[];
      const revenue = invoices.filter(i => i.status !== "refunded").reduce((a, b) => a + b.amount, 0);
      const bookings = await prisma.booking.count({ where: { businessId } });
      const cancels = await prisma.booking.count({ where: { businessId, status: "canceled" } });
      return [
        { key: "revenue", value: revenue, unit: "USD" },
        { key: "bookings", value: bookings },
        { key: "cancellations", value: cancels },
      ] as KPI[];
    },
    async exportReport(input) {
      const url = `https://your-cdn.example/reports/${businessId}/${input.report}.${input.format}`;
      return { url };
    }
  };

  const ops: OpsProvider = {
    async createTask(input) {
      const row = await prisma.task.create({ data: { businessId, title: input.title, status: "open" } }) as any;
      return { taskId: row.id, title: row.title, status: row.status } as Task;
    },
    async listTasks(_input) {
      const rows = await prisma.task.findMany({ where: { businessId }, orderBy: { createdAt: "desc" }, take: 100 }) as any[];
      return rows.map(r => ({ taskId: r.id, title: r.title, status: r.status })) as Task[];
    },
    async markDone(input) {
      const row = await prisma.task.update({ where: { id: input.taskId }, data: { status: "done" } }) as any;
      return { taskId: row.id, title: row.title, status: row.status } as Task;
    },
    async startChecklist(input) {
      const presets: Record<string, string[]> = {
        open: ["Check calendar", "Confirm supplies", "Review client notes"],
        close: ["Send follow-ups", "Reconcile payments", "Prep tomorrow slots"],
      };
      return { steps: presets[input.name] ?? ["Step 1", "Step 2"] };
    }
  };

  const admin: AdminProvider = {
    async showAudit(input) {
      const rows = await prisma.assistantAuditEvent.findMany({
        where: { businessId },
        orderBy: { createdAt: "desc" },
        take: Math.min(input.limit, 200),
      }) as any[];
      return rows.map(r => ({ at: r.createdAt.toISOString(), type: r.type, details: r.detailsJson }));
    },
    async manageRole(input) {
      await prisma.user.update({ where: { id: input.targetUserId }, data: { role: input.role } });
      return { ok: true };
    },
    async gdprExport(input) {
      return { url: `https://your-cdn.example/gdpr/${businessId}/${input.userId}.zip` };
    }
  };

  return { booking, crm, payments, marketing, analytics, ops, admin };
}
