SUBSCRIPTION & BILLING SECURITY

Payment Security
- PCI DSS compliance (as applicable)
- Never store card data (use PSP tokens)
- Tokenization for payment methods
- Secure PSP integration (webhooks verified)
- 3DS/SCA compliance
- Webhook signature verification
- Fraud detection + velocity checks
- Chargeback handling
- Refund security
- Invoice generation security
- Retry logic + dunning
- Failed payment handling
- Payment method update security
- Plan change security (upgrade/downgrade)
- Proration correctness
- Trial management
- Coupon/discount security
- Affiliate tracking integrity
- Tax calculation security
- Multi-currency edge cases

Subscription Management
- Subscription state machine
- Feature access by plan (server-enforced)
- Grace periods
- Downgrade retention policies
- Cancellation workflow
- Pause/resume
- Seat enforcement
- Usage-based billing integrity
- Meter accuracy + reconciliation
- Billing cycles
- Invoice access control
- Payment history security
- Subscription transfers
- Corporate billing (POs)
- Credit management
- Billing notifications
- Dunning management
