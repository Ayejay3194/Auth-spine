import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, listFiles } from "../utils/fs.js";
import { detectFramework } from "./framework.js";

function normalizeRoute(p: string) {
  const clean = p.replace(/\\/g, "/");
  let route = clean;
  route = route.replace(/^.*\/(app|pages)\//, "/");
  route = route.replace(/\/(page|index)\.(tsx|ts|jsx|js)$/, "/");
  route = route.replace(/\.(tsx|ts|jsx|js)$/, "/");
  route = route.replace(/\[\.\.\.(.*?)\]/g, ":$1*");
  route = route.replace(/\[(.*?)\]/g, ":$1");
  route = route.replace(/\/+/g, "/");
  if (!route.startsWith("/")) route = "/" + route;
  if (route.endsWith("/") && route !== "/") route = route.slice(0, -1);
  return route;
}

export function discoverRoutes(root: string): string[] {
  const { framework } = detectFramework(root);
  const routes: string[] = [];

  if (framework === "next") {
    const appDir = path.join(root, "app");
    const pagesDir = path.join(root, "pages");

    if (exists(appDir)) {
      const files = listFiles(appDir, { max: 8000 });
      for (const f of files) {
        const n = f.replace(/\\/g, "/");
        if (/\/page\.(tsx|ts|jsx|js)$/.test(n)) routes.push(normalizeRoute(f));
      }
    }

    if (exists(pagesDir)) {
      const files = listFiles(pagesDir, { max: 8000 });
      for (const f of files) {
        const n = f.replace(/\\/g, "/");
        if (!/\.(tsx|ts|jsx|js)$/.test(n)) continue;
        if (n.includes("/api/")) continue;
        routes.push(normalizeRoute(f));
      }
    }
  }

  return Array.from(new Set(routes)).sort();
}

export function auditRoutes(root: string): AuditSection {
  const section: AuditSection = { id: "routes", title: "Route Crawl (Inventory)", findings: [] };
  const routes = discoverRoutes(root);

  if (routes.length) {
    section.findings.push({
      id: "routes.list",
      title: `Discovered ${routes.length} routes (best-effort)`,
      severity: "INFO",
      details: "Useful for debugging missing pages and deep-link failures.",
      evidence: { routes: routes.slice(0, 250), truncated: routes.length > 250 },
    });
  } else {
    section.findings.push({
      id: "routes.none",
      title: "No Next route files discovered",
      severity: "INFO",
      details: "If you're not using Next, that's expected. If you are, check you pointed at the correct repo root.",
    });
  }

  const outFolder = exists(path.join(root, "out"));
  if (outFolder) {
    section.findings.push({
      id: "routes.staticExport",
      title: "Static export detected (out/ folder exists)",
      severity: "WARN",
      details: "Static exports can deep-link 404 without host rewrites, especially for client-side routes.",
      fix: "Configure host rewrites, or avoid static export for dynamic routing needs.",
      evidence: { outFolder: true },
    });
  }

  return section;
}
