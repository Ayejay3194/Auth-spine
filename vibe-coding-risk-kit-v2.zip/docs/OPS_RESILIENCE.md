# Ops, Backups, DR, and Capacity Checklist

## Backups
- [ ] Automated backups enabled
- [ ] Backups encrypted + stored separately from primary
- [ ] Restore procedure documented and tested (not theoretical)
- [ ] RPO and RTO defined and realistic

## Disaster Recovery
- [ ] Single-region risk acknowledged and mitigated (or accepted explicitly)
- [ ] Failover plan exists (DNS, DB, storage, queues)
- [ ] Runbooks exist (what to do at 2am)
- [ ] Tabletop DR test done quarterly (yes, really)

## Migrations
- [ ] Migrations tested on production-sized data
- [ ] Zero/low-downtime strategy for big tables (expand/contract)
- [ ] Rollback plan documented
- [ ] Migration locks/timeouts understood

## Capacity & Limits
- [ ] Connection pooling configured
- [ ] Limits monitored (DB connections, storage, logs, queue depth)
- [ ] Budget + alerts for cost spikes
- [ ] Rate limits for public APIs + abusive clients
