ADMIN DASHBOARDS
================

Views:
- Executive overview
- Ops health
- Finance health
- CX health
- Risk signals

Principle:
If it can’t drive an action, it doesn’t belong.
