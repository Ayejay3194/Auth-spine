import fs from "node:fs";
import crypto from "node:crypto";

function sha256(s){ return crypto.createHash("sha256").update(s).digest("hex"); }

function canonical(obj){
  // stable JSON stringify: sort keys recursively
  const sort = (x)=>{
    if(Array.isArray(x)) return x.map(sort);
    if(x && typeof x === "object"){
      const keys = Object.keys(x).sort();
      const out = {};
      for(const k of keys) out[k]=sort(x[k]);
      return out;
    }
    return x;
  };
  return JSON.stringify(sort(obj));
}

function hmac(secret, msg){
  return crypto.createHmac("sha256", secret).update(msg).digest("hex");
}

const ledgerPath = process.argv[2];
if(!ledgerPath) { console.error("Usage: node receipt-verify-local.mjs <ledger.jsonl>"); process.exit(2); }
if(!fs.existsSync(ledgerPath)) { console.error("Missing ledger file"); process.exit(2); }

const secret = process.env.RECEIPT_HMAC_SECRET || "";
const lines = fs.readFileSync(ledgerPath,"utf-8").trim().split(/\r?\n/).filter(Boolean);

let prev = "GENESIS";
for(let i=0;i<lines.length;i++){
  const entry = JSON.parse(lines[i]);
  const payload = entry.payload;
  const payloadCanon = canonical(payload);
  const payloadHash = sha256(payloadCanon);

  if(entry.prev_hash !== prev){
    console.error(`Bad prev_hash at line ${i+1}: expected ${prev} got ${entry.prev_hash}`);
    process.exit(1);
  }
  if(entry.payload_hash !== payloadHash){
    console.error(`Bad payload_hash at line ${i+1}`);
    process.exit(1);
  }
  const chainHash = sha256(prev + ":" + payloadHash);
  if(entry.chain_hash !== chainHash){
    console.error(`Bad chain_hash at line ${i+1}`);
    process.exit(1);
  }

  if(entry.hmac){
    if(!secret){
      console.error("Ledger includes hmac but RECEIPT_HMAC_SECRET is not set.");
      process.exit(1);
    }
    const expected = hmac(secret, chainHash);
    if(entry.hmac !== expected){
      console.error(`Bad hmac at line ${i+1}`);
      process.exit(1);
    }
  }
  prev = chainHash;
}
console.log(`Verified ${lines.length} receipt entries. Chain OK.`);
