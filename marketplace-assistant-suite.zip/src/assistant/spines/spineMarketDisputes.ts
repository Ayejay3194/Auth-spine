import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerMarketDisputesTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "market.dispute.open",
    title: "Open dispute",
    description: "Opens a dispute for a booking.",
    inputSchema: { type: "object", properties: { bookingId: { type: "string" }, reason: { type: "string" } }, required: ["bookingId","reason"] },
    async run(ctx, input) { return { ok: true, data: await p.marketDisputes.openDispute(input) }; }
  });

  reg.register({
    id: "market.dispute.resolve",
    title: "Resolve dispute",
    description: "Resolves a dispute with an outcome and refund amount.",
    inputSchema: { type: "object", properties: { disputeId: { type: "string" }, outcome: { type: "string" }, refundAmount: { type: "number" } }, required: ["disputeId","outcome","refundAmount"] },
    async run(ctx, input) { return { ok: true, data: await p.marketDisputes.resolveDispute({ disputeId: input.disputeId, outcome: input.outcome, refundAmount: input.refundAmount }) }; }
  });
}
