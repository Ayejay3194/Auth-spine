export type EntityType = "email" | "username" | "plan";

export interface Entity {
  type: EntityType;
  value: string;
  start: number;
  end: number;
  confidence: number;
}

export interface EntityExtractor { extract(text: string): Entity[]; }

export class RegexEntityExtractor implements EntityExtractor {
  extract(text: string): Entity[] {
    const out: Entity[] = [];
    const emailRe = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
    for (const m of text.matchAll(emailRe)) out.push({ type: "email", value: m[0], start: m.index ?? 0, end: (m.index ?? 0) + m[0].length, confidence: 0.95 });

    const planRe = /\b(free|paid|pro|starter)\b/gi;
    for (const m of text.matchAll(planRe)) out.push({ type: "plan", value: m[0].toLowerCase(), start: m.index ?? 0, end: (m.index ?? 0) + m[0].length, confidence: 0.6 });

    const atName = /@([a-z0-9_]{2,32})/gi;
    for (const m of text.matchAll(atName)) out.push({ type: "username", value: m[1], start: (m.index ?? 0) + 1, end: (m.index ?? 0) + 1 + m[1].length, confidence: 0.55 });

    return out;
  }
}
