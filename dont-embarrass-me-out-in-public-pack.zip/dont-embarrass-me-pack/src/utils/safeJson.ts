import type { Result } from "../runtime/types";

export function safeJsonParse(input: string): Result<unknown> {
  try {
    if (!input || !input.trim()) return { ok: true, data: null };
    return { ok: true, data: JSON.parse(input) };
  } catch (e) {
    return { ok: false, error: { code: "JSON_PARSE_ERROR", message: "Invalid JSON", details: String(e) } };
  }
}
