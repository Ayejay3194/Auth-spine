// marketing tools.ts
