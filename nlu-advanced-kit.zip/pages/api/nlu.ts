import type { NextApiRequest, NextApiResponse } from "next";
import { analyzeTurn } from "../../src/nlu/engine/analyzeTurn";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  const { text = "", sessionId = "default", debug = false } = req.body ?? {};
  const out = await analyzeTurn({ text: String(text), sessionId: String(sessionId), debug: !!debug });
  res.status(200).json(out);
}
