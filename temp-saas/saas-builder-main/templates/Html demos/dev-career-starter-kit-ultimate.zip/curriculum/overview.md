# 8-Module Practical Curriculum

1. Environment + Tools
2. React + Next.js basics
3. Database + Prisma
4. Auth patterns
5. Billing & Stripe
6. UI/UX & Design System
7. Admin & Observability
8. Deployment & Maintenance
