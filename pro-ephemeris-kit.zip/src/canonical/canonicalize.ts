import { stableStringify } from "./stable.js";
import { n } from "./number.js";
import type { ChartDataV1 } from "../contract/schema.js";

/**
 * AMJCS-1 canonicalization:
 * - sort bodies by id
 * - sort houses by house
 * - sort angles by id
 * - sort aspects by (a,b,type,orb,sep)
 * - normalize numerics
 * - strip meta fields that are allowed to vary, but keep engineId for trace
 */
export function canonicalizeChartDataV1(input: Omit<ChartDataV1, "integrity">): string {
  const bodies = [...input.bodies]
    .sort((x, y) => x.id.localeCompare(y.id))
    .map(b => ({
      ...b,
      lon: n(b.lon),
      lat: b.lat === undefined ? undefined : n(b.lat),
      speedLon: b.speedLon === undefined ? undefined : n(b.speedLon),
      degInSign: n(b.degInSign),
    }));

  const houses = [...input.houses]
    .sort((a, b) => a.house - b.house)
    .map(h => ({ ...h, lon: n(h.lon), degInSign: n(h.degInSign) }));

  const angles = [...input.angles]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(a => ({ ...a, lon: n(a.lon), degInSign: n(a.degInSign) }));

  const aspects = [...(input.aspects ?? [])]
    .sort((x, y) => {
      const ax = [x.a, x.b, x.type, x.orb, x.sep].join("|");
      const ay = [y.a, y.b, y.type, y.orb, y.sep].join("|");
      return ax.localeCompare(ay);
    })
    .map(a => ({
      ...a,
      orb: n(a.orb),
      exact: n(a.exact),
      sep: n(a.sep),
    }));

  const out = {
    ...input,
    bodies,
    houses,
    angles,
    aspects,
    meta: {
      ...input.meta,
      // computedAtUtc is allowed to vary between runs, so it does NOT affect canonical.
      computedAtUtc: "0000-00-00T00:00:00Z",
    },
  };

  return stableStringify(out);
}
