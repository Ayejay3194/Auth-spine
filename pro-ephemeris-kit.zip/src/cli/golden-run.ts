import path from "node:path";
import fs from "node:fs";
import { runOne, writeFile } from "./_common.js";

const reqDir = path.resolve("fixtures/requests");
const outDir = path.resolve("fixtures/outputs");

for (const file of fs.readdirSync(reqDir).filter(f => f.endsWith(".json"))) {
  const reqPath = path.join(reqDir, file);
  const base = file.replace(/\.json$/,"");
  const { chart, text } = await runOne(reqPath);

  writeFile(path.join(outDir, `${base}.canonical.json`), JSON.stringify(chart, null, 2) + "\n");
  writeFile(path.join(outDir, `${base}.amt1.txt`), text);
  console.log("wrote", base);
}
