const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const PHONE_RE = /\b(\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g;
const SSN_RE   = /\b\d{3}-\d{2}-\d{4}\b/g;
const BANK_RE  = /\b\d{9,18}\b/g;

export function redactText(text: string) {
  return text
    .replace(SSN_RE, "[REDACTED_SSN]")
    .replace(EMAIL_RE, "[REDACTED_EMAIL]")
    .replace(PHONE_RE, "[REDACTED_PHONE]")
    .replace(BANK_RE, "[REDACTED_NUMBER]");
}

export function deepRedact(obj: any): any {
  if (typeof obj === "string") return redactText(obj);
  if (Array.isArray(obj)) return obj.map(deepRedact);
  if (obj && typeof obj === "object") {
    const out: any = {};
    for (const [k,v] of Object.entries(obj)) out[k] = deepRedact(v);
    return out;
  }
  return obj;
}
