Stripe integration notes.
