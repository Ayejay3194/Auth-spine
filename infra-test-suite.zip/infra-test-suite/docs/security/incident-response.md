# Incident Response (stub)

Define severity levels, comms, and steps.
