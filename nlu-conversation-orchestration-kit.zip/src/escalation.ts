import { ToneLevel, TurnInput } from "./types";

export type EscalationResult = {
  toneLevel: ToneLevel;
  notes: string[];
};

// Very simple escalation model:
// - If user is noncompliant and not reactive, allow slight escalation.
// - If user is reactive, de-escalate.
export function applyEscalation(input: TurnInput, tone: ToneLevel): EscalationResult {
  const notes: string[] = [];
  const { state } = input;

  let t: ToneLevel = tone;

  if (state.recentUserEmotionalReactivity >= 0.6) {
    notes.push("High emotional reactivity -> de-escalate by 1.");
    t = Math.max(0, (t - 1)) as ToneLevel;
  } else if (state.recentUserComplianceScore <= 0.25 && state.recentUserEmotionalReactivity <= 0.25) {
    notes.push("Low compliance + low reactivity -> allow gentle escalation by 1 (cap 3).");
    t = Math.min(3, (t + 1)) as ToneLevel;
  } else {
    notes.push("No escalation change.");
  }

  return { toneLevel: t, notes };
}
