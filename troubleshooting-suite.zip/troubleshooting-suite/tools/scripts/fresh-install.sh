#!/usr/bin/env bash
set -euo pipefail
echo "[fresh-install] deleting node_modules + lock drift traps"
rm -rf node_modules dist build .next out
rm -f npm-debug.log yarn-error.log
echo "[fresh-install] installing"
if [ -f package-lock.json ]; then npm ci; else npm install; fi
echo "[fresh-install] done"
