# Just-in-time access (support/admin)
- Default: no production access
- Request access with reason + TTL
- Approver required for elevated scopes
- Auto-expire access
- Log grant + revoke events
