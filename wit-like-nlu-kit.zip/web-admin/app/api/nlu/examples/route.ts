import { NextRequest, NextResponse } from "next/server";
import { getNLUBaseUrl } from "@/lib/serverEnv";

export async function POST(req: NextRequest) {
  const payload = await req.json();
  const base = getNLUBaseUrl();
  const r = await fetch(`${base}/examples`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload)
  });
  const body = await r.json();
  return NextResponse.json(body, { status: r.status });
}
