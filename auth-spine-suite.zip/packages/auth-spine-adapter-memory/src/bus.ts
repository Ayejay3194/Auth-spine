import type { EventBus, AuthEvent } from '@spine/auth-core';
export class MemoryBus implements EventBus { events: AuthEvent[]=[]; async publish(evt:AuthEvent){ this.events.push(evt);} }
