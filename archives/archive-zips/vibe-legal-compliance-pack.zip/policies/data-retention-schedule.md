# Data Retention Schedule (Template)

**Goal:** keep data only as long as needed for operations, legal obligations, and security.

| Data category | Examples | Default retention | Notes |
|---|---|---:|---|
| Account/profile | name, email, portfolio | Active account + {{RETENTION_AFTER_CLOSE}} | delete/anonymize after close window |
| Bookings | appointments, cancellations | {{BOOKING_RETENTION}} | for disputes/taxes |
| Messages | client↔stylist DMs | {{MESSAGE_RETENTION}} | allow user delete where possible |
| Audit logs | auth/admin actions | {{AUDIT_RETENTION}} | longer for enterprise |
| Security logs | WAF/auth anomalies | {{SECURITY_LOG_RETENTION}} | minimize PII |
| Analytics | event counts | {{ANALYTICS_RETENTION}} | avoid raw PII |

## Deletion semantics
- **Soft delete** (hidden) for {{SOFT_DELETE_WINDOW}}
- **Hard delete** after retention window + backup expiry

## Backups
Backups expire after {{BACKUP_RETENTION}}. Keep deletion consistent with backup policies.
