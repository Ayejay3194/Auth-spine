import { ToneLevel, TurnInput } from "./types";

export type ToneArbiterResult = {
  toneLevel: ToneLevel;
  notes: string[];
};

function clamp01(n: number): number {
  return Math.max(0, Math.min(1, n));
}

export function arbitrateTone(input: TurnInput): ToneArbiterResult {
  const notes: string[] = [];
  const { nlu, state } = input;

  // Base: start neutral
  let score = 0;

  // Confidence gates: low confidence -> avoid sharp tone
  if (nlu.confidence < 0.5) {
    notes.push("Low NLU confidence -> dampen tone.");
    score -= 0.6;
  }

  // Intent-based nudges (customize these)
  const intent = (nlu.intent || "unknown").toLowerCase();
  const intentBoosts: Record<string, number> = {
    greeting: -0.4,
    thanks: -0.5,
    help: -0.2,
    request: -0.1,
    complaint: 0.3,
    refusal: 0.4,
    disrespect: 0.7,
    spam: 0.8,
    unknown: -0.2,
  };
  score += intentBoosts[intent] ?? 0;
  notes.push(`Intent boost for "${intent}": ${intentBoosts[intent] ?? 0}`);

  // User tolerance (low tolerance -> reduce score)
  score += (state.userTolerance - 0.5) * 0.9;
  notes.push(`User tolerance adjustment: ${(state.userTolerance - 0.5) * 0.9}`);

  // Compliance: if user has been complying recently, reduce snark
  score -= clamp01(state.recentUserComplianceScore) * 0.6;
  notes.push(`Compliance dampener: -${clamp01(state.recentUserComplianceScore) * 0.6}`);

  // Emotional reactivity: if user seems reactive, soften
  score -= clamp01(state.recentUserEmotionalReactivity) * 0.8;
  notes.push(`Reactivity dampener: -${clamp01(state.recentUserEmotionalReactivity) * 0.8}`);

  // Sticky tone: don't jump too far from last
  score += (state.lastToneLevel - 1) * 0.15;
  notes.push(`Sticky tone nudge from lastToneLevel=${state.lastToneLevel}`);

  // Map score -> tone level
  // score roughly in [-1.5, 1.5]
  let tone: ToneLevel = 0;
  if (score < -0.25) tone = 0;
  else if (score < 0.35) tone = 1;
  else if (score < 0.95) tone = 2;
  else tone = 3;

  notes.push(`Final tone score=${score.toFixed(2)} -> toneLevel=${tone}`);
  return { toneLevel: tone, notes };
}
