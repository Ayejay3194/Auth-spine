import { NextRequest, NextResponse } from "next/server";
import { applySecurityHeaders } from "./security/headers/securityHeaders";

export function middleware(req: NextRequest) {
  const res = NextResponse.next();
  applySecurityHeaders(res.headers);
  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
