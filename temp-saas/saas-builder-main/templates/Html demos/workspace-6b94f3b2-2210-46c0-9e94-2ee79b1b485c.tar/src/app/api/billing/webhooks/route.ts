import { NextRequest, NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { db } from '@/lib/db'

// POST /api/billing/webhooks - Stripe webhook handler
export async function POST(request: NextRequest) {
  const body = await request.text()
  const signature = headers().get('stripe-signature')

  if (!signature) {
    return NextResponse.json(
      { error: 'No signature' },
      { status: 400 }
    )
  }

  // In a real implementation, you would verify the webhook signature
  // const event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!)

  try {
    // For demo purposes, we'll simulate webhook events
    const event = JSON.parse(body)

    switch (event.type) {
      case 'invoice.payment_succeeded':
        await handlePaymentSucceeded(event.data.object)
        break
      case 'invoice.payment_failed':
        await handlePaymentFailed(event.data.object)
        break
      case 'customer.subscription.created':
        await handleSubscriptionCreated(event.data.object)
        break
      case 'customer.subscription.updated':
        await handleSubscriptionUpdated(event.data.object)
        break
      case 'customer.subscription.deleted':
        await handleSubscriptionDeleted(event.data.object)
        break
      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error('Webhook error:', error)
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 500 }
    )
  }
}

async function handlePaymentSucceeded(invoice: any) {
  // Update subscription status to ACTIVE
  if (invoice.subscription) {
    await db.subscription.update({
      where: { stripeId: invoice.subscription },
      data: { 
        status: 'ACTIVE',
        currentPeriodStart: new Date(invoice.period_start * 1000),
        currentPeriodEnd: new Date(invoice.period_end * 1000),
      }
    })

    // Create billing event
    await db.billingEvent.create({
      data: {
        subscriptionId: invoice.subscription,
        stripeId: invoice.id,
        type: 'INVOICE_PAYMENT_SUCCEEDED',
        amount: invoice.amount_paid,
        description: `Payment for invoice ${invoice.number}`,
      }
    })
  }
}

async function handlePaymentFailed(invoice: any) {
  // Update subscription status to PAST_DUE
  if (invoice.subscription) {
    await db.subscription.update({
      where: { stripeId: invoice.subscription },
      data: { status: 'PAST_DUE' }
    })

    // Create billing event
    await db.billingEvent.create({
      data: {
        subscriptionId: invoice.subscription,
        stripeId: invoice.id,
        type: 'INVOICE_PAYMENT_FAILED',
        amount: invoice.amount_due,
        description: `Failed payment for invoice ${invoice.number}`,
      }
    })
  }
}

async function handleSubscriptionCreated(subscription: any) {
  // Update subscription with Stripe ID
  await db.subscription.update({
    where: { workspaceId: subscription.metadata.workspaceId },
    data: {
      stripeId: subscription.id,
      status: 'ACTIVE',
      currentPeriodStart: new Date(subscription.current_period_start * 1000),
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
    }
  })
}

async function handleSubscriptionUpdated(subscription: any) {
  // Update subscription details
  await db.subscription.update({
    where: { stripeId: subscription.id },
    data: {
      status: subscription.status.toUpperCase(),
      currentPeriodStart: new Date(subscription.current_period_start * 1000),
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
    }
  })
}

async function handleSubscriptionDeleted(subscription: any) {
  // Cancel subscription
  await db.subscription.update({
    where: { stripeId: subscription.id },
    data: {
      status: 'CANCELED',
      canceledAt: new Date(),
    }
  })
}