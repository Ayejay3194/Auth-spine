#!/usr/bin/env bash
set -euo pipefail
cp -n .env.example .env || true
docker compose up -d
echo "Studio: http://localhost:3000"
echo "API:    http://localhost:8000"
echo "DB:     localhost:5432"
