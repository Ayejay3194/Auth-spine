DATA RESIDENCY & SOVEREIGNTY

Geographic Compliance
- Multi-region deploy
- Data residency per tenant
- Regional failover controls
- Cross-region replication controls
- Transfer mechanisms (SCC/BCR as needed)
- Local processing law awareness
- Transparency about data location
- Region choice + SLA commitments

Data Portability
- Full export (JSON/CSV) + metadata/config
- Large dataset export handling
- Export encryption + access logging
- Scheduled vs on-demand exports
- Export retention + deletion after download
- Import validation + rollback
- SAR support (data subject access requests)
