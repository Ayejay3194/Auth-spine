# Prompt: DevLog & Ticket Writer
[Turn messy notes into tickets, devlog, risks.]
