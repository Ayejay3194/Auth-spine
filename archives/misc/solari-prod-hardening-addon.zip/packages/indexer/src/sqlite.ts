import Database from "better-sqlite3";
import type { Node } from "@solari/schema";

export function packToSqlite(nodes: Node[], outFile: string) {
  const db = new Database(outFile);
  db.pragma("journal_mode = WAL");
  db.exec(`
    DROP TABLE IF EXISTS nodes;
    CREATE TABLE nodes (
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      title TEXT NOT NULL,
      summary TEXT,
      body TEXT,
      tags TEXT,
      aliases TEXT,
      links TEXT,
      version TEXT,
      provenance TEXT
    );
    CREATE INDEX idx_nodes_kind ON nodes(kind);
    CREATE INDEX idx_nodes_title ON nodes(title);
  `);

  const ins = db.prepare(`
    INSERT INTO nodes (id, kind, title, summary, body, tags, aliases, links, version, provenance)
    VALUES (@id, @kind, @title, @summary, @body, @tags, @aliases, @links, @version, @provenance)
  `);

  const tx = db.transaction((rows: Node[]) => {
    for (const n of rows) {
      ins.run({
        ...n,
        tags: JSON.stringify(n.tags ?? []),
        aliases: JSON.stringify(n.aliases ?? []),
        links: JSON.stringify(n.links ?? []),
        provenance: JSON.stringify(n.provenance ?? null),
      } as any);
    }
  });

  tx(nodes);
  db.close();
}
