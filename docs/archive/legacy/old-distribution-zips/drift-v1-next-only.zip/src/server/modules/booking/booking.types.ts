import type { ID, ISODateTime, BookingStatus, Money } from "@/src/server/core/types";

export type Booking = {
  id: ID;
  artistId: ID;
  clientId: ID;
  serviceId: ID;
  startAt: ISODateTime;
  endAt: ISODateTime;
  status: BookingStatus;
  deposit?: Money;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
};

export type CreateBookingInput = {
  artistId: ID;
  clientId: ID;
  serviceId: ID;
  startAt: ISODateTime;
  endAt: ISODateTime;
  requestedVia: "SMS" | "WEB" | "ARTIST_APP";
};

export type BookingLockKey = string;
