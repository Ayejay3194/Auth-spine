# Accessibility Statement (Template)

We aim to make {{PRODUCT_NAME}} usable for as many people as possible, including users with disabilities.

## Conformance target
We target **WCAG 2.1 AA**.

## What we support
- keyboard navigation
- semantic HTML
- focus indicators
- sufficient contrast
- reduced-motion support

## Report issues
Email: {{ACCESSIBILITY_EMAIL}} with:
- page URL
- device/browser
- what you were trying to do
- screenshot/video if possible
