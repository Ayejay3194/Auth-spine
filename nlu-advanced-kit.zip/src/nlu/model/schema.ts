import type { NLUModel } from "../types";

export const MODEL_VERSION = "1.0.0";

export function validateModel(model: NLUModel): { ok: true } | { ok: false; error: string } {
  if (!model || typeof model !== "object") return { ok: false, error: "Model is not an object" };
  if (!model.version) return { ok: false, error: "Model.version missing" };
  if (!Array.isArray(model.intents)) return { ok: false, error: "Model.intents must be an array" };
  if (!Array.isArray(model.entities)) return { ok: false, error: "Model.entities must be an array" };

  const intentNames = new Set<string>();
  for (const it of model.intents) {
    if (!it.name) return { ok: false, error: "Intent missing name" };
    if (intentNames.has(it.name)) return { ok: false, error: `Duplicate intent: ${it.name}` };
    intentNames.add(it.name);
    if (!Array.isArray(it.examples)) return { ok: false, error: `Intent ${it.name} examples must be array` };
  }

  const entityNames = new Set<string>();
  for (const en of model.entities) {
    if (!en.name) return { ok: false, error: "Entity missing name" };
    if (entityNames.has(en.name)) return { ok: false, error: `Duplicate entity: ${en.name}` };
    entityNames.add(en.name);
    if (!Array.isArray(en.examples)) return { ok: false, error: `Entity ${en.name} examples must be array` };
  }

  return { ok: true };
}

export function withDefaults(model: NLUModel): NLUModel {
  return {
    ...model,
    settings: {
      temperature: model.settings?.temperature ?? 0.3,
      minConfidenceToAct: model.settings?.minConfidenceToAct ?? 0.55,
      minConfidenceToSkipClarify: model.settings?.minConfidenceToSkipClarify ?? 0.75,
    },
  };
}
