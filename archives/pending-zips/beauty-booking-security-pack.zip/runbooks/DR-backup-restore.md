# Disaster Recovery: Backup Restore Drill

- Restore to isolated environment
- Validate:
  - auth works
  - bookings visible
  - payments reconciled
  - uploads accessible
- Measure:
  - RTO achieved?
  - RPO achieved?
- Document results + action items
