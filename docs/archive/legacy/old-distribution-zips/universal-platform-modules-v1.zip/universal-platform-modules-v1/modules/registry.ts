import type { ModuleSpec } from "./types";
import registryJson from "./registry.json";

export const MODULE_REGISTRY: ModuleSpec[] = registryJson as any;

export function getModule(id: string) {
  return MODULE_REGISTRY.find((m) => m.id === id);
}
