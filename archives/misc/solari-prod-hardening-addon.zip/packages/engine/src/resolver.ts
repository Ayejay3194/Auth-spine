import type { Node } from "@solari/schema";
import { RepetitionMemory } from "./memory.js";

export type Query = {
  intents: string[];        // e.g. ["hd:type","biz:policy","astro:aspect"]
  mustHaveIds?: string[];   // hard include
  preferTags?: string[];
  avoidIds?: string[];
  text?: string;            // user query
};

export type ResolveResult = {
  selected: Node[];
  reasons: Record<string, string[]>;
};

function scoreNode(node: Node, q: Query, mem?: RepetitionMemory) {
  let score = 0;
  const reasons: string[] = [];
  const text = (q.text ?? "").toLowerCase();

  if (q.intents.includes(node.kind)) { score += 50; reasons.push("kind match"); }
  if (q.preferTags?.some(t => node.tags.includes(t))) { score += 10; reasons.push("preferred tag"); }
  if (text && (node.title.toLowerCase().includes(text) || (node.summary ?? "").toLowerCase().includes(text))) {
    score += 8; reasons.push("text match");
  }
  if (mem?.hasId(node.id)) { score -= 25; reasons.push("anti-repeat id"); }
  // light anti-repeat: repeated titles
  if (mem?.hasPhrase(node.title)) { score -= 8; reasons.push("anti-repeat title"); }

  return { score, reasons };
}

/**
 * Deterministic resolver: stable sort by score desc then id asc.
 */
export function resolve(nodes: Node[], q: Query, options?: { limit?: number; memory?: RepetitionMemory }): ResolveResult {
  const reasons: Record<string, string[]> = {};
  const mem = options?.memory;

  const must = new Set(q.mustHaveIds ?? []);
  const avoid = new Set(q.avoidIds ?? []);

  const scored = nodes
    .filter(n => !avoid.has(n.id))
    .map(n => {
      const s = scoreNode(n, q, mem);
      reasons[n.id] = s.reasons;
      return { n, score: s.score };
    })
    .sort((a,b) => (b.score - a.score) || a.n.id.localeCompare(b.n.id));

  const selected: Node[] = [];

  for (const id of must) {
    const found = nodes.find(n => n.id === id);
    if (found) selected.push(found);
  }

  for (const { n } of scored) {
    if (selected.some(x => x.id === n.id)) continue;
    if (selected.length >= (options?.limit ?? 12)) break;
    selected.push(n);
  }

  // update memory
  for (const n of selected) {
    mem?.noteId(n.id);
    mem?.notePhrase(n.title);
  }

  return { selected, reasons };
}
