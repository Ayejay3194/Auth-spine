// discovery tools.ts
