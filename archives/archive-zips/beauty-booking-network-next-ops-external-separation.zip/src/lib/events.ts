import { prisma } from "@/lib/prisma";
import type { EventEntityType } from "@prisma/client";

type LogEventInput = {
  actorUserId?: string | null;
  entityType: EventEntityType;
  entityId: string;
  name: string;
  props?: any;
};

export async function logEvent(input: LogEventInput) {
  try {
    await prisma.event.create({
      data: {
        at: new Date(),
        actorUserId: input.actorUserId ?? null,
        entityType: input.entityType,
        entityId: input.entityId,
        name: input.name,
        props: input.props ?? undefined,
      },
    });
  } catch {
    // analytics should never break core flows
  }
}
