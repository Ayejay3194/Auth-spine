// marketing entities.ts
