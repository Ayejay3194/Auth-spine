import { ChartDataV1 } from './types.js';

export type ValidationIssue =
  | { level: 'error'; code: string; message: string; path?: string }
  | { level: 'warn'; code: string; message: string; path?: string };

export interface ValidationResult {
  ok: boolean;
  issues: ValidationIssue[];
}

export function validateChartData(chart: Partial<ChartDataV1>): ValidationResult {
  const issues: ValidationIssue[] = [];

  const req = (cond: any, code: string, message: string, path?: string) => {
    if (!cond) issues.push({ level: 'error', code, message, path });
  };
  const warn = (cond: any, code: string, message: string, path?: string) => {
    if (!cond) issues.push({ level: 'warn', code, message, path });
  };

  req(chart && typeof chart === 'object', 'CHART_NOT_OBJECT', 'Chart payload must be an object');
  if (!chart || typeof chart !== 'object') return { ok: false, issues };

  req(chart.schemaVersion === '1.0', 'BAD_SCHEMA_VERSION', 'schemaVersion must be "1.0"', 'schemaVersion');
  req(typeof chart.engine === 'string' && chart.engine.length > 0, 'MISSING_ENGINE', 'engine is required', 'engine');
  req(typeof chart.engineVersion === 'string' && chart.engineVersion.length > 0, 'MISSING_ENGINE_VERSION', 'engineVersion is required', 'engineVersion');
  req(typeof chart.chartType === 'string' && chart.chartType.length > 0, 'MISSING_CHART_TYPE', 'chartType is required', 'chartType');

  req(typeof chart.createdAt === 'string' && chart.createdAt.length > 0, 'MISSING_CREATED_AT', 'createdAt is required', 'createdAt');

  // Input
  req(!!chart.input, 'MISSING_INPUT', 'input is required', 'input');
  if (chart.input) {
    req(typeof chart.input.date === 'string' && chart.input.date.length > 0, 'MISSING_INPUT_DATE', 'input.date is required', 'input.date');
    req(typeof chart.input.time === 'string' && chart.input.time.length > 0, 'MISSING_INPUT_TIME', 'input.time is required', 'input.time');
    req(typeof chart.input.timezone === 'string' && chart.input.timezone.length > 0, 'MISSING_TZ', 'input.timezone is required', 'input.timezone');
    req(typeof chart.input.lat === 'number', 'MISSING_LAT', 'input.lat is required', 'input.lat');
    req(typeof chart.input.lon === 'number', 'MISSING_LON', 'input.lon is required', 'input.lon');

    // “Missing Coordinates 0°0'” is a classic landmine
    warn(!(chart.input.lat === 0 && chart.input.lon === 0), 'ZERO_COORDS', 'lat/lon are 0,0 (looks like missing coordinates)', 'input');
  }

  // Settings
  req(!!chart.settings, 'MISSING_SETTINGS', 'settings is required', 'settings');
  if (chart.settings) {
    req(typeof chart.settings.houseSystem === 'string', 'MISSING_HOUSE_SYSTEM', 'settings.houseSystem is required', 'settings.houseSystem');
    req(typeof chart.settings.zodiac === 'string', 'MISSING_ZODIAC', 'settings.zodiac is required', 'settings.zodiac');
  }

  // Output
  req(!!chart.output, 'MISSING_OUTPUT', 'output is required', 'output');
  if (chart.output) {
    req(typeof chart.output.ut === 'string' && chart.output.ut.length > 0, 'MISSING_UT', 'output.ut is required', 'output.ut');
    req(typeof chart.output.lst === 'string' && chart.output.lst.length > 0, 'MISSING_LST', 'output.lst is required', 'output.lst');
    req(Array.isArray(chart.output.points) && chart.output.points.length > 0, 'MISSING_POINTS', 'output.points must be a non-empty array', 'output.points');
    req(Array.isArray(chart.output.houses) && chart.output.houses.length > 0, 'MISSING_HOUSES', 'output.houses must be a non-empty array', 'output.houses');

    // sanity: degrees should be 0..360 (allow tiny float drift)
    if (Array.isArray(chart.output.points)) {
      for (let i = 0; i < chart.output.points.length; i++) {
        const p: any = chart.output.points[i];
        if (typeof p?.lon === 'number') {
          warn(p.lon >= -1e-7 && p.lon < 360 + 1e-7, 'BAD_LONGITUDE', `point[${i}].lon out of range: ${p.lon}`, `output.points[${i}].lon`);
        }
      }
    }
  }

  return { ok: issues.every((x) => x.level !== 'error'), issues };
}
