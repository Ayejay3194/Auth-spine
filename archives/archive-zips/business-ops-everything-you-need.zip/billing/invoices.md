Invoices, estimates, receipts, subscriptions.
