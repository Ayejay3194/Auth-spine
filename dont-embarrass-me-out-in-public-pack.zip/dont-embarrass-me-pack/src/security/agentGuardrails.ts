import { z } from "zod";
import { logger } from "../observability/logger";
import type { RequestContext, Result } from "../runtime/types";
import { featureFlags } from "./featureFlags";
import type { Policy } from "./policy";
import { isToolAllowed } from "./policy";

export const ToolCallSchema = z.object({
  name: z.string().min(1),
  input: z.record(z.any()).default({})
});

export type ToolCall = z.infer<typeof ToolCallSchema>;

export interface GuardrailConfig {
  maxSteps: number;
  maxMs: number;
  maxDepth: number;
}

export function getDefaultGuardrails(): GuardrailConfig {
  return {
    maxSteps: Number(process.env.TOOL_MAX_STEPS || 8),
    maxMs: Number(process.env.TOOL_MAX_MS || 8000),
    maxDepth: Number(process.env.TOOL_MAX_DEPTH || 4)
  };
}

export async function withToolGuardrails<T>(
  args: {
    ctx: RequestContext;
    policy: Policy;
    guardrails?: Partial<GuardrailConfig>;
    toolName: string;
    depth: number;
    startedAt: number;
    stepsUsed: number;
  },
  fn: () => Promise<T>
): Promise<Result<T>> {
  try {
    if (!featureFlags.isEnabled("TOOL_EXECUTION_ENABLED", args.ctx.tenantId)) {
      return { ok: false, error: { code: "TOOLS_DISABLED", message: "Tool execution disabled" } };
    }

    const gr = { ...getDefaultGuardrails(), ...args.guardrails };
    const elapsed = Date.now() - args.startedAt;

    if (args.depth > gr.maxDepth) {
      return { ok: false, error: { code: "TOOL_DEPTH_LIMIT", message: "Tool depth limit exceeded" } };
    }
    if (args.stepsUsed >= gr.maxSteps) {
      return { ok: false, error: { code: "TOOL_STEP_LIMIT", message: "Tool step limit exceeded" } };
    }
    if (elapsed > gr.maxMs) {
      return { ok: false, error: { code: "TOOL_TIMEOUT", message: "Tool execution time budget exceeded" } };
    }

    const role = args.ctx.actor.role;
    if (!isToolAllowed(args.policy, role, args.toolName)) {
      logger.warn("tool.deny", { tool: args.toolName, role, requestId: args.ctx.requestId });
      return { ok: false, error: { code: "TOOL_DENIED", message: "Tool not allowed" } };
    }

    const data = await fn();
    return { ok: true, data };
  } catch (e) {
    logger.error("tool.error", { err: String(e), tool: args.toolName, requestId: args.ctx.requestId });
    return { ok: false, error: { code: "TOOL_ERROR", message: "Tool failed", details: String(e) } };
  }
}
