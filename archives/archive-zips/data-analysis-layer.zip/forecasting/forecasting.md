FORECASTING
===========

Forecast:
- demand by day/week
- staffing needs
- payout liquidity
- revenue trends

Inputs:
- historical bookings
- seasonality
- policy changes
