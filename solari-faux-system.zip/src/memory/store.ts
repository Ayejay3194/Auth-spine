import { Message, MemorySnapshot } from "../types.js";

export class MemoryStore {
  private facts: Record<string, string> = {};
  private prefs: Record<string, string> = {};
  private recent: Message[] = [];
  private maxRecent = 20;

  setFact(key: string, value: string) {
    this.facts[key] = value;
  }

  setPref(key: string, value: string) {
    this.prefs[key] = value;
  }

  addMessage(msg: Message) {
    this.recent.push(msg);
    if (this.recent.length > this.maxRecent) this.recent.shift();
  }

  snapshot(): MemorySnapshot {
    return {
      facts: { ...this.facts },
      prefs: { ...this.prefs },
      recent: [...this.recent],
    };
  }
}
