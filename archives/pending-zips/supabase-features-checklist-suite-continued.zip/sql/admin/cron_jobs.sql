-- Example pg_cron jobs (if extension enabled)
-- select cron.schedule('admin-vacuum-analyze', '0 3 * * *', $$vacuum (analyze);$$);
-- select cron.schedule('admin-refresh-matviews', '*/15 * * * *', $$refresh materialized view concurrently your_matview;$$);

-- You can also schedule custom maintenance functions you define.
