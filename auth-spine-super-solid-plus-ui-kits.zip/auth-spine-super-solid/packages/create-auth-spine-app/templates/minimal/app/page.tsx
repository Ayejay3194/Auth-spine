export default function Page(){return <div style={{padding:24}}>New minimal app</div>}
