# Wit-like NLU Kit (Pro-ish)
A small, self-hosted, **Wit.ai-style** NLU loop: **label → train → parse → iterate**, with:
- **Multi-intent** classification (multi-label)
- **Entities + roles + synonyms** (lookup + regex rules)
- **Versioned models** (activate/rollback)
- **FastAPI + scikit-learn** backend
- **Next.js admin** UI (lightweight but usable)

## Quickstart (local)
### 1) Backend
```bash
cd nlu-service
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### 2) Web Admin
```bash
cd web-admin
npm i
npm run dev
# open http://localhost:3000/admin/nlu
```

## API (high level)
- `POST /examples` add labeled examples
- `POST /train` train a new model version
- `POST /parse` parse text using active model
- `GET /models` list model versions
- `POST /models/{id}/activate` activate a model version

## Data model (example)
```json
{
  "text": "Book Amy for balayage tomorrow at 2pm",
  "intents": [{"name":"booking.create","confidence":1.0}],
  "entities": [
    {"entity":"service","role":"primary","value":"balayage","start":13,"end":21},
    {"entity":"datetime","role":"start","value":"tomorrow at 2pm","start":22,"end":37},
    {"entity":"person","role":"provider","value":"Amy","start":5,"end":8}
  ]
}
```

## Notes
This kit aims for **practical** not magical. If you need ML-grade entity extraction, plug in spaCy/transformers later.
