import fs from "node:fs";
import YAML from "yaml";
import { z } from "zod";

const ProfileSchema = z.object({
  run: z.object({
    failOnSeverity: z.enum(["P0","P1","P2","INFO"]).default("P0"),
    allowlistFile: z.string().default("waivers.yaml"),
  }).default({ failOnSeverity: "P0", allowlistFile: "waivers.yaml" }),
  expectations: z.object({
    documents: z.array(z.object({
      path: z.string(),
      severity: z.enum(["P0","P1","P2","INFO"]).default("P1"),
      why: z.string().optional()
    })).default([]),
    controls: z.any().optional()
  }).default({ documents: [] }),
  rules: z.any().optional()
});

export function loadProfile(profilePath: string) {
  const raw = fs.readFileSync(profilePath, "utf-8");
  const parsed = YAML.parse(raw);
  return ProfileSchema.parse(parsed);
}

export function loadAllowlist(allowlistPath: string) {
  if (!fs.existsSync(allowlistPath)) return { waivers: [] };
  const raw = fs.readFileSync(allowlistPath, "utf-8");
  return YAML.parse(raw) ?? { waivers: [] };
}
