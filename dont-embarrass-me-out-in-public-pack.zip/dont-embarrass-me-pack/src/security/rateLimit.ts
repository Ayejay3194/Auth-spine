import type { Request, Response, NextFunction } from "express";
import { logger } from "../observability/logger";

export interface RateLimitStore {
  incr(key: string, windowMs: number): { count: number; resetAt: number };
}

export class MemoryRateLimitStore implements RateLimitStore {
  private buckets = new Map<string, { count: number; resetAt: number }>();

  incr(key: string, windowMs: number) {
    const now = Date.now();
    const existing = this.buckets.get(key);
    if (!existing || existing.resetAt <= now) {
      const resetAt = now + windowMs;
      const v = { count: 1, resetAt };
      this.buckets.set(key, v);
      return v;
    }
    existing.count += 1;
    return existing;
  }
}

export function rateLimit(opts: { max: number; windowMs: number; store?: RateLimitStore }) {
  const store = opts.store ?? new MemoryRateLimitStore();

  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ctx?.ip || req.ip || "unknown";
    const key = `rl:${ip}:${req.path}`;
    const { count, resetAt } = store.incr(key, opts.windowMs);

    res.setHeader("X-RateLimit-Limit", String(opts.max));
    res.setHeader("X-RateLimit-Remaining", String(Math.max(0, opts.max - count)));
    res.setHeader("X-RateLimit-Reset", String(Math.floor(resetAt / 1000)));

    if (count > opts.max) {
      logger.warn("ratelimit.block", { ip, path: req.path, count, max: opts.max });
      return res.status(429).json({ error: "Rate limit exceeded" });
    }
    next();
  };
}
