import { User, Workspace, WorkspaceMember, Role, Project, Task, Subscription, Plan, Invitation } from '@prisma/client'

// Enhanced types with relations
export type UserWithWorkspaces = User & {
  workspaceMembers: (WorkspaceMember & {
    workspace: Workspace
  })[]
}

export type WorkspaceWithMembers = Workspace & {
  members: (WorkspaceMember & {
    user: User
  })[]
  _count: {
    members: number
    projects: number
  }
}

export type WorkspaceWithSubscription = Workspace & {
  subscription?: (Subscription & {
    plan: Plan
  }) | null
}

export type ProjectWithTasks = Project & {
  _count: {
    tasks: number
  }
}

export type TaskWithProject = Task & {
  project: Project
}

// Auth types
export type AuthUser = {
  id: string
  email: string
  name?: string
  avatar?: string
  isAdmin: boolean
}

export type AuthSession = {
  user: AuthUser
  activeWorkspaceId?: string
}

// Permission system
export type Permission = 
  | 'workspace:read'
  | 'workspace:write'
  | 'workspace:delete'
  | 'workspace:members:read'
  | 'workspace:members:write'
  | 'workspace:billing:read'
  | 'workspace:billing:write'
  | 'project:read'
  | 'project:write'
  | 'project:delete'
  | 'task:read'
  | 'task:write'
  | 'task:delete'
  | 'admin:impersonate'
  | 'admin:system:read'

export type RolePermissions = {
  [K in Role]: Permission[]
}

// API Response types
export type ApiResponse<T = any> = {
  success: boolean
  data?: T
  error?: {
    code: string
    message: string
    details?: any
  }
  meta?: {
    pagination?: {
      page: number
      limit: number
      total: number
      totalPages: number
    }
  }
}

export type PaginatedParams = {
  page?: number
  limit?: number
  sortBy?: string
  sortOrder?: 'asc' | 'desc'
  search?: string
}

// Workspace context
export type WorkspaceContext = {
  workspace: Workspace
  membership: WorkspaceMember
  permissions: Permission[]
  subscription?: Subscription | null
}

// Invitation types
export type InvitationWithWorkspace = Invitation & {
  workspace: Workspace
  inviter: User
}

// Form types
export type CreateWorkspaceData = {
  name: string
  slug?: string
  description?: string
}

export type InviteUserData = {
  email: string
  role: Role
}

export type UpdateMemberRoleData = {
  role: Role
}

export type CreateProjectData = {
  name: string
  description?: string
}

export type CreateTaskData = {
  title: string
  description?: string
  priority?: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT'
  assignedTo?: string
  dueDate?: string
  projectId: string
}

export type UpdateTaskData = Partial<CreateTaskData> & {
  status?: 'TODO' | 'IN_PROGRESS' | 'REVIEW' | 'DONE'
}

// Admin types
export type AdminStats = {
  totalUsers: number
  totalWorkspaces: number
  activeSubscriptions: number
  monthlyRevenue: number
  churnRate: number
}

export type AdminWorkspaceList = Workspace & {
  owner: User
  _count: {
    members: number
    projects: number
  }
  subscription?: (Subscription & {
    plan: Plan
  }) | null
}

// Billing types
export type PlanFeatures = {
  maxProjects: number
  maxMembersPerWorkspace: number
  advancedFeatures: boolean
  prioritySupport: boolean
  customIntegrations: boolean
  apiAccess: boolean
}

export type SubscriptionWithPlan = Subscription & {
  plan: Plan
}