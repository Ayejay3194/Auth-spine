# SLA Notes (Template)

Define:
- uptime target (e.g., 99.9%)
- maintenance windows + notice period
- support response times by tier
- credit schedule for breaches of SLA

Keep this consistent with your pricing plans and status page.
