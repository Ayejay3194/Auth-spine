# Auth-Spine Super Solid (monorepo)

This repo is a production-minded spine with:
- env validation (Zod)
- structured errors + logging (Pino)
- shared middleware (error handler, perf monitor, rate limiting)
- health endpoint + checks
- security audit script
- tests scaffolding (Vitest + Playwright placeholders)
- CLI generator scaffold (create-auth-spine-app)

## Quick start
```bash
npm install
cp apps/web/.env.example apps/web/.env
npm run env:check
npm run dev
```

Open:
- http://localhost:3000 (app)
- http://localhost:3000/docs (implementation plan)
- http://localhost:3000/ui-toolkit
- http://localhost:3000/html-to-ts
- http://localhost:3000/health
- http://localhost:3000/api/health
