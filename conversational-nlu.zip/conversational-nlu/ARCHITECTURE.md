# Architecture

Pipeline:
1. classify(input)
2. validateNLU(nlu)
3. policyDecide(validated, state)
4. render(decision, state)
5. writeReceipt({input, nlu, decision, response})
