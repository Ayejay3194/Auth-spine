-- Soft Delete Pattern (Supabase/Postgres)
-- Adds deleted_at + optional deleted_by, plus a helper VIEW to query "active" rows.

alter table public.example
  add column if not exists deleted_at timestamptz,
  add column if not exists deleted_by uuid;

create or replace view public.example_active as
select *
from public.example
where deleted_at is null;

-- Optional: prevent updates to deleted rows (except restore) via a trigger.
create or replace function public.block_updates_when_deleted()
returns trigger language plpgsql as $$
begin
  if (old.deleted_at is not null) and (new.deleted_at is not null) then
    raise exception 'Row is soft-deleted; update blocked';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_block_updates_when_deleted on public.example;
create trigger trg_block_updates_when_deleted
before update on public.example
for each row execute function public.block_updates_when_deleted();
