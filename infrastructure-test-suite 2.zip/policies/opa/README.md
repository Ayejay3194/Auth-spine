# OPA Policies

Run via Conftest.

Inputs supported:
- Kubernetes YAML under `infra/k8s/`
- Terraform plan JSON at `artifacts/terraform-plan.json`

These are starters. Extend them for your providers/resources.
