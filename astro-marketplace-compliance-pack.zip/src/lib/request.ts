import crypto from "crypto";
export const requestId = (existing?: string | null) => existing || crypto.randomBytes(8).toString("hex");
export const hashIp = (ip?: string | null) => ip ? crypto.createHash("sha256").update(ip + (process.env.IP_HASH_SALT || "change-me")).digest("hex") : null;
