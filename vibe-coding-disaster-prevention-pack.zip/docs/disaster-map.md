# Disaster Map: "Thing that can go wrong" -> What prevents it

## Auth & Authorization
- Frontend-only auth checks -> Server-side auth middleware + RLS + API auth guards
- JWT no expiration -> Short-lived access + refresh rotation
- Tokens in localStorage -> HTTPOnly cookies
- No rate limits -> Edge/API rate limiter + captcha on suspicious traffic
- Reset tokens never expire -> Expiring tokens + one-time use

## Injection
- SQL injection -> parameterized queries only
- XSS -> output encoding, CSP, no dangerouslySetInnerHTML
- Path traversal -> sanitize filenames, store outside web root

## Data exposure
- Secrets in repo -> secret scanning + pre-commit hook + CI gate
- Stack traces in prod -> error handler + sanitized errors
- CORS * -> strict allowlist

## Database
- No constraints -> PK/FK/UNIQUE/NOT NULL
- No pagination -> default limit + cursor pagination
- No transactions -> use tx for multi-step writes
- RLS missing on new tables -> migration checklist + CI test that fails if RLS off

## Webhooks
- No signature verify -> HMAC verify
- Duplicate events -> delivery_id uniqueness
- Not idempotent -> idempotency keys + upsert/guarded transitions
