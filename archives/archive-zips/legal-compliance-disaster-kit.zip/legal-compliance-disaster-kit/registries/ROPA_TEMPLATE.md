# Record of Processing Activities (ROPA) (Template)

| Processing activity | Purpose | Data categories | Data subjects | Legal basis | Retention | Subprocessors | Transfers |
|---|---|---|---|---|---|---|---|
| Account management | provide service | email, auth IDs | users | contract | until deletion | [vendor] | [if any] |
