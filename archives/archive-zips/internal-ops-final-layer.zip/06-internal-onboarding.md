INTERNAL ONBOARDING
===================

How the system thinks:
---------------------
- Everything is a booking
- Everything touches money or time
- Everything is logged

Where NOT to touch:
-------------------
- Payroll rules
- Payment adapters
- Feature flags in prod

How to debug:
-------------
- Check audit logs
- Check receipts
- Check alerts

How to add a new vertical:
--------------------------
- Reuse booking spine
- Swap terminology
- Add compliance rules
