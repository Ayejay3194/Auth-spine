import type { UserStore } from "../ports/userStore.js";
import type { RateLimitPort } from "../ports/rateLimitPort.js";
import type { EmailPort } from "../ports/emailPort.js";
import type { AuditPort } from "../ports/auditPort.js";
import type { ClockPort } from "../ports/clockPort.js";
import type { EventBus } from "../model/events.js";
import type { AuthCapabilities } from "../model/capabilities.js";
import { AuthError } from "../model/errors.js";
import { randomId, sha256, verifyHash } from "../util/crypto.js";
import { applyTransition, canTransition } from "../model/accountState.js";
import type { SessionService } from "./sessionService.js";
import type { AuthContext } from "../model/authContext.js";

export interface AuthDeps {
  users: UserStore;
  rate: RateLimitPort;
  email: EmailPort;
  audit: AuditPort;
  clock: ClockPort;
  bus: EventBus;
  sessions: SessionService;
  caps: AuthCapabilities;
}

export class AuthService {
  constructor(private d: AuthDeps) {}

  async register(email: string, password: string, username?: string): Promise<{ userId: string; verifyToken: string }> {
    const existing = await this.d.users.byEmail(email.toLowerCase());
    if (existing) throw new AuthError("CONFLICT", "Email already in use", 409);

    const now = this.d.clock.nowIso();
    const userId = randomId("usr_");
    const u = await this.d.users.create({
      id: userId,
      email: email.toLowerCase(),
      username,
      passwordHash: sha256(password),
      emailVerified: false,
      state: "PENDING_VERIFICATION",
    } as any);

    const verifyToken = randomId("vfy_");
    await this.d.audit.append({ id: randomId("aud_"), at: now, actorId: userId, action: "auth.register", targetId: userId, metadata: { email: u.email } });
    await this.d.bus.publish({ type: "auth.user.created", userId, email: u.email, at: now });
    await this.d.email.send(u.email, "VERIFY_EMAIL", { verifyToken, userId });
    return { userId, verifyToken };
  }

  async verifyEmail(userId: string): Promise<void> {
    const u = await this.d.users.byId(userId);
    if (!u) throw new AuthError("VALIDATION", "User not found", 404);
    if (!canTransition(u.state, { type: "VERIFY_EMAIL" })) return;

    const nextState = applyTransition(u.state, { type: "VERIFY_EMAIL" });
    await this.d.users.update(userId, { emailVerified: true, state: nextState } as any);
    await this.d.bus.publish({ type: "auth.email.verified", userId, at: this.d.clock.nowIso() });
    await this.d.audit.append({ id: randomId("aud_"), at: this.d.clock.nowIso(), actorId: userId, action: "auth.email.verify", targetId: userId, metadata: {} });
  }

  async login(email: string, password: string, meta?: { ip?: string; userAgent?: string; deviceId?: string }): Promise<AuthContext> {
    const e = email.toLowerCase();
    const key = `login:${e}:${meta?.ip ?? "na"}`;
    const rl = await this.d.rate.hit(key, 10, 60);
    if (!rl.allowed) throw new AuthError("RATE_LIMITED", "Too many attempts", 429);

    const u = await this.d.users.byEmail(e);
    if (!u) {
      await this.d.bus.publish({ type: "auth.login.failed", email: e, ip: meta?.ip, reason: "no_user", at: this.d.clock.nowIso() });
      throw new AuthError("INVALID_CREDENTIALS", "Invalid credentials", 401);
    }

    if (u.state === "LOCKED") throw new AuthError("ACCOUNT_LOCKED", "Account locked", 403);
    if (u.state === "SUSPENDED") throw new AuthError("ACCOUNT_SUSPENDED", "Account suspended", 403);
    if (u.state === "DEACTIVATED") throw new AuthError("ACCOUNT_DEACTIVATED", "Account deactivated", 403);

    if (!verifyHash(password, u.passwordHash)) {
      await this.d.bus.publish({ type: "auth.login.failed", email: e, ip: meta?.ip, reason: "bad_password", at: this.d.clock.nowIso() });
      throw new AuthError("INVALID_CREDENTIALS", "Invalid credentials", 401);
    }
    if (!u.emailVerified) throw new AuthError("EMAIL_NOT_VERIFIED", "Email not verified", 403);

    const s = await this.d.sessions.create(u.id, meta);
    await this.d.bus.publish({ type: "auth.login.succeeded", userId: u.id, sessionId: s.id, ip: meta?.ip, at: this.d.clock.nowIso() });
    await this.d.audit.append({ id: randomId("aud_"), at: this.d.clock.nowIso(), actorId: u.id, action: "auth.login", targetId: u.id, metadata: { sessionId: s.id, ip: meta?.ip, ua: meta?.userAgent } });

    return {
      userId: u.id,
      sessionId: s.id,
      roles: ["user"],
      permissions: ["self:read", "self:update", "sessions:list", "sessions:revoke"],
      authProfile: this.d.caps.profile,
    };
  }

  async changeEmail(ctx: AuthContext, newEmail: string): Promise<void> {
    if (!ctx.stepUpSatisfiedUntil) throw new AuthError("STEP_UP_REQUIRED", "Step-up required", 401, { action: "changeEmail" });

    const u = await this.d.users.byId(ctx.userId);
    if (!u) throw new AuthError("VALIDATION", "User not found", 404);

    const oldEmail = u.email;
    const nextEmail = newEmail.toLowerCase();

    if (oldEmail === nextEmail) return;

    const existing = await this.d.users.byEmail(nextEmail);
    if (existing) throw new AuthError("CONFLICT", "Email already in use", 409);

    await this.d.users.update(u.id, { email: nextEmail } as any);
    await this.d.email.send(oldEmail, "EMAIL_CHANGED_ALERT_OLD", { oldEmail, newEmail: nextEmail });
    await this.d.email.send(nextEmail, "EMAIL_CHANGED_ALERT_NEW", { oldEmail, newEmail: nextEmail });
    await this.d.bus.publish({ type: "auth.email.changed", userId: u.id, oldEmail, newEmail: nextEmail, at: this.d.clock.nowIso() });
    await this.d.audit.append({ id: randomId("aud_"), at: this.d.clock.nowIso(), actorId: u.id, action: "auth.email.change", targetId: u.id, metadata: { oldEmail, newEmail: nextEmail } });

    await this.d.sessions.revokeAll(u.id, "EMAIL_CHANGED", u.id);
  }

  async changePassword(ctx: AuthContext, newPassword: string): Promise<void> {
    if (!ctx.stepUpSatisfiedUntil) throw new AuthError("STEP_UP_REQUIRED", "Step-up required", 401, { action: "changePassword" });

    const u = await this.d.users.byId(ctx.userId);
    if (!u) throw new AuthError("VALIDATION", "User not found", 404);

    await this.d.users.update(u.id, { passwordHash: sha256(newPassword) } as any);
    await this.d.email.send(u.email, "PASSWORD_CHANGED_ALERT", {});
    await this.d.bus.publish({ type: "auth.password.changed", userId: u.id, sessionId: ctx.sessionId, at: this.d.clock.nowIso() });
    await this.d.audit.append({ id: randomId("aud_"), at: this.d.clock.nowIso(), actorId: u.id, action: "auth.password.change", targetId: u.id, metadata: {} });

    await this.d.sessions.revokeAll(u.id, "PASSWORD_CHANGED", u.id);
  }
}
