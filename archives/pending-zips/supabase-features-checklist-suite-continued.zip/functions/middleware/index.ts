// Minimal middleware chain scaffold for Supabase Edge Functions (Deno)
//
// Compose: withTracing -> withCors -> withAuth -> withValidation -> handler
//
// Replace placeholders with your actual logic.

export type Ctx = {
  requestId: string;
  startedAt: number;
  userId?: string;
  role?: string;
  tenantId?: string;
};

export type Handler = (req: Request, ctx: Ctx) => Promise<Response>;

export function withTracing(next: Handler): Handler {
  return async (req, ctx) => {
    ctx.startedAt = Date.now();
    ctx.requestId = crypto.randomUUID();
    const res = await next(req, ctx);
    res.headers.set("x-request-id", ctx.requestId);
    res.headers.set("x-duration-ms", String(Date.now() - ctx.startedAt));
    return res;
  };
}

export function withCors(next: Handler): Handler {
  return async (req, ctx) => {
    if (req.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "access-control-allow-origin": "*",
          "access-control-allow-methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
          "access-control-allow-headers": "authorization,content-type",
        },
      });
    }
    const res = await next(req, ctx);
    res.headers.set("access-control-allow-origin", "*");
    return res;
  };
}

export function withAuth(next: Handler): Handler {
  return async (req, ctx) => {
    const auth = req.headers.get("authorization") || "";
    // TODO: verify JWT and populate ctx.userId/role/tenantId
    if (!auth) return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401 });
    return next(req, ctx);
  };
}

export function withValidation(next: Handler): Handler {
  return async (req, ctx) => {
    // TODO: validate payload (zod or manual)
    return next(req, ctx);
  };
}
