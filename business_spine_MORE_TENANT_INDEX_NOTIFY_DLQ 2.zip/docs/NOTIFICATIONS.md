# Notifications System
Queue job: `notify_send` (BullMQ/queue abstraction via `reportQueue`)

- `src/notify/templates.ts` templates
- `src/notify/providers.ts` provider interfaces (console defaults)
- `src/notify/notifyQueue.ts` enqueue helper
- `src/notify/notifyWorker.ts` worker handler

Test endpoint:
- POST /api/notify/test

Replace Console providers with SES/Postmark (email), Twilio (sms), FCM/APNS (push).
