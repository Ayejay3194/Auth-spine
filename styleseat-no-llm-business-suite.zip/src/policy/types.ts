import { AgentContext } from "../core/types.js";

export interface PolicyDecision {
  ok: boolean;
  code?: "RATE_LIMIT" | "FORBIDDEN" | "CONFIRM_REQUIRED";
  message?: string;
}

export interface PolicyEngine {
  checkTool(ctx: AgentContext, toolId: string): Promise<PolicyDecision>;
  checkCommit(ctx: AgentContext, intent: string, confirm?: string): Promise<PolicyDecision>;
}
