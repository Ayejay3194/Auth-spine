import { describe, it, expect } from "vitest";
import { MemoryReceiptStore } from "../src/receipts/receiptStore";
import { ReceiptService } from "../src/receipts/receiptService";

describe("receipt chain", () => {
  it("creates a hash-chained receipt and verifies", async () => {
    process.env.AUDIT_SECRET = "test_secret________________________________";
    const store = new MemoryReceiptStore();
    const svc = new ReceiptService(store);

    const ctx = {
      requestId: "req_1",
      tenantId: "t1",
      actor: { userId: "u1", role: "admin" as const },
      nowISO: new Date().toISOString()
    };

    const r1 = await svc.issue(ctx, {
      action: "create",
      entityType: "booking",
      entityId: "b1",
      payload: { price: 100 },
      status: "validated"
    });

    const v = await svc.verify(r1.id);
    expect(v.ok).toBe(true);
    expect(v.tampered).toBe(false);

    // tamper
    (v.receipt as any).entityId = "hacked";
    const v2 = (await svc.verify(r1.id));
    // verify checks stored receipt; our mutation didn't affect store
    expect(v2.ok).toBe(true);
  });
});
