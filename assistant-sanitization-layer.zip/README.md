Assistant Sanitization & Trust Boundary Layer

Purpose:
Hard separation between INTERNAL and EXTERNAL assistants.
Guarantees that no sensitive internal data leaks across trust boundaries.

Core guarantees:
- No raw DB objects cross boundaries
- DTO-only returns
- Automatic redaction + key stripping
- Sanitization events logged for audit

Drop this folder into /lib/security and wire safeReturn() into all external tools.
