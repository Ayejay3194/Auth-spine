# Full-Stack SaaS Autoboot Pack

This pack is designed to sit on top of a generic full-stack SaaS starter
(e.g. the `full_starter_pack_pro` you already have) and help you turn it
into a real, domain-specific product with minimal thinking.

It includes:

- A **project conversion checklist** (from template → real app)
- A **master "senior engineer" prompt** for tools like Cursor / Claude
- A simple **CLI script** to automate routine setup/scaffolding
- Ready-made **Cursor / Windsurf recipes** you can paste directly

## How to Use

1. Drop this folder into the root of your starter repo or somewhere nearby.
2. Use the checklist as your roadmap.
3. Use the master prompt inside Cursor / Claude when working in the repo.
4. Use the CLI for quick tasks:
   - `node tools/saas-cli.js init-env`
   - `node tools/saas-cli.js add-entity Project`
5. Use the recipes for one-shot "do this whole phase for me" workflows.
