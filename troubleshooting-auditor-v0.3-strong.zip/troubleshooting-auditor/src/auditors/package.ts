import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readJson } from "../utils/fs.js";

type Pkg = {
  scripts?: Record<string, string>;
  engines?: Record<string, string>;
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
};

export function auditPackage(root: string): AuditSection {
  const section: AuditSection = { id: "package", title: "Package & Scripts", findings: [] };
  const p = path.join(root, "package.json");

  if (!exists(p)) {
    section.findings.push({
      id: "package.missing",
      title: "package.json missing",
      severity: "ERROR",
      details: "No package.json means no scripts and no dependency graph.",
      fix: "Add package.json with build/dev/start (and optionally preview) scripts.",
      evidence: { packageJsonPath: p },
    });
    return section;
  }

  let pkg: Pkg;
  try {
    pkg = readJson<Pkg>(p);
  } catch (e) {
    section.findings.push({
      id: "package.invalid",
      title: "package.json invalid JSON",
      severity: "ERROR",
      details: "package.json failed to parse.",
      fix: "Fix JSON syntax.",
      evidence: { packageJsonPath: p, error: String(e) },
    });
    return section;
  }

  const scripts = pkg.scripts ?? {};
  if (!scripts["build"]) {
    section.findings.push({
      id: "package.scripts.build",
      title: "No build script",
      severity: "ERROR",
      details: "Deployments typically run `npm run build`.",
      fix: "Add build script (Next: `next build`; Vite: `vite build`).",
      evidence: { scripts },
    });
  }
  if (!scripts["dev"]) {
    section.findings.push({
      id: "package.scripts.dev",
      title: "No dev script",
      severity: "WARN",
      details: "Local dev should be one command.",
      fix: "Add dev script (Next: `next dev`; Vite: `vite`).",
      evidence: { scripts },
    });
  }
  if (!scripts["start"] && !scripts["preview"]) {
    section.findings.push({
      id: "package.scripts.start_preview",
      title: "No start/preview script",
      severity: "INFO",
      details: "Prod parity testing is easier when `npm start` (SSR) or `npm run preview` (static) exists.",
      fix: "Add `start` for SSR (Next: `next start`) or `preview` for Vite (`vite preview`).",
      evidence: { scripts },
    });
  }

  const lockfiles = ["package-lock.json", "yarn.lock", "pnpm-lock.yaml"];
  const present = lockfiles.filter((f) => exists(path.join(root, f)));
  if (present.length === 0) {
    section.findings.push({
      id: "package.lockfile.missing",
      title: "No lockfile found",
      severity: "WARN",
      details: "Dependency drift causes random breakage.",
      fix: "Commit a lockfile.",
      evidence: { checked: lockfiles },
    });
  }

  if (!pkg.engines?.node) {
    section.findings.push({
      id: "package.engines.node",
      title: "No Node engine pinned",
      severity: "INFO",
      details: "Node mismatches are a top prod-only failure cause.",
      fix: "Add `engines.node` and/or `.nvmrc`.",
      evidence: { engines: pkg.engines ?? null },
    });
  }

  return section;
}
