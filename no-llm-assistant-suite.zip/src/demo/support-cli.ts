import readline from "node:readline";
import crypto from "node:crypto";
import { ConsoleAuditLogger } from "../obs/consoleAudit.js";
import { SimpleTracer } from "../obs/simpleTracer.js";
import { InMemorySessionStore } from "../memory/types.js";
import { SimplePolicyEngine } from "../policy/simplePolicy.js";
import { InMemoryToolRegistry } from "../tools/registry.js";
import { supportFlows } from "../support/flows.js";
import { supportTools } from "../support/tools.js";
import { IntentDetector } from "../nlu/intents.js";
import { createAssistant } from "../assistant/assistant.js";

const audit = new ConsoleAuditLogger();
const tracer = new SimpleTracer();
const sessions = new InMemorySessionStore<any>();

const policy = new SimplePolicyEngine(sessions, {
  allow: { user: ["auth.send_forgot_username","auth.send_password_reset","gdpr.queue_export","billing.change_plan"], admin: [], system: [] },
  rate: { windowSeconds: 10, max: 30 },
  confirmIntents: ["billing.change_plan"]
});

const tools = new InMemoryToolRegistry();
for (const t of supportTools()) tools.register(t);

const detector = new IntentDetector(
  [
    { intent: "auth.forgot_username", any: ["forgot username"], all: [] },
    { intent: "auth.password_reset_request", any: ["forgot password","reset password"], all: [] },
    { intent: "gdpr.export_request", any: ["export my data","download my data","gdpr"], all: [] },
    { intent: "billing.change_plan", any: ["change plan","upgrade","downgrade"], all: [] },
  ],
  [
    { intent: "auth.forgot_username", utterance: "forgot my username" },
    { intent: "auth.password_reset_request", utterance: "reset my password" },
    { intent: "gdpr.export_request", utterance: "download my data" },
    { intent: "billing.change_plan", utterance: "upgrade to paid" },
  ],
  { minScore: 0.30 }
);

const assistant = createAssistant({ tools, policy, audit, clock: { now: () => new Date() }, tracer, intent: detector, flows: supportFlows });

const ctx = { userId: "user_" + crypto.randomBytes(4).toString("hex"), role: "user" as const };
let state: any = {};

console.log("No-LLM Support Assistant demo. Try: 'forgot my username' or 'download my data'.");
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.setPrompt("> ");
rl.prompt();

rl.on("line", async (line) => {
  const res = await assistant.handle(ctx, state, line);
  state = res.state;
  console.log(res.reply.text);
  rl.prompt();
});
