export type ToneCategory =
  | "snark" | "dry" | "corrective" | "amused" | "annoyed"
  | "sharp-care" | "boundary" | "confidence" | "meta" | "clarity"
  | "probing" | "mentoring" | "terse" | "playful" | "deescalation"
  | "apology-lite" | "executive" | "technical" | "product-voice";

export type Trigger =
  | "confusion" | "repetition" | "arrogance" | "insecurity" | "vague_question"
  | "overconfidence" | "underconfidence" | "curiosity" | "impatience"
  | "system_error" | "self_doubt" | "misuse" | "manipulation"
  | "analysis" | "scope_creep" | "missing_data" | "contradiction"
  | "misunderstanding" | "risk_sensitive" | "hostility" | "user_frustration"
  | "success" | "decision_needed" | "implementation";

export type RiskContext = "none" | "medical" | "legal" | "grief" | "panic" | "trauma" | "risk_sensitive";

export interface ToneLine {
  id: string;
  category: ToneCategory;
  trigger: Trigger;
  intensity: 1 | 2 | 3 | 4 | 5;
  text: string;
  notes?: string;
}

export interface ProductCaps {
  maxLines: number;
  maxHighIntensity: number;
  snarkMax: number;
  annoyedMax: number;
  disallowed?: ToneCategory[];
}

export interface ToneState {
  usedIds: Set<string>;
  lastIntensities: number[];
  sarcasmLock?: boolean;
  tolerance?: number; // 0..1
}

export interface ToneDecisionInput {
  intent: string;
  trigger: Trigger;
  confidence: number;
  risk: RiskContext;
  product: "support" | "consumer_app" | "internal_tools" | "other";
  maxLines?: number;
}

export interface ToneDecisionOutput {
  selected: ToneLine[];
  reason: string;
  diagnostics: {
    candidateCount: number;
    filteredByTrigger: boolean;
    appliedDeescalation: boolean;
    appliedCaps: boolean;
  };
}
