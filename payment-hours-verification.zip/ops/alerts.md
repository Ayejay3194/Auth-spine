ALERTS
======
Trigger alerts on:
- hours mismatches
- payout attempted before verification
- excessive manual edits
