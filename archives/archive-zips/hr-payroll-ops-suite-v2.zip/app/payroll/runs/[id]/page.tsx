
import { db } from "@/lib/db";
import { addAdjustment, generateItems } from "@/lib/actions/payroll";

export default async function Run({ params }: { params: { id: string } }) {
  const run = await db.payRun.findUnique({
    where: { id: params.id },
    include: {
      payGroup: true,
      items: { include: { employee: true } },
      exceptions: true,
      adjustments: { include: { employee: true }, orderBy: { createdAt: "desc" } }
    }
  });
  if (!run) return <div className="panel">Not found.</div>;

  return (
    <div className="grid">
      <div className="panel row" style={{ justifyContent: "space-between" }}>
        <div>
          <div className="h1">Run: {run.payGroup.name}</div>
          <div className="small">
            Period: {run.periodStart ? run.periodStart.toISOString().slice(0,10) : "-"} → {run.periodEnd ? run.periodEnd.toISOString().slice(0,10) : "-"} | Status: {run.status}
          </div>
        </div>
        <form action={generateItems}>
          <input type="hidden" name="id" value={run.id} />
          <button className="button">Generate/Recompute</button>
        </form>
      </div>

      <div className="panel">
        <h2 className="h2">Exceptions</h2>
        {run.exceptions.length === 0 ? (
          <div className="small">None.</div>
        ) : (
          <table className="table">
            <thead><tr><th>Kind</th><th>Message</th><th>Created</th></tr></thead>
            <tbody>
              {run.exceptions.map(x => (<tr key={x.id}><td>{x.kind}</td><td>{x.message}</td><td>{x.createdAt.toISOString()}</td></tr>))}
            </tbody>
          </table>
        )}
      </div>

      <div className="panel">
        <h2 className="h2">Add adjustment</h2>
        <form className="form" action={addAdjustment}>
          <input type="hidden" name="payRunId" value={run.id} />
          <select className="input" name="employeeId" required defaultValue={run.items[0]?.employeeId ?? ""}>
            {(await db.employee.findMany({ take: 200, orderBy: { lastName: "asc" } })).map(e => (
              <option key={e.id} value={e.id}>{e.lastName}, {e.firstName}</option>
            ))}
          </select>
          <div className="row">
            <select className="input" name="type" defaultValue="EARNING">
              <option value="EARNING">Earning</option>
              <option value="DEDUCTION">Deduction</option>
            </select>
            <input className="input" name="label" placeholder="Label (e.g. Bonus, Reimbursement, Garnishment)" />
            <input className="input" name="amountCents" placeholder="Amount cents (e.g. 5000 = $50.00)" required />
          </div>
          <button className="button" type="submit">Add</button>
          <div className="small">After adding adjustments, click Generate/Recompute.</div>
        </form>
      </div>

      <div className="panel">
        <h2 className="h2">Adjustments</h2>
        {run.adjustments.length === 0 ? (
          <div className="small">None.</div>
        ) : (
          <table className="table">
            <thead><tr><th>Employee</th><th>Type</th><th>Label</th><th>Amount</th><th>Created</th></tr></thead>
            <tbody>
              {run.adjustments.map(a => (
                <tr key={a.id}>
                  <td>{a.employee.firstName} {a.employee.lastName}</td>
                  <td>{a.type}</td>
                  <td>{a.label}</td>
                  <td>${(a.amountCents/100).toFixed(2)}</td>
                  <td>{a.createdAt.toISOString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="panel">
        <h2 className="h2">Items</h2>
        <table className="table">
          <thead><tr><th>Employee</th><th>Gross</th><th>Taxes</th><th>Deductions</th><th>Net</th></tr></thead>
          <tbody>
            {run.items.map(i => (
              <tr key={i.id}>
                <td>{i.employee.firstName} {i.employee.lastName}</td>
                <td>${(i.grossCents/100).toFixed(2)}</td>
                <td>${(i.taxesCents/100).toFixed(2)}</td>
                <td>${(i.deductionsCents/100).toFixed(2)}</td>
                <td>${(i.netCents/100).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
