PRIVACY GUARDRAILS
==================

Rules:
- no individual surveillance dashboards
- aggregate-first views
- role-based access to analytics
- retention limits
