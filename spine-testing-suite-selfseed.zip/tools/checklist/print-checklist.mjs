import fs from 'node:fs';
console.log(fs.readFileSync('tools/checklist/checklist.md','utf8'));
