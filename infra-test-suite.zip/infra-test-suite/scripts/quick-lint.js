import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const required = ["src", "profiles", "tests"];
for (const d of required) {
  if (!fs.existsSync(path.join(root, d))) {
    console.error(`Missing required directory: ${d}`);
    process.exit(2);
  }
}
console.log("Quick lint passed.");
