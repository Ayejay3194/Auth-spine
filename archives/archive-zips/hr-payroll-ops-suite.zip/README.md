
# HR + Payroll + Ops Suite (Starter)

## Run
1) cp .env.example .env
2) npm install
3) npm run db:push && npm run db:generate
4) npm run seed
5) npm run dev

## Demo auth
Send header: x-user-email = admin@demo.com | hr@demo.com | payroll@demo.com | manager@demo.com | employee@demo.com
