# Data Classification Policy
Classes:
- Public
- Internal
- Confidential
- Restricted (PII/payment)

Rules:
- No restricted data in logs
- Mask restricted fields in support tools by default
- Encryption requirements per class
