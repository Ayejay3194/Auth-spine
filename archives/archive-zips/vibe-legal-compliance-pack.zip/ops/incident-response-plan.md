# Incident Response Plan (IRP)

## Severity levels
- SEV0: widespread outage/data exposure
- SEV1: major feature down, security event suspected
- SEV2: partial degradation
- SEV3: minor bug

## Roles
- Incident Commander (IC)
- Ops Lead
- Security Lead
- Comms Lead
- Scribe

## Steps
1. Detect + declare incident (create ticket)
2. Contain (disable feature, rotate keys, block IPs)
3. Eradicate (patch, remove malicious artifacts)
4. Recover (restore service, validate data)
5. Postmortem (timeline, root cause, fixes)

## Required artifacts
- incident timeline
- impacted systems + users
- data involved (if any)
- remediation actions + owners
