import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import type { Finding, Severity } from "../types.js";

export type AuditReport = {
  meta: {
    timestamp: string;
    root: string;
    profilePath: string;
    tool: string;
    version: string;
    runId: string;
  };
  summary: {
    totalsBySeverity: Record<Severity, number>;
    failed: boolean;
    failOnSeverity: Severity;
  };
  findings: Finding[];
};

export function makeRunId(): string {
  return crypto.randomBytes(16).toString("hex");
}

export function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

export function writeReport(outDir: string, report: AuditReport) {
  ensureDir(outDir);
  const outPath = path.join(outDir, "infra-audit.json");
  fs.writeFileSync(outPath, JSON.stringify(report, null, 2), "utf-8");
  return outPath;
}

export function severityGTE(a: Severity, b: Severity): boolean {
  const rank: Record<Severity, number> = { P0: 3, P1: 2, P2: 1, INFO: 0 };
  return rank[a] >= rank[b];
}
