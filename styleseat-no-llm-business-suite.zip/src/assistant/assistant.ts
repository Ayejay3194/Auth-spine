import { AgentContext, AgentReply, AuditLogger, Clock, Tracer } from "../core/types.js";
import { DefaultEntityExtractor } from "../nlu/entities.js";
import { IntentDetector } from "../nlu/intents.js";
import { createFlowEngine } from "../flows/engine.js";
import { FlowDefinition, FlowState } from "../flows/types.js";
import { ToolRegistry } from "../tools/types.js";
import { PolicyEngine } from "../policy/types.js";

export interface ConversationState { active?: { intent: string; state: FlowState }; }

export interface AssistantDeps {
  tools: ToolRegistry;
  policy: PolicyEngine;
  audit: AuditLogger;
  clock: Clock;
  tracer: Tracer;
  detector: IntentDetector;
  flows: FlowDefinition[];
}

export function createAssistant(deps: AssistantDeps) {
  const extractor = new DefaultEntityExtractor();
  const engine = createFlowEngine({ tools: deps.tools, policy: deps.policy, audit: deps.audit, clock: deps.clock, tracer: deps.tracer });

  const getFlow = (intent: string) => deps.flows.find(f => f.intent === intent);

  async function handle(ctx: AgentContext, state: ConversationState, userText: string): Promise<{ state: ConversationState; reply: AgentReply }> {
    const entities = extractor.extract(userText, deps.clock.now());
    await deps.audit.write({ at: deps.clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "entity.extracted", details: { count: entities.length } });

    if (state.active && !state.active.state.completed) {
      const def = getFlow(state.active.intent);
      if (def) {
        const cont = await engine.cont(ctx, def, state.active.state, userText, entities);
        return { state: { active: { intent: def.intent, state: cont.state } }, reply: cont.reply };
      }
    }

    const det = deps.detector.detect(userText);
    await deps.audit.write({ at: deps.clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "intent.detected", details: det as any });

    if (det.intent === "unknown") return { state: {}, reply: { text: "Say what you want: book, invoice, promo, report, tasks, clients, etc." } };

    const def = getFlow(det.intent);
    if (!def) return { state: {}, reply: { text: `Recognized "${det.intent}" but it's not wired yet.` } };

    const started = await engine.start(ctx, def, entities);
    return { state: { active: { intent: def.intent, state: started.state } }, reply: started.reply };
  }

  return { handle };
}
