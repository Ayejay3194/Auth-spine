import { describe, it, expect } from "vitest";
import { BASE_URL, TEST_TENANTS, TEST_USERS } from "../tools/config";
import { http } from "../tools/http";

async function ensureTenant(t: any) {
  const r = await http("POST", `${BASE_URL}/tenants`, { body: t });
  if (![200, 201, 409].includes(r.status)) {
    throw new Error(`Failed creating tenant ${t.id}. status=${r.status}`);
  }
}

function decodeJwtPayload(token: string) {
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Token is not a JWT");
  return JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
}

describe("auth smoke + isolation", () => {
  it("login returns valid JWT with tenant claim", async () => {
    await ensureTenant(TEST_TENANTS.a);

    const r = await http("POST", `${BASE_URL}/auth/login`, {
      body: {
        tenantId: TEST_USERS.a.tenantId,
        email: TEST_USERS.a.email,
        deviceLabel: TEST_USERS.a.deviceLabel
      }
    });

    expect(r.ok).toBe(true);
    const token = r.json.token;
    expect(typeof token).toBe("string");

    const payload = decodeJwtPayload(token);
    expect(payload).toHaveProperty("sub");
    expect(payload).toHaveProperty("exp");
    expect(payload).toHaveProperty("tenantId");
  });

  it("missing auth header is rejected", async () => {
    const r = await http("GET", `${BASE_URL}/auth/sessions`);
    expect([401, 403]).toContain(r.status);
  });

  it("tenant A token cannot access tenant B resources", async () => {
    await ensureTenant(TEST_TENANTS.a);
    await ensureTenant(TEST_TENANTS.b);

    const la = await http("POST", `${BASE_URL}/auth/login`, {
      body: { tenantId: TEST_USERS.a.tenantId, email: TEST_USERS.a.email }
    });

    if (!la.ok) throw new Error("Seed user missing for tenant A");

    const cross = await http("GET", `${BASE_URL}/tenants/${TEST_TENANTS.b.id}`, {
      headers: { authorization: `Bearer ${la.json.token}` }
    });

    expect([401, 403, 404]).toContain(cross.status);
  });
});
