-- Storage bucket + policies (per-tenant foldering)
-- Convention: path = {tenant_id}/{user_id}/...
-- Policy can parse storage.objects.name.

-- Example (pseudo, adjust to your needs):
-- allow read if user belongs to tenant folder
-- allow write if owner == auth.uid()
