# Security Baseline (minimum)

- No public DB access
- No 0.0.0.0/0 inbound to admin ports
- Encryption in transit + at rest where available
- Secrets never committed
- Least privilege IAM
- WAF/rate limiting at the edge
- Audit logs on infra changes
- CI required checks before merge
