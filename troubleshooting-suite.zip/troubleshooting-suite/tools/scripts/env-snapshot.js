import fs from "node:fs";
const keys = Object.keys(process.env).sort();
const filtered = keys.filter(k => !/TOKEN|SECRET|KEY|PASS|PWD/i.test(k));
const out = { node: process.version, platform: process.platform, envKeys: filtered };
fs.writeFileSync("env-snapshot.json", JSON.stringify(out, null, 2), "utf-8");
console.log("Wrote env-snapshot.json");
