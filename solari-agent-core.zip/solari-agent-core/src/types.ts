export type RiskContext = "none" | "medical" | "legal" | "grief" | "panic" | "trauma" | "risk_sensitive";

export interface MemoryFact<T = unknown> {
  key: string;
  value: T;
  ts: string; // ISO
  source: string; // "user", "system", "tool:<name>", etc.
  confidence: number; // 0..1
  ttlDays: number;
  tags?: string[];
}

export interface WorkingState {
  conversationId: string;
  turn: number;
  lastUserMessage?: string;
  activeGoal?: string;
  assumptions: string[];
  constraints: string[];
}

export interface ToolSpec {
  name: string;
  description: string;
  allowed: boolean;
  requiredInputs: string[];
}

export interface PlanStep {
  id: string;
  title: string;
  action: "respond" | "tool" | "write_file" | "ask_user";
  toolName?: string;
  inputs?: Record<string, unknown>;
  successCriteria: string[];
  rollback?: string;
}

export interface Plan {
  id: string;
  intent: string;
  risk: RiskContext;
  steps: PlanStep[];
}

export interface IntentResult {
  intent: string;
  trigger: string;
  confidence: number; // 0..1
  risk: RiskContext;
}

export interface AuditEvent {
  ts: string;
  conversationId: string;
  sessionId: string;
  kind: "intent" | "plan" | "tool" | "response" | "memory_write" | "memory_prune" | "error" | "tone";
  payload: Record<string, unknown>;
}
