# Solari Responsive + Auth Starter (Next + React + Tailwind)

This is a minimal starter that does exactly what you asked:

- **Mobile vs Desktop** is handled by Tailwind breakpoints (CSS).
- **Auth + Authorization** is handled once via `Protected`.

## Run

```bash
npm install
npm run dev
```

## Key files

- `components/layout/RightRail.tsx`
  - Map route => feed rail
  - Non-map routes => mini-map rail
- `components/auth/Protected.tsx`
  - If signed out => login card
  - If role missing => not authorized screen
- `components/nav/TopNav.tsx`
  - Desktop nav + simple mobile nav strip

## Replace fake auth

Swap in your real provider later (Clerk, NextAuth, Supabase Auth).
Keep the interface: `user`, `loading`, `login`, `logout`, `roles`.
