# Service Worker stale cache

## Symptom
You shipped a fix, but some users still see old broken behavior.

## Confirm
- DevTools > Application > Service Workers shows active SW
- Network tab shows cached responses / old bundle hashes

## Fix
- implement update flow: detect waiting SW and prompt refresh
- ensure assets are content-hashed
- consider reducing cache lifetime or using network-first for critical HTML
