import { RenderContext, RenderedResponse, Message } from "../types.js";
import { uid } from "../utils/id.js";
import { pickOne } from "../utils/text.js";
import { PhraseBank } from "./phrasebank.js";

export class Renderer {
  constructor(private bank: PhraseBank) {}

  render(ctx: RenderContext): RenderedResponse {
    const { route, skillResult } = ctx;

    const tagHints = [
      route.skill,
      route.action,
      ctx.nlu.intent,
      ...(skillResult.tags ?? []),
    ].map(String);

    const retrieved = this.bank.retrieve(
      ctx.memory.recent.slice(-3).map(m => m.content).join(" ") + " " + (skillResult.kind === "text" ? skillResult.text : ""),
      tagHints,
      4
    );

    const opener = chooseOpener(route, retrieved.map(r => r.text));
    const body = renderBody(route, skillResult);
    const closer = chooseCloser(route);

    const content = [opener, body, closer].filter(Boolean).join("\n\n").trim();

    const msg: Message = {
      id: uid("a"),
      role: "assistant",
      content,
      ts: Date.now(),
    };

    return {
      message: msg,
      debug: {
        intent: ctx.nlu.intent,
        confidence: ctx.nlu.confidence,
        skill: route.skill,
        action: route.action,
        reason: route.reason,
        retrievedPhrases: retrieved.map(r => r.text).slice(0, 3),
      },
    };
  }
}

function renderBody(route: RenderContext["route"], res: RenderContext["skillResult"]): string {
  switch (res.kind) {
    case "text":
      return res.text;
    case "clarify":
      return `${res.question}${res.options?.length ? "\n" + res.options.map(o => `- ${o}`).join("\n") : ""}`;
    case "refuse":
      return res.text;
    case "structured":
      return res.summary;
    default:
      return "Tell me what you want, in human terms.";
  }
}

function chooseOpener(route: RenderContext["route"], retrieved: string[]): string {
  // Prefer retrieved lines if they look like openers (short-ish)
  const candidates = retrieved.filter(t => t.length < 120);
  if (candidates.length) return pickOne(candidates);

  const snark = route.tone.snark;
  if (snark > 0.65) return pickOne([
    "Cool. Let’s do it properly.",
    "Fine. Here’s the clean version.",
    "Alright. Specs, not vibes."
  ]);
  if (snark < 0.35) return pickOne([
    "Got you.",
    "Okay, I’m on it.",
    "Let’s work through it."
  ]);
  return pickOne([
    "Okay.",
    "Alright.",
    "Here we go."
  ]);
}

function chooseCloser(route: RenderContext["route"]): string {
  if (route.action === "clarify") return pickOne([
    "Answer that and we’re moving.",
    "Give me that and I’ll finish the job."
  ]);
  if (route.skill === "AstroInterpreterSkill") return pickOne([
    "If you want, add the house/aspects and it gets sharper.",
    "Drop the house and I’ll stop guessing."
  ]);
  return "";
}
