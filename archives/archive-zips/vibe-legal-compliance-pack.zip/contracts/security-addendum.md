# Security Addendum (Template)

## Controls (baseline)
- encryption in transit (TLS 1.2+), encryption at rest where supported
- RBAC + least privilege
- RLS/tenant isolation for customer data
- logging + monitoring + alerting
- vulnerability and dependency scanning
- incident response plan and breach notification process

## Access
- production access is restricted
- support access is time-bound and logged
- secrets are managed via KMS/secret manager

## Customer responsibilities
- configure user roles properly
- keep credentials secure
- use MFA for admin accounts
