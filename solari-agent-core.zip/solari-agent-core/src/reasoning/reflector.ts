import { AuditLog } from "../governance/audit";

export function reflect(args: {
  audit: AuditLog;
  conversationId: string;
  sessionId: string;
  success: boolean;
  notes?: string[];
}) {
  args.audit.append({
    ts: new Date().toISOString(),
    conversationId: args.conversationId,
    sessionId: args.sessionId,
    kind: "response",
    payload: { success: args.success, notes: args.notes ?? [] },
  });
}
