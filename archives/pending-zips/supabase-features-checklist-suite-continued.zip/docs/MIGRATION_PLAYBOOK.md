# Migration + Import/Export Playbooks

## Import
- Prefer staged import (validate -> load -> reconcile).
- Use COPY for large CSVs.
- Track progress via an `import_runs` table.

## Export
- For tenant exports: enforce tenant filter at source.
- Produce signed URLs for downloads.
- Add expiry and audit log event.

## Zero-downtime migrations
- Expand/contract pattern:
  1) Add nullable column
  2) Backfill
  3) Deploy code reading new column
  4) Enforce constraint
  5) Drop old column later

