PAYOUT TYPES
============
1. Standard ACH (default)
2. Instant Cash-Out (optional, controlled)

All payouts:
- create ledger entries
- reconcile to bank
- emit audit logs
