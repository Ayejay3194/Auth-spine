# 06-employee-ops

People logistics and internal ops.
