"use client";
import { useEffect, useState } from "react";

type Profile = { displayName:string; title?:string|null; bio?:string|null; heroUrl?:string|null; avatarUrl?:string|null; instagram?:string|null };
type Service = { id:string; name:string; durationMin:number; basePriceCents:number; category?:string|null };
type Rule = { id:string; dow:number; startMin:number; endMin:number };
type Booking = { id:string; startAt:string; status:string; priceCentsFinal:number; service:{ name:string }; client?:{ email:string }|null };

const fmtMoney = (c:number)=>`$${Math.round(c/100)}`;
const dows = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const minToTime = (m:number)=>`${String(Math.floor(m/60)).padStart(2,"0")}:${String(m%60).padStart(2,"0")}`;

export function StudioTabs({ stylistId }:{ stylistId:string }){
  const [tab, setTab] = useState<"profile"|"services"|"availability"|"bookings">("profile");
  return (
    <div className="rounded-[28px] border p-6" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
      <div className="flex flex-wrap gap-2">
        <TabButton onClick={()=>setTab("profile")} active={tab==="profile"}>Profile</TabButton>
        <TabButton onClick={()=>setTab("services")} active={tab==="services"}>Services</TabButton>
        <TabButton onClick={()=>setTab("availability")} active={tab==="availability"}>Availability</TabButton>
        <TabButton onClick={()=>setTab("bookings")} active={tab==="bookings"}>Bookings</TabButton>
      </div>
      <div className="mt-6">
        {tab==="profile" && <ProfilePanel />}
        {tab==="services" && <ServicesPanel />}
        {tab==="availability" && <AvailabilityPanel />}
        {tab==="bookings" && <BookingsPanel />}
      </div>
    </div>
  );
}

function TabButton({ active, children, onClick }:{active?:boolean; children:any; onClick?:()=>void}){
  return (
    <button onClick={onClick} className="rounded-full border px-4 py-2 text-sm font-semibold"
      style={{borderColor: active ? "var(--accent)" : "var(--border)", background: active ? "var(--accent)" : "var(--panel2)", color: active ? "var(--accentText)" : "var(--text)"}}>
      {children}
    </button>
  );
}

function Field({ label, children }:{label:string; children:any}){
  return (
    <label className="block">
      <div className="mb-2 text-xs tracking-[.18em] uppercase" style={{color:"var(--dim)"}}>{label}</div>
      {children.type === "textarea" ? (
        <textarea {...children.props} className="w-full rounded-xl border px-3 py-3 text-sm" style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}} />
      ) : (
        <input {...children.props} className="w-full rounded-xl border px-3 py-3 text-sm" style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}} />
      )}
    </label>
  );
}

function FieldInline({ label, children }:{label:string; children:any}){
  return (
    <label className="block">
      <div className="mb-2 text-xs tracking-[.18em] uppercase" style={{color:"var(--dim)"}}>{label}</div>
      {children.type === "select" ? children : (
        <input {...children.props} className="w-full rounded-xl border px-3 py-3 text-sm" style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}} />
      )}
    </label>
  );
}

function ProfilePanel(){
  const [p, setP] = useState<Profile | null>(null);
  const [saved, setSaved] = useState<string>("");

  useEffect(()=>{ (async()=>{
    const r = await fetch("/api/studio/profile", { cache:"no-store" });
    if(!r.ok) return;
    const j = await r.json();
    setP(j.profile);
  })(); },[]);

  async function save(){
    setSaved("");
    const r = await fetch("/api/studio/profile", { method:"PUT", headers:{ "content-type":"application/json" }, body: JSON.stringify(p) });
    if(r.ok) setSaved("Saved.");
  }

  if(!p) return <div style={{color:"var(--muted)"}}>Loading…</div>;

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Field label="Display name"><input value={p.displayName||""} onChange={(e)=>setP({...p, displayName:e.target.value})} /></Field>
      <Field label="Title"><input value={p.title||""} onChange={(e)=>setP({...p, title:e.target.value})} /></Field>
      <Field label="Hero image URL"><input value={p.heroUrl||""} onChange={(e)=>setP({...p, heroUrl:e.target.value})} /></Field>
      <Field label="Avatar URL"><input value={p.avatarUrl||""} onChange={(e)=>setP({...p, avatarUrl:e.target.value})} /></Field>
      <div className="md:col-span-2">
        <Field label="Bio"><textarea rows={4} value={p.bio||""} onChange={(e)=>setP({...p, bio:e.target.value})} /></Field>
      </div>
      <Field label="Instagram handle"><input value={p.instagram||""} onChange={(e)=>setP({...p, instagram:e.target.value})} /></Field>
      <div className="md:col-span-2 flex items-center gap-3">
        <button onClick={save} className="rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>Save</button>
        {saved ? <div className="text-sm" style={{color:"var(--muted)"}}>{saved}</div> : null}
      </div>
    </div>
  );
}

function ServicesPanel(){
  const [services, setServices] = useState<Service[]>([]);
  const [form, setForm] = useState({ name:"", durationMin:60, basePriceCents:10000, category:"" });

  async function load(){
    const r = await fetch("/api/studio/services", { cache:"no-store" });
    const j = await r.json();
    setServices(j.services || []);
  }
  useEffect(()=>{ load(); },[]);

  async function add(){
    await fetch("/api/studio/services", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify(form) });
    setForm({ name:"", durationMin:60, basePriceCents:10000, category:"" });
    load();
  }
  async function del(id:string){
    await fetch(`/api/studio/services/${id}`, { method:"DELETE" });
    load();
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
        <div className="text-xs tracking-[.18em] uppercase" style={{color:"var(--dim)"}}>Add service</div>
        <div className="mt-3 grid gap-3 md:grid-cols-4">
          <FieldInline label="Name"><input value={form.name} onChange={(e)=>setForm({...form, name:e.target.value})} /></FieldInline>
          <FieldInline label="Duration (min)"><input type="number" value={form.durationMin} onChange={(e)=>setForm({...form, durationMin: Number(e.target.value)})} /></FieldInline>
          <FieldInline label="Price (cents)"><input type="number" value={form.basePriceCents} onChange={(e)=>setForm({...form, basePriceCents: Number(e.target.value)})} /></FieldInline>
          <FieldInline label="Category"><input value={form.category} onChange={(e)=>setForm({...form, category:e.target.value})} /></FieldInline>
        </div>
        <button onClick={add} className="mt-4 rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>Add</button>
      </div>

      <div className="grid gap-2">
        {services.map(s => (
          <div key={s.id} className="flex items-center justify-between rounded-2xl border px-4 py-3" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
            <div>
              <div className="text-sm font-semibold">{s.name}</div>
              <div className="text-xs" style={{color:"var(--dim)"}}>{s.durationMin}m · {fmtMoney(s.basePriceCents)} · {s.category||"—"}</div>
            </div>
            <button onClick={()=>del(s.id)} className="rounded-xl border px-3 py-2 text-sm" style={{borderColor:"var(--border)", background:"var(--panel)"}}>Delete</button>
          </div>
        ))}
        {!services.length ? <div style={{color:"var(--muted)"}}>No services yet.</div> : null}
      </div>
    </div>
  );
}

function AvailabilityPanel(){
  const [rules, setRules] = useState<Rule[]>([]);
  const [form, setForm] = useState({ dow:1, startMin:600, endMin:1080 });

  async function load(){
    const r = await fetch("/api/studio/availability", { cache:"no-store" });
    const j = await r.json();
    setRules(j.rules || []);
  }
  useEffect(()=>{ load(); },[]);

  async function add(){
    await fetch("/api/studio/availability", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify(form) });
    load();
  }
  async function del(id:string){
    await fetch(`/api/studio/availability/${id}`, { method:"DELETE" });
    load();
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
        <div className="text-xs tracking-[.18em] uppercase" style={{color:"var(--dim)"}}>Add rule</div>
        <div className="mt-3 grid gap-3 md:grid-cols-3">
          <FieldInline label="Day">
            <select value={form.dow} onChange={(e)=>setForm({...form, dow:Number(e.target.value)})} className="w-full rounded-xl border px-3 py-3 text-sm"
              style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}}>
              {dows.map((d,i)=> <option key={i} value={i}>{d}</option>)}
            </select>
          </FieldInline>
          <FieldInline label="Start (min)"><input type="number" value={form.startMin} onChange={(e)=>setForm({...form, startMin:Number(e.target.value)})} /></FieldInline>
          <FieldInline label="End (min)"><input type="number" value={form.endMin} onChange={(e)=>setForm({...form, endMin:Number(e.target.value)})} /></FieldInline>
        </div>
        <button onClick={add} className="mt-4 rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>Add</button>
      </div>

      <div className="grid gap-2">
        {rules.map(r => (
          <div key={r.id} className="flex items-center justify-between rounded-2xl border px-4 py-3" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
            <div>
              <div className="text-sm font-semibold">{dows[r.dow]}</div>
              <div className="text-xs" style={{color:"var(--dim)"}}>{minToTime(r.startMin)} – {minToTime(r.endMin)}</div>
            </div>
            <button onClick={()=>del(r.id)} className="rounded-xl border px-3 py-2 text-sm" style={{borderColor:"var(--border)", background:"var(--panel)"}}>Delete</button>
          </div>
        ))}
        {!rules.length ? <div style={{color:"var(--muted)"}}>No rules yet.</div> : null}
      </div>
    </div>
  );
}

function BookingsPanel(){
  const [bookings, setBookings] = useState<Booking[]>([]);

  async function load(){
    const r = await fetch("/api/studio/bookings", { cache:"no-store" });
    const j = await r.json();
    setBookings(j.bookings || []);
  }
  useEffect(()=>{ load(); },[]);

  return (
    <div className="space-y-3">
      {bookings.map(b => (
        <div key={b.id} className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-sm font-semibold">{b.service.name}</div>
              <div className="text-xs" style={{color:"var(--dim)"}}>
                {new Date(b.startAt).toLocaleString()} · {fmtMoney(b.priceCentsFinal)}
              </div>
              <div className="mt-2 text-xs tracking-[.16em] uppercase" style={{color:"var(--muted)"}}>{b.status}</div>
            </div>
            <div className="text-xs" style={{color:"var(--dim)"}}>{b.client?.email || "client"}</div>
          </div>
        </div>
      ))}
      {!bookings.length ? <div style={{color:"var(--muted)"}}>No bookings yet.</div> : null}
    </div>
  );
}
