export default function Home() {
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Auth-Spine Super Solid</h1>
      <p className="text-slate-700">
        This is the spine repo you asked for: config validation, errors, logging, health checks,
        security audit, and toolkits so your UI stops acting like a toddler in a sugar crash.
      </p>

      <div className="grid md:grid-cols-2 gap-4">
        <a className="rounded-xl bg-white shadow p-5 hover:shadow-md transition" href="/docs">
          <div className="font-semibold">Implementation Plan</div>
          <div className="text-sm text-slate-600">Your plan, rendered and organized.</div>
        </a>
        <a className="rounded-xl bg-white shadow p-5 hover:shadow-md transition" href="/api/health">
          <div className="font-semibold">/api/health</div>
          <div className="text-sm text-slate-600">Machine-readable health checks.</div>
        </a>
      </div>
    </div>
  )
}
