PROACTIVE PROBLEM INTERCEPTION
==============================

Detect:
- provider running late
- double-book risk
- payment failure risk
- no-show patterns

Actions:
- notify ops
- notify user calmly
- pre-emptive holds or rebooking
