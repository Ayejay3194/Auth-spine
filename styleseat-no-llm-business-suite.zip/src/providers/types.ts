export interface Slot { slotId: string; startISO: string; durationMin: number; }
export interface Booking { bookingId: string; slotId: string; service: string; status: "confirmed" | "canceled"; }
export interface Client { clientId: string; name: string; email?: string; phone?: string; tags: string[]; notes: string[]; }
export interface Invoice { invoiceId: string; clientId: string; amount: number; status: "draft" | "sent" | "paid" | "refunded"; }
export interface Promo { code: string; percentOff: number; active: boolean; }
export interface Referral { code: string; referrerClientId: string; uses: number; }
export interface Task { taskId: string; title: string; status: "open" | "done"; }
export interface KPI { key: string; value: number; unit?: string; }

export interface BookingProvider {
  findSlots(input: { service: string; dateISO?: string; partOfDay?: string; durationMin: number; timezone?: string }): Promise<Slot[]>;
  createBooking(input: { userId: string; slotId: string; service: string }): Promise<Booking>;
  cancelBooking(input: { userId: string; bookingId: string }): Promise<Booking>;
  listBookings(input: { userId: string }): Promise<Booking[]>;
}

export interface CRMProvider {
  findClient(input: { query: string }): Promise<Client | null>;
  addNote(input: { clientId: string; note: string }): Promise<void>;
  tagClient(input: { clientId: string; tag: string }): Promise<void>;
  history(input: { clientId: string }): Promise<{ bookings: Booking[]; invoices: Invoice[] }>;
}

export interface PaymentsProvider {
  createInvoice(input: { clientId: string; amount: number }): Promise<Invoice>;
  refund(input: { invoiceId: string; amount?: number }): Promise<Invoice>;
  applyCredit(input: { clientId: string; amount: number }): Promise<void>;
}

export interface MarketingProvider {
  createPromo(input: { code: string; percentOff: number }): Promise<Promo>;
  endPromo(input: { code: string }): Promise<Promo>;
  referralStatus(input: { code: string }): Promise<Referral | null>;
  sendCampaign(input: { segment: string; message: string }): Promise<{ sent: number }>;
}

export interface AnalyticsProvider {
  kpis(input: { dateISO?: string }): Promise<KPI[]>;
  exportReport(input: { report: string; format: "csv" | "json" }): Promise<{ url: string }>;
}

export interface OpsProvider {
  createTask(input: { title: string }): Promise<Task>;
  listTasks(): Promise<Task[]>;
  markDone(input: { taskId: string }): Promise<Task>;
  startChecklist(input: { name: string }): Promise<{ steps: string[] }>;
}

export interface AdminProvider {
  showAudit(input: { limit: number }): Promise<Array<{ at: string; type: string; details: any }>>;
  manageRole(input: { targetUserId: string; role: string }): Promise<{ ok: boolean }>;
  gdprExport(input: { userId: string }): Promise<{ url: string }>;
}
