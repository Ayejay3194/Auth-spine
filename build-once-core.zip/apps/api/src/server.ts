import Fastify from "fastify";
import { getPrisma } from "@suite/db";
import { createLogger } from "@suite/observability";
import { createSession, validateSession, revokeSession } from "@suite/sessions";
import { verifyStripeSignature, handleStripeEvent } from "@suite/billing";

const log = createLogger();
const app = Fastify({ logger: false });

app.get("/health", async () => ({ ok: true }));

// DEV: create tenant
app.post("/tenants", async (req, reply) => {
  const prisma = getPrisma();
  const body = (req.body ?? {}) as any;
  const t = await prisma.tenant.create({ data: { slug: body.slug ?? `t${Date.now()}`, name: body.name ?? "Tenant" } });
  return t;
});

// DEMO login: creates a session for an existing user (you'll swap to real auth)
app.post("/auth/login", async (req, reply) => {
  const prisma = getPrisma();
  const body = (req.body ?? {}) as any;
  const user = await prisma.user.findFirst({ where: { tenantId: body.tenantId, email: body.email } });
  if (!user) return reply.code(401).send({ ok: false, error: "invalid_credentials" });

  const sess = await createSession({
    tenantId: body.tenantId,
    userId: user.id,
    ip: (req.headers["x-forwarded-for"] as string) || req.ip,
    userAgent: (req.headers["user-agent"] as string) || undefined,
    deviceLabel: body.deviceLabel,
  });

  return { ok: true, token: sess.token, expiresAt: sess.expiresAt.toISOString() };
});

app.get("/auth/sessions", async (req, reply) => {
  const prisma = getPrisma();
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i,"");
  const s = token ? await validateSession(token) : null;
  if (!s) return reply.code(401).send({ ok:false });

  const sessions = await prisma.session.findMany({
    where: { tenantId: s.tenantId, userId: s.userId, revokedAt: null },
    orderBy: { lastSeenAt: "desc" }
  });
  return { ok:true, sessions };
});

app.post("/auth/sessions/:id/revoke", async (req, reply) => {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i,"");
  const s = token ? await validateSession(token) : null;
  if (!s) return reply.code(401).send({ ok:false });
  await revokeSession((req.params as any).id, s.tenantId);
  return { ok:true };
});

// Stripe webhook: needs RAW body
app.post("/billing/stripe/webhook", { config: { rawBody: true } } as any, async (req, reply) => {
  const secret = process.env.STRIPE_WEBHOOK_SECRET || "";
  const raw = (req.body as any) as Buffer; // raw payload
  const sig = req.headers["stripe-signature"] as string | undefined;

  if (!verifyStripeSignature(raw, sig, secret)) {
    log.warn("stripe webhook signature failed");
    return reply.code(400).send({ ok:false });
  }

  const event = JSON.parse(raw.toString("utf8"));
  await handleStripeEvent(event);
  return { received: true };
});

app.listen({ port: 3001, host: "0.0.0.0" }).then(() => log.info("api up", { port: 3001 }));
