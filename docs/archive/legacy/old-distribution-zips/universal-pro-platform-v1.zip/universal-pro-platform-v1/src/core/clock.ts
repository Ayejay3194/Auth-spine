export class SystemClock { nowUtc(): string { return new Date().toISOString(); } }
