Platform Security Non-Negotiables Pack

This pack turns the baseline security requirements into:
- checklists you can enforce
- configs/templates you can copy into a Next.js app
- CI gates placeholders to prevent unsafe deploys

Use this as the minimum bar before any public launch.
