import { findFiles, readText, rel } from "../utils/fs.js";
import type { Check, Finding } from "../types.js";

export const BackupsConfigCheck: Check = {
  id: "data.backups_present",
  title: "Backups configuration is present",
  category: "Data",
  async run(ctx) {
    const controls = ctx.profile.expectations?.controls ?? {};
    if (!controls.backups?.required) return [];

    // Heuristic: look for terraform resources or docs that indicate backups/snapshots/PITR
    const files = findFiles(ctx.root, ["**/*.tf", "**/*.md", "**/*.yml", "**/*.yaml", "**/*.json"])
      .filter(f => !f.includes("node_modules/") && !f.includes("dist/"));

    const needles = [
      "backup", "snapshot", "point_in_time", "pitr", "retention", "wal", "continuous_backup"
    ];

    let found = false;
    let foundFile = "";
    for (const f of files) {
      const txt = readText(f);
      if (!txt) continue;
      const lower = txt.toLowerCase();
      if (needles.some(n => lower.includes(n))) {
        found = true; foundFile = rel(ctx.root, f); break;
      }
    }

    if (!found) {
      return [{
        id: this.id,
        title: this.title,
        category: this.category,
        severity: controls.backups?.severity ?? "P0",
        evidence: [{
          message: "No obvious backup/PITR configuration found in repo artifacts",
          hint: "Add automated backups (and prove restore works). Include retention + encryption."
        }]
      } satisfies Finding];
    }
    return [];
  }
};
