# Conversation regression tests (JSONL)

Run:
```bash
python backend/tests/run_convo_tests.py
```
