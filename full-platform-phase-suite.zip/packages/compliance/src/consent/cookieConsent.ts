export type ConsentCategory = "necessary" | "analytics" | "marketing";
export type ConsentState = Record<ConsentCategory, boolean>;

export function defaultConsent(): ConsentState {
  return { necessary: true, analytics: false, marketing: false };
}

export function applyConsent(prev: ConsentState, patch: Partial<ConsentState>): ConsentState {
  return { ...prev, ...patch, necessary: true };
}
