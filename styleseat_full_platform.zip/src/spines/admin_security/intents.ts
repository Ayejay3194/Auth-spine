// admin_security intents.ts
