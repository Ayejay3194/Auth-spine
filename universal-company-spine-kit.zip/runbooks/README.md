Runbooks (Operational Playbooks)
================================

These are plug-and-play runbooks you ship with any project to reduce support + panic.

Included
--------
- auth.md
- payments.md
- data.md
- feature-flags.md
- incidents.md
- launch.md

How to use
----------
1) Put these in your repo at /runbooks
2) Link them in your admin panel + internal docs
3) Add environment-specific notes as you deploy
