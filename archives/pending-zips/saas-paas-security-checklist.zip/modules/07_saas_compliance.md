SAAS-SPECIFIC COMPLIANCE

SOC2
- Control environment + evidence collection
- Access reviews, change management, incident response tests
- Vendor risk program
- Audit cadence + report sharing (NDA)

ISO27001
- ISMS, SoA, internal audits, continuous improvement
- Asset mgmt, access control, supplier relationships

GDPR
- DPA, lawful basis, consent, SAR, deletion, portability
- DPIA, ROPA, breach notification timelines
- Privacy by design/default, retention schedules

Other
- CCPA/CPRA, HIPAA (if needed), PCI, FedRAMP/FISMA, etc.
