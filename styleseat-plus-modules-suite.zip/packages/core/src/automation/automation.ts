import type { ID, ISODateTime, Result } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type Trigger =
  | "booking.completed"
  | "booking.no_show"
  | "client.inactive"
  | "payment.failed";

export type Action =
  | { kind: "send_campaign"; campaignId: ID }
  | { kind: "create_notification"; userId: ID; title: string; body?: string; url?: string }
  | { kind: "apply_tag"; clientId: ID; tag: string }
  | { kind: "require_deposit_next_time"; clientId: ID };

export type Rule = { id: ID; businessId: ID; name: string; trigger: Trigger; enabled: boolean; conditions?: Record<string, any>; actions: Action[] };

export type Fired = { id: ID; ruleId: ID; trigger: Trigger; at: ISODateTime; payload: any; actions: Action[] };

export class AutomationService {
  private rules: Rule[] = [];
  private fired: Fired[] = [];

  createRule(r: Omit<Rule,"id">): Rule { const rr = { ...r, id: cuid("rule") }; this.rules.push(rr); return rr; }
  listRules(businessId: ID) { return this.rules.filter(r => r.businessId === businessId); }

  fire(businessId: ID, trigger: Trigger, payload: any, at: ISODateTime): Fired[] {
    const hits = this.rules.filter(r => r.businessId===businessId && r.enabled && r.trigger===trigger);
    const events: Fired[] = hits.map(r => {
      const f: Fired = { id: cuid("fire"), ruleId: r.id, trigger, at, payload, actions: r.actions };
      this.fired.push(f);
      return f;
    });
    return events;
  }

  listFired(businessId: ID, limit=200) {
    const ruleIds = new Set(this.rules.filter(r => r.businessId===businessId).map(r=>r.id));
    return this.fired.filter(f => ruleIds.has(f.ruleId)).slice(-limit).reverse();
  }
}
