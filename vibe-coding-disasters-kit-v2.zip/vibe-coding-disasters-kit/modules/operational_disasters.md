# OPERATIONAL DISASTERS

## Maintenance Problems

- [ ] No maintenance window
- [ ] Maintenance during peak hours
- [ ] No maintenance notifications
- [ ] Surprise downtime
- [ ] Extended unplanned outages
- [ ] Cannot perform maintenance without downtime
- [ ] Schema changes causing downtime
- [ ] Deployments causing downtime
- [ ] Database migrations taking too long
- [ ] Migration rollback not tested
- [ ] Breaking changes in migrations
- [ ] Data corruption during migration
- [ ] No rollback capability

## Backup Disasters

- [ ] No backups at all
- [ ] Backups never tested
- [ ] Backups corrupted
- [ ] Backups in same location as primary
- [ ] Backups not encrypted
- [ ] Backup retention too short
- [ ] No point-in-time recovery
- [ ] Restore process unknown
- [ ] Restore takes too long (RTO)
- [ ] Too much data loss on restore (RPO)
- [ ] Backup process breaking production
- [ ] Backups consuming too many resources
- [ ] No backup monitoring
- [ ] Backup failures ignored
- [ ] Cannot restore specific records
- [ ] Backups too large to download

## Disaster Recovery Failures

- [ ] No disaster recovery plan
- [ ] DR plan never tested
- [ ] DR plan outdated
- [ ] Single region deployment
- [ ] No geographic redundancy
- [ ] DNS single point of failure
- [ ] Database single point of failure
- [ ] No failover mechanism
- [ ] Failover process manual and slow
- [ ] Failover never tested
- [ ] Data loss during failover
- [ ] Cannot fail back
- [ ] No runbooks for incidents
- [ ] Incident response chaotic
- [ ] No communication plan during outage
- [ ] Team doesn’t know DR procedures

## Capacity Issues

- [ ] No capacity planning
- [ ] Running out of resources
- [ ] Cannot scale fast enough
- [ ] Hitting infrastructure limits
- [ ] Database connections exhausted
- [ ] File descriptors exhausted
- [ ] Memory exhausted
- [ ] CPU at 100%
- [ ] Disk full
- [ ] Network bandwidth maxed
- [ ] Rate limits from providers hit
- [ ] API quotas exceeded
- [ ] Database storage full
- [ ] Log storage full
- [ ] Backup storage full
- [ ] No auto-scaling
- [ ] Auto-scaling too slow
- [ ] Auto-scaling too aggressive

---
