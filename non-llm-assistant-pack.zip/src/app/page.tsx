import Link from 'next/link';
export default function Home(){return(<main><h1>Non‑LLM Assistant Pack</h1><p>Deterministic, explainable automation engines.</p><ul><li><Link href='/demo'>Open Demo Runner</Link></li></ul></main>);}
