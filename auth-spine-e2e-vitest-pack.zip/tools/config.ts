export const BASE_URL = process.env.BASE_URL || process.env.TEST_URL || 'http://localhost:3000';

export const TEST_TENANTS = {
  a: { id: 'tenant-a', name: 'Tenant A', slug: 'tenant-a' },
  b: { id: 'tenant-b', name: 'Tenant B', slug: 'tenant-b' }
};

export const TEST_USERS = {
  a: { tenantId: 'tenant-a', email: 'a@example.com', deviceLabel: 'test-device-a' },
  b: { tenantId: 'tenant-b', email: 'b@example.com', deviceLabel: 'test-device-b' }
};
