import type { Providers, Booking, Client, Invoice, Promo, KPI, Task } from "../assistant/providers/types.js";

let tasks: Task[] = [
  { taskId: "t1", title: "Confirm tomorrow appointments", status: "open" },
  { taskId: "t2", title: "Send follow-ups", status: "open" }
];

let invoices: Invoice[] = [];
let promos: Promo[] = [];
let audit: Array<{ at: string; type: string; details: any }> = [];

export function makeMockProviders(): Providers {
  return {
    booking: {
      async findSlots() { return []; },
      async createBooking() { return { bookingId: "bk_1", slotId: "slot_1", status: "confirmed" } as Booking; },
      async cancelBooking(input) { return { bookingId: input.bookingId, slotId: "slot_1", status: "canceled" } as Booking; },
      async listBookings(input) { return [{ bookingId: "bk_1", slotId: "slot_1", service: "consult", status: "confirmed" }]; },
    },
    crm: {
      async findClient(input) { return { clientId: "cl_1", name: "A Client", email: "a@x.com", tags: [] } as Client; },
      async addNote() { },
      async tagClient() { }
    },
    payments: {
      async createInvoice(input) {
        const inv: Invoice = { invoiceId: `inv_${invoices.length+1}`, clientId: input.clientId, amount: input.amount, status: "sent" };
        invoices.push(inv);
        return inv;
      },
      async refund(input) {
        const inv = invoices.find(i => i.invoiceId === input.invoiceId) ?? { invoiceId: input.invoiceId, clientId: "cl_1", amount: 0, status: "sent" as const };
        inv.status = "refunded";
        return inv;
      }
    },
    marketing: {
      async createPromo(input) {
        const p: Promo = { code: input.code, percentOff: input.percentOff, active: true };
        promos.push(p);
        return p;
      },
      async referralStatus(input) { return null; },
      async sendCampaign() { return { queued: true }; }
    },
    analytics: {
      async kpis() {
        const revenue = invoices.filter(i => i.status !== "refunded").reduce((a,b)=>a+b.amount,0);
        const k: KPI[] = [
          { key: "revenue", value: revenue, unit: "USD" },
          { key: "invoices", value: invoices.length }
        ];
        return k;
      },
      async exportReport() { return { url: "https://example.com/report.csv" }; }
    },
    ops: {
      async listTasks() { return tasks; },
      async createTask(input) {
        const t: Task = { taskId: `t${tasks.length+1}`, title: input.title, status: "open" };
        tasks.push(t);
        return t;
      },
      async markDone(input) {
        const t = tasks.find(x => x.taskId === input.taskId);
        if (t) t.status = "done";
        return t ?? { taskId: input.taskId, title: "Unknown", status: "done" };
      },
      async startChecklist() { return { steps: ["Step 1", "Step 2"] }; }
    },
    admin: {
      async showAudit(input) { return audit.slice(0, input.limit); },
      async gdprExport(input) { return { url: `https://example.com/gdpr/${input.userId}.zip` }; }
    }
  };
}
