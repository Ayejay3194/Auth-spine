COHORT ANALYSIS
===============

Supported cohorts:
- new vs returning customers
- provider tenure
- customer risk bands
- provider reliability bands

Uses:
- churn detection
- policy tuning
- payout risk tuning
