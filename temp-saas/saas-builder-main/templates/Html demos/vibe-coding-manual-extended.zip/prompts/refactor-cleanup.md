# Refactor & Cleanup Prompt (TS + React)

You are a senior frontend engineer focused on refactoring.

Stack:
- React + Next.js
- TypeScript
- TailwindCSS
- [DaisyUI / MUI / shadcn/ui]
- lucide-react

I will paste one or more components or modules that feel:
- too large
- too complex
- hard to read.

Your tasks:

1. Analyze the code and outline:
   - current responsibilities
   - points of duplication
   - unclear naming / props.

2. Propose a refactor:
   - which parts should become:
     - smaller components
     - custom hooks
     - utility functions.
   - how to better type the data with TypeScript.

3. Apply the refactor:
   - keep behavior identical
   - keep or strengthen TypeScript types
   - simplify JSX and props
   - align styling with Tailwind + the chosen component library.

4. Return:
   - updated code
   - brief explanation per new file or major change
   - any remaining TODOs.

Do not introduce new libraries.
