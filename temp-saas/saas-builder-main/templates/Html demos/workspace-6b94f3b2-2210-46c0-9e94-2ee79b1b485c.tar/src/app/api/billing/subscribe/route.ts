import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { db } from '@/lib/db'
import { z } from 'zod'

const subscribeSchema = z.object({
  planId: z.string(),
  workspaceId: z.string(),
})

// POST /api/billing/subscribe - Create subscription
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { planId, workspaceId } = subscribeSchema.parse(body)

    // Check if user is workspace owner
    const membership = await db.workspaceMember.findUnique({
      where: {
        userId_workspaceId: {
          userId: session.user.id,
          workspaceId: workspaceId
        }
      }
    })

    if (!membership || membership.role !== 'OWNER') {
      return NextResponse.json(
        { success: false, error: { code: 'FORBIDDEN', message: 'Only workspace owners can manage billing' } },
        { status: 403 }
      )
    }

    // Check if workspace already has a subscription
    const existingSubscription = await db.subscription.findUnique({
      where: { workspaceId }
    })

    if (existingSubscription) {
      return NextResponse.json(
        { success: false, error: { code: 'ALREADY_SUBSCRIBED', message: 'Workspace already has a subscription' } },
        { status: 409 }
      )
    }

    // Get plan details
    const plan = await db.plan.findUnique({
      where: { id: planId }
    })

    if (!plan) {
      return NextResponse.json(
        { success: false, error: { code: 'PLAN_NOT_FOUND', message: 'Plan not found' } },
        { status: 404 }
      )
    }

    // In a real implementation, you would create a Stripe checkout session here
    // For demo purposes, we'll create a subscription directly
    const subscription = await db.subscription.create({
      data: {
        workspaceId,
        planId,
        status: 'TRIALING',
        currentPeriodStart: new Date(),
        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      },
      include: {
        plan: true
      }
    })

    // Create audit log
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        workspaceId,
        action: 'subscription.created',
        resource: 'subscription',
        resourceId: subscription.id,
        newValues: {
          planId,
          status: subscription.status
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: subscription
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: { code: 'VALIDATION_ERROR', message: 'Invalid input', details: error.errors } },
        { status: 400 }
      )
    }

    console.error('Failed to create subscription:', error)
    return NextResponse.json(
      { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to create subscription' } },
      { status: 500 }
    )
  }
}