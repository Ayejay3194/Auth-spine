# Code Review Prompt: Security + Reliability Gate

Review this PR like you have to sleep at night.

Checklist:
- Auth is enforced server-side; no client-only gates.
- No new endpoints without authz.
- Inputs validated; outputs encoded; no innerHTML with user content.
- Queries parameterized; pagination added for list endpoints.
- RLS/policies updated for any new tables or access paths.
- No secrets in diff.
- Errors handled; logs redacted; request IDs propagated.
- Webhooks idempotent + signature verified.
- Tests cover the change; rollback plan exists for migrations.
