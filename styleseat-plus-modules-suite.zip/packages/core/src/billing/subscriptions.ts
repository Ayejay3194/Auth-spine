import type { ID, ISODateTime, Result, Money } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type PlanTier = "free" | "solo" | "pro" | "studio" | "enterprise";

export type Plan = {
  tier: PlanTier;
  priceMonthly: Money;
  entitlements: Record<string, boolean>;
  quotas: Record<string, number>; // e.g. "bookingsPerMonth", "teamMembers"
};

export type Subscription = {
  subscriptionId: ID;
  businessId: ID;
  tier: PlanTier;
  status: "active" | "past_due" | "canceled";
  currentPeriodStart: ISODateTime;
  currentPeriodEnd: ISODateTime;
};

export type UsageEvent = { id: ID; businessId: ID; key: string; amount: number; at: ISODateTime };

export class SubscriptionService {
  private subs: Subscription[] = [];
  private usage: UsageEvent[] = [];

  constructor(private plans: Plan[]) {}

  upsertSubscription(businessId: ID, tier: PlanTier, startISO: ISODateTime, endISO: ISODateTime): Subscription {
    const existing = this.subs.find(s => s.businessId === businessId);
    const sub: Subscription = existing ? { ...existing, tier, status: "active", currentPeriodStart: startISO, currentPeriodEnd: endISO } :
      { subscriptionId: cuid("sub"), businessId, tier, status: "active", currentPeriodStart: startISO, currentPeriodEnd: endISO };
    if (!existing) this.subs.push(sub);
    else Object.assign(existing, sub);
    return sub;
  }

  getPlan(tier: PlanTier): Plan {
    const p = this.plans.find(p => p.tier === tier);
    if (!p) throw new Error(`Missing plan tier: ${tier}`);
    return p;
  }

  getSubscription(businessId: ID): Subscription | null { return this.subs.find(s => s.businessId === businessId) ?? null; }

  entitled(businessId: ID, entitlement: string): boolean {
    const sub = this.getSubscription(businessId);
    const tier = sub?.tier ?? "free";
    return !!this.getPlan(tier).entitlements[entitlement];
  }

  recordUsage(ev: UsageEvent) { this.usage.push(ev); }

  usageInPeriod(businessId: ID, key: string, startISO: ISODateTime, endISO: ISODateTime): number {
    const start = Date.parse(startISO), end = Date.parse(endISO);
    return this.usage
      .filter(u => u.businessId === businessId && u.key === key)
      .filter(u => { const t = Date.parse(u.at); return t >= start && t < end; })
      .reduce((a,b)=>a+b.amount,0);
  }

  checkQuota(businessId: ID, key: string): Result<{ used: number; limit: number }> {
    const sub = this.getSubscription(businessId);
    const tier = sub?.tier ?? "free";
    const plan = this.getPlan(tier);
    const limit = plan.quotas[key] ?? 0;
    if (!sub) return { ok: true, data: { used: 0, limit } }; // free plan assumed
    const used = this.usageInPeriod(businessId, key, sub.currentPeriodStart, sub.currentPeriodEnd);
    if (limit > 0 && used >= limit) return { ok: false, error: { code: "QUOTA_EXCEEDED", message: `Quota exceeded for ${key}`, details: { used, limit } } };
    return { ok: true, data: { used, limit } };
  }
}
