// loyalty intents.ts
