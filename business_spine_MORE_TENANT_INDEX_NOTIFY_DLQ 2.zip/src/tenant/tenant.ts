export function getTenant(req: Request): { tenantId: string } {
  const h = req.headers.get("x-tenant-id");
  if (h) return { tenantId: h };
  return { tenantId: "tenant_demo" };
}
