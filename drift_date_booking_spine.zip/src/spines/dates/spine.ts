    import { Spine, Intent, AssistantContext, Extraction, FlowStep } from "../../core/types.js";
    import { detectByPatterns } from "../../core/intent.js";
    import { requireFields, extractDateTime } from "../../core/entities.js";
    import { patterns } from "./intents.js";

    const REQUIRED: Record<string, string[]> = {
  "date_propose": [
    "matchId",
    "inviteeUserId",
    "category"
  ],
  "date_accept": [
    "dateRequestId"
  ],
  "date_decline": [
    "dateRequestId"
  ],
  "date_cancel": [
    "dateRequestId"
  ],
  "date_set_time": [
    "dateRequestId",
    "proposedStartISO"
  ],
  "venue_search": [],
  "reservation_create": [
    "dateRequestId",
    "venueId",
    "proposedStartISO"
  ]
};
    const MAP: Record<string, { tool: string; action: string; sensitivity: "low"|"medium"|"high" }> = {
  "date_propose": {
    "tool": "date.create_request",
    "action": "date.create_request",
    "sensitivity": "medium"
  },
  "date_accept": {
    "tool": "date.accept",
    "action": "date.accept",
    "sensitivity": "medium"
  },
  "date_decline": {
    "tool": "date.decline",
    "action": "date.decline",
    "sensitivity": "medium"
  },
  "date_cancel": {
    "tool": "date.cancel",
    "action": "date.cancel",
    "sensitivity": "medium"
  },
  "date_set_time": {
    "tool": "date.set_time",
    "action": "date.set_time",
    "sensitivity": "medium"
  },
  "venue_search": {
    "tool": "venue.search",
    "action": "venue.search",
    "sensitivity": "low"
  },
  "reservation_create": {
    "tool": "reservation.create",
    "action": "reservation.create",
    "sensitivity": "high"
  }
};

    function baseEntities(text: string, ctx: AssistantContext): Record<string, unknown> {
      const out: Record<string, unknown> = {};

      const mid = text.match(/\b(match_[a-z0-9]+)\b/i);
      if (mid) out.matchId = mid[1];

      const dr = text.match(/\b(date_[a-z0-9]+|daterequest_[a-z0-9]+)\b/i);
      if (dr) out.dateRequestId = dr[1];

      const uid = text.match(/\b(invitee|for)\s+(user_[a-z0-9]+)\b/i);
      if (uid) out.inviteeUserId = uid[2];

      const cat = text.match(/\b(dinner|drinks|coffee|museum|minigolf|mini golf|movie|walk)\b/i);
      if (cat) out.category = cat[1].toLowerCase().replace("mini golf","minigolf");

      const bud = text.match(/\$\s*(\d+)\b/);
      if (bud) out.budget = Number(bud[1]);

      const ps = text.match(/\bparty\s*(\d+)\b/i);
      if (ps) out.partySize = Number(ps[1]);

      const dt = extractDateTime(text, ctx.nowISO);
      if (dt.dateTimeISO) out.proposedStartISO = dt.dateTimeISO;

      const venue = text.match(/\bvenue\s+(venue_[a-z0-9]+)\b/i);
      if (venue) out.venueId = venue[1];

      const tr = text.match(/\btitle\s+(.+)$/i);
      if (tr) out.title = tr[1].trim();

      return out;
    }

    export const spine: Spine = {
      name: "dates",
      description: "Drift date booking: propose/accept/decline/cancel/set time/search venue/reserve",
      detectIntent: (text, _ctx) => detectByPatterns(text, patterns),
      extractEntities: (intent: Intent, text: string, ctx: AssistantContext): Extraction => {
        const entities = baseEntities(text, ctx);



        const req = REQUIRED[intent.name] ?? [];
        const missing = requireFields(entities, req);
        return { entities, missing };
      },
      buildFlow: (intent, extraction, _ctx): FlowStep[] => {
        if (extraction.missing.length) {
          return [{ kind: "ask", prompt: `Missing: ${extraction.missing.join(", ")}`, missing: extraction.missing }];
        }
        const m = MAP[intent.name];
        if (!m) return [{ kind: "respond", message: `No mapping for intent: ${intent.name}` }];

        return [{
          kind: "execute",
          action: m.action,
          sensitivity: m.sensitivity,
          tool: m.tool,
          input: extraction.entities,
        }];
      },
    };
