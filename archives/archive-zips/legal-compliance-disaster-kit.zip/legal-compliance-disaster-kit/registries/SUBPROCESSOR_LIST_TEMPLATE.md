# Subprocessor List (Template)

| Subprocessor | Purpose | Data categories | Location | DPA link |
|---|---|---|---|---|
| [Vendor] | hosting | account + content | [region] | [link] |

Update history:
- [date] added/removed [vendor]
