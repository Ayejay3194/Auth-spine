# Payments, Billing, and Money-Safety Checklist

Money code is where small bugs become large lawsuits.

## Payment Processing
- [ ] Use a processor (no raw cards, no DIY)
- [ ] Validate amounts server-side (never trust client totals)
- [ ] Webhooks: signature verification + idempotency keys + replay handling
- [ ] Double-charge prevention (unique constraints + idempotent intent creation)
- [ ] Refunds actually reconcile (and have a retry path)
- [ ] Receipts + confirmations (email + in-app)

## Subscriptions & Entitlements
- [ ] Subscription state machine (trial -> active -> past_due -> canceled)
- [ ] Entitlement checks server-side (feature flags tied to billing status)
- [ ] Proration tested (upgrade/downgrade)
- [ ] Cancel works (immediate vs end-of-period is explicit)
- [ ] Dunning: retries + notifications + eventual downgrade/lock

## Fraud & Chargebacks
- [ ] Basic fraud controls: velocity limits, IP/device signals, risky BIN/country rules
- [ ] Clear policies (refund, disputes) shown before purchase
- [ ] Evidence capture: delivery confirmation, session logs, timestamps
- [ ] Chargeback dashboard + threshold alerts (keep < 1% or processors get cranky)

## Taxes (if applicable)
- [ ] Tax region captured where required
- [ ] Invoices include required info (business name/address, tax IDs where needed)
- [ ] Currency precision correct (integers for cents)

## Engineering Artifacts
- `payments` table (intentId, processorId, amountCents, currency, status, userId, createdAt)
- `webhook_events` table (eventId UNIQUE, receivedAt, processedAt, status, payloadHash)
- `entitlements` table (userId, planId, status, expiresAt)
