import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logEvent } from "@/lib/events";

const Body = z.object({
  entityType: z.enum(["USER","STYLIST","SALON","SERVICE","BOOKING","SLOT"]),
  entityId: z.string(),
  name: z.string().min(1),
  props: z.any().optional(),
});

export async function POST(req: Request){
  const session = await auth();
  let actorUserId: string | null = null;
  if(session?.user?.email){
    const u = await prisma.user.findUnique({ where:{ email: session.user.email } });
    actorUserId = u?.id ?? null;
  }

  const data = Body.parse(await req.json());
  await logEvent({ actorUserId, entityType: data.entityType as any, entityId: data.entityId, name: data.name, props: data.props });

  return Response.json({ ok:true });
}
