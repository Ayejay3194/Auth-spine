export type Locale = string;
export type Messages = Record<string, string>;

export interface I18n {
  locale(): Locale;
  t(key: string, vars?: Record<string, string | number>): string;
}

export interface MessageLoader {
  load(locale: Locale): Promise<Messages>;
}

export class SimpleI18n implements I18n {
  private msgs: Messages = {};
  constructor(private loc: Locale, private loader: MessageLoader) {}

  async init() { this.msgs = await this.loader.load(this.loc); return this; }

  locale() { return this.loc; }

  t(key: string, vars: Record<string, string | number> = {}): string {
    const raw = this.msgs[key] ?? key;
    return raw.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_, k) => String(vars[k] ?? ""));
  }
}
