
export interface SellerDashboardMetrics {
  revenue30d: number;
  bookings30d: number;
  cancellations30d: number;
  avgRating: number;
  trustScore: number;
}

export class SellerDashboardSpine {
  async getMetrics(sellerId: string): Promise<SellerDashboardMetrics> {
    return {
      revenue30d: 4200,
      bookings30d: 38,
      cancellations30d: 3,
      avgRating: 4.8,
      trustScore: 87
    };
  }
}
