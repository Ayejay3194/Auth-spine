import type { IntentMatch, NLUModel } from "../types";

/**
 * Combines multiple signals into a single decision.
 * You can tune thresholds in model.settings.
 */
export function pickBest(model: NLUModel, candidates: IntentMatch[]): IntentMatch {
  const sorted = [...candidates].sort((a, b) => (b.confidence - a.confidence));
  const best = sorted[0] ?? { name: "unknown", confidence: 0, method: "fallback" as const };

  const minAct = model.settings?.minConfidenceToAct ?? 0.55;
  if (best.confidence < minAct) return { name: "unknown", confidence: best.confidence, method: "fallback", reasoning: `below minConfidenceToAct(${minAct})` };

  return best;
}

export function isConfident(model: NLUModel, match: IntentMatch): boolean {
  const minSkip = model.settings?.minConfidenceToSkipClarify ?? 0.75;
  return match.confidence >= minSkip;
}
