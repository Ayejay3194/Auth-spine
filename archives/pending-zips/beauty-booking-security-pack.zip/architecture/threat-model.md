# Threat Model (Template)

## Assets
- User accounts, sessions
- Bookings + calendars
- Payments/payouts
- Portfolio media (uploads)
- PII (email, phone, address)
- Ops notes + audit logs

## Actors
- External attacker
- Malicious user (client/stylist)
- Compromised admin account
- Vendor compromise

## Entry points
- Auth endpoints
- Booking creation + modification endpoints
- File upload endpoints
- Messaging endpoints
- Admin actions (refunds, approvals)
- Webhooks (payments, notifications)

## Top threats (bookings platform reality)
- Credential stuffing + account takeover
- Privilege escalation (horizontal + vertical)
- CSRF on state-changing ops endpoints
- Payment tampering / price manipulation
- Upload attacks (malware, stored XSS via SVG)
- Data exfiltration via admin tools
- Webhook forgery

## Controls mapping
- MFA for ops
- Rate limits + lockouts
- Strict RBAC/ABAC
- CSRF protection
- Signed webhook verification
- CSP + output encoding
- Upload re-encoding + virus scan + signed URLs
- Immutable audit logging
