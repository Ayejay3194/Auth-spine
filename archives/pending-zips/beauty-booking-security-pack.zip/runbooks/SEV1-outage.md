# SEV1: Outage Runbook

- Identify blast radius (public vs ops vs payments vs uploads)
- Rollback last deploy
- Check DB health + connection pool
- Check rate limits (are we self-DDoSing?)
- Fail open vs fail closed decisions (payments should fail closed)
- Status updates every 30 minutes
