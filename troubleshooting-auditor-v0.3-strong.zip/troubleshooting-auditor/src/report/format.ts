import type { AuditReport, Severity } from "../types.js";
function sevRank(s: Severity) { return s === "ERROR" ? 0 : s === "WARN" ? 1 : 2; }

export function toMarkdown(r: AuditReport): string {
  const lines: string[] = [];
  lines.push(`# Troubleshooting Audit Report`);
  lines.push(`- Root: \`${r.meta.root}\``);
  lines.push(`- Timestamp: \`${r.meta.timestamp}\``);
  lines.push(`- Node: \`${r.meta.node}\``);
  lines.push(`- Platform: \`${r.meta.platform}\``);
  lines.push("");
  lines.push(`## Summary`);
  lines.push(`- Errors: **${r.summary.errors}**`);
  lines.push(`- Warnings: **${r.summary.warns}**`);
  lines.push(`- Info: **${r.summary.infos}**`);
  lines.push("");

  for (const s of r.sections) {
    const findings = [...s.findings].sort((a,b)=> sevRank(a.severity)-sevRank(b.severity));
    lines.push(`## ${s.title}`);
    if (!findings.length) { lines.push(`- ✅ No findings`); lines.push(""); continue; }

    for (const f of findings) {
      lines.push(`### [${f.severity}] ${f.title}`);
      lines.push(f.details);
      if (f.fix) lines.push(`**Fix:** ${f.fix}`);
      if (f.evidence && Object.keys(f.evidence).length) {
        lines.push(`**Evidence:**`);
        lines.push("```json");
        lines.push(JSON.stringify(f.evidence, null, 2));
        lines.push("```");
      }
      lines.push("");
    }
  }
  return lines.join("\n");
}
export function toJson(r: AuditReport): string { return JSON.stringify(r, null, 2); }
