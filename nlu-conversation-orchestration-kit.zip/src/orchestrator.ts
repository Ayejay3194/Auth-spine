import { ResponsePlan, ToneLevel, TurnInput } from "./types";
import { arbitrateTone } from "./toneArbiter";
import { applyMemoryDampener } from "./memoryDampener";
import { applyEscalation } from "./escalation";
import { mapSignalsToStyle } from "./interpretationMapper";
import { applyPersonaFilter } from "./personaFilter";

export type QuotePack = {
  // Your quote selector can use toneTag + intent + entities to pick a line.
  // This kit just decides *whether* to use it and which tag.
  getLine: (toneTag: string, ctx?: { intent: string }) => string;
};

function toneTagFromLevel(level: ToneLevel): string {
  switch (level) {
    case 0: return "neutral";
    case 1: return "polite_shade";
    case 2: return "dry_passive";
    case 3: return "surgical";
  }
}

export function createOrchestrator() {
  return {
    orchestrateTurn(input: TurnInput, quotePack: QuotePack): { plan: ResponsePlan; suggestedLine: string } {
      const notes: string[] = [];

      const arb = arbitrateTone(input);
      notes.push(...arb.notes);

      const esc = applyEscalation(input, arb.toneLevel);
      notes.push(...esc.notes);

      const damp = applyMemoryDampener(input, esc.toneLevel);
      notes.push(...damp.notes);

      const finalTone = damp.toneLevelAfterDampen;
      const toneTag = toneTagFromLevel(finalTone);

      const style = mapSignalsToStyle(finalTone, input.signals);

      const plan: ResponsePlan = {
        intent: input.nlu.intent || "unknown",
        toneLevel: finalTone,
        toneTag,
        shouldUsePassiveAggressiveLine: damp.allowPassiveAggressive && finalTone >= 2,
        deliveryStyle: style,
        reasoning: notes,
      };

      const filtered = applyPersonaFilter(plan);
      const finalPlan = filtered.plan;
      finalPlan.reasoning = [...finalPlan.reasoning, ...filtered.notes];

      const line = quotePack.getLine(finalPlan.toneTag, { intent: finalPlan.intent });

      return { plan: finalPlan, suggestedLine: line };
    }
  };
}
