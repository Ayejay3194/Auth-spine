import { ResidualRow, ResidualSchema } from "./schema.js";

export function assertResidualRow(x: any): asserts x is ResidualRow {
  for (const k of ResidualSchema.required) {
    if (!(k in x)) throw new Error(`Missing field: ${k}`);
  }
  if (typeof x.ts !== "string") throw new Error("ts must be string");
  if (typeof x.body !== "string") throw new Error("body must be string");
  for (const k of ["dx_arcsec", "dy_arcsec"] as const) {
    if (typeof x[k] !== "number" || !Number.isFinite(x[k])) {
      throw new Error(`${k} must be finite number`);
    }
  }
  if (typeof x.model_version !== "number" || !Number.isFinite(x.model_version)) {
    throw new Error("model_version must be number");
  }
}
