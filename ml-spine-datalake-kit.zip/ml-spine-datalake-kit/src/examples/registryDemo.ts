import { registerDataset, registerFeatureSet, registerModel, loadRegistry } from "../registry/registry.js";

async function run() {
  const cfg = { root: "./lake" };

  await registerDataset(cfg, {
    dataset: "de440_residuals",
    version: "v3",
    schemaVersion: "1",
    description: "Residual facts",
    tags: ["facts", "residuals"]
  });

  await registerFeatureSet(cfg, {
    name: "residual_features",
    version: "v1",
    schemaVersion: "1",
    sourceDataset: { dataset: "de440_residuals", version: "v3" },
    notes: "magnitude + buckets"
  });

  await registerModel(cfg, {
    name: "residual_corrector",
    version: "v7",
    datasetRef: { dataset: "de440_residuals", version: "v3" },
    featureSetRef: { name: "residual_features", version: "v1" },
    notes: "GBDT residual corrector"
  });

  console.log(JSON.stringify(await loadRegistry(cfg), null, 2));
}

run().catch((e) => { console.error(e); process.exit(1); });
