# Etsy-Level Marketplace Layer

This zip adds the **buyer-facing marketplace layer** on top of the existing assistant + store spine.

Includes:
- Public product listing API
- Product detail API
- Seller profile API
- Review model (Prisma)
- Minimal Next.js buyer UI (Marketplace + Product page)

What this gives you:
- Functional Etsy-equivalent marketplace surface
- Fully backed by existing inventory, orders, fulfillment, and audit systems
- No changes to assistant logic required

Next optional upgrades:
- Search + filters
- Reviews UI
- Checkout + Stripe Connect
