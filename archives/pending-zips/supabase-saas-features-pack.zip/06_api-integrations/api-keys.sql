create table if not exists api_keys (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  name text not null,
  key_hash text not null,
  scopes text[] not null default '{}',
  status text not null default 'ACTIVE',
  created_at timestamptz default now(),
  last_used_at timestamptz
);
create index if not exists api_keys_hash_idx on api_keys (key_hash);
