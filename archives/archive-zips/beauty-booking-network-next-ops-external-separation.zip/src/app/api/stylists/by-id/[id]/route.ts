import { prisma } from "@/lib/prisma";

export async function GET(_:Request, { params }:{ params:{ id:string } }) {
  const stylist = await prisma.stylistProfile.findUnique({
    where:{ id: params.id },
    include:{
      services:true,
      memberships:{ where:{ status:"ACTIVE" }, include:{ salon:true }, orderBy:{ effectiveFrom:"desc" }, take:1 }
    }
  });
  if(!stylist) return new Response("Not found", { status:404 });

  const membership = stylist.memberships[0] || null;
  const salon = membership?.salon || null;
  const settings: any = membership?.settings || {};
  const approvalRequired = Boolean(settings.requireApprovalForNewClients);

  let services = stylist.services.map(s => ({ ...s }));
  if (salon) {
    const overrides = await prisma.salonServiceOverride.findMany({ where:{ salonId: salon.id, serviceId: { in: stylist.services.map(s=>s.id) } } });
    const byService = new Map(overrides.map(o => [o.serviceId, o.priceCents]));
    services = services.map(s => ({ ...s, priceCentsFinal: byService.get(s.id) ?? s.basePriceCents }));
  }

  return Response.json({
    stylist: {
      id: stylist.id,
      slug: stylist.slug,
      displayName: stylist.displayName,
      services,
      membership: salon ? { salonId: salon.id, salonSlug: salon.slug, approvalRequired } : { salonId: null, salonSlug: null, approvalRequired: false }
    }
  });
}
