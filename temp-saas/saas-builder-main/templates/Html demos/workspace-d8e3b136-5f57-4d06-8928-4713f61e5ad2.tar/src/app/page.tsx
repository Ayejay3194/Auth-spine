'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Moon, Sun, Menu, X, Github, Twitter, Zap, Users, Shield, Code, Database, Globe, Lock } from 'lucide-react'
import Link from 'next/link'

export default function Home() {
  const [isDark, setIsDark] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [isDark])

  const features = [
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Lightning Fast",
      description: "Built with Next.js 15 and optimized for performance"
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Secure by Default",
      description: "Enterprise-grade security with best practices"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "User Management",
      description: "Complete authentication and authorization system"
    },
    {
      icon: <Database className="w-6 h-6" />,
      title: "Database Ready",
      description: "Prisma ORM with SQLite for rapid development"
    },
    {
      icon: <Code className="w-6 h-6" />,
      title: "TypeScript",
      description: "Full type safety and excellent developer experience"
    },
    {
      icon: <Globe className="w-6 h-6" />,
      title: "Responsive Design",
      description: "Mobile-first approach with Tailwind CSS"
    }
  ]

  const techStack = [
    { name: "Next.js 15", category: "Framework" },
    { name: "TypeScript", category: "Language" },
    { name: "Tailwind CSS", category: "Styling" },
    { name: "Prisma", category: "Database" },
    { name: "shadcn/ui", category: "Components" },
    { name: "SQLite", category: "Database" },
    { name: "Zustand", category: "State Management" },
    { name: "TanStack Query", category: "Data Fetching" }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center space-x-2">
            <div className="relative w-8 h-8">
              <img
                src="/logo.svg"
                alt="Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <span className="font-bold text-xl">FullStack Template</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
              Features
            </Link>
            <Link href="#tech-stack" className="text-muted-foreground hover:text-foreground transition-colors">
              Tech Stack
            </Link>
            <Link href="#getting-started" className="text-muted-foreground hover:text-foreground transition-colors">
              Getting Started
            </Link>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsDark(!isDark)}
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
            <Button asChild>
              <Link href="/auth/signin">Get Started</Link>
            </Button>
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsDark(!isDark)}
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t bg-background p-4">
            <div className="flex flex-col space-y-4">
              <Link href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
                Features
              </Link>
              <Link href="#tech-stack" className="text-muted-foreground hover:text-foreground transition-colors">
                Tech Stack
              </Link>
              <Link href="#getting-started" className="text-muted-foreground hover:text-foreground transition-colors">
                Getting Started
              </Link>
              <Button asChild className="w-full">
                <Link href="/auth/signin">Get Started</Link>
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <Badge variant="secondary" className="mb-4">
            🚀 Production Ready
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent">
            Full-Stack Template
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            A comprehensive Next.js 15 template with authentication, database, and all the tools you need to build production-ready applications.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/auth/signin">Get Started</Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="https://github.com" target="_blank" rel="noopener noreferrer">
                <Github className="w-4 h-4 mr-2" />
                View on GitHub
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Everything You Need</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Built with modern technologies and best practices to accelerate your development.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="relative overflow-hidden">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle>{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Tech Stack Section */}
      <section id="tech-stack" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Modern Tech Stack</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Built with the latest and greatest technologies for optimal performance and developer experience.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {techStack.map((tech, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="font-semibold">{tech.name}</div>
                  <div className="text-sm text-muted-foreground">{tech.category}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Getting Started Section */}
      <section id="getting-started" className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Quick Start Guide</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Get up and running in minutes with our simple setup process.
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <Tabs defaultValue="setup" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="setup">Setup</TabsTrigger>
                <TabsTrigger value="auth">Authentication</TabsTrigger>
                <TabsTrigger value="deploy">Deployment</TabsTrigger>
              </TabsList>
              <TabsContent value="setup" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>1. Clone and Install</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-muted p-4 rounded-lg font-mono text-sm">
                      <div>git clone https://github.com/your-repo/fullstack-template.git</div>
                      <div>cd fullstack-template</div>
                      <div>npm install</div>
                      <div>npm run db:push</div>
                      <div>npm run dev</div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="auth" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>2. Configure Authentication</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">
                      Set up your authentication providers and environment variables for secure user management.
                    </p>
                    <div className="bg-muted p-4 rounded-lg font-mono text-sm">
                      <div># .env.local</div>
                      <div>NEXTAUTH_SECRET=your-secret-key</div>
                      <div>NEXTAUTH_URL=http://localhost:3000</div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="deploy" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>3. Deploy to Production</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">
                      Deploy your application to Vercel, Netlify, or any other platform with ease.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">Vercel</Badge>
                      <Badge variant="secondary">Netlify</Badge>
                      <Badge variant="secondary">Railway</Badge>
                      <Badge variant="secondary">DigitalOcean</Badge>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="relative w-6 h-6">
                  <img
                    src="/logo.svg"
                    alt="Logo"
                    className="w-full h-full object-contain"
                  />
                </div>
                <span className="font-bold">FullStack Template</span>
              </div>
              <p className="text-muted-foreground text-sm">
                A modern full-stack template for rapid development.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#features" className="hover:text-foreground">Features</Link></li>
                <li><Link href="#tech-stack" className="hover:text-foreground">Tech Stack</Link></li>
                <li><Link href="#getting-started" className="hover:text-foreground">Documentation</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#" className="hover:text-foreground">API Reference</Link></li>
                <li><Link href="#" className="hover:text-foreground">Examples</Link></li>
                <li><Link href="#" className="hover:text-foreground">Blog</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <div className="flex space-x-4">
                <Button variant="ghost" size="icon">
                  <Github className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Twitter className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 FullStack Template. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}