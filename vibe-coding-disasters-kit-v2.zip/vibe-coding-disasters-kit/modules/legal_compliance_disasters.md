## LEGAL & COMPLIANCE DISASTERS

### Privacy Violations
- [ ] No privacy policy
- [ ] Collecting data without consent
- [ ] No GDPR compliance

# LEGAL & COMPLIANCE DISASTERS (CONTINUED)

## Privacy Violations (Continued)

- [ ] No cookie consent banner
- [ ] Tracking users without permission
- [ ] Sharing user data without consent
- [ ] No data processing agreements
- [ ] Not honoring “Do Not Track”
- [ ] No way to delete account
- [ ] No way to export user data
- [ ] Not deleting data after retention period
- [ ] Keeping data longer than needed
- [ ] No data anonymization
- [ ] PII in logs
- [ ] PII in URLs
- [ ] PII in analytics
- [ ] Sending PII to third parties
- [ ] No data breach notification plan
- [ ] Not reporting breaches within required time
- [ ] No Data Protection Officer (when required)
- [ ] Children’s data without parental consent (COPPA)
- [ ] No age verification
- [ ] Violating CCPA/CPRA requirements
- [ ] No opt-out mechanism for data sale
- [ ] Not respecting user data rights
- [ ] No record of processing activities (ROPA)

## Terms of Service Issues

- [ ] No terms of service
- [ ] Copied ToS from another site
- [ ] ToS not enforceable
- [ ] No acceptance mechanism
- [ ] Changes to ToS without notification
- [ ] Unclear liability limitations
- [ ] No dispute resolution clause
- [ ] Wrong jurisdiction specified
- [ ] Contradictory terms
- [ ] Unreasonable terms
- [ ] No intellectual property rights defined
- [ ] No user content ownership clarity
- [ ] No prohibited use policy
- [ ] No acceptable use policy
- [ ] No service termination terms

## Compliance Violations

- [ ] Not PCI DSS compliant (if handling cards)
- [ ] Storing credit card data improperly
- [ ] Not HIPAA compliant (if healthcare)
- [ ] PHI not properly encrypted
- [ ] Not SOC 2 compliant (when promised)
- [ ] No audit logs for compliance
- [ ] Not meeting contractual SLAs
- [ ] Violating industry regulations
- [ ] No compliance documentation
- [ ] No security policies
- [ ] No incident response plan (when required)
- [ ] Not meeting data residency requirements
- [ ] Using non-compliant subprocessors
- [ ] No vendor management program
- [ ] No business associate agreements (BAA)
- [ ] Accessibility violations (ADA, Section 508)

## Licensing Issues

- [ ] Using GPL code in proprietary software
- [ ] Not including required license notices
- [ ] Violating open source licenses
- [ ] Using pirated software
- [ ] No software license tracking
- [ ] Using libraries beyond license terms
- [ ] Not attributing third-party code
- [ ] Closed-source code using copy-left licenses
- [ ] No license file in repository
- [ ] Conflicting licenses in dependencies
- [ ] Using commercial fonts without license
- [ ] Using stock photos without license
- [ ] Copyright violations in content
