import json
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MultiLabelBinarizer
import joblib
from pathlib import Path
from .versioning import model_path

@dataclass
class TrainResult:
    labels: List[str]
    stats: Dict[str, Any]

def _extract_labels(examples: List[Dict[str, Any]]) -> List[List[str]]:
    labs = []
    for ex in examples:
        intents = ex.get("intents") or []
        labs.append([i.get("name") for i in intents if i.get("name")])
    return labs

def train_intents(model_id: str, examples: List[Dict[str, Any]]) -> TrainResult:
    texts = [ex.get("text","") for ex in examples]
    y = _extract_labels(examples)

    mlb = MultiLabelBinarizer()
    Y = mlb.fit_transform(y)

    clf = OneVsRestClassifier(LinearSVC())
    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1,2), min_df=1, max_df=0.95)),
        ("clf", clf)
    ])
    pipe.fit(texts, Y)

    mp = model_path(model_id)
    mp.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipe, mp / "intent_model.joblib")
    joblib.dump(mlb, mp / "intent_labels.joblib")

    # stats (simple)
    counts = {lab:0 for lab in mlb.classes_.tolist()}
    for row in y:
        for lab in row:
            counts[lab] = counts.get(lab,0)+1

    return TrainResult(labels=mlb.classes_.tolist(), stats={"intent_counts": counts, "n_examples": len(examples)})

def load_intent(model_id: str):
    mp = model_path(model_id)
    pipe = joblib.load(mp / "intent_model.joblib")
    mlb = joblib.load(mp / "intent_labels.joblib")
    return pipe, mlb

def predict_intents(model_id: str, text: str, top_k: int = 3) -> List[Dict[str, Any]]:
    pipe, mlb = load_intent(model_id)
    # LinearSVC doesn't provide probabilities. We'll approximate via decision function.
    scores = pipe.decision_function([text])[0]
    # scores is array of shape (n_labels,)
    pairs = list(zip(mlb.classes_.tolist(), scores))
    pairs.sort(key=lambda x: x[1], reverse=True)
    top = pairs[:max(1, top_k)]
    # convert to 0..1-ish confidence via sigmoid-ish squashing
    def squash(s: float) -> float:
        import math
        return 1.0 / (1.0 + math.exp(-s/2.5))
    return [{"name": n, "confidence": float(squash(float(sc)))} for n, sc in top if sc is not None]
