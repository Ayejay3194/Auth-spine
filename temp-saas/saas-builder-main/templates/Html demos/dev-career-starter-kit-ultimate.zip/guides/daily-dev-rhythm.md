# Daily Dev Rhythm

1. Plan 3 outcomes.
2. Implement ONE end-to-end feature slice.
3. Clean up errors + add TODOs.
4. Log what you did; turn notes into tickets.
5. Once a week: review progress, pick next concept to deepen.
