import { parseDateTime, ParsedDateTime } from "./datetime.js";

export type EntityType = "email" | "username" | "plan" | "service" | "bookingId" | "datetime" | "duration" | "contactMethod";

export interface Entity {
  type: EntityType;
  value: string;
  start: number;
  end: number;
  confidence: number;
  meta?: Record<string, unknown>;
}

export interface EntityExtractor {
  extract(text: string, now: Date): Entity[];
}

export class DefaultEntityExtractor implements EntityExtractor {
  extract(text: string, now: Date): Entity[] {
    const out: Entity[] = [];

    const emailRe = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
    for (const m of text.matchAll(emailRe)) out.push({ type: "email", value: m[0], start: m.index ?? 0, end: (m.index ?? 0)+m[0].length, confidence: 0.95 });

    const atName = /@([a-z0-9_]{2,32})/gi;
    for (const m of text.matchAll(atName)) out.push({ type: "username", value: m[1], start: (m.index ?? 0)+1, end: (m.index ?? 0)+1+m[1].length, confidence: 0.55 });

    const planRe = /\b(free|paid|pro|starter|enterprise)\b/gi;
    for (const m of text.matchAll(planRe)) out.push({ type: "plan", value: m[0].toLowerCase(), start: m.index ?? 0, end: (m.index ?? 0)+m[0].length, confidence: 0.6 });

    const serviceRe = /\b(tarot|astrology|reading|consult|coaching)\b/gi;
    for (const m of text.matchAll(serviceRe)) out.push({ type: "service", value: m[0].toLowerCase(), start: m.index ?? 0, end: (m.index ?? 0)+m[0].length, confidence: 0.5 });

    const bookingRe = /\b(bk_[a-z0-9]{6,})\b/gi;
    for (const m of text.matchAll(bookingRe)) out.push({ type: "bookingId", value: m[0], start: m.index ?? 0, end: (m.index ?? 0)+m[0].length, confidence: 0.9 });

    const durRe = /\b(15|30|45|60|90)\s*(min|mins|minutes)\b/gi;
    for (const m of text.matchAll(durRe)) out.push({ type: "duration", value: String(m[1]), start: m.index ?? 0, end: (m.index ?? 0)+m[0].length, confidence: 0.7, meta: { minutes: Number(m[1]) } });

    const cmRe = /\b(video|phone|chat)\b/gi;
    for (const m of text.matchAll(cmRe)) out.push({ type: "contactMethod", value: m[0].toLowerCase(), start: m.index ?? 0, end: (m.index ?? 0)+m[0].length, confidence: 0.6 });

    const dt: ParsedDateTime = parseDateTime(text, now);
    if (dt.dateISO || dt.time24 || dt.partOfDay || dt.range) {
      out.push({ type: "datetime", value: "datetime", start: 0, end: 0, confidence: 0.5, meta: dt as any });
    }

    return out;
  }
}
