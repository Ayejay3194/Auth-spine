'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function RegisterPage() {
  const router = useRouter()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setErr(null)
    setLoading(true)
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    })
    setLoading(false)
    if (!res.ok) {
      const j = await res.json().catch(() => ({}))
      setErr(j?.error?.message || 'Register failed')
      return
    }
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-6 space-y-4">
        <h1 className="text-2xl font-bold">Register</h1>
        {err ? <div className="text-sm text-red-700 bg-red-50 border border-red-200 rounded p-2">{err}</div> : null}
        <form onSubmit={onSubmit} className="space-y-3">
          <input className="w-full border rounded-lg p-3" placeholder="Name (optional)" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="w-full border rounded-lg p-3" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="w-full border rounded-lg p-3" placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button className="w-full bg-slate-900 text-white rounded-lg p-3 font-semibold disabled:opacity-60" disabled={loading}>
            {loading ? '...' : 'Create account'}
          </button>
        </form>
        <div className="text-sm text-slate-600">
          Already have an account? <a className="underline" href="/login">Login</a>
        </div>
      </div>
    </div>
  )
}
