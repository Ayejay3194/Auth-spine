import { WorkingState } from "../types";

export function newWorkingState(conversationId: string): WorkingState {
  return { conversationId, turn: 0, assumptions: [], constraints: [] };
}

export function bumpTurn(s: WorkingState): WorkingState {
  return { ...s, turn: s.turn + 1 };
}
