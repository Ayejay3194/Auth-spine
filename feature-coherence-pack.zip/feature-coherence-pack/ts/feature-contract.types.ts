/**
 * Feature Coherence Pack
 * Drop this into your repo (e.g., /packages/feature-coherence)
 * and wire it into build-time checks or runtime diagnostics.
 */

export type EventType =
  | "created"
  | "updated"
  | "deleted"
  | "synced"
  | "failed"
  | "user_action"
  | "system_action";

export type EntryPointType =
  | "user_action"
  | "scheduled_job"
  | "external_event"
  | "agent_tool";

export type StateLayer =
  | "ui_local"
  | "redux_global"
  | "server_db"
  | "cache_memory"
  | "indexdb";

export interface FeatureEvent {
  name: string; // e.g. "tasks.task.created"
  type: EventType;
  payload_schema: string; // path to JSON schema
  description?: string;
}

export interface EventListener {
  event_name: string;
  handler: string;
  conditions?: string;
  effects?: string[];
}

export interface FeatureContract {
  id: string;
  name: string;
  version: string;
  status?: "proposed" | "building" | "beta" | "shipping" | "deprecated";
  primary_user_job: string;

  entry_points: Array<{
    type: EntryPointType;
    name: string;
    route_or_surface?: string;
    trigger?: string;
  }>;

  input_sources: Array<{
    name: string;
    type: "api" | "db" | "cache" | "indexdb" | "device" | "third_party" | "user_input";
    entities?: string[];
    schema_ref?: string;
  }>;

  output_artifacts: Array<{
    name: string;
    type:
      | "api_mutation"
      | "db_write"
      | "cache_write"
      | "indexdb_write"
      | "ui_state"
      | "notification"
      | "analytics_event";
    entities?: string[];
    schema_ref?: string;
  }>;

  state_touches: Array<{
    layer: StateLayer;
    keys?: string[];
    owned_by: string;
  }>;

  events: {
    emits: FeatureEvent[];
    listens: EventListener[];
  };

  dependencies: {
    upstream: string[];
    downstream: string[];
  };

  primitives_used?: string[];

  lifecycle: {
    states: Array<"inactive" | "loading" | "active" | "degraded" | "failed">;
    default_state: "inactive" | "loading" | "active" | "degraded" | "failed";
  };

  flags: {
    feature_flag: string;
    kill_switch: boolean;
    rollout?: { strategy: "off" | "internal" | "beta" | "gradual" | "on"; percent?: number };
  };

  failure_modes: Array<{
    mode: string;
    user_message: string;
    recovery: string;
    telemetry?: string[];
  }>;

  owner: { system: string; team_or_person: string };
}
