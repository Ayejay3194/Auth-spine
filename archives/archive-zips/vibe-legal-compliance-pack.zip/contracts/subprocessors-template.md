# Subprocessors List (Template)

| Vendor | Purpose | Data | Region | DPA link |
|---|---|---|---|---|
| {{PAYMENT_PROCESSOR}} | payments | payment tokens, billing metadata | {{REGION}} | {{LINK}} |
| {{EMAIL_PROVIDER}} | transactional email | email, message templates | {{REGION}} | {{LINK}} |
| {{HOSTING_PROVIDER}} | hosting | app + database | {{REGION}} | {{LINK}} |
| {{ANALYTICS_PROVIDER}} | product analytics (optional) | event IDs (no PII) | {{REGION}} | {{LINK}} |

Update date: {{DATE}}
Notification policy: we provide notice {{NOTICE_WINDOW}} before adding materially different subprocessors.
