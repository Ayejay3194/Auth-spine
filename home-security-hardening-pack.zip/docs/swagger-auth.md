# Swagger / OpenAPI hardening
Swagger is useful for you, and also for every person probing your system.

## Recommended
- Only expose `/swagger` + `/api/openapi.json` in **dev/staging**
- In production: expose behind auth (admin role) OR a separate internal host.

## Simple production rule
- `ALLOW_PUBLIC_SWAGGER=false`
- `ALLOW_PUBLIC_OPENAPI=false`
- Middleware returns 404 in production for these routes.

## If you *must* expose in prod (not recommended)
- Put behind auth:
  - Require admin session/cookie
  - Or require a token header (rotate it)
- Add IP allowlist if possible.
