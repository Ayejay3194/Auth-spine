export type UserId = string;
export type Role = "user" | "admin" | "system";

export interface AgentContext {
  userId: UserId;
  role: Role;
  locale?: string;      // e.g., "en-US"
  timezone?: string;    // e.g., "America/New_York"
  ip?: string;
  userAgent?: string;
  channel?: "web" | "mobile" | "cli";
}

export interface AgentReply {
  text: string;
  done?: boolean;
  ui?: { type: "form" | "choices" | "link" | "calendar"; data: unknown };
}

export interface AuditEvent {
  at: Date;
  userId: UserId;
  role: Role;
  type:
    | "intent.detected"
    | "entity.extracted"
    | "slot.asked"
    | "slot.filled"
    | "policy.blocked"
    | "tool.called"
    | "tool.result"
    | "tool.error"
    | "flow.completed"
    | "flow.failed";
  details: Record<string, unknown>;
}

export interface AuditLogger { write(ev: AuditEvent): Promise<void>; }
export interface Clock { now(): Date; }

export interface Span {
  name: string;
  start: number;
  end?: number;
  meta?: Record<string, unknown>;
  error?: string;
}
export interface Tracer {
  start(name: string, meta?: Record<string, unknown>): Span;
  end(span: Span, meta?: Record<string, unknown>): void;
}
