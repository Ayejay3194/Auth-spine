export const SENSITIVE_KEYS = new Set([
  "ssn","taxId","dob","dateOfBirth","address","phone",
  "salary","salaryCents","payRateCents",
  "bankAccount","routingNumber","accountNumber",
  "notes","internalNotes","audit","auditLog",
  "password","hash","token","apiKey"
]);

export function stripSensitiveKeys(obj: any): any {
  if (!obj || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(stripSensitiveKeys);

  const out: any = {};
  for (const [k,v] of Object.entries(obj)) {
    if (SENSITIVE_KEYS.has(k)) continue;
    out[k] = stripSensitiveKeys(v);
  }
  return out;
}
