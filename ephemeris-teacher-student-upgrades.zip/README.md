# Teacher–Student + Residual Atlas + Golden Tests (TypeScript)

This repo is an **upgrade pack** for a math-first ephemeris engine:

## What you get
- **Teacher–Student training loop**
  - Teacher: slower/high-precision truth provider (JPL/DE, Swiss, or your slow mode)
  - Student: your fast TypeScript ephemeris core + optional residual corrector
- **Residual atlas sweep**
  - Outputs CSV + JSON summaries (p50/p95/p99/max) by body and time ranges
- **Golden test harness**
  - Generate locked test vectors and validate regressions deterministically
- **Hard safety rails**
  - Residual caps per body
  - Confidence/anomaly gating
  - Drift logging + audit fields

## Plug in your engine
Replace the placeholder implementations in:
- `src/ephemeris/student/studentCore.ts`
- `src/ephemeris/teacher/teacherSource.ts`

Keep the interfaces. Everything else will work.

## Run
```bash
npm i
npm run build
npm run demo:teacher-student
npm run sweep:residuals
npm run gen:golden
npm run test:golden
```

## Output
- `out/residuals/*.csv`
- `out/residuals/summary.json`
- `out/golden/*.json`
