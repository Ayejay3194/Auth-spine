import { ChartDataV1 } from "../contract/schema.js";

export function validateChartDataV1(payload: unknown) {
  const parsed = ChartDataV1.safeParse(payload);
  if (!parsed.success) {
    const issues = parsed.error.issues.map(i => `${i.path.join(".")}: ${i.message}`).join("\n");
    throw new Error(`ChartDataV1 validation failed:\n${issues}`);
  }
  return parsed.data;
}
