import { execa } from "execa";

export async function prismaMigrate() {
  await execa("npx", ["prisma", "migrate", "deploy"], { stdio: "inherit" });
}
