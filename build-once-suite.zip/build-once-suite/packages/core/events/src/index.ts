export type EventEnvelope<T extends string = string, P = unknown> = {
  id: string;
  type: T;
  ts: string; // ISO
  actor?: { userId?: string; actorType: "user" | "admin" | "system" };
  payload: P;
  meta?: Record<string, unknown>;
};

export type EventHandler<T extends string = string> = (evt: EventEnvelope<T, any>) => Promise<void> | void;

export interface EventBus {
  publish<T extends string, P>(evt: EventEnvelope<T, P>): Promise<void>;
  subscribe<T extends string>(type: T, handler: EventHandler<T>): () => void;
}

/**
 * Simple in-process bus. Swap with Redis/NATS/Kafka later.
 */
export class InMemoryEventBus implements EventBus {
  private handlers = new Map<string, Set<EventHandler<any>>>();

  async publish<T extends string, P>(evt: EventEnvelope<T, P>): Promise<void> {
    const hs = this.handlers.get(evt.type);
    if (!hs) return;
    for (const h of hs) await h(evt);
  }

  subscribe<T extends string>(type: T, handler: EventHandler<T>): () => void {
    const set = this.handlers.get(type) ?? new Set();
    set.add(handler as any);
    this.handlers.set(type, set);
    return () => set.delete(handler as any);
  }
}

export function newEventId() {
  return cryptoRandomId();
}

export function cryptoRandomId(len = 16) {
  // Node 18+ has crypto.getRandomValues on globalThis; fallback to Math.random for demo
  const a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let out = "";
  for (let i = 0; i < len; i++) out += a[Math.floor(Math.random() * a.length)];
  return out;
}
