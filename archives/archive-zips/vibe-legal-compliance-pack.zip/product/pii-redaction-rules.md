# PII Redaction Rules (Logs + Analytics)

## Do not log
- passwords, tokens, session cookies
- full email/phone (hash or redact)
- full addresses, DOB, payment info
- message bodies (unless necessary, then encrypt + restrict)

## Safe patterns
- correlation/request IDs
- user_id (uuid) not email
- error codes not stack traces to clients
- structured logs with field allowlist

## Analytics
- no raw PII in events
- avoid unique identifiers that reconstruct identity
- consent-gated analytics where required
