// discovery entities.ts
