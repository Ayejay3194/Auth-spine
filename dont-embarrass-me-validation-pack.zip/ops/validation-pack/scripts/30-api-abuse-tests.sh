#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/out"

echo "== API abuse tests =="
node "$ROOT/scripts/api-abuse-tests.mjs" > "$OUT/api-abuse.log" || true
