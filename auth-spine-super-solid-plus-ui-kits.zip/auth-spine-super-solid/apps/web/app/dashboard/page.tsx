import Link from 'next/link'

export default async function Dashboard() {
  return (
    <div className="p-8 space-y-4">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      <p className="text-slate-700">If you can see this, middleware auth is working.</p>
      <div className="flex gap-3">
        <Link className="underline" href="/admin">Admin</Link>
        <Link className="underline" href="/ui-toolkit">UI Toolkit</Link>
        <Link className="underline" href="/html-to-ts">HTML→TS Kit</Link>
        <form action="/api/auth/logout" method="post">
          <button className="underline" type="submit">Logout</button>
        </form>
      </div>
    </div>
  )
}
