export default async function ProductPage({ params }: { params: { id: string } }) {
  const res = await fetch(process.env.NEXT_PUBLIC_BASE_URL + `/api/marketplace/products/${params.id}`);
  const p = await res.json();

  return (
    <main>
      <h1>{p.name}</h1>
      <p>${p.price}</p>
      <p>SKU: {p.sku}</p>
    </main>
  );
}
