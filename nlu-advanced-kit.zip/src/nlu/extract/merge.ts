import type { EntitySpan } from "../types";

/**
 * Removes exact duplicates and prefers longer spans on overlaps.
 */
export function mergeEntities(entities: EntitySpan[]): EntitySpan[] {
  const uniqKey = (e: EntitySpan) => `${e.entity}|${e.start}|${e.end}|${e.value}`;
  const uniq = new Map<string, EntitySpan>();
  for (const e of entities) uniq.set(uniqKey(e), e);

  const arr = Array.from(uniq.values()).sort((a, b) => a.start - b.start || (b.end - b.start) - (a.end - a.start));

  const out: EntitySpan[] = [];
  for (const e of arr) {
    const overlaps = out.some(o => !(e.end <= o.start || e.start >= o.end));
    if (!overlaps) out.push(e);
  }
  return out.sort((a, b) => a.start - b.start);
}
