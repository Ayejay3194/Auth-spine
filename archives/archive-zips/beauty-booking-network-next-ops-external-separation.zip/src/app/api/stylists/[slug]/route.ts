import { prisma } from "@/lib/prisma";
export async function GET(_:Request, { params }:{ params:{ slug:string } }) {
  const stylist = await prisma.stylistProfile.findUnique({
    where:{ slug: params.slug },
    include:{ services:true, memberships:{ where:{ status:"ACTIVE" }, include:{ salon:true }, orderBy:{ effectiveFrom:"desc" }, take:1 } }
  });
  if(!stylist) return new Response("Not found", { status:404 });
  return Response.json({ stylist });
}
