# Persistent AI Memory Template

This is a generic template for building a **persistent memory layer** that any AI model
can use across sessions. It is framework-agnostic and can be used with different LLM tools.

The goal is to:
- Avoid "losing context" between sessions.
- Keep architecture and engine decisions stable.
- Clearly separate what lightweight/cheap models can touch vs what they must not touch.
- Give collaborators a single source of truth for the system.

## Contents

- `memory.json`  
  Core memory file. This is where you define:
  - your main engines
  - your platform / stack
  - rules for which models can do what
  - high-level architecture and module boundaries

- `prompts/load_memory_prompt.txt`  
  A reusable prompt you can paste at the start of any AI session.
  It tells the model to load and respect `memory.json` as the source of truth.

- `prompts/update_memory_prompt.txt`  
  A prompt for generating JSON "patches" or fragments when you make new decisions.
  You paste the fragments back into `memory.json` manually or via tooling.

## How to Use

1. **Customize `memory.json`**
   - Replace placeholder values with your real project details.
   - Add new engines, modules, or rules under the existing structure.
   - Commit this file into your repo.

2. **At the start of any AI session:**
   - Open `memory.json`
   - Copy its contents
   - Paste it into your AI with the contents of `prompts/load_memory_prompt.txt`
   - The model now "remembers" the project context for that session.

3. **When you make new decisions:**
   - Describe the decision to the model using `update_memory_prompt.txt`
   - The model outputs a JSON fragment.
   - Merge that fragment into `memory.json`.

4. **Share with collaborators**
   - Give them this folder.
   - Tell them: "Never start a session without loading memory.json using the load prompt."
   - This keeps everyone (and every model) aligned.

## Tips

- Treat `memory.json` like a living spec or "project brain".
- Keep it small, structured, and high-level.
- Do not dump entire APIs or code into it.
- Use it to record decisions, invariants, and rules that should not silently change.

You can rename files, keys, and structures to match your own ecosystem,
but this template gives you a solid starting point.
