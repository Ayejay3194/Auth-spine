// inventory flows.ts
