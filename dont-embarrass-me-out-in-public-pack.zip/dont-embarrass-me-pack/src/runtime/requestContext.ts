import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import type { RequestContext } from "./types";
import { safeJsonParse } from "../utils/safeJson";

declare global {
  namespace Express {
    interface Request {
      ctx: RequestContext;
    }
  }
}

function randId(prefix: string) {
  return `${prefix}_${crypto.randomBytes(8).toString("hex")}`;
}

export function withRequestContext() {
  return (req: Request, _res: Response, next: NextFunction) => {
    const requestId = req.header("x-request-id") || randId("req");
    const tenantId = req.header("x-tenant-id") || "public";
    const actorHeader = req.header("x-actor") || "";
    const parsed = safeJsonParse(actorHeader);
    const actor = parsed.ok
      ? { userId: String((parsed.data as any)?.userId || "anonymous"), role: ((parsed.data as any)?.role || "readonly") }
      : { userId: "anonymous", role: "readonly" as const };

    req.ctx = {
      requestId,
      tenantId,
      actor,
      nowISO: new Date().toISOString(),
      ip: req.ip,
      userAgent: req.header("user-agent") || undefined,
      traceId: req.header("traceparent") || undefined
    };

    next();
  };
}
