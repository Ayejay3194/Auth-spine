import { AgentContext, AgentReply, AuditLogger, Clock } from "../core/types.js";
import { Entity } from "../nlu/entities.js";
import { IntentId } from "../nlu/intents.js";
import { ToolRegistry } from "../tools/types.js";

export type SlotValue = string;

export interface FlowStep {
  ask?: { slot: string; prompt: string; hint?: string };
  call?: { toolId: any; inputFromSlots: (slots: Record<string, SlotValue>) => any };
  done?: { message: string };
}

export interface FlowDefinition {
  intent: IntentId;
  slots: Array<{ name: string; required: boolean; fromEntity?: (entities: Entity[]) => string | null }>;
  steps: (slots: Record<string, SlotValue>) => FlowStep[];
}

export interface FlowRuntimeDeps { tools: ToolRegistry; audit: AuditLogger; clock: Clock; }

export interface FlowState { intent: IntentId; stepIndex: number; slots: Record<string, SlotValue>; completed: boolean; }

export interface FlowEngine {
  start(ctx: AgentContext, intent: IntentId, entities: Entity[]): Promise<{ state: FlowState; reply: AgentReply }>;
  continue(ctx: AgentContext, state: FlowState, userText: string, entities: Entity[]): Promise<{ state: FlowState; reply: AgentReply }>;
}
