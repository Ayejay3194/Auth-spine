// loyalty tools.ts
