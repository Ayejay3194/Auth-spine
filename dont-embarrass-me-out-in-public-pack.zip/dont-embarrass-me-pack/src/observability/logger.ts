import crypto from "crypto";

type Level = "debug" | "info" | "warn" | "error";

const levels: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };
const LOG_LEVEL = (process.env.LOG_LEVEL as Level) || "info";

const redactFields = new Set(
  (process.env.REDACT_FIELDS || "password,token,authorization,apiKey,secret")
    .split(",")
    .map(s => s.trim().toLowerCase())
    .filter(Boolean)
);

function redact(obj: any): any {
  if (obj == null) return obj;
  if (Array.isArray(obj)) return obj.map(redact);
  if (typeof obj !== "object") return obj;

  const out: any = {};
  for (const [k, v] of Object.entries(obj)) {
    if (redactFields.has(k.toLowerCase())) {
      out[k] = "***REDACTED***";
    } else if (typeof v === "string" && looksSensitive(v)) {
      out[k] = "***REDACTED***";
    } else {
      out[k] = redact(v);
    }
  }
  return out;
}

function looksSensitive(v: string): boolean {
  // lightweight heuristics: emails, long tokens, bearer, etc.
  if (/bearer\s+[a-z0-9\-\._~\+\/]+=*/i.test(v)) return true;
  if (/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(v)) return true;
  if (v.length > 80 && /[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+/.test(v)) return true; // jwt-ish
  return false;
}

function write(level: Level, msg: string, meta?: any) {
  if (levels[level] < levels[LOG_LEVEL]) return;
  const payload = {
    ts: new Date().toISOString(),
    level,
    msg,
    meta: meta ? redact(meta) : undefined
  };
  // JSON logs so your log platform can actually search them.
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(payload));
}

export const logger = {
  debug: (m: string, meta?: any) => write("debug", m, meta),
  info: (m: string, meta?: any) => write("info", m, meta),
  warn: (m: string, meta?: any) => write("warn", m, meta),
  error: (m: string, meta?: any) => write("error", m, meta),
};

export function stableHash(input: string): string {
  return crypto.createHash("sha256").update(input).digest("hex");
}
