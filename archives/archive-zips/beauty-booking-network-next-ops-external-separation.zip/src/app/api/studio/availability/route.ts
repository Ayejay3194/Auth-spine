import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { z } from "zod";

const Create = z.object({
  dow: z.number().int().min(0).max(6),
  startMin: z.number().int().min(0).max(1439),
  endMin: z.number().int().min(1).max(1440),
});

async function getStylistId(){
  const session = await auth();
  if(!session?.user?.email) return null;
  const user = await prisma.user.findUnique({ where:{ email: session.user.email }, include:{ stylistProfile:true } });
  return user?.stylistProfile?.id ?? null;
}

export async function GET(){
  const stylistId = await getStylistId();
  if(!stylistId) return new Response("Unauthorized", { status:401 });
  const rules = await prisma.availabilityRule.findMany({
    where:{ ownerType:"STYLIST", stylistId },
    orderBy:[{ dow:"asc" }, { startMin:"asc" }]
  });
  return Response.json({ rules });
}

export async function POST(req: Request){
  const stylistId = await getStylistId();
  if(!stylistId) return new Response("Unauthorized", { status:401 });
  const data = Create.parse(await req.json());
  const rule = await prisma.availabilityRule.create({ data: { ownerType:"STYLIST", stylistId, dow:data.dow, startMin:data.startMin, endMin:data.endMin } });
  return Response.json({ rule });
}
