from app.training_store import read_training
from app.model import train_intent_model, save_model
from app.config import MODEL_PATH

def main():
    examples = read_training()
    if len(examples) < 3:
        raise SystemExit("Need at least 3 examples in data/training.jsonl to train.")
    model = train_intent_model(examples)
    save_model(model, MODEL_PATH)
    print(f"Saved model to {MODEL_PATH} using {len(examples)} examples.")

if __name__ == "__main__":
    main()
