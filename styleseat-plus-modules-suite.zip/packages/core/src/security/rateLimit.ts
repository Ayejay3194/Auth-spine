import type { ID, Result } from "../shared/types.js";

export type RatePolicy = { windowSeconds: number; max: number };

export interface RateStore { incr(key: string, windowSeconds: number): Promise<number>; }

export class InMemoryRateStore implements RateStore {
  private m = new Map<string, { count: number; resetAt: number }>();
  async incr(key: string, windowSeconds: number): Promise<number> {
    const now = Date.now();
    const cur = this.m.get(key);
    if (!cur || cur.resetAt <= now) { this.m.set(key, { count: 1, resetAt: now + windowSeconds*1000 }); return 1; }
    cur.count += 1; return cur.count;
  }
}

export class RateLimiter {
  constructor(private store: RateStore, private policy: RatePolicy) {}
  async check(userId: ID, bucket: string): Promise<Result<true>> {
    const n = await this.store.incr(`rl:${bucket}:${userId}`, this.policy.windowSeconds);
    return n > this.policy.max ? { ok: false, error: { code: "RATE_LIMIT", message: "Too many requests" } } : { ok: true, data: true };
  }
}
