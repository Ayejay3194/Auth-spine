-- Minimal app schema (profiles/salons/memberships/bookings)
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid references auth.users on delete cascade primary key,
  role text not null check (role in ('CLIENT','STYLIST','RECEPTION','MANAGER','OWNER','ADMIN','SUPPORT')),
  created_at timestamptz default now()
);

create table if not exists salons (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null
);

create table if not exists salon_memberships (
  id uuid primary key default gen_random_uuid(),
  salon_id uuid references salons(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  role text not null,
  settings jsonb default '{}'::jsonb
);

create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  stylist_id uuid references profiles(id),
  salon_id uuid references salons(id),
  client_id uuid references profiles(id),
  status text default 'PENDING',
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz default now()
);
