SOC 2 TYPE II CROSSWALK

Maps controls to:
- CC1 Governance
- CC2 Communication
- CC3 Risk Assessment
- CC4 Monitoring
- CC5 Control Activities
- CC6 Logical & Physical Access
- CC7 System Operations
- CC8 Change Management
- CC9 Risk Mitigation

Use as evidence index during audits.