
# Risk Acceptance

Control:
Severity:
Reason:
Owner:
Mitigations:
Expires:
Approved by:
