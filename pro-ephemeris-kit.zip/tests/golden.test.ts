import { describe, it } from "vitest";
import { execSync } from "node:child_process";

describe("golden fixtures", () => {
  it("match expected", () => {
    execSync("npm run -s golden:verify", { stdio: "inherit" });
  });
});
