export type Severity = "P0" | "P1" | "P2" | "INFO";

export type Evidence = {
  message: string;
  file?: string;
  line?: number;
  hint?: string;
  meta?: Record<string, unknown>;
};

export type Finding = {
  id: string;
  title: string;
  severity: Severity;
  category: string;
  evidence: Evidence[];
};

export type CheckContext = {
  root: string;
  profilePath: string;
  profile: any;
  allowlist: any;
  nowISO: string;
};

export type Check = {
  id: string;
  title: string;
  category: string;
  run: (ctx: CheckContext) => Promise<Finding[]>;
};
