
/**
 * Central health checks for "am I lying quietly?"
 * Keep these small, deterministic, and runnable in CI.
 */
export type HealthCheck = {
  name: string;
  run: () => Promise<{ ok: boolean; details?: string }>;
};

export async function runHealthChecks(checks: HealthCheck[]) {
  const results = [];
  for (const c of checks) {
    try {
      const r = await c.run();
      results.push({ name: c.name, ...r });
    } catch (e: any) {
      results.push({ name: c.name, ok: false, details: String(e?.message ?? e) });
    }
  }
  const ok = results.every(r => r.ok);
  return { ok, results };
}
