// If you later use prompts/templates for an LLM-backed NLU, keep them here.
// For now it's intentionally empty.
export const PROMPTS = {};
