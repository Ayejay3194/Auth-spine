SERVICE COMPLETION VERIFICATION
===============================

Payment release requires:
- Service marked completed
- No active dispute
- Verification window elapsed (optional)

Auto-hold if:
- booking modified after completion
- abnormal duration detected
- client dispute opened
