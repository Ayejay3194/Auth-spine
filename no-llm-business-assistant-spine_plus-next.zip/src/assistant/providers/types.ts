export type Slot = { slotId: string; startISO: string; durationMin: number };
export type Booking = { bookingId: string; slotId: string; service: string; status: string };
export type Client = { clientId: string; name: string; email?: string; phone?: string; tags: string[]; notes: string[] };
export type Invoice = { invoiceId: string; clientId: string; amount: number; status: string };
export type Promo = { code: string; percentOff: number; active: boolean };
export type Referral = { code: string; referrerClientId: string; uses: number };
export type KPI = { key: string; value: number; unit?: string };
export type Task = { taskId: string; title: string; status: string };

export interface BookingProvider {
  findSlots(input: { dateISO?: string; durationMin: number; service?: string; userId: string }): Promise<Slot[]>;
  createBooking(input: { userId: string; slotId: string; service: string }): Promise<Booking>;
  cancelBooking(input: { bookingId: string }): Promise<Booking>;
  listBookings(input: { userId: string }): Promise<Booking[]>;
}

export interface CRMProvider {
  findClient(input: { query: string }): Promise<Client | null>;
  addNote(input: { clientId: string; note: string }): Promise<void>;
  tagClient(input: { clientId: string; tag: string }): Promise<void>;
  history(input: { clientId: string }): Promise<{ bookings: Booking[]; invoices: Invoice[] }>;
}

export interface PaymentsProvider {
  createInvoice(input: { clientId: string; amount: number }): Promise<Invoice>;
  refund(input: { invoiceId: string; amount?: number }): Promise<Invoice>;
  applyCredit(input: { clientId: string; amount: number }): Promise<void>;
}

export interface MarketingProvider {
  createPromo(input: { code: string; percentOff: number; expiresISO?: string }): Promise<Promo>;
  endPromo(input: { code: string }): Promise<Promo>;
  referralStatus(input: { code: string }): Promise<Referral | null>;
  sendCampaign(input: { segment: string; message: string }): Promise<{ sent: number }>;
}

export interface AnalyticsProvider {
  kpis(input: { businessId: string; userId: string }): Promise<KPI[]>;
  exportReport(input: { report: string; format: "csv" | "json" }): Promise<{ url: string }>;
}

export interface OpsProvider {
  createTask(input: { title: string }): Promise<Task>;
  listTasks(input: {}): Promise<Task[]>;
  markDone(input: { taskId: string }): Promise<Task>;
  startChecklist(input: { name: "open" | "close" }): Promise<{ steps: string[] }>;
}

export interface AdminProvider {
  showAudit(input: { limit: number }): Promise<{ at: string; type: string; details: any }[]>;
  manageRole(input: { targetUserId: string; role: string }): Promise<{ ok: boolean }>;
  gdprExport(input: { userId: string }): Promise<{ url: string }>;
}
