ACCOUNTANT PACKET EXPORT
=======================

Export bundle should include:
- Chart of accounts
- General ledger
- Trial balance
- P&L for selected period
- Balance sheet for selected period
- AR aging
- AP aging
- Payroll summary (if applicable)
- Bank reconciliation report

Formats:
- CSV + PDF
