import type { NLUModel } from "../types";
import { analyzeTurn } from "../engine/analyzeTurn";
import { computeMetrics, EvalRow } from "./metrics";

export async function runEval(model: NLUModel, dataset: EvalRow[]): Promise<{ metrics: ReturnType<typeof computeMetrics> }> {
  const preds: { intent: string }[] = [];
  for (const row of dataset) {
    const out = await analyzeTurn({ text: row.text, sessionId: "eval", model });
    preds.push({ intent: out.nlu.intent.name });
  }
  return { metrics: computeMetrics(dataset, preds) };
}
