# Breach Notification Templates

## Customer notification (email)
Subject: Security incident notice regarding {{PRODUCT_NAME}}

Hello {{NAME}},
We are notifying you of a security incident that may have affected your account data.

- Incident window: {{START}} to {{END}}
- What happened: {{SUMMARY}}
- Data involved: {{DATA_TYPES}}
- What we did: {{ACTIONS_TAKEN}}
- What you should do: {{CUSTOMER_ACTIONS}}
- Support: {{SUPPORT_CONTACT}}

We will provide updates at: {{STATUS_URL}}

## Regulator notification (outline)
- Controller/processor contact details
- nature of breach
- categories + approximate number of data subjects
- likely consequences
- measures taken/proposed
