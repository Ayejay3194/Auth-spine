#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

if compgen -G "infra/terraform/**/*.tf" > /dev/null || compgen -G "infra/terraform/*.tf" > /dev/null; then
  log "Terraform: fmt check"
  docker_run hashicorp/terraform:1.6.6 fmt -check -recursive infra/terraform

  log "Terraform: validate"
  docker_run hashicorp/terraform:1.6.6 -chdir=infra/terraform init -backend=false
  docker_run hashicorp/terraform:1.6.6 -chdir=infra/terraform validate

  log "tfsec scan"
  docker_run aquasec/tfsec:latest infra/terraform

  log "checkov scan"
  docker_run bridgecrew/checkov:latest -d infra/terraform
else
  log "No Terraform found under infra/terraform/. Skipping."
fi

if compgen -G "infra/k8s/**/*.yml" > /dev/null || compgen -G "infra/k8s/**/*.yaml" > /dev/null || compgen -G "infra/k8s/*.yml" > /dev/null || compgen -G "infra/k8s/*.yaml" > /dev/null; then
  log "Kubernetes: kubeconform schema validation"
  docker_run ghcr.io/yannh/kubeconform:latest -strict -summary -ignore-missing-schemas -kubernetes-version 1.29.0     -schema-location default     -schema-location 'https://raw.githubusercontent.com/yannh/kubernetes-json-schema/master/{{.NormalizedKubernetesVersion}}-standalone-strict/{{.ResourceKind}}.json'     infra/k8s
else
  log "No Kubernetes manifests found under infra/k8s/. Skipping."
fi

if [ -f Dockerfile ]; then
  log "Trivy filesystem scan"
  docker_run aquasec/trivy:latest fs --exit-code 1 --severity HIGH,CRITICAL .
else
  log "No Dockerfile in root. Skipping Trivy fs scan."
fi
