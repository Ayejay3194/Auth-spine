import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists } from "../utils/fs.js";

export function auditArtifacts(root: string): AuditSection {
  const section: AuditSection = { id: "artifacts", title: "Build Artifacts & Static Assets", findings: [] };
  const candidates = [".next", "dist", "build", "out"];
  const present = candidates.filter((d) => exists(path.join(root, d)));

  if (present.length === 0) {
    section.findings.push({
      id: "artifacts.none",
      title: "No build output folders found",
      severity: "INFO",
      details: "Fine if you haven't built yet. In deployment this often means artifacts weren't produced or uploaded.",
      fix: "Run your build locally and confirm output exists. Ensure CI uploads/serves the right folder.",
      evidence: { checked: candidates },
    });
  }

  if (!exists(path.join(root, "public"))) {
    section.findings.push({
      id: "assets.public.missing",
      title: "No public/ folder found",
      severity: "INFO",
      details: "If you reference /logo.png style assets, you typically need public/ (framework-specific).",
      fix: "Create public/ for static assets or ensure your framework serves them another way.",
    });
  }

  return section;
}
