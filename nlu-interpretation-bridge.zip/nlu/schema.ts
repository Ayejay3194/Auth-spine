
export interface NLUResult {
  intent: string;
  confidence: number;
  entities: Record<string, any>;
  context?: Record<string, any>;
}
