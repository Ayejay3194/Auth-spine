"use client";

import { useMemo, useState } from "react";
import { z } from "zod";
import { Plus, Play, RefreshCw } from "lucide-react";
import type { ParseResult, TrainExample } from "@/lib/types";

const exampleSchema = z.object({
  text: z.string().min(1),
  intent: z.string().min(1),
  entities: z.array(z.object({ entity: z.string().min(1), value: z.string().min(1) })).default([])
});

function pill(bg: string) {
  return {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    padding: "4px 10px",
    borderRadius: 999,
    background: bg,
    fontSize: 12
  } as const;
}

export default function NLUAdminPage() {
  const [text, setText] = useState("book me for friday at 2pm");
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const [busy, setBusy] = useState(false);

  const [exText, setExText] = useState("reschedule to monday 10am");
  const [exIntent, setExIntent] = useState("booking.reschedule");
  const [entityRows, setEntityRows] = useState<Array<{ entity: string; value: string }>>([
    { entity: "datetime", value: "monday 10am" }
  ]);

  const completion = useMemo(() => {
    if (!parseResult) return null;
    return Math.round(parseResult.intent.confidence * 100);
  }, [parseResult]);

  async function runParse() {
    setBusy(true);
    try {
      const r = await fetch("/api/nlu/parse", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ text })
      });
      setParseResult(await r.json());
    } finally {
      setBusy(false);
    }
  }

  async function addExample() {
    setBusy(true);
    try {
      const payload: TrainExample = exampleSchema.parse({
        text: exText,
        intent: exIntent,
        entities: entityRows.filter(r => r.entity && r.value)
      });

      const r = await fetch("/api/nlu/examples", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload)
      });
      const body = await r.json();
      if (!r.ok) throw new Error(body?.detail ?? "Failed to add example");
      alert("Saved example to training.jsonl");
    } finally {
      setBusy(false);
    }
  }

  async function retrain() {
    setBusy(true);
    try {
      const r = await fetch("/api/nlu/train", { method: "POST" });
      const body = await r.json();
      if (!r.ok) throw new Error(body?.detail ?? "Train failed");
      alert(`Trained on ${body.examples} examples`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main style={{ minHeight: "100vh", background: "#0b1220", color: "white", padding: 24 }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gap: 16 }}>
        <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 28 }}>Wit-like NLU Admin</h1>
            <p style={{ margin: "6px 0 0", color: "#b8c1d1" }}>Intent + entities. No magical thinking required.</p>
          </div>
          <button
            onClick={retrain}
            disabled={busy}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              padding: "10px 14px",
              borderRadius: 10,
              border: "1px solid #2a3550",
              background: "#141c2f",
              color: "white",
              cursor: "pointer"
            }}
          >
            <RefreshCw size={18} />
            Retrain
          </button>
        </header>

        <section style={{ display: "grid", gridTemplateColumns: "1.2fr 0.8fr", gap: 16 }}>
          <div style={{ background: "#111a2e", border: "1px solid #24304a", borderRadius: 14, padding: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h2 style={{ margin: 0, fontSize: 16 }}>Try it</h2>
              <button
                onClick={runParse}
                disabled={busy}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "10px 14px",
                  borderRadius: 10,
                  border: "1px solid #2a3550",
                  background: "#1d2a4a",
                  color: "white",
                  cursor: "pointer"
                }}
              >
                <Play size={18} />
                Parse
              </button>
            </div>

            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={4}
              style={{
                width: "100%",
                marginTop: 12,
                borderRadius: 12,
                border: "1px solid #24304a",
                background: "#0c1427",
                color: "white",
                padding: 12,
                resize: "vertical"
              }}
            />

            {parseResult && (
              <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                  <span style={pill("#182445")}>
                    intent: <b>{parseResult.intent.name}</b>
                  </span>
                  <span style={pill("#182445")}>
                    confidence: <b>{completion}%</b>
                  </span>
                  {parseResult.entities.length > 0 && (
                    <span style={pill("#182445")}>
                      entities: <b>{parseResult.entities.length}</b>
                    </span>
                  )}
                </div>

                <div style={{ display: "grid", gap: 8 }}>
                  <h3 style={{ margin: "6px 0 0", fontSize: 14, color: "#b8c1d1" }}>Top intents</h3>
                  <div style={{ display: "grid", gap: 6 }}>
                    {parseResult.intents.map((i) => (
                      <div
                        key={i.name}
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          padding: 10,
                          borderRadius: 12,
                          border: "1px solid #24304a",
                          background: "#0c1427"
                        }}
                      >
                        <span>{i.name}</span>
                        <span style={{ color: "#b8c1d1" }}>{Math.round(i.confidence * 100)}%</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div style={{ display: "grid", gap: 8 }}>
                  <h3 style={{ margin: "6px 0 0", fontSize: 14, color: "#b8c1d1" }}>Entities</h3>
                  {parseResult.entities.length === 0 ? (
                    <div
                      style={{
                        padding: 10,
                        borderRadius: 12,
                        border: "1px solid #24304a",
                        background: "#0c1427",
                        color: "#b8c1d1"
                      }}
                    >
                      none detected
                    </div>
                  ) : (
                    <div style={{ display: "grid", gap: 6 }}>
                      {parseResult.entities.map((e, idx) => (
                        <div
                          key={idx}
                          style={{
                            padding: 10,
                            borderRadius: 12,
                            border: "1px solid #24304a",
                            background: "#0c1427"
                          }}
                        >
                          <div style={{ display: "flex", justifyContent: "space-between" }}>
                            <b>{e.entity}</b>
                            <span style={{ color: "#b8c1d1" }}>
                              {Math.round(e.confidence * 100)}% · {e.source}
                            </span>
                          </div>
                          <div style={{ marginTop: 6, color: "#d6def0" }}>{e.value}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <details style={{ marginTop: 6 }}>
                  <summary style={{ cursor: "pointer", color: "#b8c1d1" }}>Raw JSON</summary>
                  <pre
                    style={{
                      whiteSpace: "pre-wrap",
                      marginTop: 10,
                      padding: 12,
                      borderRadius: 12,
                      border: "1px solid #24304a",
                      background: "#0c1427",
                      overflowX: "auto"
                    }}
                  >
{JSON.stringify(parseResult, null, 2)}
                  </pre>
                </details>
              </div>
            )}
          </div>

          <div style={{ background: "#111a2e", border: "1px solid #24304a", borderRadius: 14, padding: 16 }}>
            <h2 style={{ margin: 0, fontSize: 16 }}>Add training example</h2>
            <p style={{ margin: "6px 0 12px", color: "#b8c1d1" }}>
              Writes to <code style={{ color: "#e0e7ff" }}>nlu-service/data/training.jsonl</code> through the API.
            </p>

            <label style={{ display: "grid", gap: 6, marginBottom: 10 }}>
              <span style={{ color: "#b8c1d1", fontSize: 12 }}>Text</span>
              <input
                value={exText}
                onChange={(e) => setExText(e.target.value)}
                style={{
                  width: "100%",
                  borderRadius: 10,
                  border: "1px solid #24304a",
                  background: "#0c1427",
                  color: "white",
                  padding: "10px 12px"
                }}
              />
            </label>

            <label style={{ display: "grid", gap: 6, marginBottom: 10 }}>
              <span style={{ color: "#b8c1d1", fontSize: 12 }}>Intent</span>
              <input
                value={exIntent}
                onChange={(e) => setExIntent(e.target.value)}
                style={{
                  width: "100%",
                  borderRadius: 10,
                  border: "1px solid #24304a",
                  background: "#0c1427",
                  color: "white",
                  padding: "10px 12px"
                }}
              />
            </label>

            <div style={{ display: "grid", gap: 8, marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: "#b8c1d1", fontSize: 12 }}>Entities (optional)</span>
                <button
                  onClick={() => setEntityRows([...entityRows, { entity: "", value: "" }])}
                  disabled={busy}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "8px 10px",
                    borderRadius: 10,
                    border: "1px solid #2a3550",
                    background: "#141c2f",
                    color: "white",
                    cursor: "pointer"
                  }}
                >
                  <Plus size={16} />
                  Add
                </button>
              </div>

              {entityRows.map((row, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 8 }}>
                  <input
                    value={row.entity}
                    onChange={(e) => {
                      const next = [...entityRows];
                      next[i] = { ...next[i], entity: e.target.value };
                      setEntityRows(next);
                    }}
                    placeholder="entity (e.g. datetime)"
                    style={{
                      borderRadius: 10,
                      border: "1px solid #24304a",
                      background: "#0c1427",
                      color: "white",
                      padding: "10px 12px"
                    }}
                  />
                  <input
                    value={row.value}
                    onChange={(e) => {
                      const next = [...entityRows];
                      next[i] = { ...next[i], value: e.target.value };
                      setEntityRows(next);
                    }}
                    placeholder="value (e.g. monday 10am)"
                    style={{
                      borderRadius: 10,
                      border: "1px solid #24304a",
                      background: "#0c1427",
                      color: "white",
                      padding: "10px 12px"
                    }}
                  />
                </div>
              ))}
            </div>

            <button
              onClick={addExample}
              disabled={busy}
              style={{
                width: "100%",
                display: "inline-flex",
                justifyContent: "center",
                alignItems: "center",
                gap: 8,
                padding: "12px 14px",
                borderRadius: 12,
                border: "1px solid #2a3550",
                background: "#1d2a4a",
                color: "white",
                cursor: "pointer"
              }}
            >
              <Plus size={18} />
              Save example
            </button>
          </div>
        </section>
      </div>
    </main>
  );
}
