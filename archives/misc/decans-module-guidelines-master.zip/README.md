HOW TO USE
==========
- Master rules live in DECANS_MODULE_GUIDELINES_MASTER.txt
- Transit sizing is authoritative in transit_guidelines.txt
- Use transit_card_template.txt for all transit outputs
- Enforce word counts using linter_transit_rules.json

This prevents:
- bloated transits
- prophecy language
- tone drift
