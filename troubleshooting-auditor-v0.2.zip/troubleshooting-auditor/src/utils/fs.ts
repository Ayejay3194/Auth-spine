import fs from "node:fs";
import path from "node:path";

export function exists(p: string) {
  try { fs.accessSync(p); return true; } catch { return false; }
}
export function readText(p: string) { return fs.readFileSync(p, "utf-8"); }
export function readJson<T = unknown>(p: string): T { return JSON.parse(readText(p)) as T; }

export function safeReadText(p: string): string | null {
  try { return readText(p); } catch { return null; }
}

export function findFirstExisting(root: string, files: string[]) {
  for (const f of files) {
    const full = path.join(root, f);
    if (exists(full)) return full;
  }
  return null;
}

export function listFiles(root: string, opts?: { max?: number; skipDirs?: string[] }) {
  const max = opts?.max ?? 8000;
  const skipDirs = new Set(opts?.skipDirs ?? ["node_modules", ".git", ".next", "dist", "build", ".turbo"]);
  const out: string[] = [];
  const stack = [root];

  while (stack.length) {
    const cur = stack.pop()!;
    let ents: fs.Dirent[];
    try { ents = fs.readdirSync(cur, { withFileTypes: true }); } catch { continue; }

    for (const e of ents) {
      const full = path.join(cur, e.name);
      if (e.isDirectory()) {
        if (skipDirs.has(e.name)) continue;
        stack.push(full);
      } else {
        out.push(full);
        if (out.length >= max) return out;
      }
    }
  }
  return out;
}
