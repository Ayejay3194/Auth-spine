import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerMarketingTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "marketing.create_promo",
    title: "Create promo code",
    description: "Creates a promo code with percent off.",
    inputSchema: { type: "object", properties: { code: { type: "string" }, percentOff: { type: "number" } }, required: ["code", "percentOff"] },
    async run(ctx, input) {
      const data = await p.marketing.createPromo({ code: input.code, percentOff: input.percentOff });
      return { ok: true, data };
    }
  });

  reg.register({
    id: "marketing.referral_status",
    title: "Referral status",
    description: "Checks referral code status.",
    inputSchema: { type: "object", properties: { code: { type: "string" } }, required: ["code"] },
    async run(ctx, input) {
      const data = await p.marketing.referralStatus({ code: input.code });
      return { ok: true, data };
    }
  });

  reg.register({
    id: "marketing.send_campaign",
    title: "Send campaign",
    description: "Queues a campaign message to a segment.",
    inputSchema: { type: "object", properties: { segment: { type: "string" }, message: { type: "string" } }, required: ["segment", "message"] },
    async run(ctx, input) {
      const data = await p.marketing.sendCampaign({ segment: input.segment, message: input.message });
      return { ok: true, data };
    }
  });
}
