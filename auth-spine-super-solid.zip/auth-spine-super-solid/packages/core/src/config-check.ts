import { validateEnv } from './config.js'

validateEnv()
console.log('✅ Env looks valid')
