#!/usr/bin/env bash
set -euo pipefail
docker compose down -v
rm -rf ./volumes/db ./volumes/storage || true
mkdir -p ./volumes/db ./volumes/storage
docker compose up -d
echo "Reset complete."
