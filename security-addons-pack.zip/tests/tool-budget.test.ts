import { describe, it, expect } from "vitest";
import { ToolBudgetManager } from "../src/security/tool-budget/middleware";

describe("Tool budget", () => {
  it("rejects too many tool calls", () => {
    const m = new ToolBudgetManager({ maxToolCalls: 2, maxTotalMs: 5000 });
    m.beforeTool("a");
    m.beforeTool("b");
    expect(() => m.beforeTool("c")).toThrow();
  });
});
