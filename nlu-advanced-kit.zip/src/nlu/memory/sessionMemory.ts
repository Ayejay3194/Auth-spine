import type { DialogueState, EntitySpan } from "../types";

/**
 * Minimal in-memory cache (server-safe).
 * If you use the browser, also persist via model/store.ts.
 */
const stateMem = new Map<string, DialogueState>();

export function getSessionState(sessionId: string): DialogueState | null {
  return stateMem.get(sessionId) ?? null;
}

export function setSessionState(state: DialogueState): void {
  stateMem.set(state.sessionId, state);
}

export function seedReferencesFromEntities(state: DialogueState, entities: EntitySpan[]): DialogueState {
  let lastLocation = state.references.lastLocation;
  let lastDate = state.references.lastDate;

  for (const e of entities) {
    if (e.entity === "location") lastLocation = String(e.normalized ?? e.value);
    if (e.entity === "date") lastDate = String(e.normalized ?? e.value);
  }

  return {
    ...state,
    lastEntities: entities,
    references: { ...state.references, lastLocation, lastDate },
  };
}
