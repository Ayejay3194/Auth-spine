import { AuditEvent, AuditLogger } from "../core/types.js";

export class ConsoleAuditLogger implements AuditLogger {
  public events: AuditEvent[] = [];
  async write(ev: AuditEvent): Promise<void> {
    this.events.push(ev);
    // eslint-disable-next-line no-console
    console.log(`[AUDIT] ${ev.at.toISOString()} ${ev.type} ${JSON.stringify(ev.details)}`);
  }
}
