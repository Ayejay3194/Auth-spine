// inventory policies.ts
