import { ChartDataV1, ChartPoint, HouseCusp } from './types.js';

const pad2 = (n: number) => String(n).padStart(2, '0');

function degToDMS(deg: number): string {
  // only used for pretty print. canonicalization is elsewhere.
  const d = Math.floor(deg);
  const minutesFull = (deg - d) * 60;
  const m = Math.floor(minutesFull);
  const s = Math.round((minutesFull - m) * 60);
  return `${d}°${pad2(m)}'${pad2(s)}"`;
}

function fmtPoint(p: ChartPoint): string {
  const r = p.retrograde ? ',R' : '';
  // leave sign/deg from engine. If you want '9°51’' style, use pos within sign.
  const lon = Number.isFinite(p.lon) ? p.lon : 0;
  return `${p.name},${p.sign},${degToDMS(p.pos)}${r}`;
}

function fmtHouse(h: HouseCusp): string {
  return `H${h.house},${h.sign},${degToDMS(h.pos)}`;
}

/**
 * Strict, boring, copy-paste-safe output format (AMTXT-1).
 * Humans can read it, machines can diff it.
 */
export function formatChartAsText(chart: ChartDataV1): string {
  const lines: string[] = [];

  lines.push(`Schema: AMJCS-1 (schemaVersion ${chart.schemaVersion})`);
  lines.push(`Engine: ${chart.engine} (${chart.engineVersion})`);
  lines.push(`Chart Type: ${chart.chartType}`);
  lines.push('');

  lines.push(`Date of Birth: ${chart.input.date} - ${chart.input.time} (${chart.input.timezone})`);
  lines.push(`Universal Time: ${chart.output.ut}`);
  lines.push(`Local Sidereal Time: ${chart.output.lst}`);
  lines.push(`House system: ${chart.settings.houseSystem}`);

  const locName = chart.input.locationName ? ` ${chart.input.locationName}` : '';
  lines.push(`Latitude, Longitude:${locName} ${chart.input.lat} , ${chart.input.lon}`);
  lines.push('');

  // Points
  for (const p of chart.output.points) lines.push(fmtPoint(p));
  lines.push('');
  // Angles
  for (const a of chart.output.angles) {
    const r = a.retrograde ? ',R' : '';
    lines.push(`${a.name},${a.sign},${degToDMS(a.pos)}${r}`);
  }
  lines.push('');

  // Houses
  for (const h of chart.output.houses) lines.push(fmtHouse(h));

  // Optional integrity
  if (chart.integrity?.hash) {
    lines.push('');
    lines.push(`Integrity: ${chart.integrity.algorithm}:${chart.integrity.hash}`);
  }

  return lines.join('\n');
}
