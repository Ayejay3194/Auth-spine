# Drift Date Booking Spine (Uber-Eats-level logistics, but for dates)

This adds two kernel spines:
- `dates` (propose/accept/decline/cancel/set-time/venue-search/reserve)
- `safety` (rules + check-in)

And extends the assistant wrapper to support:
- provider interfaces: `VenueProvider`, `DateProvider`, `ReservationProvider`, `SafetyProvider`
- tool IDs:
  - `date.create_request`, `date.accept`, `date.decline`, `date.cancel`, `date.set_time`
  - `venue.search`
  - `reservation.create`, `reservation.cancel`
  - `safety.set_rules`, `safety.checkin`

## Example commands
- `book a date dinner match_match123 for user_u2 friday 7pm $80`
- `reschedule date_date123 to saturday 8pm`
- `find a restaurant near soho`
- `reserve venue_abc for date_date123 friday 7pm`
- `safety settings match_match123 share at check in check-in timer 30 min`
- `check in date_date123`

## Integration notes
1) Add the Prisma models in `prisma/schema.drift_dates.additions.prisma` to your schema and migrate.
2) Implement provider adapters in your app:
   - `venue.searchVenues` -> your place provider or internal DB
   - `dates.*` -> your DB state machine rules
   - `reservations.*` -> your reservation API or internal holds
   - `safety.*` -> your DB + notification scheduling
3) Add the providers into `buildAssistantRuntime({ providers: ... })`.

This is deterministic and audited. No LLM required.
