# 16-health-dashboard

Green lights sanity panel.
