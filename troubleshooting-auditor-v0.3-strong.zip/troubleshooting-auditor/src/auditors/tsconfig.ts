import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readJson } from "../utils/fs.js";

type TsConfig = { compilerOptions?: Record<string, unknown>; exclude?: string[]; };

export function auditTsconfig(root: string): AuditSection {
  const section: AuditSection = { id: "tsconfig", title: "TypeScript Config", findings: [] };
  const p = path.join(root, "tsconfig.json");

  if (!exists(p)) {
    section.findings.push({ id: "tsconfig.missing", title: "tsconfig.json missing", severity: "ERROR",
      details: "TypeScript tooling/builds become inconsistent without a tsconfig.json.", fix: "Add a tsconfig.json.", evidence: { tsconfigPath: p }});
    return section;
  }

  let cfg: TsConfig;
  try { cfg = readJson<TsConfig>(p); } catch (e) {
    section.findings.push({ id: "tsconfig.invalid", title: "tsconfig.json is not valid JSON", severity: "ERROR",
      details: "Your tsconfig.json failed to parse.", fix: "Fix JSON syntax.", evidence: { tsconfigPath: p, error: String(e) }});
    return section;
  }

  const co = cfg.compilerOptions ?? {};
  const module = String(co["module"] ?? "");
  const moduleResolution = String(co["moduleResolution"] ?? "");
  if (module && moduleResolution && /node/i.test(module) && !/node/i.test(moduleResolution)) {
    section.findings.push({ id: "tsconfig.moduleResolution", title: "Module and moduleResolution may be mismatched", severity: "WARN",
      details: "Mismatches cause runtime import errors in prod.", fix: "Align moduleResolution with module (NodeNext/Node16).",
      evidence: { module, moduleResolution }});
  }

  const exclude = cfg.exclude ?? [];
  if (!exclude.some((x) => /dist|build|\.next|out/i.test(x))) {
    section.findings.push({ id: "tsconfig.exclude.build", title: "Build output folders not excluded", severity: "INFO",
      details: "Compiling output folders can cause duplicate errors and slower builds.", fix: "Exclude dist/build/.next/out if present.",
      evidence: { exclude }});
  }

  return section;
}
