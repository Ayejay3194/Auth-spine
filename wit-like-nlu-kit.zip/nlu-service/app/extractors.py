import regex as re
from typing import List, Dict, Any

DATE_TIME_PATTERNS = [
    (re.compile(r"\b(today|tomorrow|tonight)\b", re.I), "datetime"),
    (re.compile(r"\b(mon|tue|wed|thu|fri|sat|sun)(day)?\b", re.I), "datetime"),
    (re.compile(r"\b\d{1,2}:\d{2}\s*(am|pm)?\b", re.I), "datetime"),
    (re.compile(r"\b\d{1,2}\s*(am|pm)\b", re.I), "datetime"),
]

EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b", re.I)
PHONE_RE = re.compile(r"\b(?:\+?1[-.\s]?)?(?:\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}\b")
MONEY_RE = re.compile(r"\b\$\s*\d+(?:\.\d{2})?\b")

def extract_entities(text: str, lookups: Dict[str, List[str]] | None = None) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []

    def add(entity: str, start: int, end: int, value: str, conf: float, source: str):
        out.append({
            "entity": entity,
            "value": value,
            "start": start,
            "end": end,
            "confidence": conf,
            "source": source,
        })

    for m in EMAIL_RE.finditer(text):
        add("email", m.start(), m.end(), m.group(0), 0.98, "regex")
    for m in PHONE_RE.finditer(text):
        add("phone", m.start(), m.end(), m.group(0), 0.90, "regex")
    for m in MONEY_RE.finditer(text):
        add("money", m.start(), m.end(), m.group(0), 0.85, "regex")

    for rx, ent in DATE_TIME_PATTERNS:
        for m in rx.finditer(text):
            add(ent, m.start(), m.end(), m.group(0), 0.80, "regex")

    if lookups:
        lowered = text.lower()
        for entity, values in lookups.items():
            for v in values:
                idx = lowered.find(v.lower())
                if idx != -1:
                    add(entity, idx, idx+len(v), text[idx:idx+len(v)], 0.75, "lookup")

    out.sort(key=lambda x: (x["start"], -(x["end"]-x["start"])))
    dedup=[]
    last_end=-1
    for e in out:
        if e["start"] >= last_end:
            dedup.append(e)
            last_end = e["end"]
    return dedup
