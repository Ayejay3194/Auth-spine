import { describe, it, expect } from "vitest";
import { signRequest, verifySignedRequest } from "../src/security/signing/signer";
import { InMemoryNonceStore } from "../src/security/signing/nonce-store";

describe("Signing + replay protection", () => {
  it("accepts a valid signed request and rejects replay", async () => {
    const key = { keyId: "k1", secret: "supersecret" };
    const keys = { k1: key };
    const nonceStore = new InMemoryNonceStore();

    const body = { hello: "world" };
    const sig = signRequest(key, { method: "POST", path: "/api/chat", body });

    const ok1 = await verifySignedRequest(keys, nonceStore, {
      method: "POST",
      path: "/api/chat",
      body,
      ...sig,
    });
    expect(ok1.ok).toBe(true);

    const ok2 = await verifySignedRequest(keys, nonceStore, {
      method: "POST",
      path: "/api/chat",
      body,
      ...sig,
    });
    expect(ok2.ok).toBe(false);
  });
});
