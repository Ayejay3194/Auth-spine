import type { ID, ISODateTime } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type Touchpoint = {
  id: ID;
  businessId: ID;
  clientId: ID;
  source?: string;
  medium?: string;
  campaign?: string;
  content?: string;
  term?: string;
  at: ISODateTime;
};

export class AttributionStore {
  private touches: Touchpoint[] = [];
  record(tp: Omit<Touchpoint,"id">): Touchpoint { const t = { ...tp, id: cuid("tp") }; this.touches.push(t); return t; }
  lastTouch(businessId: ID, clientId: ID): Touchpoint | null {
    return this.touches.filter(t => t.businessId===businessId && t.clientId===clientId).slice(-1)[0] ?? null;
  }
  list(businessId: ID, limit=200) { return this.touches.filter(t => t.businessId===businessId).slice(-limit).reverse(); }
}
