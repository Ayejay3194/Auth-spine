export function normalizeQuery(q: string): string {
  return q.trim().replace(/\s+/g, " ").toLowerCase();
}

export function roundCoord(n: number, decimals = 5): number {
  const p = Math.pow(10, decimals);
  return Math.round(n * p) / p;
}

export function buildForwardKey(args: { query: string; locale?: string; countryCodes?: string[] }): string {
  const locale = (args.locale ?? "en").toLowerCase();
  const cc = (args.countryCodes ?? []).map(s => s.toLowerCase()).sort().join(",");
  return `geo:fwd:${locale}:${cc}:${normalizeQuery(args.query)}`;
}

export function buildReverseKey(args: { lat: number; lon: number; locale?: string }): string {
  const locale = (args.locale ?? "en").toLowerCase();
  return `geo:rev:${locale}:${roundCoord(args.lat)}:${roundCoord(args.lon)}`;
}

export function inferConfidenceFromRank(rank?: number, importance?: number): number | undefined {
  // Nominatim doesn't give a clean confidence. We infer one. It's not perfect, but it's consistent.
  // rank_search tends to correlate with granularity; importance is 0..1-ish.
  if (rank == null && importance == null) return undefined;
  const r = rank == null ? 0.5 : Math.max(0, Math.min(1, 1 - (rank / 40)));
  const i = importance == null ? 0.5 : Math.max(0, Math.min(1, importance));
  return Math.max(0, Math.min(1, (r * 0.6 + i * 0.4)));
}

export function safeJsonParse<T>(s: string): T | null {
  try { return JSON.parse(s) as T; } catch { return null; }
}
