export type EntityIn = { entity: string; value: string };

export type TrainExample = {
  text: string;
  intent: string;
  entities: EntityIn[];
};

export type ParseResult = {
  text: string;
  intent: { name: string; confidence: number };
  intents: { name: string; confidence: number }[];
  entities: { entity: string; value: string; start: number; end: number; confidence: number; source: string }[];
};
