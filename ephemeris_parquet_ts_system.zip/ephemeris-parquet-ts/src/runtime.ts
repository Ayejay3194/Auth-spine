import type { SegmentCoeffs, State } from "./types.js";
import { evalCheb, mapJdToChebX } from "./chebyshev.js";

export class SegmentIndex {
  segments: SegmentCoeffs[];
  constructor(segments: SegmentCoeffs[]) {
    this.segments = [...segments].sort((a,b)=>a.segStartJd-b.segStartJd);
  }

  find(jd: number): SegmentCoeffs | null {
    let lo = 0, hi = this.segments.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const s = this.segments[mid];
      if (jd < s.segStartJd) hi = mid - 1;
      else if (jd > s.segEndJd) lo = mid + 1;
      else return s;
    }
    return null;
  }
}

export function evalState(index: SegmentIndex, jd: number): State {
  const seg = index.find(jd);
  if (!seg) throw new Error(`No segment covers jd=${jd}`);
  const x = mapJdToChebX(jd, seg.segStartJd, seg.segEndJd);

  const r = [
    evalCheb(seg.px, x),
    evalCheb(seg.py, x),
    evalCheb(seg.pz, x),
  ] as any;

  const v = [
    evalCheb(seg.vx, x),
    evalCheb(seg.vy, x),
    evalCheb(seg.vz, x),
  ] as any;

  return { r, v };
}
