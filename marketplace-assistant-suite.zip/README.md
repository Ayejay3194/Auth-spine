# Marketplace + No-LLM Assistant Suite (TypeScript)

This is a deterministic, auditable, **no-LLM** assistant framework with:
- Core assistant runtime (intent + entity extraction + slot fill flows + confirm gate)
- Policy (roles, allowlists, rate limiting)
- Tool registry + audited tool execution
- Business spines (single-business): booking, CRM, payments/invoicing, marketing, analytics/export, ops, admin/GDPR
- **Marketplace spines**: discovery/search, booking holds + confirmation, escrow/payouts, messaging/notifications, reviews/reputation, disputes/support

Run demo:
```bash
npm i
npm run build
npm run demo
```

Integration:
- Copy `src/assistant/**` into your repo
- Implement providers in `src/assistant/providers/real/providers.ts`
- Use Next.js route templates in `src/next-api-templates/**`
- Add persistence tables (see `prisma.schema.snippet.prisma`)
