"use client";
import React from "react";
import { useAuth } from "./AuthContext";
import { LoginCard } from "./LoginCard";
import { NotAuthorized } from "./NotAuthorized";

export function Protected({ children, role }: { children: React.ReactNode; role?: string }) {
  const { user, loading } = useAuth();

  if (loading) return <div className="glass rounded-xl2 p-6">Loading…</div>;
  if (!user) return <LoginCard />;

  if (role && !user.roles.includes(role)) return <NotAuthorized neededRole={role} />;

  return <>{children}</>;
}
