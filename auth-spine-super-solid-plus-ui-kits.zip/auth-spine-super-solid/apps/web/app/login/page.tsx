'use client'

import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

export default function LoginPage() {
  const router = useRouter()
  const sp = useSearchParams()
  const next = sp.get('next') || '/dashboard'
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setErr(null)
    setLoading(true)
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email, password }),
    })
    setLoading(false)
    if (!res.ok) {
      const j = await res.json().catch(() => ({}))
      setErr(j?.error?.message || 'Login failed')
      return
    }
    router.push(next)
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-6 space-y-4">
        <h1 className="text-2xl font-bold">Login</h1>
        <p className="text-slate-600 text-sm">Use admin@example.com / Admin123! after seeding.</p>
        {err ? <div className="text-sm text-red-700 bg-red-50 border border-red-200 rounded p-2">{err}</div> : null}
        <form onSubmit={onSubmit} className="space-y-3">
          <input className="w-full border rounded-lg p-3" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="w-full border rounded-lg p-3" placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button className="w-full bg-slate-900 text-white rounded-lg p-3 font-semibold disabled:opacity-60" disabled={loading}>
            {loading ? '...' : 'Login'}
          </button>
        </form>
        <div className="text-sm text-slate-600">
          No account? <a className="underline" href="/register">Register</a>
        </div>
      </div>
    </div>
  )
}
