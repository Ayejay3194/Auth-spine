# Solari Astrology JSONL Pack v1

This is a foundational, ingestion-safe JSONL knowledge pack for Solari.

## Files
- `signs.jsonl`
- `planets.jsonl`
- `houses.jsonl`
- `aspects.jsonl`
- `decans.jsonl`
- `transits.jsonl`
- `style_rules.jsonl`

## Ingestion
Treat each line as a document. Index by `type` + `name`/`id`.

## Notes
- No copyrighted text.
- Designed for conversational, grounded interpretations.
