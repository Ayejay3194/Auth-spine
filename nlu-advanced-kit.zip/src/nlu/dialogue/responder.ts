import type { AssistantReply, DialogueState, NLUModel, NLUResult } from "../types";
import { nextClarifyingQuestion } from "./clarifier";
import { missingRequiredSlots } from "./slots";

export function respond(model: NLUModel, state: DialogueState, nlu: NLUResult): AssistantReply {
  // Unknown or low confidence: ask user what they mean.
  if (nlu.intent.name === "unknown") {
    return {
      text: "I’m not sure what you want yet. What are you trying to do?",
      suggestions: model.intents.slice(0, 6).map(i => i.name.replace(/_/g, " ")),
    };
  }

  // Greeting
  if (nlu.intent.name === "greeting") {
    return {
      text: "Hey. Tell me what you need and I’ll route it.",
      suggestions: ["weather", "book flight", "help"],
    };
  }

  // Slot filling flow
  const missing = missingRequiredSlots(model, state, state.activeIntent);
  if (missing.length > 0) {
    const q = nextClarifyingQuestion(model, state);
    if (q) return q;
  }

  // If confirmation style is ask, confirm summary
  const intentSpec = model.intents.find(i => i.name === state.activeIntent);
  if (intentSpec?.confirmationStyle === "ask") {
    const summary = summarize(state);
    return { text: `Cool. Just confirming: ${summary} (yes/no)` };
  }

  // Otherwise proceed
  return {
    text: `Got it. Intent: ${state.activeIntent}. You’re good to proceed.`,
    suggestions: ["export model", "add examples", "run eval"],
  };
}

function summarize(state: DialogueState): string {
  const parts: string[] = [];
  for (const [k, v] of Object.entries(state.slots)) {
    parts.push(`${k.replace(/_/g, " ")}=${String(v.value)}`);
  }
  return parts.length ? parts.join(", ") : "no details yet";
}
