import { api } from "@/src/core/api";
export async function GET(){return api(async()=>({ok:false,todo:"Exchange code->token->userinfo; create session"}));}
