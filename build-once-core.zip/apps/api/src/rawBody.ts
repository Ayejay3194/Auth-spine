import type { FastifyInstance } from "fastify";

/**
 * Fastify doesn't include raw body by default.
 * This hook captures raw payload into req.body for the webhook route.
 */
export async function installRawBody(app: FastifyInstance) {
  app.addContentTypeParser("*", { parseAs: "buffer" }, async (_req, body) => body);
}
