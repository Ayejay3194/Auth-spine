import { verifyHmacWebhook } from "../../security/webhooks/verify";
import { audit } from "../../security/observability/audit";

/**
 * Processor-agnostic webhook handler skeleton.
 * For real providers (Stripe), plug in exact signature scheme.
 */
export async function handleBillingWebhook(input: {
  rawBody: string;
  signature: string | undefined;
  secret: string;
}) {
  await verifyHmacWebhook({
    rawBody: input.rawBody,
    signatureHeader: input.signature,
    secret: input.secret,
  });

  await audit({ event: "billing_webhook_verified", meta: { size: input.rawBody.length } });

  // TODO: parse event, map to tenant, update subscription state, idempotency keys, replay cache.
  return { ok: true };
}
