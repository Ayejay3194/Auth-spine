export { spine as crmSpine } from './spine.js';
