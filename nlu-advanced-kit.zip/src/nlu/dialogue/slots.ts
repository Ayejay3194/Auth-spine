import type { DialogueState, EntitySpan, NLUModel, SlotSpec } from "../types";

export function getIntentSlots(model: NLUModel, intentName?: string): SlotSpec[] {
  if (!intentName) return [];
  return model.intents.find(i => i.name === intentName)?.slots ?? [];
}

export function fillSlots(model: NLUModel, state: DialogueState, intentName: string, entities: EntitySpan[]): DialogueState {
  const slots = getIntentSlots(model, intentName);
  const next = { ...state, activeIntent: intentName, lastIntent: intentName };

  // naive mapping: for each slot spec, if entity exists, store first match
  for (const slot of slots) {
    const match = entities.find(e => e.entity === slot.entity);
    if (match) {
      next.slots[slot.name] = {
        value: match.normalized ?? match.value,
        raw: match.value,
        entity: slot.entity,
        confidence: 0.9,
      };
    }
  }

  return next;
}

export function missingRequiredSlots(model: NLUModel, state: DialogueState, intentName?: string): SlotSpec[] {
  const slots = getIntentSlots(model, intentName);
  return slots.filter(s => s.required).filter(s => state.slots[s.name]?.value == null);
}

export function validateSlot(spec: SlotSpec, value: unknown): boolean {
  if (!spec.validate || spec.validate === "nonempty") return value != null && String(value).trim().length > 0;
  if (spec.validate === "number") return typeof value === "number" && Number.isFinite(value);
  if (spec.validate === "date") {
    if (typeof value !== "string") return false;
    return /^\d{4}-\d{2}-\d{2}$/.test(value);
  }
  return true;
}
