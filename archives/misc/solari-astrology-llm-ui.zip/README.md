# Solari Astrology LLM UI (Client-side JSONL Retriever)

This is a **React + TypeScript + Vite** UI that:
- Loads a local JSONL "book database" into memory
- Searches it with simple relevance scoring
- Transforms the top passages into a "Solari-style" response

## Run it

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## JSONL format

One JSON object per line:

```json
{"id":"optional","book":"Book Title","topic":"sun","sign":"scorpio","house":7,"text":"..."}
```

Notes:
- `topic` and `sign` are case-insensitive in the app (it lowercases them).
- If `id` is missing, the UI will generate one.
