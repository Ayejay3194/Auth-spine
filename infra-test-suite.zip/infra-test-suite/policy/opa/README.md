# Policy-as-Code (OPA/Conftest)

Drop Rego policies here and Conftest will run them against your Kubernetes manifests.

Example: require resource limits, forbid latest tags, require namespaces, etc.
