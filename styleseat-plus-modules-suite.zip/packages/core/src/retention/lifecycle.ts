import type { ID, ISODateTime } from "../shared/types.js";

export type LifecycleEvent =
  | { type: "booking.completed"; businessId: ID; clientId: ID; at: ISODateTime }
  | { type: "booking.no_show"; businessId: ID; clientId: ID; at: ISODateTime }
  | { type: "client.inactive"; businessId: ID; clientId: ID; daysInactive: number; at: ISODateTime };

export type Offer = { kind: "rebook_reminder" | "free_addon" | "percent_off"; value?: number; description: string };

export function recommendedOffer(ev: LifecycleEvent): Offer {
  switch (ev.type) {
    case "booking.no_show":
      return { kind: "rebook_reminder", description: "Rebook reminder + deposit required next time." };
    case "booking.completed":
      return { kind: "rebook_reminder", description: "Rebook suggestion with next best slot." };
    case "client.inactive":
      if (ev.daysInactive >= 90) return { kind: "percent_off", value: 20, description: "Win-back 20% off" };
      if (ev.daysInactive >= 45) return { kind: "free_addon", description: "Win-back free add-on" };
      return { kind: "rebook_reminder", description: "We miss you. Rebook?" };
  }
}
