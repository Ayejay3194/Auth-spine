# Email & Notification Deliverability Checklist

## DNS / Auth
- [ ] SPF set
- [ ] DKIM enabled
- [ ] DMARC policy set (at least monitoring)
- [ ] From domain aligned with sending service

## Sending Hygiene
- [ ] Validate emails on signup (format + bounce handling)
- [ ] Unsubscribe links for marketing mail (and it works)
- [ ] Preferences center for notification types
- [ ] Suppress hard bounces + complainers automatically

## Notification Systems
- [ ] De-dupe keys to prevent duplicate sends
- [ ] Per-user rate limiting (avoid notification spam)
- [ ] Ordering rules where it matters (e.g., state changes)
- [ ] Costs tracked for SMS/push
