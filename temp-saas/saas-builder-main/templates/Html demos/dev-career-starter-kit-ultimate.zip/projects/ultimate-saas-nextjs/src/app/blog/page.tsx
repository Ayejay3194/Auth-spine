import Link from 'next/link';
import { prisma } from '../../lib/db';

export const dynamic = 'force-dynamic';

export default async function BlogIndexPage() {
  const posts = await prisma.post.findMany({
    orderBy: { createdAt: 'desc' },
  });

  return (
    <main className="max-w-2xl mx-auto py-12 space-y-6">
      <h1 className="text-3xl font-semibold">Blog</h1>
      <p className="text-sm text-slate-300">
        Simple content system powered by the Post model.
      </p>
      <div className="space-y-4">
        {posts.map((post) => (
          <article key={post.id} className="border-b border-slate-800 pb-4">
            <Link href={`/blog/${post.slug}`} className="text-lg font-medium hover:underline">
              {post.title}
            </Link>
          </article>
        ))}
      </div>
    </main>
  );
}
