"use client";
import { useBooking } from "@/booking/bookingStore";

export function BookButton({ stylistId, stylistName }:{ stylistId:string; stylistName:string; }){
  const { open } = useBooking();
  return (
    <button className="rounded-2xl px-5 py-3 text-sm font-semibold"
      style={{background:"var(--accent)", color:"var(--accentText)"}}
      onClick={()=>open({ stylistId, stylistName })}
    >
      Book with {stylistName}
    </button>
  );
}
