# Supabase at Home (Local Self-Hosted Dev Pack)

You want Supabase running locally on your machine (aka "at home"), with:
- Postgres
- Auth
- Storage
- Studio (web UI)
- Kong API gateway
- Realtime
- REST (PostgREST)
- Optional: Edge Functions

This pack uses the official Supabase **Docker** setup approach.

## Prereqs
- Docker Desktop (or Docker Engine) + docker compose
- Node.js 20+ (recommended) if you want Supabase CLI
- Git (optional)

## Fast path (Docker only)
1) Copy `.env.example` to `.env` and keep defaults for local dev.
2) Run:
```bash
docker compose up -d
```
3) Open:
- Studio: http://localhost:3000
- API: http://localhost:8000
- Postgres: localhost:5432

## Supabase CLI path (recommended)
This mirrors hosted Supabase most closely.

1) Install Supabase CLI:
```bash
npm i -g supabase
```

2) Start:
```bash
supabase start
```

3) Apply schema + RLS:
```bash
supabase db reset
```

This repo includes `supabase/migrations/` you can drop into a CLI project.

## Connecting your Next app
Set env:
```env
NEXT_PUBLIC_SUPABASE_URL=http://localhost:8000
NEXT_PUBLIC_SUPABASE_ANON_KEY=<from Studio settings or generated in env>
SUPABASE_SERVICE_ROLE_KEY=<server-only>
```

**Never** put the service role key in the browser.

## What’s included
- `docker-compose.yml` local stack
- `.env.example` safe defaults
- `supabase/` migrations (schema + RLS + storage)
- `scripts/` helper commands
