import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerAdminTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "admin.show_audit",
    title: "Show audit log",
    description: "Returns recent audit events.",
    inputSchema: { type: "object", properties: { limit: { type: "number" } }, required: ["limit"] },
    async run(ctx, input) {
      const data = await p.admin.showAudit({ limit: input.limit });
      return { ok: true, data };
    }
  });

  reg.register({
    id: "gdpr.export_request",
    title: "GDPR export",
    description: "Generates a GDPR export bundle and returns a URL.",
    inputSchema: { type: "object", properties: { userId: { type: "string" } }, required: ["userId"] },
    async run(ctx, input) {
      const data = await p.admin.gdprExport({ userId: input.userId });
      return { ok: true, data };
    }
  });
}
