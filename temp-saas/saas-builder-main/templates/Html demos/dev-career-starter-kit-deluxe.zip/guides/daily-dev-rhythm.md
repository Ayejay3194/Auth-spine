# Daily Dev Rhythm

1. Plan (10 minutes)
   - Write 3 bullets for what you want to ship today.

2. Focus (60–90 minutes)
   - Pick ONE small feature and do it end-to-end (DB → API → UI).

3. Clean up (15 minutes)
   - Fix obvious errors, add TODOs where needed.

4. Log (10 minutes)
   - Paste messy notes into the DevLog & Ticket Writer prompt.
   - Turn them into tickets and follow-ups.

Weekly:
- Review what you shipped.
- Notice repeated blockers.
- Pick one concept to deepen next week.
