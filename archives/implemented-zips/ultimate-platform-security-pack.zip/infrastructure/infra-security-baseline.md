Infrastructure Security Baseline

- Hardened hosts
- Regular patching
- No default accounts
- IAM least privilege
- Immutable infrastructure preferred
