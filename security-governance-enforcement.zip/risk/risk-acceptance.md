# Risk Acceptance Record

Control ID:
Reason for acceptance:
Owner:
Expiration date:
Mitigation plan:

NOTE:
Expired risk acceptances automatically block deploys.
