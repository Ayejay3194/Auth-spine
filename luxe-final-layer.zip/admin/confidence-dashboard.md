INTERNAL CONFIDENCE DASHBOARD
=============================

Single-screen signals:
- booking stability
- payout health
- dispute volume
- SLA adherence
- anomaly detection

Green = log off.
Red = act.
