import type { Flow } from "./flowTypes.js";
import type { Reply } from "../core/types.js";
import { runTool } from "../tools/registry.js";

export function makeSlotFillFlow(audit: any): Flow {
  return {
    id: "slotFill",
    async handle({ ctx, text, state, tools }) {
      const af = state.activeFlow;
      if (!af || af.id !== "slotFill") return { state, reply: { text: "No active form.", done: true } };

      // Expect JSON-ish: key=value, or plain value (fills first missing)
      const payload = parseKeyVals(text);
      const base = (af.slots as any).input ?? {};
      const toolId = (af.slots as any).toolId as string;

      const merged = { ...base, ...payload };

      const missing = missingRequired(toolId, merged);
      if (missing.length) {
        const reply: Reply = {
          text: `Still need: ${missing.join(", ")}.`,
          ui: {
            type: "form",
            title: "Missing info",
            fields: missing.map(k => ({ key: k, label: k, type: k.includes("amount") ? "number" : "text" }))
          },
          done: false
        };
        return { state: { ...state, activeFlow: { ...af, slots: { ...af.slots, input: merged } } }, reply };
      }

      // If flow requires confirm, transition
      if (af.requiresConfirm) {
        return {
          state: {
            ...state,
            activeFlow: {
              id: "confirm",
              step: "confirm",
              slots: {},
              requiresConfirm: true,
              confirmPhrase: "YES",
              pendingAction: { toolId, input: merged }
            }
          },
          reply: { text: "Type **YES** to confirm.", done: false }
        };
      }

      const tool = tools.get(toolId);
      if (!tool) return { state, reply: { text: "Tool missing.", done: true } };

      const res = await runTool({ tool, ctx, input: merged, audit });
      return {
        state: { ...state, activeFlow: undefined },
        reply: res.ok ? { text: "Done.", done: true } : { text: `Failed: ${res.error.message}`, done: true }
      };
    }
  };
}

function parseKeyVals(text: string) {
  const out: any = {};
  const pairs = text.split(/\s+/).filter(Boolean);
  for (const p of pairs) {
    const m = p.match(/^([a-zA-Z_][a-zA-Z0-9_]*)=(.+)$/);
    if (m) {
      const k = m[1];
      const v = m[2];
      out[k] = maybeNumber(v);
    }
  }
  if (Object.keys(out).length) return out;
  return { value: maybeNumber(text.trim()) };
}

function maybeNumber(v: string) {
  const n = Number(v);
  return Number.isFinite(n) && v.match(/^[0-9.]+$/) ? n : v;
}

function missingRequired(toolId: string, input: any): string[] {
  const req: Record<string, string[]> = {
    "booking.cancel": ["bookingId"],
    "crm.add_note": ["clientId", "note"],
    "payments.create_invoice": ["clientId", "amount"],
    "payments.refund": ["invoiceId"],
    "marketing.create_promo": ["code", "percentOff"],
  };
  const keys = req[toolId] ?? [];
  // allow "value" fallback for single missing
  if (keys.length === 1 && input.value !== undefined && (input[keys[0]] === undefined)) {
    input[keys[0]] = input.value;
    delete input.value;
  }
  // special: if two missing and user provided value, ignore
  return keys.filter(k => input[k] === undefined || input[k] === null || input[k] === "");
}
