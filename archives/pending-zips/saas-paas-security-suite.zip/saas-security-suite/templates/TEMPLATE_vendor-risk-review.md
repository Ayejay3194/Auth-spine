# Vendor / Sub-processor Risk Review

## Vendor
- Name:
- Service:
- Data types accessed:
- Regions:

## Security Questions (minimum)
- SOC 2 / ISO reports available?
- Encryption at rest/in transit?
- SSO/MFA support?
- Data retention and deletion?
- Sub-processors list?
- Incident notification SLAs?
- Pen-test frequency?

## Decision
- Approved / Conditionally approved / Rejected
- Conditions:
- Reviewer / Date:
