from fastapi import FastAPI
from pydantic import BaseModel
from db import fetch_df
from model_no_show import train as train_no_show, score as score_no_show

app = FastAPI(title="Beauty Booking ML Service", version="0.1.0")

class ScoreReq(BaseModel):
  clientUserId: str

@app.get("/health")
def health():
  return {"ok": True}

@app.post("/train/no_show")
def train():
  sql = '''
  with feats as (
    select "entityId" as user_id,
           (features->>'bookings_90d')::int as bookings_90d,
           (features->>'cancels_90d')::int as cancels_90d,
           (features->>'no_shows_365d')::int as no_shows_365d
    from "EntityFeatures"
    where "entityType" = 'USER'
  ),
  labels as (
    select "clientUserId" as user_id,
           max(case when status = 'NO_SHOW' then 1 else 0 end) as label
    from "Booking"
    group by "clientUserId"
  )
  select f.*, coalesce(l.label,0) as label
  from feats f
  left join labels l using (user_id)
  '''
  df = fetch_df(sql)
  return train_no_show(df)

@app.post("/score/no_show")
def score(req: ScoreReq):
  sql = 'select features from "EntityFeatures" where "entityType" = %s and "entityId" = %s'
  df = fetch_df(sql, params=["USER", req.clientUserId])
  if df.empty:
    return {"risk": 0.15, "note": "no features found, fallback"}
  features = df.iloc[0]["features"] or {}
  risk = score_no_show(features)
  return {"risk": risk, "features": features}
