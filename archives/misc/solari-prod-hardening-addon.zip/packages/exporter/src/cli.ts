import fs from "fs-extra";
import path from "node:path";
import { Document, Packer, Paragraph, HeadingLevel } from "docx";

const inFile = process.argv[2];
const outFile = process.argv[3] ?? "out/report.docx";

if (!inFile) {
  console.error("Usage: pnpm --filter @solari/exporter export <in.md> [out.docx]");
  process.exit(1);
}

const md = fs.readFileSync(inFile, "utf-8");

function mdToParas(markdown: string) {
  const lines = markdown.split(/\r?\n/);
  const paras: Paragraph[] = [];
  for (const line of lines) {
    if (line.startsWith("# ")) paras.push(new Paragraph({ text: line.slice(2), heading: HeadingLevel.TITLE }));
    else if (line.startsWith("## ")) paras.push(new Paragraph({ text: line.slice(3), heading: HeadingLevel.HEADING_1 }));
    else if (line.startsWith("### ")) paras.push(new Paragraph({ text: line.slice(4), heading: HeadingLevel.HEADING_2 }));
    else if (line.trim() === "") paras.push(new Paragraph({ text: "" }));
    else paras.push(new Paragraph({ text: line }));
  }
  return paras;
}

const doc = new Document({ sections: [{ children: mdToParas(md) }] });

fs.ensureDirSync(path.dirname(outFile));
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(outFile, buf);
  console.log(`Wrote ${outFile}`);
});
