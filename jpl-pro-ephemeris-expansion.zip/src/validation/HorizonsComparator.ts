
/**
 * Compares engine output against JPL Horizons reference values.
 * Used in CI to prevent regression.
 */

export interface HorizonsSample {
  jdTDB: number;
  target: string;
  x: number;
  y: number;
  z: number;
}

export function compareWithHorizons(
  engineResult: number[],
  horizons: HorizonsSample
): number {
  const dx = engineResult[0] - horizons.x;
  const dy = engineResult[1] - horizons.y;
  const dz = engineResult[2] - horizons.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}
