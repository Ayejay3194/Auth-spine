Privacy Policy Placeholder

- What data you collect
- Why you collect it
- How you use it
- How long you retain it
- Who you share it with
- How users delete their data
- Contact details

Replace with real counsel-reviewed language before launch.
