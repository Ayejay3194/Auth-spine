import path from "node:path";
import { writeFile, readFile } from "node:fs/promises";
import { walkFiles, sha256File } from "./fswalk.js";
import type { Manifest } from "./types.js";

export async function createManifest(root: string): Promise<Manifest> {
  const files = await walkFiles(root);
  const entries = [];
  for (const rel of files) {
    const abs = path.join(root, rel);
    const meta = await sha256File(abs);
    entries.push({ path: rel, ...meta });
  }
  return { createdAt: new Date().toISOString(), root, entries };
}

export async function saveManifest(root: string, manifest: Manifest) {
  const fp = path.join(root, ".guardian", "manifest.json");
  await writeFile(fp, JSON.stringify(manifest, null, 2));
  return fp;
}

export async function loadManifest(root: string): Promise<Manifest> {
  const fp = path.join(root, ".guardian", "manifest.json");
  const raw = await readFile(fp, "utf-8");
  return JSON.parse(raw) as Manifest;
}
