# Security Test Patterns (copy/paste into your test suite)

## IDOR (broken object authorization)
Goal: prove user A cannot access user B by swapping IDs.

Pattern:
1. Create resource as user A -> get idA
2. Create resource as user B -> get idB
3. Call GET/PUT/DELETE on idB using user A token
Expected: 403 or 404 (consistent with your policy)

## Auth-required endpoints
For every POST/PATCH/DELETE:
- Call with no auth -> 401
- Call with auth but wrong role -> 403
- Call with auth + correct perms -> 200/201

## Supabase RLS
- Run tests with anon key + user JWT (not service role).
- Add a “policy completeness” test:
  - Ensure each table has RLS enabled
  - Ensure policies exist for the operations you use
