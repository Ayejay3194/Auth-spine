"use client";
import { useEffect, useState } from "react";

type Member = { id:string; stylist:{ displayName:string; slug:string }; settings:any };
type Booking = { id:string; startAt:string; status:string; service:{ name:string }; stylist:{ displayName:string; slug:string } };

export function SalonAdminTabs({ salonId }:{ salonId:string }){
  const [tab, setTab] = useState<"members"|"approvals">("approvals");
  return (
    <div className="rounded-[28px] border p-6" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
      <div className="flex flex-wrap gap-2">
        <Tab active={tab==="approvals"} onClick={()=>setTab("approvals")}>Approvals</Tab>
        <Tab active={tab==="members"} onClick={()=>setTab("members")}>Members</Tab>
      </div>

      <div className="mt-6">
        {tab==="approvals" ? <Approvals salonId={salonId} /> : <Members salonId={salonId} />}
      </div>
    </div>
  );
}

function Tab({ active, children, onClick }:{active?:boolean; children:any; onClick?:()=>void}){
  return (
    <button onClick={onClick} className="rounded-full border px-4 py-2 text-sm font-semibold"
      style={{borderColor: active ? "var(--accent)" : "var(--border)", background: active ? "var(--accent)" : "var(--panel2)", color: active ? "var(--accentText)" : "var(--text)"}}>
      {children}
    </button>
  );
}

function Toggle({ label, on, onClick }:{label:string; on:boolean; onClick:()=>void}){
  return (
    <button onClick={onClick} className="rounded-full border px-3 py-2 text-xs font-semibold"
      style={{borderColor: on ? "var(--accent)" : "var(--border)", background: on ? "var(--accent)" : "var(--panel)", color: on ? "var(--accentText)" : "var(--text)"}}>
      {label}: {on ? "On" : "Off"}
    </button>
  );
}

function Members({ salonId }:{ salonId:string }){
  const [members, setMembers] = useState<Member[]>([]);

  async function load(){
    const r = await fetch(`/api/salon-admin/members?salonId=${salonId}`, { cache:"no-store" });
    const j = await r.json();
    setMembers(j.members || []);
  }
  useEffect(()=>{ load(); },[]);

  async function toggle(memberId:string, key:string){
    const m = members.find(x=>x.id===memberId);
    const next = { ...(m?.settings||{}), [key]: !(m?.settings?.[key]) };
    await fetch(`/api/salon-admin/members/${memberId}/settings`, { method:"PUT", headers:{ "content-type":"application/json" }, body: JSON.stringify(next) });
    load();
  }

  return (
    <div className="space-y-2">
      {members.map(m => (
        <div key={m.id} className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-sm font-semibold">{m.stylist.displayName}</div>
              <div className="text-xs" style={{color:"var(--dim)"}}>/@{m.stylist.slug}</div>
            </div>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Toggle label="Direct bookings" on={Boolean(m.settings?.allowDirectBookings)} onClick={()=>toggle(m.id,"allowDirectBookings")} />
            <Toggle label="Require approval for new clients" on={Boolean(m.settings?.requireApprovalForNewClients)} onClick={()=>toggle(m.id,"requireApprovalForNewClients")} />
            <Toggle label="Manager can view calendar" on={Boolean(m.settings?.managerCanViewCalendar)} onClick={()=>toggle(m.id,"managerCanViewCalendar")} />
          </div>
        </div>
      ))}
      {!members.length ? <div style={{color:"var(--muted)"}}>No members.</div> : null}
    </div>
  );
}

function Approvals({ salonId }:{ salonId:string }){
  const [items, setItems] = useState<Booking[]>([]);

  async function load(){
    const r = await fetch(`/api/salon-admin/approvals?salonId=${salonId}`, { cache:"no-store" });
    const j = await r.json();
    setItems(j.bookings || []);
  }
  useEffect(()=>{ load(); },[]);

  async function act(id:string, action:"approve"|"reject"){
    await fetch(`/api/salon-admin/bookings/${id}/${action}`, { method:"POST" });
    load();
  }

  return (
    <div className="space-y-2">
      {items.map(b => (
        <div key={b.id} className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-sm font-semibold">{b.service.name}</div>
              <div className="text-xs" style={{color:"var(--dim)"}}>{new Date(b.startAt).toLocaleString()} · {b.stylist.displayName}</div>
              <div className="mt-2 text-xs tracking-[.16em] uppercase" style={{color:"var(--muted)"}}>{b.status}</div>
            </div>
            <div className="flex gap-2">
              <button onClick={()=>act(b.id,"approve")} className="rounded-xl px-3 py-2 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>Approve</button>
              <button onClick={()=>act(b.id,"reject")} className="rounded-xl border px-3 py-2 text-sm font-semibold" style={{borderColor:"var(--border)", background:"var(--panel)"}}>Reject</button>
            </div>
          </div>
        </div>
      ))}
      {!items.length ? <div style={{color:"var(--muted)"}}>No pending approvals.</div> : null}
    </div>
  );
}
