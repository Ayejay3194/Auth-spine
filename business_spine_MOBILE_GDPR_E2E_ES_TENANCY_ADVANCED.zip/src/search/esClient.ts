import { Client } from "@elastic/elasticsearch";
let _client: Client | null = null;
export function es() {
  if (_client) return _client;
  const node = process.env.ES_NODE ?? "http://localhost:9200";
  _client = new Client({ node });
  return _client;
}
