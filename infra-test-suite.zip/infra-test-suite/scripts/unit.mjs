import Ajv from "ajv";
import addFormats from "ajv-formats";
import fs from "node:fs";
import path from "node:path";
import { readJson, section, fail, ok, exists, findFiles, readText } from "./_util.mjs";

section("Validate infra.config.json against schema");
const ajv = new Ajv({ allErrors:true });
addFormats(ajv);
const schema = readJson("./schemas/infra-config.schema.json");
const validate = ajv.compile(schema);
const config = readJson("./infra.config.json");

if(!validate(config)){
  console.error(validate.errors);
  fail("infra.config.json failed schema validation");
} else {
  ok("infra.config.json schema looks valid");
}

section("Basic anti-footgun scans (PII in URLs/log templates)");
const pii = new Set((config.policy?.pii_log_blocklist ?? []).map(s=>String(s).toLowerCase()));
const suspect = [];

for(const root of ["./apps","./observability","./iac"]){
  if(!exists(root)) continue;
  const files = findFiles(root, [".ts",".js",".mjs",".json",".yml",".yaml",".txt",".md"]);
  for(const f of files){
    const t = readText(f).toLowerCase();
    for(const token of pii){
      // simple heuristic: token near "log", "url", "query", "path"
      if(t.includes(token) && (t.includes("log") || t.includes("url") || t.includes("query") || t.includes("path"))){
        suspect.push({ file:f, token });
        break;
      }
    }
  }
}

if(suspect.length){
  console.log("Possible PII tokens detected in code/config contexts:");
  for(const s of suspect.slice(0,30)) console.log(`- ${s.file} (token: ${s.token})`);
  fail("PII risk scan found suspects. Review and fix. (You asked for unbreakable.)");
} else {
  ok("No obvious PII-in-logs/urls patterns found (heuristic scan)");
}
