import fs from "node:fs";
import { normalize, unique } from "../utils/text.js";

export type PhraseRecord = {
  text: string;
  tags: string[];
};

export class PhraseBank {
  private phrases: PhraseRecord[] = [];

  loadFromJSONL(paths: string[]) {
    for (const p of paths) {
      if (!p || !fs.existsSync(p)) continue;
      const data = fs.readFileSync(p, "utf-8");
      for (const line of data.split(/\r?\n/)) {
        if (!line.trim()) continue;
        try {
          const obj = JSON.parse(line);
          const rec = extractPhrase(obj);
          if (rec) this.phrases.push(rec);
        } catch {
          // ignore bad lines
        }
      }
    }
  }

  retrieve(query: string, tagHints: string[], k = 6): PhraseRecord[] {
    const q = normalize(query);
    const hints = new Set(tagHints.map(t => normalize(t)));
    const scored = this.phrases.map((p) => {
      const t = normalize(p.text);
      let score = 0;
      // keyword overlap
      for (const w of q.split(" ")) {
        if (w.length < 3) continue;
        if (t.includes(w)) score += 1;
      }
      // tag match
      for (const tag of p.tags) {
        if (hints.has(normalize(tag))) score += 2;
      }
      // penalize super long
      score -= Math.max(0, (p.text.length - 140) / 200);
      return { p, score };
    });

    scored.sort((a, b) => b.score - a.score);
    const top = scored.filter(s => s.score > 0.5).slice(0, k).map(s => s.p);
    return uniqueByText(top);
  }
}

function uniqueByText(arr: PhraseRecord[]): PhraseRecord[] {
  const seen = new Set<string>();
  const out: PhraseRecord[] = [];
  for (const a of arr) {
    const key = normalize(a.text);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(a);
  }
  return out;
}

function extractPhrase(obj: any): PhraseRecord | null {
  // Supports your unified JSONL types loosely.
  // We try common shapes: {type:"phrase", text}, {messages:[{role:"assistant",content}]}, {output}, {response}
  const tags: string[] = [];

  if (typeof obj?.type === "string") tags.push(obj.type);
  if (Array.isArray(obj?.tags)) tags.push(...obj.tags);

  if (typeof obj?.text === "string" && obj.text.length >= 10) {
    return { text: obj.text.trim(), tags: tags.length ? tags : ["phrase"] };
  }

  // messages format
  const msgs = obj?.messages;
  if (Array.isArray(msgs)) {
    const a = msgs.find((m: any) => m?.role === "assistant" && typeof m?.content === "string");
    if (a?.content) return { text: a.content.trim(), tags: tags.length ? tags : ["conversation"] };
  }

  for (const k of ["output","response","completion","answer","summary"]) {
    if (typeof obj?.[k] === "string" && obj[k].length >= 10) {
      return { text: obj[k].trim(), tags: tags.length ? tags : ["snippet"] };
    }
  }

  return null;
}
