# Data Flow Diagram (Text Template)

## Components
- Browser (public)
- Browser (ops)
- Next.js app server
- Database (Postgres)
- Object storage (uploads)
- Payment processor (webhooks)
- Email/SMS provider

## Flows
1) Public -> Next (GET profile)
2) Public -> Next (POST booking)
3) Next -> DB (create booking)
4) Next -> Payment provider (create payment intent)
5) Payment provider -> Next webhook (signed)
6) Next -> DB (mark paid)
7) Next -> Object storage (signed upload)
8) Ops -> Next -> DB (approve/reject/refund)
