import { getProjectsForDemoUser } from '../../../lib/db';
import { ProjectList } from '../../../components/projects/project-list';

export const dynamic = 'force-dynamic';

export default async function ProjectsPage() {
  const projects = await getProjectsForDemoUser();

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Projects</h1>
      <ProjectList projects={projects} />
    </div>
  );
}
