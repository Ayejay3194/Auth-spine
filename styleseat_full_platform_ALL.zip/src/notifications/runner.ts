import { prisma } from "@/lib/prisma";

export async function sendMessage(input: { providerId: string; clientId: string; channel: "email"|"sms"|"push"; templateKey: string; vars: Record<string, unknown> }) {
  // Template: store as campaign log, let a worker deliver via SendGrid/Twilio/FCM
  await prisma.campaign.create({
    data: {
      providerId: input.providerId,
      channel: input.channel,
      segment: JSON.stringify({ clientId: input.clientId }),
      templateKey: input.templateKey,
      status: "queued",
      scheduledAt: new Date()
    }
  });
}

export async function createTask(_input: { providerId: string; title: string }) {
  // Hook to ops/task table if you add one. Keeping minimal.
}

export async function schedule(_input: { runAtISO: string; event: any; ctx: any }) {
  // Hook to a job queue (BullMQ/Temporal/Cloud scheduler). Not included.
}
