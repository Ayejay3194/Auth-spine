# CRON & SCHEDULED TASK DISASTERS

## Scheduling Problems

- [ ] Cron jobs not running
- [ ] Cron running on multiple servers
- [ ] Duplicate cron execution
- [ ] No distributed locking
- [ ] Cron overlapping with previous run
- [ ] Long-running cron blocking next execution
- [ ] Cron timezone issues
- [ ] DST causing double/missed execution
- [ ] Cron schedule incorrect
- [ ] No cron monitoring
- [ ] Cron failures not alerted
- [ ] Cannot manually trigger cron
- [ ] Cron logs not accessible
- [ ] No cron execution history
- [ ] Cron consuming too many resources
