import type { BodyName, SampleRow, SegmentCoeffs } from "./types.js";
import { fitChebLeastSquares } from "./chebyshev.js";

export interface FitOptions {
  segmentDays: number;
  order: number;
}

export function fitBodySegments(samples: SampleRow[], body: BodyName, span: string, opts: FitOptions): SegmentCoeffs[] {
  const segLen = opts.segmentDays;
  const order = opts.order;
  const out: SegmentCoeffs[] = [];
  const rows = [...samples].sort((a,b)=>a.jd-b.jd);

  let i = 0;
  while (i < rows.length) {
    const start = rows[i].jd;
    const end = start + segLen;

    const jds: number[] = [];
    const xs: number[] = [], ys: number[] = [], zs: number[] = [];
    const vxs: number[] = [], vys: number[] = [], vzs: number[] = [];

    while (i < rows.length && rows[i].jd <= end) {
      const st = rows[i].states[body];
      jds.push(rows[i].jd);
      xs.push(st.r[0]); ys.push(st.r[1]); zs.push(st.r[2]);
      vxs.push(st.v[0]); vys.push(st.v[1]); vzs.push(st.v[2]);
      i++;
    }

    if (jds.length < Math.max(order + 1, 8)) break;

    const segStartJd = jds[0];
    const segEndJd = jds[jds.length - 1];

    const px = fitChebLeastSquares(jds, xs, segStartJd, segEndJd, order);
    const py = fitChebLeastSquares(jds, ys, segStartJd, segEndJd, order);
    const pz = fitChebLeastSquares(jds, zs, segStartJd, segEndJd, order);

    const vx = fitChebLeastSquares(jds, vxs, segStartJd, segEndJd, order);
    const vy = fitChebLeastSquares(jds, vys, segStartJd, segEndJd, order);
    const vz = fitChebLeastSquares(jds, vzs, segStartJd, segEndJd, order);

    out.push({ body, span, segStartJd, segEndJd, order, px, py, pz, vx, vy, vz });
  }

  return out;
}
