# Incident Response Policy (Starter)

## Severity
- SEV1: confirmed breach, major outage, payment compromise
- SEV2: suspected breach, partial outage, high-risk vuln
- SEV3: minor incident, low-risk vuln

## Required
- Central incident channel
- Incident commander assigned
- Timeline + decisions logged
- Post-incident review within 5 business days
