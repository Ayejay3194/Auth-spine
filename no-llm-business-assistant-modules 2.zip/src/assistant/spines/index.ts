import { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";
import { registerBookingTools } from "./spineBooking.js";
import { registerCrmTools } from "./spineCrm.js";
import { registerPaymentsTools } from "./spinePayments.js";
import { registerMarketingTools } from "./spineMarketing.js";
import { registerAnalyticsTools } from "./spineAnalytics.js";
import { registerOpsTools } from "./spineOps.js";
import { registerAdminTools } from "./spineAdmin.js";

export function loadAllSpines(providers: Providers) {
  const tools = new ToolRegistry();
  registerBookingTools(tools, providers);
  registerCrmTools(tools, providers);
  registerPaymentsTools(tools, providers);
  registerMarketingTools(tools, providers);
  registerAnalyticsTools(tools, providers);
  registerOpsTools(tools, providers);
  registerAdminTools(tools, providers);
  return { tools };
}
