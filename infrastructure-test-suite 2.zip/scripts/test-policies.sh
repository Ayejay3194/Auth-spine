#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

log "OPA/Conftest policy checks"

if [ -d policies/opa ]; then
  if [ -d infra/k8s ]; then
    log "Conftest: k8s manifests"
    docker_run openpolicyagent/conftest:v0.55.0 test infra/k8s -p policies/opa --all-namespaces || true
  fi

  if [ -f artifacts/terraform-plan.json ]; then
    log "Conftest: terraform plan JSON"
    docker_run openpolicyagent/conftest:v0.55.0 test artifacts/terraform-plan.json -p policies/opa --all-namespaces || true
  else
    log "No artifacts/terraform-plan.json found (generate from terraform show -json)."
  fi
else
  log "No policies/opa directory. Skipping."
fi

log "Policy checks complete."
