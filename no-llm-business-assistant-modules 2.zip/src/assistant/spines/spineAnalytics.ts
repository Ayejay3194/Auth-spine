import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerAnalyticsTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "analytics.kpi",
    title: "KPIs",
    description: "Returns key business metrics.",
    inputSchema: { type: "object", properties: {} },
    async run(ctx, input) {
      const data = await p.analytics.kpis({});
      return { ok: true, data };
    }
  });

  reg.register({
    id: "analytics.report_export",
    title: "Export report",
    description: "Exports a report as CSV/JSON and returns a URL.",
    inputSchema: { type: "object", properties: { report: { type: "string" }, format: { type: "string" } }, required: ["report", "format"] },
    async run(ctx, input) {
      const data = await p.analytics.exportReport({ report: input.report, format: input.format });
      return { ok: true, data };
    }
  });
}
