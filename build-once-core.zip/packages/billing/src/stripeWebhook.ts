import crypto from "node:crypto";
import { getPrisma } from "@suite/db";
import { entitlementsForPlan } from "./entitlements.js";

/**
 * Minimal Stripe webhook verifier using the signing secret.
 * Use official stripe SDK in production if you want object expansion, but this works.
 */
export function verifyStripeSignature(rawBody: Buffer, sigHeader: string | undefined, secret: string) {
  if (!sigHeader) return false;
  const parts = Object.fromEntries(sigHeader.split(",").map(p => p.split("=").map(s => s.trim())));
  const t = parts["t"];
  const v1 = parts["v1"];
  if (!t || !v1) return false;
  const payload = `${t}.${rawBody.toString("utf8")}`;
  const mac = crypto.createHmac("sha256", secret).update(payload).digest("hex");
  // constant-time compare
  return timingSafeEqual(mac, v1);
}

function timingSafeEqual(a: string, b: string) {
  const ba = Buffer.from(a); const bb = Buffer.from(b);
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

export async function handleStripeEvent(event: any) {
  const prisma = getPrisma();
  const type = event.type;

  // You map stripe product/price IDs -> planKey in your config. Keeping it simple:
  const planKey = (event.data?.object?.metadata?.planKey || "free") as string;

  if (type === "customer.subscription.created" || type === "customer.subscription.updated") {
    const sub = event.data.object;
    const tenantId = sub.metadata?.tenantId;
    if (!tenantId) throw new Error("Missing tenantId in subscription metadata");
    await prisma.subscription.upsert({
      where: { providerSubId: sub.id },
      update: {
        tenantId,
        provider: "stripe",
        planKey,
        status: sub.status,
        currentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end * 1000) : null,
        entitlements: entitlementsForPlan(planKey),
      },
      create: {
        tenantId,
        provider: "stripe",
        providerSubId: sub.id,
        planKey,
        status: sub.status,
        currentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end * 1000) : null,
        entitlements: entitlementsForPlan(planKey),
      }
    });
  }

  if (type === "customer.subscription.deleted") {
    const sub = event.data.object;
    await prisma.subscription.updateMany({ where: { providerSubId: sub.id }, data: { status: "canceled" } });
  }

  return { ok: true };
}
