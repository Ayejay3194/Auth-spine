import { InMemoryEventBus } from "@suite/core-events";
import { InMemoryAuditStore } from "@suite/core-audit";
import { InMemoryEntitlements, type Plan } from "@suite/core-entitlements";
import { InMemoryRBAC } from "@suite/core-policy";
import { InMemorySlidingWindow } from "@suite/core-rate-limit";
import { InMemoryGdpr } from "@suite/core-gdpr";

import { InMemoryAnalytics } from "@suite/modules-analytics";
import { InMemoryFlags } from "@suite/modules-experiments";
import { EmailService } from "@suite/modules-email";
import { WebhookService } from "@suite/modules-webhooks";
import { NotificationService } from "@suite/modules-notifications";
import { PromoService } from "@suite/modules-promos";
import { ReferralService } from "@suite/modules-referrals";
import { CsvReportEngine } from "@suite/modules-reports";

import { ConsoleEmailAdapter } from "@suite/adapters-email-console";
import { InMemoryTemplateStore } from "@suite/adapters-email-inmemory-templates";
import { InMemoryWebhookStore, FetchWebhookDeliveryEngine } from "@suite/adapters-webhooks-inmemory";
import { ConsoleRealtimeAdapter } from "@suite/adapters-realtime-console";
import { InMemoryNotificationStore } from "@suite/adapters-notifications-inmemory";
import { InMemoryPromoStore } from "@suite/adapters-promos-inmemory";
import { InMemoryReferralStore } from "@suite/adapters-referrals-inmemory";

const bus = new InMemoryEventBus();
const audit = new InMemoryAuditStore();

const plans: Plan[] = [
  { id:"free", name:"Free", priceCentsMonthly:0, entitlements:{ "api": true, "api.requestsPerMin": 60, "reports.export.pdf": false } },
  { id:"pro", name:"Pro", priceCentsMonthly:1900, entitlements:{ "api": true, "api.requestsPerMin": 600, "reports.export.pdf": true } },
];
const subs = new Map<string, any>([
  ["u_1", { userId:"u_1", planId:"pro", status:"active" }],
  ["u_2", { userId:"u_2", planId:"free", status:"free" }],
]);

const entitlements = new InMemoryEntitlements(plans, subs);

const roles = [
  { id:"admin", name:"Admin", permissions:["audit.read","audit.export","billing.write","flags.write"] },
  { id:"user", name:"User", permissions:["profile.read"] },
];
const bindings = [
  { userId:"u_1", roleId:"admin" },
  { userId:"u_2", roleId:"user" },
];
const acl = new InMemoryRBAC(roles, bindings);

const limiter = new InMemorySlidingWindow();
const gdpr = new InMemoryGdpr(audit);

const analytics = new InMemoryAnalytics();
const flags = new InMemoryFlags([
  { key:"newDashboard", enabled:true, variants:["control","v1"], rules:[{kind:"percentage", pct:50}] }
], bus);

// Email setup
const templateStore = new InMemoryTemplateStore();
await templateStore.upsert({
  key: "type:welcome",
  subject: "Welcome, {{name}}",
  previewText: "Your account is ready.",
  html: "<h1>Welcome {{name}}</h1><p>Plan: {{plan}}</p>",
  text: "Welcome {{name}}. Plan: {{plan}}",
  variables: ["name","plan"],
  darkModeHtml: "<div style='background:#111;color:#fff;padding:16px'><h1>Welcome {{name}}</h1></div>"
});
const email = new EmailService(templateStore, new ConsoleEmailAdapter(), audit);

// Webhooks
const whStore = new InMemoryWebhookStore();
const whEngine = new FetchWebhookDeliveryEngine(whStore, audit);
const webhooks = new WebhookService(whStore, whEngine, audit);

// Notifications
const notifStore = new InMemoryNotificationStore();
const realtime = new ConsoleRealtimeAdapter();
const notifications = new NotificationService(notifStore, realtime, bus);

// Promos + referrals
const promoStore = new InMemoryPromoStore();
promoStore.seed({ code:"SAVE10", kind:"percent", amount:10, active:true, maxRedemptions: 100, perUserLimit: 1 });
const promos = new PromoService(promoStore);

const referralStore = new InMemoryReferralStore();
const referrals = new ReferralService(referralStore, audit);

// Reports
const reports = new CsvReportEngine();

// Demo flow
console.log("\n== Build-Once Suite Demo ==");

// Rate limit based on plan
const userId = "u_1";
const rpm = (await entitlements.get(userId, "api.requestsPerMin")) as number;
const res = await limiter.check(userId, { key:"api.default", windowSec:60, max:rpm });
console.log("Rate limit:", res);

// Flags
const assign = await flags.evaluate({ id:userId }, "newDashboard");
console.log("Flag assignment:", assign);

// Track event
await analytics.track({ id:"e1", userId, name:"page.view", ts:new Date().toISOString(), props:{ page:"/home" } });
console.log("Top events:", await analytics.topEvents(new Date(Date.now()-3600_000).toISOString(), new Date().toISOString(), 5));

// Promo validation
console.log("Promo:", await promos.validate(userId, "SAVE10", 5000));

// Referral
const code = await referrals.createCode("u_1");
await referrals.trackClick(code, { utm_source:"test" });
await referrals.attachSignup("u_999", code);
console.log("Referral code:", code);

// Email
await email.send("aj@example.com", "welcome", { name:"AJ", plan:(await entitlements.planForUser(userId)).name }, { useDark:true, actorUserId:userId });

// Notification
await notifications.publish(userId, { type:"system", title:"Your suite is alive", body:"This is a real-time notification.", url:"/inbox" });

// GDPR
console.log("GDPR export job:", await gdpr.requestExport(userId));
console.log("GDPR delete job:", await gdpr.requestDelete(userId, "deactivate"));

// Audit dump
console.log("\nRecent audit events:");
console.log((await audit.query({ limit: 10 })).map(a => ({ ts:a.ts, action:a.action, target:a.targetId, hash:a.hash })).slice(0,10));

// Report export
const bytes = await reports.generate({ type:"activity", filters:{ from:"today", plan:"pro" }, format:"csv" });
console.log("\nReport bytes:", bytes.length);
