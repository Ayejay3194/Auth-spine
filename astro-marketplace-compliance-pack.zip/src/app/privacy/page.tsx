import React from "react";
export default function PrivacyPage(){
  return (
    <main style={{maxWidth:760,margin:"40px auto",padding:16}}>
      <h1>Privacy Center</h1>
      <section style={{marginTop:24}}>
        <h2>Export your data</h2>
        <form action="/api/privacy/export" method="post"><button type="submit">Request export</button></form>
      </section>
      <section style={{marginTop:24}}>
        <h2>Delete your account</h2>
        <form action="/api/privacy/delete" method="post"><button type="submit">Delete account</button></form>
      </section>
    </main>
  );
}
