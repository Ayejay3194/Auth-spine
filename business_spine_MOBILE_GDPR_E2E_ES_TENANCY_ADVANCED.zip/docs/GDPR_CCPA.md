GDPR/CCPA endpoints in app/api/privacy/* and DSR model in prisma.
Worker stubs added in workers/worker.mjs.
