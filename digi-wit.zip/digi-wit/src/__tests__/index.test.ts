import test from "node:test";
import assert from "node:assert/strict";
import { DigiWitRouter } from "../router.js";
import { builtInIntents } from "../schemas.js";

// NOTE: this test is offline and does not call Wit.ai.
// It sanity-checks schema validation + receipt emission by monkeypatching the client call.

test("schema rejects invalid payload", async () => {
  const receipts: any[] = [];
  const router = new DigiWitRouter({
    accessToken: "dummy",
    confidenceFloor: 0.0,
    intents: builtInIntents,
    receiptSink: (r) => receipts.push(r),
  });

  // @ts-expect-error patch private field for unit test
  router["wit"].message = async () => ({
    text: "export pdf",
    intents: [{ name: "export_chart_pdf", confidence: 0.99 }],
    entities: {
      chartId: [{ value: "not-a-uuid", confidence: 0.99 }],
    },
  });

  const out = await router.parseAndValidate({ text: "export pdf", requestId: "req1" });
  assert.equal(out.ok, false);
  assert.equal(receipts.length, 1);
  assert.equal(receipts[0].result.accepted, false);
});

test("accepts valid payload and returns deterministic output", async () => {
  const receipts: any[] = [];
  const router = new DigiWitRouter({
    accessToken: "dummy",
    confidenceFloor: 0.0,
    intents: builtInIntents,
    receiptSink: (r) => receipts.push(r),
  });

  // @ts-expect-error patch private field for unit test
  router["wit"].message = async () => ({
    text: "export chart",
    intents: [{ name: "export_chart_pdf", confidence: 0.93 }],
    entities: {
      chartId: [{ value: "550e8400-e29b-41d4-a716-446655440000", confidence: 0.99 }],
      style: [{ value: "print", confidence: 0.9 }],
    },
  });

  const out = await router.parseAndValidate({ text: "export chart", userId: "u1", requestId: "req2" });
  assert.equal(out.ok, true);
  if (out.ok) {
    assert.equal(out.intent, "export_chart_pdf");
    assert.equal((out.payload as any).style, "print");
  }
  assert.equal(receipts[0].result.accepted, true);
});
