import { InMemoryFlagStore } from "./flags/in_memory_flag_store.js";
import { FeatureFlagController } from "./flags/flag_controller.js";
import { authDecision } from "./auth/policy.js";

const store = new InMemoryFlagStore();
const flags = new FeatureFlagController(store, "dev");

(async () => {
  const change = await flags.setFlag({ key: "feature.newDashboard", newValue: true, actorUserId: "admin_1", reason: "beta" });
  console.log("FlagChange", change);

  const decision = authDecision({
    tsISO: new Date().toISOString(),
    subjectUserId: "user_1",
    receipts: [
      { id: "r1", tsISO: new Date().toISOString(), kind: "auth", subjectUserId: "user_1", reasonCode: "FAILED_LOGIN_BURST", confidence: 1, weight: 12 }
    ]
  });
  console.log("AuthDecision", decision);
})();
