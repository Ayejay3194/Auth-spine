console.log("Smoke: repo boots. Add DATABASE_URL + STRIPE_SECRET_KEY then run prisma migrate.");
