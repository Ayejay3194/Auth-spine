export function multiIntentFlow() { return { ok: true }; }
