import { PrismaClient, Role } from '@prisma/client'
import { hashPassword } from '@auth-spine/auth'

const prisma = new PrismaClient()

async function main() {
  const adminEmail = 'admin@example.com'
  const adminPass = 'Admin123!'
  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      name: 'Admin',
      role: Role.ADMIN,
      password: await hashPassword(adminPass),
    },
  })

  console.log('Seeded admin:', admin.email)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
