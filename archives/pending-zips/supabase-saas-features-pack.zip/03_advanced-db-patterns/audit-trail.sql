-- Audit trail via trigger
create table if not exists audit_log (
  id bigserial primary key,
  tenant_id uuid,
  actor_user_id uuid,
  action text not null,
  table_name text not null,
  row_id text,
  before jsonb,
  after jsonb,
  created_at timestamptz default now()
);

create or replace function audit.if_modified()
returns trigger
language plpgsql
as $$
begin
  if (tg_op = 'UPDATE') then
    insert into audit_log(tenant_id, actor_user_id, action, table_name, row_id, before, after)
    values (app.current_tenant_id(), auth.uid(), 'UPDATE', tg_table_name, (new.id)::text, to_jsonb(old), to_jsonb(new));
    return new;
  elsif (tg_op = 'INSERT') then
    insert into audit_log(tenant_id, actor_user_id, action, table_name, row_id, before, after)
    values (app.current_tenant_id(), auth.uid(), 'INSERT', tg_table_name, (new.id)::text, null, to_jsonb(new));
    return new;
  elsif (tg_op = 'DELETE') then
    insert into audit_log(tenant_id, actor_user_id, action, table_name, row_id, before, after)
    values (app.current_tenant_id(), auth.uid(), 'DELETE', tg_table_name, (old.id)::text, to_jsonb(old), null);
    return old;
  end if;
  return null;
end;
$$;

-- Example attach:
-- create trigger workspaces_audit
-- after insert or update or delete on workspaces
-- for each row execute function audit.if_modified();
