// Edge Function: webhook-handler (Deno)
// Pattern: verify signature + idempotency + async processing stub
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

async function hmacSHA256(key: string, msg: string) {
  const enc = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(key),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(msg));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

serve(async (req) => {
  const secret = Deno.env.get("WEBHOOK_SECRET") ?? "";
  const raw = await req.text();
  const provided = req.headers.get("x-signature") ?? "";

  if (!secret) return new Response("missing WEBHOOK_SECRET", { status: 500 });

  const expected = await hmacSHA256(secret, raw);
  if (expected !== provided) return new Response("invalid signature", { status: 401 });

  // TODO: idempotency key (event id), store in DB table to dedupe
  // TODO: enqueue for async processing (queue/cron pattern) if heavy

  return new Response("ok", { status: 200 });
});
