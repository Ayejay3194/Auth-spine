# conversational-nlu

A minimal conversational NLU skeleton: classify -> validate -> policy -> render -> receipt.

## Structure
- `conversation/` orchestration, policy, state, rendering, receipts
- `nlu/` classifier + schema + validators
- `flows/` intent flows
- `tools/` helpers / adapters
- `tests/` test stubs

## Notes
This repo is intentionally tiny. Swap stubs for your real implementations.
