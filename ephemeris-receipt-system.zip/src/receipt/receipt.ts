
import { EphemerisReceipt } from "./types.js";
import { hashInputsForReceipt, assertNoPIIKeys } from "./redaction.js";
import { sha256Hex } from "./crypto.js";

export type ReceiptCreateArgs = {
  requestId: string;
  product: string;      // "natal" | "transits" | etc
  body: string;         // "Earth" | "Mars" | etc

  // Provenance
  kernel: {
    de: string;
    spkSha256: string;
    coverageStart: string;
    coverageEnd: string;
    segmentId: string;
    chebyshevDegree: number;
    subintervalDays: number;
  };
  time: {
    inputScale: "UTC" | "TAI" | "TT" | "TDB";
    internalScale: "UTC" | "TAI" | "TT" | "TDB";
    leapSecondsSha256: string;
    deltaTModel: string;
    tzdbVersion: string;
  };
  iau: {
    precession: string;
    nutation: string;
    eop: string;
  };
  build: {
    gitSha: string;
    buildId: string;
    engineVersion: string;
    platform: string;
  };

  // Inputs/Outputs (redacted)
  rawInputs: unknown;
  outputSchema: string;
  outputObjectForHash: unknown;
  outputSummary?: EphemerisReceipt["output"]["summary"];

  validation: {
    pass: boolean;
    goldenVectorId?: string;
    goldenMaxAbsError?: number;
    horizonsSnapshotSha256?: string;
    notes?: string;
  };
};

export function createUnsignedReceipt(args: ReceiptCreateArgs): Omit<EphemerisReceipt, "ledger"> {
  const { inputSha256 } = hashInputsForReceipt(args.rawInputs);

  // enforce: no PII-ish keys in output summary
  assertNoPIIKeys((args.outputSummary ?? {}) as any);

  const outputSha256 = sha256Hex(JSON.stringify(args.outputObjectForHash));

  return {
    receiptVersion: "1.0",
    createdAt: new Date().toISOString(),
    input: {
      requestId: args.requestId,
      inputSha256,
      body: args.body,
      product: args.product,
    },
    kernel: args.kernel,
    time: args.time,
    iau: args.iau,
    build: args.build,
    output: {
      outputSha256,
      outputSchema: args.outputSchema,
      summary: args.outputSummary ?? {},
    },
    validation: {
      pass: args.validation.pass,
      goldenVectorId: args.validation.goldenVectorId,
      goldenMaxAbsError: args.validation.goldenMaxAbsError,
      horizonsSnapshotSha256: args.validation.horizonsSnapshotSha256,
      notes: args.validation.notes,
    },
  };
}
