import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Create plans
  const freePlan = await prisma.plan.upsert({
    where: { slug: 'free' },
    update: {},
    create: {
      name: 'Free',
      slug: 'free',
      price: 0,
      interval: 'MONTHLY',
      features: {
        maxProjects: 3,
        maxMembersPerWorkspace: 5,
        advancedFeatures: false,
        prioritySupport: false,
        customIntegrations: false,
        apiAccess: false,
      },
      isActive: true,
    },
  })

  const proPlan = await prisma.plan.upsert({
    where: { slug: 'pro' },
    update: {},
    create: {
      name: 'Pro',
      slug: 'pro',
      price: 2900, // $29.00
      interval: 'MONTHLY',
      features: {
        maxProjects: 50,
        maxMembersPerWorkspace: 20,
        advancedFeatures: true,
        prioritySupport: true,
        customIntegrations: true,
        apiAccess: true,
      },
      isActive: true,
    },
  })

  const enterprisePlan = await prisma.plan.upsert({
    where: { slug: 'enterprise' },
    update: {},
    create: {
      name: 'Enterprise',
      slug: 'enterprise',
      price: 9900, // $99.00
      interval: 'MONTHLY',
      features: {
        maxProjects: 'Unlimited',
        maxMembersPerWorkspace: 'Unlimited',
        advancedFeatures: true,
        prioritySupport: true,
        customIntegrations: true,
        apiAccess: true,
      },
      isActive: true,
    },
  })

  console.log('Plans created:', { freePlan, proPlan, enterprisePlan })
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })