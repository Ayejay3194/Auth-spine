export interface ClockPort { nowIso(): string; nowMs(): number; }
