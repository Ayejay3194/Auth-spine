import type { AuditLogger, Clock, AgentContext, AssistantState, AssistantHandleResult } from "./runtimeTypes.js";
import { Orchestrator } from "../core/orchestrator.js";
import type { AssistantContext } from "../core/types.js";
import { IntentDetector } from "./nlu/intents.js";
import { loadAllSpines } from "./spines/index.js";
import { InMemorySessionStore } from "./storage/sessionStore.js";
import { SimplePolicyEngine } from "./policy/simplePolicy.js";
import { SimpleTracer } from "./obs/simpleTracer.js";

import { bookingSpine, crmSpine, paymentsSpine, marketingSpine, analyticsSpine, admin_securitySpine } from "../spines/index.js";

export type Providers = Parameters<typeof loadAllSpines>[0]["providers"];

export function buildAssistantRuntime(opts: {
  providers: Providers;
  audit: AuditLogger;
  clock: Clock;
  rateStore?: InMemorySessionStore<{ count: number }>;
  slotCache?: InMemorySessionStore<any>;
}) {
  const tracer = new SimpleTracer();
  const rateStore = opts.rateStore ?? new InMemorySessionStore<{ count: number }>();
  const slotCache = opts.slotCache ?? new InMemorySessionStore<any>();

  const { tools } = loadAllSpines({ providers: opts.providers, slotCache });

  const policy = new SimplePolicyEngine(rateStore, {
    allow: {
      owner: Object.keys(tools),
      staff: Object.keys(tools),
      assistant: Object.keys(tools),
      accountant: Object.keys(tools),
      admin: Object.keys(tools),
      system: [],
    },
    rate: { windowSeconds: 10, max: 60 },
    confirmIntents: [
      "booking.create",
      "booking.cancel",
      "payments.create_invoice",
      "payments.refund",
      "marketing.create_promo",
      "marketing.send_campaign",
      "analytics.report_export",
      "gdpr.export_request",
      "admin.show_audit",
    ],
  });

  const detector = new IntentDetector(
    [
      { intent: "booking.create", any: ["book", "schedule", "appointment"], all: [] },
      { intent: "booking.cancel", any: ["cancel"], all: [] },
      { intent: "booking.list", any: ["my bookings", "upcoming", "appointments", "list bookings"], all: [] },

      { intent: "crm.find_client", any: ["find client", "look up client", "client"], all: [] },
      { intent: "crm.add_note", any: ["add note", "note"], all: [] },

      { intent: "payments.create_invoice", any: ["invoice", "bill"], all: [] },
      { intent: "payments.refund", any: ["refund"], all: [] },

      { intent: "marketing.create_promo", any: ["promo", "discount"], all: [] },
      { intent: "marketing.send_campaign", any: ["campaign", "broadcast", "text everyone"], all: [] },

      { intent: "analytics.kpi", any: ["kpi", "metrics", "revenue", "how did i do"], all: [] },
      { intent: "analytics.report_export", any: ["export", "download report"], all: [] },

      { intent: "ops.list_tasks", any: ["tasks", "to do"], all: [] },
      { intent: "ops.create_task", any: ["create task", "remind me", "add task"], all: [] },

      { intent: "gdpr.export_request", any: ["gdpr", "export my data"], all: [] },
      { intent: "admin.show_audit", any: ["audit log", "show audit"], all: [] },
    ],
    [
      { intent: "booking.create", utterance: "book me an appointment next tuesday evening" },
      { intent: "payments.create_invoice", utterance: "create an invoice for $75 for client cl_1" },
      { intent: "marketing.create_promo", utterance: "make promo promo_new10 for 10 percent off" },
      { intent: "analytics.kpi", utterance: "show my revenue this week" },
      { intent: "ops.list_tasks", utterance: "show my tasks" },
    ],
    { minScore: 0.30 }
  );

  // Core kernel orchestrator (existing deterministic flows/spines)
  const kernel = new Orchestrator({
    spines: [bookingSpine, crmSpine, paymentsSpine, marketingSpine, analyticsSpine, admin_securitySpine],
    tools,
  });

  async function handle(ctxIn: AgentContext, state: AssistantState, text: string): Promise<AssistantHandleResult> {
    tracer.event("assistant.message", { intentHint: undefined, userId: ctxIn.userId });

    const picked = detector.detect(text)[0];
    if (!picked) {
      return {
        state,
        reply: { text: "Unknown command. Try: book, cancel, invoice, refund, tasks, audit.", done: true },
      };
    }

    const pol = await policy.check(ctxIn, picked.intent);
    if (!pol.allow) {
      await opts.audit.write({
        businessId: ctxIn.businessId,
        actorId: ctxIn.userId,
        role: String(ctxIn.role),
        type: "policy.block",
        at: opts.clock.now(),
        details: { intent: picked.intent, reason: pol.reason },
      });
      return { state, reply: { text: `Blocked: ${pol.reason}`, done: true } };
    }

    // Bridge to kernel context
    const kctx: AssistantContext = {
      tenantId: ctxIn.businessId,
      nowISO: opts.clock.now().toISOString(),
      actor: { userId: ctxIn.userId, role: (ctxIn.role as any) },
      timezone: ctxIn.timezone,
      locale: ctxIn.locale,
      channel: (ctxIn.channel as any) ?? "api",
    };

    // Confirmation handling: if user sent a token, pass it through
    let confirmToken: string | undefined;
    const tokenMatch = text.match(/\bconfirm_[a-z0-9]+\b/i);
    if (tokenMatch) confirmToken = tokenMatch[0];

    // Also allow using stored pending token (if user just says "yes")
    if (!confirmToken && state.pendingConfirm && /\byes\b|\bconfirm\b/i.test(text)) {
      confirmToken = state.pendingConfirm.token;
    }

    const res = await kernel.handle(text, kctx, { confirmToken });

    // If kernel requested a confirmation token, persist it
    const payload: any = res.final?.payload;
    if (payload?.confirmToken) {
      const nextState: AssistantState = { ...state, pendingConfirm: { token: payload.confirmToken, lastText: text } };
      await opts.audit.write({
        businessId: ctxIn.businessId,
        actorId: ctxIn.userId,
        role: String(ctxIn.role),
        type: "confirm.requested",
        at: opts.clock.now(),
        details: { intent: picked.intent, token: payload.confirmToken },
      });
      return { state: nextState, reply: { text: String(res.final?.message ?? "Confirm?"), ui: { type: "confirm", token: payload.confirmToken }, done: false } };
    }

    // Clear pending confirm on successful completion
    const done = Boolean(res.final?.ok);
    const nextState: AssistantState = done ? { ...state, pendingConfirm: undefined } : state;

    await opts.audit.write({
      businessId: ctxIn.businessId,
      actorId: ctxIn.userId,
      role: String(ctxIn.role),
      type: "assistant.result",
      at: opts.clock.now(),
      details: { intent: picked.intent, ok: res.final?.ok, message: res.final?.message },
    });

    return {
      state: nextState,
      reply: { text: String(res.final?.message ?? "Done"), ui: res.final?.payload ?? null, done: true },
    };
  }

  return { assistant: { handle } };
}
