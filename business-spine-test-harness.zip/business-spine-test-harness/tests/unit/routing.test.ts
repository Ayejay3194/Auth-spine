import { describe, test, expect } from "vitest";

describe("Routing registry", () => {
  test("expected routes exist on ApiServer (no network)", async () => {
    const { createBusinessSpine, ApiServer } = await import("../../dist/index.js");

    const spine = await createBusinessSpine({ tenantId: "routing-test" });
    try {
      const server = new ApiServer(spine);

      // Assumes ApiServer exposes a route registry or router stack.
      // If you don't have this, add `server.listRoutes()` and this test becomes real.
      const listRoutes = (server as any).listRoutes?.bind(server);

      if (!listRoutes) {
        // Minimal assertion: construction doesn't throw and core endpoints exist by convention.
        expect(server).toBeDefined();
        return;
      }

      const routes = listRoutes() as Array<{ method: string; path: string }>;

      const expected = [
        { method: "GET", path: "/health" },
        { method: "GET", path: "/api/system/info" },
        { method: "POST", path: "/api/chat" },
        { method: "POST", path: "/api/intent" },
        { method: "POST", path: "/api/suggestions" },
        { method: "GET", path: "/api/spines" },
        { method: "GET", path: "/api/tools" },
        { method: "GET", path: "/api/plugins" }
      ];

      for (const e of expected) {
        expect(routes.some(r => r.method === e.method && r.path === e.path)).toBe(true);
      }
    } finally {
      await spine.shutdown?.();
    }
  });
});