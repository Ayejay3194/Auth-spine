export type LogLevel = "debug" | "info" | "warn" | "error";
const order: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40 };

function should(level: LogLevel) {
  const env = (process.env.LOG_LEVEL as LogLevel) || "info";
  return order[level] >= order[env];
}

function redact(v: unknown): unknown {
  if (v == null) return v;
  if (typeof v === "string") {
    if (v.includes("@")) return "[REDACTED_EMAIL]";
    if (v.length > 32 && /[A-Za-z0-9_-]{32,}/.test(v)) return "[REDACTED_TOKEN]";
    return v;
  }
  if (Array.isArray(v)) return v.map(redact);
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(o)) {
      const key = k.toLowerCase();
      if (["password","token","secret","authorization","cookie"].some(x=>key.includes(x))) out[k]="[REDACTED]";
      else if (["email","birth","dob","address","phone","lat","lon"].some(x=>key.includes(x))) out[k]="[REDACTED_PII]";
      else out[k]=redact(val);
    }
    return out;
  }
  return v;
}

export function log(level: LogLevel, msg: string, meta?: Record<string, unknown>) {
  if (!should(level)) return;
  console.log(JSON.stringify({ ts: new Date().toISOString(), level, msg, meta: meta ? redact(meta) : undefined }));
}

export const logger = {
  info: (m: string, meta?: Record<string, unknown>) => log("info", m, meta),
  warn: (m: string, meta?: Record<string, unknown>) => log("warn", m, meta),
  error: (m: string, meta?: Record<string, unknown>) => log("error", m, meta),
};
