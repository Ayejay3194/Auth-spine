from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, List
from .schemas import ParseRequest, ParseResponse, IntentOut, EntityOut, TrainExample
from .config import MODEL_PATH
from .training_store import read_training, append_example
from .model import load_model, train_intent_model, save_model, predict_intents
from .extractors import extract_entities

app = FastAPI(title="Wit-like NLU", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

MODEL = load_model(MODEL_PATH)

LOOKUPS: Dict[str, List[str]] = {
    "service": ["haircut", "balayage", "braids", "consultation"],
    "plan": ["free", "pro", "enterprise"],
}

@app.get("/health")
def health():
    return {"ok": True, "has_model": MODEL is not None}

@app.post("/examples")
def add_example(ex: TrainExample):
    append_example(ex.model_dump())
    return {"ok": True}

@app.post("/train")
def train():
    global MODEL
    examples = read_training()
    if len(examples) < 3:
        raise HTTPException(status_code=400, detail="Need at least 3 examples to train.")
    MODEL = train_intent_model(examples)
    save_model(MODEL, MODEL_PATH)
    return {"ok": True, "examples": len(examples)}

@app.post("/parse", response_model=ParseResponse)
def parse(req: ParseRequest):
    global MODEL
    text = req.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Empty text.")

    ents = extract_entities(text, LOOKUPS)
    entities_out = [EntityOut(**e) for e in ents]

    if MODEL is None:
        lowered = text.lower()
        guess = "smalltalk"
        if any(k in lowered for k in ["book", "schedule", "appointment"]):
            guess = "booking.create"
        elif any(k in lowered for k in ["reschedule", "move", "change time"]):
            guess = "booking.reschedule"
        intents = [(guess, 0.51), ("smalltalk", 0.49)]
    else:
        intents = predict_intents(MODEL, text, top_k=5)

    best = intents[0]
    return ParseResponse(
        text=text,
        intent=IntentOut(name=best[0], confidence=float(best[1])),
        intents=[IntentOut(name=n, confidence=float(c)) for n,c in intents],
        entities=entities_out,
    )

if __name__ == "__main__":
    import os
    import uvicorn
    port = int(os.getenv("PORT", "8008"))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=False)
