# Solari GenAI Kit — v4 (token pressure + architecture criteria + retrain triggers)

Adds:
- **Token pressure evals** (truncation, long JSON, unicode, long numbers)
- **Tokenizer consistency check** (train vs serve mismatch detector)
- **Architecture selection criteria** (what to pick and why, for your use case)
- **Auto retrain triggers** (when evals cross thresholds, harvest failures -> training set + print exact commands)

Generated: 2026-02-26T01:07:50.264944Z
