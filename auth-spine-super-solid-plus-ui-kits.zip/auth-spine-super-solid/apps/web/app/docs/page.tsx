import fs from 'node:fs'
import path from 'node:path'

function mdToHtml(md: string) {
  // tiny markdown-ish renderer (no deps). good enough for headings/paras.
  return md
    .split('\n\n')
    .map(block => {
      if (block.startsWith('# ')) return `<h1 class="text-3xl font-bold mb-4">${block.slice(2)}</h1>`
      if (block.startsWith('## ')) return `<h2 class="text-xl font-semibold mt-6 mb-2">${block.slice(3)}</h2>`
      if (block.startsWith('- ')) {
        const items = block.split('\n').map(l => l.replace(/^- /,'').trim())
        return `<ul class="list-disc pl-6 space-y-1">${items.map(i => `<li>${i}</li>`).join('')}</ul>`
      }
      return `<p class="text-slate-700 leading-relaxed">${block.replace(/\n/g,'<br/>')}</p>`
    })
    .join('\n')
}

export default function DocsPage() {
  const mdPath = path.join(process.cwd(), 'src/docs/implementation-plan.md')
  const md = fs.readFileSync(mdPath, 'utf-8')
  const html = mdToHtml(md)

  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <div dangerouslySetInnerHTML={{ __html: html }} />
    </div>
  )
}
