import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const results = [];
function push(check, status, message){ results.push({check, status, message}); }

function check(name, fn, okMsg){
  try{
    fn();
    push(name, "pass", okMsg);
  } catch (e){
    push(name, "fail", e?.message || String(e));
  }
}

check("Env example exists", () => {
  const p = path.join(process.cwd(), "apps/web/.env.example");
  if(!fs.existsSync(p)) throw new Error("Missing apps/web/.env.example");
}, "apps/web/.env.example present");

check("No obvious hardcoded secrets", () => {
  const cmd = `git grep -nE "(password|secret|api[_-]?key|token)\\s*=\\s*['\\\"][^'\\\"]+['\\\"]" -- . ":!node_modules" ":!.next" || true`;
  const out = execSync(cmd, { encoding: "utf8" }).trim();
  if(out) throw new Error("Potential secrets found:\n" + out);
}, "No obvious secrets committed");

check("npm audit (high)", () => {
  try{
    execSync("npm audit --audit-level=high", { stdio: "ignore" });
  } catch {
    throw new Error("npm audit reported high+ vulnerabilities");
  }
}, "No high+ vulns (per npm audit)");

console.log("\n🔒 Security Audit Results\n");
for(const r of results){
  const icon = r.status === "pass" ? "✅" : "❌";
  console.log(`${icon} ${r.check}: ${r.message}`);
}
const failed = results.filter(r => r.status === "fail").length;
if(failed){
  console.log(`\n❌ ${failed} checks failed\n`);
  process.exit(1);
}
console.log("\n✅ All checks passed\n");
