export type FileRef = {
  path: string;   // relative to lake root
  sha256: string;
  rows?: number;
};

export type Commit = {
  commitVersion: "1";
  id: string;               // sha256 of payload (stable)
  table: string;            // dataset/table name
  tableVersion: string;     // v1, v2 (table lineage)
  parent?: string;          // previous commit id
  createdAtISO: string;
  schemaVersion: string;

  // "actions"
  add: FileRef[];
  remove?: { path: string }[];

  // metadata
  generator: string;
  message?: string;
  tags?: string[];
};

export type Head = {
  table: string;
  tableVersion: string;
  head: string | null;      // current commit id
  updatedAtISO: string;
};
