# Vibe Coding Disasters Kit

Because “move fast and break things” is cute until you’re the one doing incident response.

## Contents
- `VIBE_CODING_DISASTERS.md`: master checklist
- `modules/`: split-by-area checklists
- `structured/`: JSON + JSONL risk register for building UI/workflows
- `templates/`: PR/release/CI guardrails

## Quick use
1) Drop `templates/PR_CHECKLIST.md` into your repo.
2) Make PRs fail if any CRITICAL/HIGH item applies and isn’t addressed.
3) Use `structured/risk_register.json` to generate an internal “preflight” checklist UI.

## Modules
- `modules/analytics_tracking_disasters.md`
- `modules/configuration_settings_disasters.md`
- `modules/cron_scheduled_tasks_disasters.md`
- `modules/database_disasters.md`
- `modules/edge_cases_rare_failures.md`
- `modules/email_notifications_disasters.md`
- `modules/financial_business_disasters.md`
- `modules/import_export_disasters.md`
- `modules/legal_compliance_disasters.md`
- `modules/localization_i18n_disasters.md`
- `modules/migration_disasters.md`
- `modules/mobile_disasters.md`
- `modules/multi_tenancy_disasters.md`
- `modules/operational_disasters.md`
- `modules/queue_background_jobs_disasters.md`
- `modules/search_filtering_disasters.md`
- `modules/security_vulnerabilities.md`
- `modules/websocket_realtime_disasters.md`
