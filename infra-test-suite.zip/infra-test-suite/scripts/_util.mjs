import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import YAML from "yaml";

export function readJson(p){
  return JSON.parse(fs.readFileSync(p,"utf-8"));
}

export function exists(p){ try { fs.accessSync(p); return true; } catch { return false; } }

export function findFiles(dir, exts){
  const out=[];
  if(!exists(dir)) return out;
  const walk=(d)=>{
    for(const ent of fs.readdirSync(d,{withFileTypes:true})){
      const p=path.join(d,ent.name);
      if(ent.isDirectory()) walk(p);
      else if(exts.some(e=>p.toLowerCase().endsWith(e))) out.push(p);
    }
  };
  walk(dir);
  return out;
}

export function readText(p){ return fs.readFileSync(p,"utf-8"); }

export function parseYaml(p){
  return YAML.parse(readText(p));
}

export async function run(cmd, args, opts={}){
  return new Promise((resolve)=>{
    const child = spawn(cmd, args, { stdio:"inherit", shell: process.platform==="win32", ...opts });
    child.on("close",(code)=>resolve(code ?? 1));
  });
}

export async function runCapture(cmd, args, opts={}){
  return new Promise((resolve)=>{
    const child = spawn(cmd, args, { stdio:["ignore","pipe","pipe"], shell: process.platform==="win32", ...opts });
    let stdout="", stderr="";
    child.stdout.on("data",(d)=>stdout+=d.toString());
    child.stderr.on("data",(d)=>stderr+=d.toString());
    child.on("close",(code)=>resolve({ code: code ?? 1, stdout, stderr }));
  });
}

export function section(title){
  console.log("\n========================================");
  console.log(title);
  console.log("========================================\n");
}

export function fail(msg){
  console.error("❌ " + msg);
  process.exitCode = 1;
}

export function ok(msg){
  console.log("✅ " + msg);
}
