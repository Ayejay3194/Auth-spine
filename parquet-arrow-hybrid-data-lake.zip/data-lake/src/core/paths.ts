import path from "node:path";

export type WarehouseConfig = {
  root: string;           // e.g. ./warehouse
  dataset: string;        // e.g. de440_residuals
  datasetVersion: string; // e.g. v1
};

export function datasetRoot(cfg: WarehouseConfig) {
  return path.join(cfg.root, `dataset=${cfg.dataset}`, `ver=${cfg.datasetVersion}`);
}

export function dayPartitionDir(cfg: WarehouseConfig, dayISO: string) {
  return path.join(datasetRoot(cfg), `day=${dayISO}`);
}

export function partFile(cfg: WarehouseConfig, dayISO: string, part: number) {
  return path.join(dayPartitionDir(cfg, dayISO), `part-${String(part).padStart(4, "0")}.parquet`);
}
