export type SAMLConfig = { entryPoint: string; issuer: string; callbackUrl: string; cert: string };

export function samlLoginUrl(cfg: SAMLConfig, relayState?: string): string {
  const u = new URL(cfg.entryPoint);
  if (relayState) u.searchParams.set("RelayState", relayState);
  return u.toString();
}
