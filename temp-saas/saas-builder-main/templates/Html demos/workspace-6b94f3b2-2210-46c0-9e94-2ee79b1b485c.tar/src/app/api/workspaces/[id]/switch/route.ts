import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { db } from '@/lib/db'
import { ROLE_PERMISSIONS } from '@/lib/permissions'

// POST /api/workspaces/[id]/switch - Switch active workspace
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
        { status: 401 }
      )
    }

    const membership = await db.workspaceMember.findUnique({
      where: {
        userId_workspaceId: {
          userId: session.user.id,
          workspaceId: params.id
        }
      },
      include: {
        workspace: true
      }
    })

    if (!membership) {
      return NextResponse.json(
        { success: false, error: { code: 'NOT_FOUND', message: 'Workspace not found' } },
        { status: 404 }
      )
    }

    const permissions = ROLE_PERMISSIONS[membership.role]

    return NextResponse.json({
      success: true,
      data: {
        workspace: membership.workspace,
        membership,
        permissions
      }
    })
  } catch (error) {
    console.error('Failed to switch workspace:', error)
    return NextResponse.json(
      { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to switch workspace' } },
      { status: 500 }
    )
  }
}