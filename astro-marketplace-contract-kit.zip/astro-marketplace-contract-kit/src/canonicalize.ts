import { ChartDataV1 } from './types.js';

/**
 * AMJCS-1 (Astro Marketplace JSON Canonical String v1)
 * Goal: produce a byte-identical string for the same semantic chart.
 *
 * Rules:
 * - Objects: keys sorted lexicographically (UTF-16 code unit order, JS default)
 * - Arrays: order preserved
 * - Numbers: normalized to fixed precision strings, then treated as strings in canonical output
 * - Strings: unchanged
 * - Undefined: omitted (like JSON)
 */

const NUMBER_KEYS = new Set([
  'lat',
  'lon',
  'degree',
  'minute',
  'second',
  'timezoneOffsetMinutes',
  'orbDeg'
]);

export interface CanonicalizeOptions {
  numberPrecision?: number; // default 8
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

function normalizeNumber(n: number, precision: number): string {
  if (!Number.isFinite(n)) return 'null';
  // Fixed precision, but trim trailing zeros and trailing dot.
  const fixed = n.toFixed(precision);
  return fixed.replace(/\.0+$/, '').replace(/(\.[0-9]*?)0+$/, '$1');
}

function walk(value: unknown, precision: number, keyHint?: string): unknown {
  if (value === null) return null;
  if (Array.isArray(value)) return value.map((v) => walk(v, precision));
  if (typeof value === 'number') {
    // If the key is known numeric, normalize; else still normalize to avoid 1 vs 1.0 drift.
    return normalizeNumber(value, precision);
  }
  if (typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'undefined') return undefined;

  if (isPlainObject(value)) {
    const out: Record<string, unknown> = {};
    const keys = Object.keys(value).sort();
    for (const k of keys) {
      const v = (value as Record<string, unknown>)[k];
      if (typeof v === 'undefined') continue;
      // Key-hint is mostly for readability, but we still normalize all numbers.
      out[k] = walk(v, precision, k);
    }
    return out;
  }

  // Dates, BigInt, etc: stringify so they don't explode determinism.
  return String(value);
}

/** Returns the canonical JSON string used for hashing and golden tests. */
export function canonicalizeChart(chart: ChartDataV1, opts: CanonicalizeOptions = {}): string {
  const precision = opts.numberPrecision ?? 8;
  const normalized = walk(chart, precision);
  return JSON.stringify(normalized);
}
