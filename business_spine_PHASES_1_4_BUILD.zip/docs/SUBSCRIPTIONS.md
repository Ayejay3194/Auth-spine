Subscription routes under /api/billing/subscription/* (stub). Wire to Stripe webhooks later.
