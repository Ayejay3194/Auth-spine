# Prompt: Monorepo Assembly & Wiring
[Use inside editor to move files, update imports, keep INTEGRATION_LOG.md.]
