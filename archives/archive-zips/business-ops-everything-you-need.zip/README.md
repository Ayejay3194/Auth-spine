# Business Operations & Accounting Spine

This kit contains everything needed to run business operations, accounting, payroll hooks, reporting, and admin control.
