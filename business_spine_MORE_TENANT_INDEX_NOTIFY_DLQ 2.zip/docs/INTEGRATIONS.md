Integration model is scaffolded. Store tokens in Integration.meta; sync via queue.
