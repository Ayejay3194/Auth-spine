# Routing Diagram

```mermaid
flowchart TD
  A[User text] --> B[NLU: intent/entities/confidence]
  B --> C[Tone Arbiter]
  C --> D[Escalation / De-escalation]
  D --> E[Memory Dampener (rate limit)]
  E --> F[Interpretation Mapper (signals -> style)]
  F --> G[Persona Filter (caps/consistency)]
  G --> H[Quote/Template Selector]
  H --> I[Interpretation Layer (content generation)]
  I --> J[Final Response]
```

## Practical notes

- **NLU is not the personality.** It's just routing metadata.
- **Tone Arbiter** decides *tone level* from intent + confidence + user tolerance + recent behavior.
- **Memory Dampener** stops the assistant from repeatedly being snide (the #1 way people quit).
- **Interpretation Mapper** is where your astrology/HD/pattern signals modulate delivery without corrupting meaning.
- **Persona Filter** is your last line of defense for consistency and sensitive-topic caps.
