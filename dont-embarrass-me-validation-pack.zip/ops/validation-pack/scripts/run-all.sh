#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/out"
mkdir -p "$OUT"

echo "== Validation Pack =="
echo "ROOT: $ROOT"
echo "OUT:  $OUT"

bash "$ROOT/scripts/00-env-check.sh"
bash "$ROOT/scripts/10-deps-audit.sh"
bash "$ROOT/scripts/20-zap-baseline.sh"
bash "$ROOT/scripts/30-api-abuse-tests.sh"
bash "$ROOT/scripts/40-load-test.sh"
bash "$ROOT/scripts/50-ops-drills.sh"
node "$ROOT/scripts/90-make-receipt.mjs"

echo "✅ Done. See:"
echo " - $OUT/receipt.json"
echo " - $OUT/receipt.md"
