Decans Ops Spine v2 JSONL
========================

File: decans_ops_spine_v2.jsonl
Records: 147

Purpose:
- Operations spine for Decans (release governance, incidents, billing, tenancy, security, moderation, observability).
- Enforces a strict response contract:
  Decision → Steps → Risk notes → Rollback plan
- Includes BLOCK RELEASE and BLOCKED patterns for unsafe actions.

Format:
- JSONL, each line is an object with `messages` array (system/user/assistant).

Suggested use:
- Fine-tuning dataset OR retrieval corpus for an ops-assistant router.
- Route admin-panel “help me decide” prompts through this spine.
