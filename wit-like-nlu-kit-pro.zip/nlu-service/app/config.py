from pydantic import BaseModel
import os

class Settings(BaseModel):
    data_dir: str = os.getenv("NLU_DATA_DIR", "data")
    model_dir: str = os.getenv("NLU_MODEL_DIR", "models")
    max_examples: int = int(os.getenv("NLU_MAX_EXAMPLES", "20000"))

settings = Settings()
