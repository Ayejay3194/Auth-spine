# Advanced NLU Kit (TypeScript)

This is a lightweight, dependency-minimal NLU + dialogue-state kit for Next.js/React apps.

What you get:
- Intent routing (keywords + example retrieval + optional LLM judge stub)
- Entity extraction (regex + dictionary) + normalization
- Dialogue state + slot filling + clarifying questions
- Session memory + context carry ("there", "tomorrow", "same time")
- Model store (JSON export/import, versioning)
- Evaluation harness (basic metrics)

## Drop-in
Copy `src/nlu` into your project.

## Next.js API
- App Router: `app/api/nlu/route.ts` (provided in this kit)
- Pages Router: `pages/api/nlu.ts` (provided too)

## Configure
Edit `src/nlu/model/defaultModel.ts` to add intents/entities and slot rules.

## Use (client)
```ts
import { analyzeTurn } from "@/nlu";

const out = await analyzeTurn({
  text: "Book me a flight to SF next Friday",
  sessionId: "demo",
});
console.log(out.reply.text, out.nlu, out.state);
```

## Notes
- `llmJudge.ts` is a stub by default. Wire it to your provider if you want.
- `embeddingRetrieve.ts` uses a simple token TF-IDF-ish similarity (no deps).
