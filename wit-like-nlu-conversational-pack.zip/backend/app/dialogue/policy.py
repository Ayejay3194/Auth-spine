import uuid
from .intents import INTENT_SLOTS, CONFIRM_INTENTS

LOW_CONF = 0.55
SLOT_CONF_MIN = 0.70

SLOT_QUESTIONS = {
  "service": "What service are you trying to book?",
  "date": "What day do you want it?",
  "time": "What time?",
  "stylist": "Any stylist preference?",
  "appointment_id": "What appointment are we canceling? (share the ID)",
}

FALLBACK_SUGGESTIONS = ["Book an appointment", "Check pricing", "See business hours"]

def choose_intent(nlu: dict):
    top = (nlu.get("intents") or [{"name":"fallback","confidence":0.2}])[0]
    return top["name"], float(top.get("confidence", 0.0))

def merge_entities_into_slots(state: dict, entities: list[dict]) -> dict:
    slots = dict(state.get("slots") or {})
    for e in entities:
        if float(e.get("confidence", 0.0)) < SLOT_CONF_MIN:
            continue
        slots[e["name"]] = e["value"]
    state["slots"] = slots
    return state

def next_action(state: dict, text: str, nlu: dict) -> dict:
    intent, intent_conf = choose_intent(nlu)

    # Smalltalk -> immediate response
    if intent.startswith("smalltalk."):
        return {"type":"respond", "template":intent, "params":{}}

    # Low confidence -> ask what they meant + give options
    if intent_conf < LOW_CONF:
        return {"type":"respond", "template":"fallback", "params":{"suggestions":FALLBACK_SUGGESTIONS}}

    # Switch intent if changed
    if state.get("active_intent") != intent and intent != "fallback":
        state["active_intent"] = intent
        state["awaiting"] = None

    state = merge_entities_into_slots(state, nlu.get("entities") or [])

    awaiting = state.get("awaiting")

    # Confirmation gate
    if awaiting and awaiting.get("type") == "confirm":
        t = text.lower()
        if any(w in t for w in ["yes","yep","confirm","ok","do it"]):
            state["awaiting"] = None
            return {"type":"execute", "intent": state.get("active_intent"), "confirm": True}
        if any(w in t for w in ["no","nah","stop","cancel"]):
            state["awaiting"] = None
            return {"type":"respond", "template":"cancelled", "params":{}}
        return {"type":"respond", "template":"confirm_again", "params":{}}

    # Slot filling
    schema = INTENT_SLOTS.get(state.get("active_intent") or "")
    if schema:
        required = schema.get("required", [])
        slots = state.get("slots") or {}
        missing = [s for s in required if s not in slots]
        if missing:
            need = missing[0]
            state["awaiting"] = {"type":"slot", "name": need}
            return {"type":"ask", "slot": need, "question": SLOT_QUESTIONS.get(need, f"Need {need}")}

        # All required slots present
        if state.get("active_intent") in CONFIRM_INTENTS:
            state["awaiting"] = {"type":"confirm", "action_id": str(uuid.uuid4())}
            return {"type":"respond", "template":"confirm_action", "params":{"intent": state["active_intent"], "slots": slots}}

        return {"type":"execute", "intent": state.get("active_intent"), "confirm": False}

    return {"type":"respond", "template":"fallback", "params":{"suggestions":FALLBACK_SUGGESTIONS}}
