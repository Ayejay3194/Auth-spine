import registry from "../modules/registry.json" assert { type: "json" };
console.log(registry.map(m => `${m.id} - ${m.name}`).join("\n"));
