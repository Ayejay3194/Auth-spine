import crypto from "node:crypto";
import { findFiles, readText, rel } from "../utils/fs.js";
import type { Check, Finding } from "../types.js";

// lightweight secret patterns. add your own.
const PATTERNS: { name: string; re: RegExp }[] = [
  { name: "AWS Access Key", re: /AKIA[0-9A-Z]{16}/g },
  { name: "Stripe Secret Key", re: /sk_(live|test)_[0-9a-zA-Z]{16,}/g },
  { name: "Private Key Block", re: /-----BEGIN (RSA|EC|OPENSSH|PRIVATE) KEY-----/g },
  { name: "Generic API Key", re: /(api[_-]?key|secret|token)\s*[:=]\s*["'][0-9a-zA-Z\-_.]{16,}["']/gi },
];

function hash(s: string) {
  return crypto.createHash("sha256").update(s).digest("hex").slice(0, 10);
}

export const SecretsScanCheck: Check = {
  id: "security.secrets_scan",
  title: "No obvious secrets committed",
  category: "Security",
  async run(ctx) {
    const files = findFiles(ctx.root, ["**/*.{ts,js,tsx,jsx,json,yml,yaml,tf,md,env}"])
      .filter(f => !f.includes("node_modules/") && !f.includes("dist/") && !f.includes(".git/"));
    const findings: Finding[] = [];
    for (const f of files) {
      const txt = readText(f);
      if (!txt) continue;
      for (const p of PATTERNS) {
        const m = txt.match(p.re);
        if (m && m.length) {
          findings.push({
            id: this.id,
            title: this.title,
            category: this.category,
            severity: "P0",
            evidence: m.slice(0, 3).map(val => ({
              message: `Potential secret (${p.name}) in ${rel(ctx.root, f)}: ${hash(val)}…`,
              file: rel(ctx.root, f),
              hint: "Remove from git history, rotate the credential, add secret scanning + pre-commit hooks."
            }))
          });
        }
      }
    }
    return findings;
  }
};
