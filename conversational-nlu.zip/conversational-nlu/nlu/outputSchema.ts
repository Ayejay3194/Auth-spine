export const NLU_SCHEMA = {
  intent: "string",
  confidence: "number",
  entities: "array",
  reasoning: "string"
};
