import { FlowDefinition } from "./types.js";

export const flowDefs: FlowDefinition[] = [
  {
    intent: "auth.forgot_username",
    slots: [{ name: "email", required: true, fromEntity: (ents) => ents.find((e) => e.type === "email")?.value ?? null }],
    steps: (slots) => [
      { ask: { slot: "email", prompt: "What’s the email on the account?", hint: "example: you@domain.com" } },
      { call: { toolId: "auth.send_forgot_username", inputFromSlots: (s) => ({ email: s.email }) } },
      { done: { message: "Sent. Check your email for your username." } },
    ],
  },
  {
    intent: "auth.password_reset_request",
    slots: [
      {
        name: "identifier",
        required: true,
        fromEntity: (ents) => ents.find((e) => e.type === "email")?.value ?? ents.find((e) => e.type === "username")?.value ?? null,
      },
    ],
    steps: () => [
      { ask: { slot: "identifier", prompt: "Email or username?", hint: "you@domain.com or @handle" } },
      { call: { toolId: "auth.send_password_reset", inputFromSlots: (s) => ({ identifier: s.identifier }) } },
      { done: { message: "Okay. If that account exists, a reset link/code was sent." } },
    ],
  },
  {
    intent: "gdpr.export_request",
    slots: [],
    steps: () => [
      { call: { toolId: "gdpr.queue_export", inputFromSlots: () => ({}) } },
      { done: { message: "Queued your data export. You’ll get an email when it’s ready." } },
    ],
  },
  {
    intent: "billing.change_plan",
    slots: [
      { name: "plan", required: true, fromEntity: (ents) => ents.find((e) => e.type === "plan")?.value ?? null },
      { name: "confirm", required: true },
    ],
    steps: (slots) => [
      { ask: { slot: "plan", prompt: "Which plan do you want? (free | paid | pro | starter)", hint: "free | paid | pro | starter" } },
      { ask: { slot: "confirm", prompt: `Confirm change to "${slots.plan}". Type YES to proceed.`, hint: "YES" } },
      { call: { toolId: "billing.change_plan", inputFromSlots: (s) => ({ plan: s.plan, confirm: s.confirm }) } },
      { done: { message: "Plan updated." } },
    ],
  },
];
