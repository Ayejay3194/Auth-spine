import { sanitizePayload } from "./sanitize";

export async function safeReturn<T>(
  viewer: { email?: string|null; role: string },
  event: string,
  payload: any,
  log?: (entry: any) => Promise<void>
): Promise<T> {
  const { data, removedKeys } = sanitizePayload<T>(payload);

  if (log) {
    await log({
      event: "sanitize",
      actor: viewer.email ?? "system",
      role: viewer.role,
      removedKeys,
      size: JSON.stringify(payload).length,
      sourceEvent: event
    });
  }

  return data;
}
