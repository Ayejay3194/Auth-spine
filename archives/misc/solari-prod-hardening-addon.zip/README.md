# Solari Production Hardening Add-on (IDs + Golden Tests + Provenance + Packaging + Admin)

This is a **drop-in** suite that adds the stuff that prevents your interpretive library from turning into a haunted house:
- Canonical IDs + versioning
- Golden tests (deterministic resolver/composer outputs)
- Source provenance + citations
- Anti-repetition memory
- Fast packaging (SQLite index)
- Mini admin panel to browse nodes and see broken links
- Local API for search + rebuild + audit

## Quick start
```bash
pnpm i
pnpm build

# Put your JSONL files under ./data/jsonl (or edit solari.config.json)
pnpm ingest
pnpm audit
pnpm pack

# run local API + admin UI
pnpm api
pnpm admin
```

Outputs:
- `out/index.sqlite` (packed index)
- `out/audit.report.json`
- `out/golden/*.md` (golden snapshots)

## Where to plug your content
- `data/jsonl/*.jsonl` (your HD + business + astro packs)
- `solari.config.json` controls ingest + alias rules + required coverage rules.

## Production use
Use `out/index.sqlite` with `@solari/indexer` runtime loader (see `packages/indexer/src/runtime.ts`).
