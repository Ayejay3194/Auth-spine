WS server: src/realtime/wsServer.ts. SSE route: /api/realtime/stream (stub).
