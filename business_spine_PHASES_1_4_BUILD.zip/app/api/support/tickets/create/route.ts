import { z } from "zod";
import { api } from "@/src/core/api";
import { prisma } from "@/lib/prisma";
import { getTenant } from "@/src/tenant/tenant";
import { getActor } from "@/src/core/auth";

const Q = z.object({ subject: z.string().min(3), body: z.string().min(1) });
export async function POST(req: Request) {
  return api(async () => {
    const actor = getActor(req);
    const { tenantId } = getTenant(req);
    const body = Q.parse(await req.json());
    const t = await prisma.supportTicket.create({ data: { tenantId, userId: actor.userId, subject: body.subject, body: body.body } });
    return { ticketId: t.id, status: t.status };
  });
}
