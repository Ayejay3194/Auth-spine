Audit Logging Requirements

Log all:
- Auth attempts
- Permission denials
- Assistant tool calls
- Sanitization events
- Security violations

Logs must be immutable and retained per policy.
