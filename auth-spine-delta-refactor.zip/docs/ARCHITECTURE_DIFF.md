# Architecture Differences

Old vs new spine layout.