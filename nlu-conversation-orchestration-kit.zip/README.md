# NLU Conversation Orchestration Kit

This kit sits **above** your NLU + quote packs and makes responses feel *conversational* (intentional tone, memory dampening, escalation/de-escalation, and an interpretation bridge).

## What's inside

- `src/orchestrator.ts` — one-call orchestration: input -> policy -> chosen style -> output plan
- `src/toneArbiter.ts` — chooses tone level (0–3)
- `src/memoryDampener.ts` — prevents stacking passive-aggressive replies
- `src/escalation.ts` — escalation + de-escalation rules
- `src/interpretationMapper.ts` — maps interpretation signals to delivery style
- `src/personaFilter.ts` — final safety/consistency filter
- `data/tone_policies.jsonl` — editable policy rows (rules + weights)
- `docs/routing.mmd` — Mermaid routing diagram
- `docs/routing.md` — diagram + notes

## Minimal integration example

```ts
import { createOrchestrator } from "./src/orchestrator";

const orch = createOrchestrator();

const plan = orch.orchestrateTurn(
  {
    text: "Sure. Whatever.",
    nlu: { intent: "complaint", confidence: 0.82, entities: [] },
    signals: { saturn: 0.6, neptune: 0.1, mars: 0.2 },
    state: {
      userTolerance: 0.55,
      lastToneLevel: 1,
      lastPassiveAggressiveAtTurn: 4,
      turnIndex: 9,
      recentUserComplianceScore: 0.2,
      recentUserEmotionalReactivity: 0.1
    },
  },
  {
    getLine: (toneTag) => `{{QUOTE:${toneTag}}}`, // swap with your quote JSONL retrieval
  }
);

console.log(plan);
```

## Notes

- This kit does **not** call any external API.
- If you already have a quote JSONL, wire it through `quotePack.getLine(toneTag)`.

Generated: 2025-12-17
