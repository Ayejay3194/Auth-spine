# SEARCH & FILTERING DISASTERS

## Search Problems

- [ ] No search functionality
- [ ] Search too slow
- [ ] Search not finding results
- [ ] Search finding irrelevant results
- [ ] No fuzzy matching
- [ ] Typos breaking search
- [ ] Search case-sensitive
- [ ] No partial matching
- [ ] Search accent-sensitive
- [ ] No search suggestions
- [ ] No search highlighting
- [ ] Search pagination broken
- [ ] Search sorting wrong
- [ ] Search relevance poor
- [ ] No faceted search
- [ ] Cannot filter search results
- [ ] Search index not updated
- [ ] Stale search results
- [ ] Search index corruption

## Filtering & Sorting Issues

- [ ] No filtering options
- [ ] Filters not working
- [ ] Filters conflicting with each other
- [ ] Cannot clear filters
- [ ] Filter state not preserved
- [ ] Sorting not working
- [ ] Sort order inconsistent
- [ ] No multi-column sorting
- [ ] Default sort order confusing
- [ ] Filter/sort performance terrible
- [ ] Client-side filtering of large datasets
- [ ] Not using database for filtering
- [ ] Filter values not validated

---
