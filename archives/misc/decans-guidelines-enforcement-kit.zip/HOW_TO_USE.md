# How to use

## Files
- DECANS_INTERPRETIVE_CONSTITUTION.txt (human-readable)
- rules.json / rules.yaml (machine-readable)
- linter/ (Node/TS linter)

## Quick start
1) cd linter
2) npm i
3) npm run dev -- ../examples/sample_output.txt Free

Exit codes:
- 0 = OK
- 2 = errors found (forbidden phrases)

Use in CI:
- Run linter on generated drafts before saving/publishing.
