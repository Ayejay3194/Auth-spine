import { describe, it, expect } from "vitest";
import { loadProfile } from "../src/profile.js";
import path from "node:path";

describe("profile", () => {
  it("loads the marketplace profile", () => {
    const p = loadProfile(path.resolve("profiles/marketplace-pro.yaml"));
    expect(p.run.failOnSeverity).toBeDefined();
    expect(Array.isArray(p.expectations.documents)).toBe(true);
  });
});
