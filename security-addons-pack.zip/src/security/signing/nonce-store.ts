export interface NonceStore {
  seen(keyId: string, nonce: string): Promise<boolean>;
  mark(keyId: string, nonce: string, ttlSeconds: number): Promise<void>;
}

export class InMemoryNonceStore implements NonceStore {
  private m = new Map<string, number>(); // key -> expiresAtMs
  private k(keyId: string, nonce: string) { return `${keyId}::${nonce}`; }

  async seen(keyId: string, nonce: string) {
    const k = this.k(keyId, nonce);
    const exp = this.m.get(k);
    if (!exp) return false;
    if (exp <= Date.now()) { this.m.delete(k); return false; }
    return true;
  }

  async mark(keyId: string, nonce: string, ttlSeconds: number) {
    this.m.set(this.k(keyId, nonce), Date.now() + ttlSeconds*1000);
  }
}
