import { Tool } from "../tools/types.js";

const emailLike = (s: string) => /@/.test(s);

export function supportTools(): Tool<any, any>[] {
  const forgotUsername: Tool<{ email: string }, { sent: boolean }> = {
    id: "auth.send_forgot_username",
    description: "Send username reminder email",
    validate: (i) => { if (!emailLike(i.email)) throw new Error("Invalid email"); },
    run: async () => ({ ok: true, data: { sent: true } }),
    timeoutMs: 1500,
  };

  const reset: Tool<{ identifier: string }, { sent: boolean }> = {
    id: "auth.send_password_reset",
    description: "Send password reset email/code",
    validate: (i) => { if (!i.identifier || i.identifier.length < 2) throw new Error("Invalid identifier"); },
    run: async () => ({ ok: true, data: { sent: true } }),
    timeoutMs: 1500,
  };

  const gdpr: Tool<{}, { queued: boolean }> = {
    id: "gdpr.queue_export",
    description: "Queue GDPR export",
    validate: () => {},
    run: async () => ({ ok: true, data: { queued: true } }),
    timeoutMs: 1500,
  };

  const plan: Tool<{ plan: string; confirm: string }, { updated: boolean }> = {
    id: "billing.change_plan",
    description: "Change plan",
    validate: (i) => {
      if (!["free","paid","pro","starter"].includes(i.plan)) throw new Error("Unknown plan");
      if (i.confirm.trim().toUpperCase() != "YES") throw new Error("Confirmation required");
    },
    run: async () => ({ ok: true, data: { updated: true } }),
    timeoutMs: 1500,
  };

  return [forgotUsername, reset, gdpr, plan];
}
