export type NotifyChannel = "email" | "sms" | "push";

export type Notification = {
  tenantId: string;
  userId?: string;
  to: string; // email or phone or device token
  channel: NotifyChannel;
  template: string;
  vars: Record<string, any>;
  idempotencyKey?: string;
};
