import Link from "next/link";
import { Container } from "@/components/Container";
import { prisma } from "@/lib/prisma";
import { StylistCard } from "@/components/StylistCard";
import { auth } from "@/lib/auth";

export default async function Following(){
  const session = await auth();
  if(!session?.user?.email){
    return (
      <main className="py-10">
        <Container>
          <div className="rounded-[28px] border p-8" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
            <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>My Stylists</div>
            <h1 className="serif mt-2 text-3xl">Sign in to see your people.</h1>
            <p className="mt-2 text-sm" style={{color:"var(--muted)"}}>Following is how this platform prints money. Naturally it needs identity.</p>
            <div className="mt-6">
              <Link href="/auth/sign-in" className="rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>
                Sign in
              </Link>
            </div>
          </div>
        </Container>
      </main>
    );
  }

  const user = await prisma.user.findUnique({ where:{ email: session.user.email } });
  if(!user) return <main className="py-10"><Container>User not found. (Seed or sign in once.)</Container></main>;

  const follows = await prisma.follow.findMany({ where:{ followerUserId: user.id }, include:{ stylist:true } });

  return (
    <main className="py-10">
      <Container>
        <div>
          <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>My Stylists</div>
          <h1 className="serif mt-2 text-3xl">Following</h1>
          <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>Openings, rebooks, and your personal roster.</div>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {follows.map(f => <StylistCard key={f.stylistId} slug={f.stylist.slug} displayName={f.stylist.displayName} title={f.stylist.title} heroUrl={f.stylist.heroUrl} />)}
          {!follows.length ? <div style={{color:"var(--muted)"}}>No follows yet. Go act like a client and follow a stylist.</div> : null}
        </div>
      </Container>
    </main>
  );
}
