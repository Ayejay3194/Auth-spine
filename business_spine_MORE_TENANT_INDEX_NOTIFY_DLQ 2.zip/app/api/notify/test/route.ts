import { z } from "zod";
import { api } from "@/src/core/api";
import { getTenant } from "@/src/tenant/tenant";
import { enqueueNotification } from "@/src/notify/notifyQueue";
import { getActor } from "@/src/core/auth";

const Q = z.object({
  channel: z.enum(["email","sms","push"]).default("email"),
  to: z.string().min(3),
  template: z.string().default("booking_confirm"),
  vars: z.record(z.any()).default({}),
});

export async function POST(req: Request) {
  return api(async () => {
    const actor = getActor(req);
    const { tenantId } = getTenant(req);
    const body = Q.parse(await req.json());

    await enqueueNotification({
      tenantId,
      userId: actor.userId,
      channel: body.channel,
      to: body.to,
      template: body.template,
      vars: body.vars,
      idempotencyKey: `test:${tenantId}:${actor.userId}:${body.template}:${body.to}`,
    });

    return { ok: true };
  });
}
