# Alerting starter set
Page-worthy:
- cross-tenant access detected
- payment webhook verification failures spike
- auth failure spike / credential stuffing
- error budget burn rate high
- database connection saturation
- queue backlog > threshold
