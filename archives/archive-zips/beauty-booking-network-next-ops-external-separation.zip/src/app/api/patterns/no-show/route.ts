import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const Body = z.object({ clientUserId: z.string().optional() });

export async function POST(req: Request){
  const session = await auth();
  if(!session?.user?.email) return new Response("Unauthorized", { status: 401 });

  const u = await prisma.user.findUnique({ where:{ email: session.user.email } });
  if(!u) return new Response("Unauthorized", { status: 401 });

  const data = Body.parse(await req.json().catch(()=>({})));
  const targetId = data.clientUserId ?? u.id;

  const ML_URL = process.env.ML_SERVICE_URL || "http://localhost:8001";
  const r = await fetch(`${ML_URL}/score/no_show`, {
    method:"POST",
    headers:{ "content-type":"application/json" },
    body: JSON.stringify({ clientUserId: targetId }),
    cache:"no-store",
  }).catch(()=>null);

  if(!r || !r.ok){
    return Response.json({ risk: 0.15, note: "ml service unavailable" });
  }
  const j = await r.json();
  return Response.json(j);
}
