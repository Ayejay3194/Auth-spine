import {
  Table as ArrowTable,
  Vector,
  Utf8Vector,
  Float64Vector,
  Int32Vector,
  BoolVector,
  DataType,
} from "apache-arrow";
import { readParquetToArrowTable, writeArrowTableToParquet } from "../core/parquetArrowHybrid.js";

export type Row = Record<string, any>;
export type SortDir = "asc" | "desc";
export type WhereOp = "==" | "!=" | ">" | ">=" | "<" | "<=";

type AggFn = "count" | "sum" | "mean" | "min" | "max";
export type AggSpec = Record<string, AggFn[]>;

function isNumberVector(v: Vector): boolean {
  const t = v.type;
  // Arrow JS types are runtime classes; simplest checks:
  return t.typeId === 3 /* Int */ || t.typeId === 2 /* Float */ || t.toString().includes("Float") || t.toString().includes("Int");
}

function toArray(v: Vector): any[] {
  const out = new Array(v.length);
  for (let i = 0; i < v.length; i++) out[i] = v.get(i);
  return out;
}

export class DataFrame {
  readonly table: ArrowTable;

  constructor(table: ArrowTable) {
    this.table = table;
  }

  static fromArrow(table: ArrowTable) {
    return new DataFrame(table);
  }

  static fromRows(rows: Row[]) {
    if (!rows.length) return new DataFrame(ArrowTable.new({}));
    const cols = Object.keys(rows[0]);
    const data: Record<string, Vector> = {};
    for (const c of cols) {
      const values = rows.map(r => r[c]);
      // Minimal type inference
      if (values.every(v => typeof v === "number" || v === null || v === undefined)) {
        data[c] = Float64Vector.from(values.map(v => (v == null ? NaN : v)));
      } else if (values.every(v => typeof v === "boolean" || v === null || v === undefined)) {
        data[c] = BoolVector.from(values.map(v => !!v));
      } else if (values.every(v => Number.isInteger(v) || v === null || v === undefined)) {
        data[c] = Int32Vector.from(values.map(v => (v == null ? 0 : v)));
      } else {
        data[c] = Utf8Vector.from(values.map(v => (v == null ? "" : String(v))));
      }
    }
    return new DataFrame(ArrowTable.new(data));
  }

  static async fromParquet(filePath: string) {
    const t = await readParquetToArrowTable(filePath);
    return new DataFrame(t);
  }

  async toParquet(filePath: string, opts?: { compression?: "snappy" | "zstd" | "gzip" | "uncompressed"; metadata?: Record<string,string> }) {
    await writeArrowTableToParquet(filePath, this.table, opts);
  }

  get columns(): string[] {
    return this.table.schema.fields.map(f => f.name);
  }

  get shape(): [number, number] {
    return [this.table.numRows, this.columns.length];
  }

  head(n = 5): Row[] {
    const out: Row[] = [];
    const cols = this.columns;
    for (let i = 0; i < Math.min(n, this.table.numRows); i++) {
      const r: Row = {};
      for (const c of cols) r[c] = this.table.getChild(c)?.get(i);
      out.push(r);
    }
    return out;
  }

  select(cols: string[]): DataFrame {
    const data: Record<string, Vector> = {};
    for (const c of cols) {
      const v = this.table.getChild(c);
      if (!v) throw new Error(`Unknown column: ${c}`);
      data[c] = v;
    }
    return new DataFrame(ArrowTable.new(data));
  }

  drop(cols: string[]): DataFrame {
    const dropSet = new Set(cols);
    return this.select(this.columns.filter(c => !dropSet.has(c)));
  }

  rename(map: Record<string,string>): DataFrame {
    const data: Record<string, Vector> = {};
    for (const c of this.columns) {
      const v = this.table.getChild(c)!;
      data[map[c] ?? c] = v;
    }
    return new DataFrame(ArrowTable.new(data));
  }

  /**
   * Row-wise filter (simple, readable; not fastest for huge datasets).
   */
  filter(pred: (row: Row, i: number) => boolean): DataFrame {
    const cols = this.columns;
    const rows: Row[] = [];
    for (let i = 0; i < this.table.numRows; i++) {
      const r: Row = {};
      for (const c of cols) r[c] = this.table.getChild(c)?.get(i);
      if (pred(r, i)) rows.push(r);
    }
    return DataFrame.fromRows(rows);
  }

  /**
   * Column-based where for common comparisons.
   */
  where(col: string, op: WhereOp, value: any): DataFrame {
    const v = this.table.getChild(col);
    if (!v) throw new Error(`Unknown column: ${col}`);
    return this.filter((row) => {
      const x = row[col];
      switch (op) {
        case "==": return x === value;
        case "!=": return x !== value;
        case ">": return x > value;
        case ">=": return x >= value;
        case "<": return x < value;
        case "<=": return x <= value;
      }
    });
  }

  withColumn(name: string, fnOrVector: ((row: Row, i: number) => any) | Vector): DataFrame {
    const cols = this.columns;
    const data: Record<string, Vector> = {};
    for (const c of cols) data[c] = this.table.getChild(c)!;

    if (typeof fnOrVector !== "function") {
      data[name] = fnOrVector;
      return new DataFrame(ArrowTable.new(data));
    }

    const values: any[] = [];
    for (let i = 0; i < this.table.numRows; i++) {
      const r: Row = {};
      for (const c of cols) r[c] = this.table.getChild(c)?.get(i);
      values.push(fnOrVector(r, i));
    }

    // Basic inference
    if (values.every(v => typeof v === "number" || v == null)) {
      data[name] = Float64Vector.from(values.map(v => (v == null ? NaN : v)));
    } else if (values.every(v => typeof v === "boolean" || v == null)) {
      data[name] = BoolVector.from(values.map(v => !!v));
    } else {
      data[name] = Utf8Vector.from(values.map(v => (v == null ? "" : String(v))));
    }
    return new DataFrame(ArrowTable.new(data));
  }

  sortBy(col: string, dir: SortDir = "asc"): DataFrame {
    const v = this.table.getChild(col);
    if (!v) throw new Error(`Unknown column: ${col}`);
    const idx = Array.from({ length: this.table.numRows }, (_, i) => i);
    idx.sort((a,b) => {
      const av = v.get(a) as any;
      const bv = v.get(b) as any;
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      const cmp = av < bv ? -1 : av > bv ? 1 : 0;
      return dir === "asc" ? cmp : -cmp;
    });

    const data: Record<string, Vector> = {};
    for (const c of this.columns) {
      const colV = this.table.getChild(c)!;
      const arr = idx.map(i => colV.get(i));
      // preserve primitive types loosely
      if (arr.every(x => typeof x === "number" || x == null)) data[c] = Float64Vector.from(arr.map(x => (x == null ? NaN : x)));
      else if (arr.every(x => typeof x === "boolean" || x == null)) data[c] = BoolVector.from(arr.map(x => !!x));
      else data[c] = Utf8Vector.from(arr.map(x => (x == null ? "" : String(x))));
    }
    return new DataFrame(ArrowTable.new(data));
  }

  groupBy(keys: string[]) {
    return new GroupBy(this, keys);
  }

  describe(cols?: string[]) {
    const use = cols ?? this.columns;
    const out: Record<string, any> = {};
    for (const c of use) {
      const v = this.table.getChild(c);
      if (!v) continue;
      const arr = toArray(v).filter(x => x != null && !(typeof x === "number" && Number.isNaN(x)));
      if (!arr.length) continue;

      if (arr.every(x => typeof x === "number")) {
        const nums = arr as number[];
        let min = nums[0], max = nums[0], sum = 0;
        for (const x of nums) { if (x < min) min = x; if (x > max) max = x; sum += x; }
        out[c] = { count: nums.length, mean: sum / nums.length, min, max };
      } else {
        out[c] = { count: arr.length, unique: new Set(arr.map(String)).size };
      }
    }
    return out;
  }
}

export class GroupBy {
  private df: DataFrame;
  private keys: string[];
  constructor(df: DataFrame, keys: string[]) {
    this.df = df;
    this.keys = keys;
    for (const k of keys) if (!df.table.getChild(k)) throw new Error(`Unknown group key: ${k}`);
  }

  agg(spec: AggSpec): DataFrame {
    const cols = this.df.columns;
    const keyVectors = this.keys.map(k => this.df.table.getChild(k)!);

    // Build groups: key string -> row indices
    const groups = new Map<string, number[]>();
    for (let i = 0; i < this.df.table.numRows; i++) {
      const key = this.keys.map((k, j) => String(keyVectors[j].get(i))).join("||");
      const arr = groups.get(key);
      if (arr) arr.push(i); else groups.set(key, [i]);
    }

    // Prepare output columns
    const outCols: Record<string, any[]> = {};
    for (const k of this.keys) outCols[k] = [];
    for (const [col, fns] of Object.entries(spec)) {
      for (const fn of fns) outCols[`${col}_${fn}`] = [];
    }

    for (const [key, idxs] of groups.entries()) {
      const parts = key.split("||");
      this.keys.forEach((k, j) => outCols[k].push(parts[j]));

      for (const [col, fns] of Object.entries(spec)) {
        const v = this.df.table.getChild(col);
        if (!v) throw new Error(`Unknown agg column: ${col}`);

        const values = idxs.map(i => v.get(i)).filter(x => x != null && !(typeof x === "number" && Number.isNaN(x)));
        const n = values.length;

        // numeric-only aggs for sum/mean/min/max
        const nums = values.filter(x => typeof x === "number") as number[];

        for (const fn of fns) {
          const outName = `${col}_${fn}`;
          switch (fn) {
            case "count":
              outCols[outName].push(n);
              break;
            case "sum":
              outCols[outName].push(nums.reduce((a,b) => a + b, 0));
              break;
            case "mean":
              outCols[outName].push(nums.length ? nums.reduce((a,b) => a + b, 0) / nums.length : NaN);
              break;
            case "min":
              outCols[outName].push(nums.length ? Math.min(...nums) : NaN);
              break;
            case "max":
              outCols[outName].push(nums.length ? Math.max(...nums) : NaN);
              break;
          }
        }
      }
    }

    // Convert arrays to Arrow vectors
    const data: Record<string, Vector> = {};
    for (const [name, arr] of Object.entries(outCols)) {
      if (arr.every(v => typeof v === "number" || v == null)) {
        data[name] = Float64Vector.from(arr.map(v => (v == null ? NaN : v as number)));
      } else {
        data[name] = Utf8Vector.from(arr.map(v => (v == null ? "" : String(v))));
      }
    }
    return DataFrame.fromArrow(ArrowTable.new(data));
  }
}
