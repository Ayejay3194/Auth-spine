# Observability Pack

## Required fields on logs
- timestamp (ISO)
- level (debug/info/warn/error)
- service (api/web/edge/db)
- request_id
- tenant_id (if multi-tenant)
- user_id (if authenticated)
- action (semantic name)
- duration_ms (when applicable)
- error_code (when applicable)

## Event taxonomy
See `observability/event_taxonomy.json`.

## Alert checklist
See `observability/alert_rules.md`.

