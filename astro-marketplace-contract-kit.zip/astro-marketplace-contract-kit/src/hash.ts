import crypto from 'node:crypto';
import { ChartDataV1 } from './types.js';
import { canonicalizeChart, CanonicalizeOptions } from './canonicalize.js';

export type HashAlgorithm = 'sha256';

export interface IntegrityResult {
  algorithm: HashAlgorithm;
  hashHex: string;
  canonical: string;
}

export function computeChartIntegrity(
  chart: ChartDataV1,
  opts: CanonicalizeOptions = {}
): IntegrityResult {
  const canonical = canonicalizeChart(chart, opts);
  const hashHex = crypto.createHash('sha256').update(canonical, 'utf8').digest('hex');
  return { algorithm: 'sha256', hashHex, canonical };
}
