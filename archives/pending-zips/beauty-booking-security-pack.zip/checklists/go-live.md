# Go-Live Security Checklist

## Must-have (block release if missing)
- [ ] TLS enforced + HSTS
- [ ] CSP shipped (even a conservative one)
- [ ] Rate limits on auth + booking endpoints
- [ ] MFA enforced for ops/admin
- [ ] Host-based ops separation (ops 404 on public)
- [ ] RBAC perms on every ops endpoint
- [ ] ABAC salon scoping on ops reads/writes
- [ ] CSRF for state-changing ops routes (cookie + header/token)
- [ ] Webhook signature verification
- [ ] Upload validation + re-encoding + signed URLs
- [ ] Audit logs for ops mutations
- [ ] PII access logging enabled for sensitive reads
- [ ] Secrets not in repo (scan passes)
- [ ] Dependency scan passes (no criticals)

## Nice-to-have (soon)
- [ ] Device/session alerts
- [ ] WAF rules and bot protection
- [ ] SIEM integration
- [ ] DLP controls for exports
