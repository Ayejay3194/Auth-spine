import { parseSmsIntent } from "./sms.parser";
import { ContextService } from "@/src/server/modules/context/context.service";
import { ClientIdentityService } from "@/src/server/modules/clientIdentity/client.service";
import { CalendarService } from "@/src/server/modules/calendar/calendar.service";
import { TrustService } from "@/src/server/modules/trust/trust.service";
import { PaymentsService } from "@/src/server/modules/payments/payments.service";
import { BookingService } from "@/src/server/modules/booking/booking.service";

export class SmsBookingService {
  constructor(
    private ctx: ContextService,
    private clients: ClientIdentityService,
    private calendar: CalendarService,
    private trust: TrustService,
    private payments: PaymentsService,
    private booking: BookingService
  ) {}

  async handleInbound(input: { fromE164: string; toE164: string; body: string }) {
    const intent = parseSmsIntent(input.body);
    const session = await this.ctx.getOrCreate(input.fromE164);

    if (intent.kind === "UNKNOWN") {
      return "Text what you want and when. Example: “Haircut Thursday at 2pm”";
    }

    const client = await this.clients.resolveClient(input.fromE164);
    if (!client.ok) return "Something broke. Try again.";

    const artistId = await this.clients.resolveArtistByInboundNumber(input.toE164);

    // waiting for slot choice
    if (session.stage === "AWAITING_SLOT_CHOICE" && session.proposedSlots?.length) {
      const msg = input.body.toLowerCase();
      const chosen =
        session.proposedSlots.find(s => msg.includes("first") && s === session.proposedSlots?.[0]) ??
        session.proposedSlots.find(s => msg.includes("second") && s === session.proposedSlots?.[1]) ??
        session.proposedSlots.find(s => msg.includes(s.label.toLowerCase()));

      if (!chosen) return `I have ${session.proposedSlots.map(s => s.label).join(" or ")}. Which works?`;

      const trust = await this.trust.getTrustLevel(client.value.clientId);
      if (trust === "DEPOSIT_REQUIRED" && !session.cardOnFile) {
        const link = await this.payments.createDepositLink({ artistId, clientId: client.value.clientId, amountCents: 2000 });
        await this.ctx.patch(input.fromE164, { stage: "AWAITING_DEPOSIT", pendingSlot: chosen });
        return `I can do ${chosen.label}. I’ll need a $20 deposit: ${link}`;
      }

      const created = await this.booking.createBooking({
        artistId,
        clientId: client.value.clientId,
        serviceId: session.serviceId ?? "service_default",
        startAt: chosen.startAt,
        endAt: chosen.endAt,
        requestedVia: "SMS"
      });

      if (!created.ok) return "That slot got taken. Want the next opening?";
      await this.ctx.patch(input.fromE164, { stage: "NEW", proposedSlots: undefined, pendingSlot: undefined });
      return `You’re booked for ${chosen.label}. See you then.`;
    }

    // default: propose slots
    const slots = await this.calendar.getNextAvailableSlots(artistId, 2);
    if (!slots.length) return "No openings right now. Try another day?";
    await this.ctx.patch(input.fromE164, { stage: "AWAITING_SLOT_CHOICE", proposedSlots: slots });

    return `I have ${slots.map(s => s.label).join(" or ")}. Which works?`;
  }
}
