export type DoctorReport = {
  meta: { appName?: string; version?: string; timestamp: string; url: string; };
  env: {
    userAgent: string;
    platform: string;
    language: string;
    languages?: string[];
    timezone?: string;
    cookieEnabled: boolean;
    online: boolean;
    hardwareConcurrency?: number;
    deviceMemory?: number;
    screen: { w: number; h: number; dpr: number; };
    viewport: { w: number; h: number; };
    prefers: { darkMode: boolean; reducedMotion: boolean; };
  };
  network?: { effectiveType?: string; downlink?: number; rtt?: number; saveData?: boolean; };
  storage: {
    localStorage: boolean;
    sessionStorage: boolean;
    indexedDB: boolean;
    cacheStorage: boolean;
  };
  serviceWorker: { supported: boolean; controller: boolean; registrations?: number; scopeHints?: string[]; };
  errors: Array<{ type: "error" | "rejection"; message: string; source?: string; stack?: string; time: string; }>;
};

function safe(fn: () => any): any { try { return fn(); } catch { return null; } }

export function collectDoctorReport(opts?: { appName?: string; version?: string }): Promise<DoctorReport> {
  const now = new Date().toISOString();
  const nav: any = navigator as any;
  const tz = safe(() => Intl.DateTimeFormat().resolvedOptions().timeZone) ?? undefined;

  const report: DoctorReport = {
    meta: { appName: opts?.appName, version: opts?.version, timestamp: now, url: location.href },
    env: {
      userAgent: navigator.userAgent,
      platform: (navigator as any).platform ?? "",
      language: navigator.language,
      languages: (navigator as any).languages,
      timezone: tz,
      cookieEnabled: navigator.cookieEnabled,
      online: navigator.onLine,
      hardwareConcurrency: nav.hardwareConcurrency,
      deviceMemory: nav.deviceMemory,
      screen: { w: screen.width, h: screen.height, dpr: window.devicePixelRatio ?? 1 },
      viewport: { w: window.innerWidth, h: window.innerHeight },
      prefers: {
        darkMode: matchMedia?.("(prefers-color-scheme: dark)")?.matches ?? false,
        reducedMotion: matchMedia?.("(prefers-reduced-motion: reduce)")?.matches ?? false,
      },
    },
    network: safe(() => nav.connection ? ({
      effectiveType: nav.connection.effectiveType,
      downlink: nav.connection.downlink,
      rtt: nav.connection.rtt,
      saveData: nav.connection.saveData,
    }) : undefined) ?? undefined,
    storage: {
      localStorage: safe(() => { localStorage.setItem("__t","1"); localStorage.removeItem("__t"); return true; }) ?? false,
      sessionStorage: safe(() => { sessionStorage.setItem("__t","1"); sessionStorage.removeItem("__t"); return true; }) ?? false,
      indexedDB: !!safe(() => indexedDB),
      cacheStorage: !!safe(() => (window as any).caches),
    },
    serviceWorker: { supported: "serviceWorker" in navigator, controller: !!navigator.serviceWorker?.controller },
    errors: [],
  };

  return new Promise(async (resolve) => {
    if (!("serviceWorker" in navigator)) { resolve(report); return; }
    try {
      const regs = await navigator.serviceWorker.getRegistrations();
      report.serviceWorker.registrations = regs.length;
      report.serviceWorker.scopeHints = regs.map(r => r.scope).slice(0, 10);
    } catch { /* ignore */ }
    resolve(report);
  });
}

export function mountBrowserDoctor(el: HTMLElement, opts?: { appName?: string; version?: string; reportEndpoint?: string }) {
  const state = { errors: [] as DoctorReport["errors"], unsub: [] as Array<() => void> };

  const onError = (ev: ErrorEvent) => {
    state.errors.push({ type:"error", message: ev.message, source: ev.filename, stack: (ev.error?.stack ?? ""), time: new Date().toISOString() });
    render();
  };
  const onRej = (ev: PromiseRejectionEvent) => {
    state.errors.push({ type:"rejection", message: String(ev.reason ?? "Unhandled rejection"), stack: (ev.reason?.stack ?? ""), time: new Date().toISOString() });
    render();
  };
  window.addEventListener("error", onError);
  window.addEventListener("unhandledrejection", onRej);
  state.unsub.push(()=>window.removeEventListener("error", onError));
  state.unsub.push(()=>window.removeEventListener("unhandledrejection", onRej));

  async function render() {
    const rep = await collectDoctorReport({ appName: opts?.appName, version: opts?.version });
    rep.errors = [...rep.errors, ...state.errors].slice(-50);

    const json = JSON.stringify(rep, null, 2);
    el.innerHTML = `
      <div style="font-family: ui-monospace, Menlo, monospace; line-height:1.3; max-width: 920px">
        <h2>Browser Doctor</h2>
        <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:8px">
          <button id="bd-copy">Copy JSON</button>
          <button id="bd-download">Download JSON</button>
          ${opts?.reportEndpoint ? `<button id="bd-send">Send to server</button>` : ``}
          <button id="bd-clear">Clear captured errors</button>
        </div>
        <pre style="white-space:pre-wrap; background:rgba(0,0,0,0.06); padding:12px; border-radius:8px">${escapeHtml(json)}</pre>
      </div>
    `;

    (el.querySelector("#bd-copy") as HTMLButtonElement).onclick = async () => {
      await navigator.clipboard.writeText(json);
    };
    (el.querySelector("#bd-download") as HTMLButtonElement).onclick = () => {
      const blob = new Blob([json], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `browser-doctor-${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
    };
    const clearBtn = el.querySelector("#bd-clear") as HTMLButtonElement;
    clearBtn.onclick = () => { state.errors = []; render(); };

    const send = el.querySelector("#bd-send") as HTMLButtonElement | null;
    if (send && opts?.reportEndpoint) {
      send.onclick = async () => {
        try {
          await fetch(opts.reportEndpoint, { method:"POST", headers:{ "Content-Type":"application/json" }, body: json });
          send.textContent = "Sent ✓";
          setTimeout(()=> send.textContent = "Send to server", 1200);
        } catch {
          send.textContent = "Send failed";
          setTimeout(()=> send.textContent = "Send to server", 1200);
        }
      };
    }
  }

  render();

  return {
    destroy() { state.unsub.forEach(fn=>fn()); el.innerHTML = ""; },
  };
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"]/g, (c) => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;" }[c] as string));
}
