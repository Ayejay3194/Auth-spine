# Test Files License

This directory contains binary test files from [apache/parquet-testing](https://github.com/apache/parquet-testing), under the [Apache 2.0 license](https://www.apache.org/licenses/LICENSE-2.0).

Copyright 2004 The Apache Software Foundation (http://www.apache.org/).
