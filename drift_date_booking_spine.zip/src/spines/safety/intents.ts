import { Pattern } from "../../core/intent.js";

export const patterns: Pattern[] = [
  {
    "spine": "safety",
    "intent": "safety_set_rules",
    "re": "safety settings|set safety|location share|check[- ]?in timer",
    "baseConfidence": 0.7,
    "hint": "safety rules"
  },
  {
    "spine": "safety",
    "intent": "safety_checkin",
    "re": "check in|i'm safe|arrived safe",
    "baseConfidence": 0.7,
    "hint": "checkin"
  }
];
