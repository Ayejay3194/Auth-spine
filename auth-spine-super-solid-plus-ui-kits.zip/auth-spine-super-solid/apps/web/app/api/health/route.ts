import { NextResponse } from 'next/server'
import { performanceMonitor } from '@auth-spine/core/middleware/performance'
import { log } from '@auth-spine/core/logger'

type HealthCheck = { name: string; status: 'healthy'|'degraded'|'unhealthy'; responseTime?: number; error?: string }

async function checkSelf(): Promise<HealthCheck> {
  const start = Date.now()
  return { name: 'app', status: 'healthy', responseTime: Date.now() - start }
}

async function checkRedis(): Promise<HealthCheck> {
  const start = Date.now()
  // Stub: wire Redis adapter if you actually use it.
  const enabled = Boolean(process.env.REDIS_URL)
  return enabled
    ? { name: 'redis', status: 'degraded', responseTime: Date.now() - start, error: 'REDIS_URL set but redis checks not wired' }
    : { name: 'redis', status: 'healthy', responseTime: Date.now() - start }
}

async function checkDatabase(): Promise<HealthCheck> {
  const start = Date.now()
  // Stub: wire Prisma if you use it.
  const enabled = Boolean(process.env.DATABASE_URL)
  return enabled
    ? { name: 'database', status: 'degraded', responseTime: Date.now() - start, error: 'DATABASE_URL set but prisma checks not wired' }
    : { name: 'database', status: 'healthy', responseTime: Date.now() - start }
}

export async function GET(req: Request) {
  const perf = performanceMonitor(req as any)
  try {
    const checks = await Promise.all([checkSelf(), checkDatabase(), checkRedis()])
    const allHealthy = checks.every(c => c.status === 'healthy')
    const anyUnhealthy = checks.some(c => c.status === 'unhealthy')
    const overallStatus = anyUnhealthy ? 'unhealthy' : allHealthy ? 'healthy' : 'degraded'
    const res = NextResponse.json({ status: overallStatus, timestamp: new Date().toISOString(), checks }, { status: overallStatus === 'unhealthy' ? 503 : 200 })
    return perf.end(res as any)
  } catch (e: any) {
    log.error(e)
    const res = NextResponse.json({ status: 'unhealthy', error: e?.message || 'unknown' }, { status: 503 })
    return perf.end(res as any)
  }
}
