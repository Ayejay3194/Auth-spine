import { NextResponse } from "next/server";
import { analyzeTurn } from "@/nlu";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const text = String(body.text ?? "");
  const sessionId = String(body.sessionId ?? "default");

  const out = await analyzeTurn({ text, sessionId, persistState: false, debug: !!body.debug });
  return NextResponse.json(out);
}
