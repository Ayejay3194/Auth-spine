export default function Page() {
  return (
    <main style={{ fontFamily: "system-ui", padding: 24, lineHeight: 1.5 }}>
      <h1>Drift V1 (Next-only scaffold)</h1>
      <p>SMS webhook: <code>/api/sms/inbound</code></p>
      <p>Debug booking API: <code>/api/booking</code></p>
      <p>Memory-only by design. Swap infra when the wedge proves itself.</p>
    </main>
  );
}
