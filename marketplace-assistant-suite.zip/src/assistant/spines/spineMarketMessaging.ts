import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerMarketMessagingTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "market.message.send",
    title: "Send message",
    description: "Sends a message in a booking thread.",
    inputSchema: { type: "object", properties: { bookingId: { type: "string" }, fromId: { type: "string" }, text: { type: "string" } }, required: ["bookingId","fromId","text"] },
    async run(ctx, input) { return { ok: true, data: await p.marketMessaging.sendMessage(input) }; }
  });
}
