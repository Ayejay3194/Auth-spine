import type { NextApiRequest, NextApiResponse } from "next";
import { envList, safeEqual } from "../../lib/security/env";

// You should *prefer* serving metrics on an internal network (or sidecar), not the public app.
// This endpoint is gated by Bearer token OR IP allowlist.
export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const allowIps = envList(process.env.METRICS_IP_ALLOWLIST);
  const xf = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim();
  const ip = xf || (req.socket as any).remoteAddress || "";

  const auth = (req.headers.authorization ?? "").replace(/^Bearer\s+/i, "");
  const expected = process.env.METRICS_TOKEN ?? "";

  const okByIp = allowIps.includes(ip);
  const okByToken = expected && auth && safeEqual(auth, expected);

  if (!okByIp && !okByToken) {
    res.status(404).send("Not found");
    return;
  }

  res.setHeader("Content-Type", "text/plain; version=0.0.4");
  res.status(200).send([
    "# HELP process_cpu demo metric",
    "# TYPE process_cpu gauge",
    `process_cpu ${Math.random().toFixed(6)}`
  ].join("\n") + "\n");
}
