import type { AgentContext, AssistantState, Reply, AuditLogger, Clock } from "../core/types.js";
import { IntentDetector } from "../nlu/intents.js";
import { extractEntities } from "../nlu/entities.js";
import { ToolRegistry, runTool } from "../tools/registry.js";
import { PolicyEngine } from "../policy/policy.js";
import type { Flow } from "../flows/flowTypes.js";
import { SimpleTracer } from "../obs/tracer.js";

export function createAssistant(opts: {
  tools: ToolRegistry;
  policy: PolicyEngine;
  audit: AuditLogger;
  clock: Clock;
  detector: IntentDetector;
  flows: Flow[];
  tracer?: SimpleTracer;
}) {
  const tracer = opts.tracer ?? new SimpleTracer();
  const flowIndex = new Map(opts.flows.map(f => [f.id, f]));

  async function handle(ctx: AgentContext, state: AssistantState, text: string): Promise<{ state: AssistantState; reply: Reply }> {
    const span = tracer.start("assistant.handle", { textLen: text.length });

    // Rate limit
    const rate = await opts.policy.checkRate(ctx);
    if (!rate.ok) return { state, reply: { text: rate.error.message, done: true } };

    // Active flow continuation
    if (state.activeFlow) {
      const flow = flowIndex.get(state.activeFlow.id) ?? flowIndex.get("confirm");
      if (flow) {
        const out = await flow.handle({
          ctx,
          text,
          state,
          tools: opts.tools,
          intentId: "unknown",
          entities: {}
        });
        tracer.end(span, { path: "activeFlow" });
        return out;
      }
    }

    const det = opts.detector.detect(text);
    const entities = extractEntities(text);

    // Dispatch by intent -> tool/flow
    const toolMap: Record<string, string> = {
      "booking.list": "booking.list",
      "booking.cancel": "booking.cancel",
      "crm.find_client": "crm.find_client",
      "crm.add_note": "crm.add_note",
      "payments.create_invoice": "payments.create_invoice",
      "payments.refund": "payments.refund",
      "marketing.create_promo": "marketing.create_promo",
      "marketing.referral_status": "marketing.referral_status",
      "marketing.send_campaign": "marketing.send_campaign",
      "analytics.kpi": "analytics.kpi",
      "analytics.report_export": "analytics.report_export",
      "ops.list_tasks": "ops.list_tasks",
      "ops.create_task": "ops.create_task",
      "gdpr.export_request": "gdpr.export_request",
      "admin.show_audit": "admin.show_audit"
    };

    const toolId = toolMap[det.intent];
    if (!toolId) {
      tracer.end(span, { intent: det.intent, score: det.score });
      return { state, reply: { text: "I didn’t catch that. Try: “book appointment”, “create invoice $75”, “show revenue”.", done: true } };
    }

    if (!opts.policy.canUseTool(ctx, toolId)) {
      tracer.end(span, { denied: toolId });
      return { state, reply: { text: "Permission denied for that action.", done: true } };
    }

    const tool = opts.tools.get(toolId);
    if (!tool) return { state, reply: { text: "Tool missing. Refusing.", done: true } };

    // Build minimal input from entities, fallback to simple slot form for missing required fields
    const input = buildInput(toolId, ctx, text, entities);

    const missing = missingRequired(toolId, input);
    if (missing.length) {
      const reply: Reply = {
        text: `Need: ${missing.join(", ")}.`,
        ui: {
          type: "form",
          title: "Missing info",
          fields: missing.map(k => ({
            key: k,
            label: k,
            type: k.includes("amount") ? "number" : "text"
          }))
        },
        done: false
      };

      return {
        state: {
          ...state,
          activeFlow: { id: "slotFill", step: "collect", slots: { toolId, input }, requiresConfirm: opts.policy.needsConfirm(det.intent) }
        },
        reply
      };
    }

    // Confirm gate for sensitive intents
    if (opts.policy.needsConfirm(det.intent)) {
      return {
        state: {
          ...state,
          activeFlow: {
            id: "confirm",
            step: "confirm",
            slots: {},
            requiresConfirm: true,
            confirmPhrase: opts.policy.confirmPhrase(),
            pendingAction: { toolId, input }
          }
        },
        reply: { text: `Type **${opts.policy.confirmPhrase()}** to confirm.`, done: false }
      };
    }

    const res = await runTool({ tool, ctx, input, audit: opts.audit });
    tracer.end(span, { intent: det.intent, toolId });

    return res.ok
      ? { state, reply: formatToolReply(toolId, res.data) }
      : { state, reply: { text: `Failed: ${res.error.message}`, done: true } };
  }

  return { handle, tracer };
}

function buildInput(toolId: string, ctx: any, text: string, e: any) {
  switch (toolId) {
    case "booking.list":
      return { userId: ctx.userId };
    case "booking.cancel":
      return { bookingId: e.bookingId };
    case "crm.find_client":
      return { query: text.replace(/^find\s+/i, "").slice(0, 120) };
    case "crm.add_note":
      return { clientId: e.clientId, note: text };
    case "payments.create_invoice":
      return { clientId: e.clientId, amount: e.money };
    case "payments.refund":
      return { invoiceId: e.invoiceId };
    case "marketing.create_promo":
      return { code: e.promoCode, percentOff: e.percent };
    case "marketing.referral_status":
      return { code: e.promoCode ?? "" };
    case "marketing.send_campaign":
      return { segment: "all", message: text };
    case "analytics.kpi":
      return {};
    case "analytics.report_export":
      return { report: "kpi", format: "csv" };
    case "ops.list_tasks":
      return {};
    case "ops.create_task":
      return { title: text.replace(/^add\s+/i, "").slice(0, 140) };
    case "gdpr.export_request":
      return { userId: ctx.userId };
    case "admin.show_audit":
      return { limit: 50 };
    default:
      return {};
  }
}

function missingRequired(toolId: string, input: any): string[] {
  const req: Record<string, string[]> = {
    "booking.cancel": ["bookingId"],
    "crm.add_note": ["clientId", "note"],
    "payments.create_invoice": ["clientId", "amount"],
    "payments.refund": ["invoiceId"],
    "marketing.create_promo": ["code", "percentOff"],
  };
  const keys = req[toolId] ?? [];
  return keys.filter(k => input[k] === undefined || input[k] === null || input[k] === "");
}

function formatToolReply(toolId: string, data: any): Reply {
  switch (toolId) {
    case "analytics.kpi":
      return {
        text: "Here are your KPIs.",
        ui: { type: "table", title: "KPIs", columns: ["key", "value", "unit"], rows: data }
      };
    case "ops.list_tasks":
      return {
        text: "Tasks:",
        ui: { type: "table", title: "Tasks", columns: ["taskId", "title", "status"], rows: data }
      };
    default:
      return { text: "Done.", done: true };
  }
}
