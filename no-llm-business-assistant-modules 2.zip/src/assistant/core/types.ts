export type Role = "owner" | "admin" | "staff" | "assistant" | "accountant";

export type Channel = "web" | "mobile" | "api";

export type AgentContext = {
  businessId: string;
  userId: string;
  role: Role;
  timezone: string;
  locale: string;
  channel: Channel;
};

export type Clock = { now(): Date };

export type AuditEvent = {
  at: Date;
  businessId: string;
  actorId: string;
  role: Role;
  type: string;
  details: Record<string, unknown>;
};

export interface AuditLogger {
  write(ev: AuditEvent): Promise<void>;
}

export type AssistantState = {
  // flow state persisted between messages
  activeFlow?: {
    id: string;
    step: string;
    slots: Record<string, unknown>;
    // Optional “confirm” gate
    requiresConfirm?: boolean;
    confirmPhrase?: string; // e.g. "YES"
    pendingAction?: { toolId: string; input: any };
  };
  // user-level memory
  memory?: Record<string, unknown>;
};

export type UIForm = {
  type: "form";
  title: string;
  fields: Array<{
    key: string;
    label: string;
    help?: string;
    placeholder?: string;
    type: "text" | "number" | "date" | "select";
    options?: Array<{ label: string; value: string }>;
  }>;
};

export type UITable = {
  type: "table";
  title: string;
  columns: string[];
  rows: Array<Record<string, unknown>>;
};

export type Reply = {
  text: string;
  ui?: UIForm | UITable | null;
  done?: boolean;
};

export type ToolResult<T = unknown> =
  | { ok: true; data: T }
  | { ok: false; error: { code: string; message: string; details?: any } };
