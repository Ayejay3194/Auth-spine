#!/usr/bin/env node
import fs from "node:fs";

function loadJson(p){ return JSON.parse(fs.readFileSync(p,"utf8")); }
function saveJson(p,obj){ fs.writeFileSync(p, JSON.stringify(obj,null,2)); }

function flatten(checklist){
  const out=[];
  for (const sec of checklist.sections){
    for (const grp of sec.groups){
      for (const item of grp.items){
        out.push({id:item.id, section:sec.title, group:grp.title, text:item.text});
      }
    }
  }
  return out;
}

const [,,cmd,...args]=process.argv;

if(!cmd){
  console.log("commands: completion <checklist.json> <progress.json> | set <progress.json> <itemId> <status> [note]");
  process.exit(0);
}

if(cmd==="completion"){
  const [checkPath, progPath]=args;
  const checklist=loadJson(checkPath);
  const prog=loadJson(progPath);
  const flat=flatten(checklist);
  let done=0, total=flat.length;
  for(const it of flat){
    const st=prog.items?.[it.id]?.status ?? "todo";
    if(st==="done") done++;
  }
  const pct = total? Math.round((done/total)*1000)/10 : 0;
  console.log(JSON.stringify({total, done, percent:pct}, null, 2));
  process.exit(0);
}

if(cmd==="set"){
  const [progPath, itemId, status, ...noteParts]=args;
  const prog=loadJson(progPath);
  prog.items = prog.items || {};
  prog.items[itemId] = { status, note: noteParts.join(" ") || undefined, at: new Date().toISOString() };
  prog.updatedAt = new Date().toISOString();
  saveJson(progPath, prog);
  console.log(`set ${itemId} -> ${status}`);
  process.exit(0);
}

console.error("unknown command");
process.exit(1);
