import { Skill, SkillContext, SkillResult, SkillName } from "../types.js";
import { ChitchatSkill } from "./chitchat.js";
import { AstroInterpreterSkill } from "./astro.js";
import { WeatherSkill } from "./weather.js";
import { PlannerSkill } from "./planner.js";
import { BugTriageSkill } from "./bugtriage.js";
import { FileHelperSkill } from "./filehelper.js";
import { FallbackSkill } from "./fallback.js";

const SKILLS = new Map<SkillName, Skill>([
  ["ChitchatSkill", new ChitchatSkill()],
  ["AstroInterpreterSkill", new AstroInterpreterSkill()],
  ["WeatherSkill", new WeatherSkill()],
  ["PlannerSkill", new PlannerSkill()],
  ["BugTriageSkill", new BugTriageSkill()],
  ["FileHelperSkill", new FileHelperSkill()],
  ["FallbackSkill", new FallbackSkill()],
]);

export function getSkill(name: SkillName): Skill {
  const s = SKILLS.get(name);
  if (!s) throw new Error(`Unknown skill: ${name}`);
  return s;
}
