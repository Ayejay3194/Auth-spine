# Solari GenAI Kit (self-hosted, controlled generation)

Starter kit to turn JSONL + domain tools into a **controlled** generative system, with a data hygiene + eval harness
that covers the real failure modes: leakage, missing fields, imbalance, schema compliance, tool grounding.

Generated: 2026-02-26T00:43:37.781627Z

## Folders
- `training/` : JSONL conversion + validation + stats + dedupe + split (including group split) + Axolotl configs
- `serve/`    : vLLM OpenAI-compatible server (Docker) + optional auth proxy (x-api-key)
- `runtime/`  : schema-locked generation + tool router (TypeScript)
- `rag/`      : Postgres+pgvector compose + ingest/retrieval contracts
- `evals/`    : golden tests + results.json summary output

## Run order
1) `serve/` (model API)
2) `runtime/` (control plane)
3) `evals/` (regression checks)
