import { TenantContext } from "../../platform/tenant/types";
import { hasPermission, Permission } from "./rbac";

export class AuthorizationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AuthorizationError";
  }
}

/**
 * Object-Level Authorization (OLA)
 * Always check tenant ownership AND permission.
 */
export function assertTenantAccess(
  ctx: TenantContext,
  resourceTenantId: string,
  perm: Permission
) {
  if (ctx.tenantId !== (resourceTenantId as any)) {
    throw new AuthorizationError("Cross-tenant access blocked");
  }
  if (!hasPermission(ctx.roles, perm)) {
    throw new AuthorizationError("Permission denied");
  }
}
