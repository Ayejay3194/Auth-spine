import { Table as ArrowTable, Utf8Vector, Float64Vector, Int32Vector } from "apache-arrow";
import { latestCommitId } from "../delta/log.js";
import { writeParquetPartAndCommit } from "../delta/writePart.js";

async function run() {
  const cfg = { root: "./lake" };
  const table = "de440_residuals";
  const tableVersion = "v3";

  const expectedHead = await latestCommitId(cfg, table, tableVersion);

  const part = ArrowTable.new({
    ts: Utf8Vector.from(["2026-02-27T00:00:00Z", "2026-02-27T00:10:00Z"]),
    body: Utf8Vector.from(["Mercury", "Venus"]),
    dx: Float64Vector.from([1.36, 0.44]),
    dy: Float64Vector.from([0.44, 0.12]),
    model_version: Int32Vector.from([3, 3]),
  });

  const res = await writeParquetPartAndCommit({
    cfg,
    table,
    tableVersion,
    schemaVersion: "1",
    partition: { day: "2026-02-27" },
    part: 1,
    tableData: part,
    generator: "writeCommitDemo@local",
    expectedHead,
    message: "ingest residuals part-0001"
  });

  console.log(res);
}

run().catch((e) => { console.error(e); process.exit(1); });
