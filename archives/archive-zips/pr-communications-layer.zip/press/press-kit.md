PRESS KIT CONTENT
=================

Includes:
- Company boilerplate
- Founder bio
- Product overview
- Key differentiators
- Logo usage rules
- Screenshots
- Contact info

Update quarterly.
