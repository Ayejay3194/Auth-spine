## LEGAL & COMPLIANCE DISASTERS

### Privacy Violations
- [ ] No privacy policy
- [ ] Collecting data without consent
- [ ] No GDPR compliance
