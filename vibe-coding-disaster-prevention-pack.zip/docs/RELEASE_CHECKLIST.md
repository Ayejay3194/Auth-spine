# Release Checklist
- [ ] CI green (lint/typecheck/tests)
- [ ] Migrations applied in staging first
- [ ] Smoke test: auth, critical flows, payments/webhooks
- [ ] Observability: errors, latency, DB connections
- [ ] Rollback plan confirmed
- [ ] Feature flags used for risky changes
