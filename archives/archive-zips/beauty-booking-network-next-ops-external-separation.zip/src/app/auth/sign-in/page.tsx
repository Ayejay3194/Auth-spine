import { Container } from "@/components/Container";
import { SignInPanel } from "./ui";

export default function SignInPage(){
  return (
    <main className="py-14">
      <Container>
        <div className="mx-auto max-w-lg overflow-hidden rounded-[28px] border p-8" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
          <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Sign in</div>
          <h1 className="serif mt-2 text-3xl">Welcome back.</h1>
          <p className="mt-2 text-sm" style={{color:"var(--muted)"}}>Magic link or OAuth. Pick your poison.</p>
          <div className="mt-6">
            <SignInPanel />
          </div>
        </div>
      </Container>
    </main>
  );
}
