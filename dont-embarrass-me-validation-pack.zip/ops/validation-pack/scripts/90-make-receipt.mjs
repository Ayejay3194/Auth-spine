import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const out = path.join(root, 'out');

function readIf(p) { try { return fs.readFileSync(p, 'utf8'); } catch { return null; } }
function hashFile(p) {
  try { return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'); }
  catch { return null; }
}

const baseUrl = readIf(path.join(out, 'target_base_url.txt'))?.trim() || null;
const names = [
  'npm-audit.json','snyk.json',
  'zap-report.html','zap-report.json','zap-warnings.md','zap-report.xml',
  'api-abuse-results.json','api-abuse.log',
  'k6-smoke.log','k6-auth-abuse.log','artillery.json','load-test.json',
  'BACKUP_RESTORE_DRILL.md','INCIDENT_RUNBOOK.md','ROLLBACK.md'
];

const artifacts = names.map(name => {
  const p = path.join(out, name);
  return { name, sha256: hashFile(p), exists: fs.existsSync(p) };
});

const receipt = {
  kind: 'validation_receipt',
  version: '1.0.0',
  createdAt: new Date().toISOString(),
  baseUrl,
  artifacts
};

fs.writeFileSync(path.join(out, 'receipt.json'), JSON.stringify(receipt, null, 2));

const md = [];
md.push(`# Validation Receipt`);
md.push(`- Created: ${receipt.createdAt}`);
md.push(`- Target: ${receipt.baseUrl || 'unknown'}`);
md.push(``);
md.push(`## Artifacts`);
for (const a of artifacts) md.push(`- ${a.exists ? '✅' : '⚠️'} **${a.name}** ${a.sha256 ? `\`${a.sha256}\`` : ''}`);
md.push(``);
md.push(`## Quick tells (aka: do not embarrass yourself)`);
md.push(`- If **login-spam** never shows **429**, your rate limiting is fake.`);
md.push(`- If ZAP report shows **High/Medium**, fix those first, rerun.`);
md.push(`- If npm audit has **Critical/High**, patch/replace deps before launch.`);
fs.writeFileSync(path.join(out, 'receipt.md'), md.join('\n'));

console.log('Wrote receipt.json + receipt.md');
