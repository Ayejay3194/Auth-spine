import { BODY_ORDER, HOUSE_ORDER } from "./enums.js";
import type { ChartContract } from "./types.js";

export function sortPointsInPlace(chart: ChartContract): void {
  chart.points.bodies.sort((a, b) => BODY_ORDER.indexOf(a.key) - BODY_ORDER.indexOf(b.key));
  chart.points.houses.sort((a, b) => HOUSE_ORDER.indexOf(a.key) - HOUSE_ORDER.indexOf(b.key));
}
