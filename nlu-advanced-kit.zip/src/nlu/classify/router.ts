import type { NLUModel, NLUResult } from "../types";
import { keywordClassify } from "./keywordFallback";
import { retrieveClassify } from "./embeddingRetrieve";
import { llmJudge } from "./llmJudge";
import { pickBest } from "./confidence";

export async function classify(model: NLUModel, text: string): Promise<NLUResult> {
  const keyword = keywordClassify(model, text);
  const retrieved = retrieveClassify(model, text);

  // If both are weak, optionally ask LLM judge (stubbed by default).
  let llm: any = null;
  const weak = Math.max(keyword.confidence, retrieved.confidence) < 0.55;
  if (weak) llm = await llmJudge(model, text);

  const best = pickBest(model, [keyword, retrieved, ...(llm?.intent ? [llm.intent] : [])]);

  return {
    text,
    intent: best,
    entities: llm?.entities ?? [],
    isQuestion: /\?$/.test(text.trim()) || /^\s*(who|what|when|where|why|how)\b/i.test(text.trim()),
  };
}
