import type { NextRequest } from 'next/server'
import { NextResponse } from 'next/server'
import { AppError, ErrorCode } from '../errors.js'
import { log } from '../logger.js'

export function errorHandler(error: Error, req: NextRequest) {
  log.error(error, {
    path: req.nextUrl.pathname,
    method: req.method,
    query: Object.fromEntries(req.nextUrl.searchParams),
  })

  if (error instanceof AppError && error.isOperational) {
    return NextResponse.json(
      { error: { code: error.code, message: error.message, details: error.details } },
      { status: error.statusCode }
    )
  }

  return NextResponse.json(
    {
      error: {
        code: ErrorCode.INTERNAL_ERROR,
        message: process.env.NODE_ENV === 'production' ? 'An unexpected error occurred' : error.message,
      },
    },
    { status: 500 }
  )
}
