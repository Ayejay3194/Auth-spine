import { prisma } from "@/lib/prisma";
import { requireAdmin } from "../_guard";

export async function GET(req: Request){
  const g = await requireAdmin();
  if(!g.ok) return new Response("Forbidden", { status: g.status });

  const { searchParams } = new URL(req.url);
  const salonId = searchParams.get("salonId");
  if(!salonId) return new Response("Missing salonId", { status:400 });

  const members = await prisma.salonMembership.findMany({
    where:{ salonId, status:"ACTIVE" },
    include:{ stylist:true },
    orderBy:{ effectiveFrom:"desc" }
  });

  return Response.json({
    members: members.map(m => ({
      id: m.id,
      settings: m.settings || {},
      stylist: { displayName: m.stylist.displayName, slug: m.stylist.slug }
    }))
  });
}
