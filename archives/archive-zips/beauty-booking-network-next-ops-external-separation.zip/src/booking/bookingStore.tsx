"use client";
import React, { createContext, useContext, useMemo, useState } from "react";

export type BookingPreset = {
  stylistId?: string;
  stylistName?: string;
  salonId?: string | null;
  salonSlug?: string | null;
  serviceId?: string;
  serviceName?: string;
};

export type BookingState = BookingPreset & {
  open: boolean;
  date?: string;
  slot?: string;
  note?: string;
};

type BookingCtx = {
  state: BookingState;
  open: (preset?: BookingPreset) => void;
  close: () => void;
  set: (patch: Partial<BookingState>) => void;
  reset: () => void;
};

const Ctx = createContext<BookingCtx | null>(null);
const initial: BookingState = { open: false };

export function BookingProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<BookingState>(initial);
  const api = useMemo<BookingCtx>(() => ({
    state,
    open: (preset) => setState((s) => ({ ...s, ...preset, open: true })),
    close: () => setState((s) => ({ ...s, open: false })),
    set: (patch) => setState((s) => ({ ...s, ...patch })),
    reset: () => setState(initial),
  }), [state]);
  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useBooking(){ const v = useContext(Ctx); if(!v) throw new Error("useBooking must be used inside BookingProvider"); return v; }
