HOURS VERIFICATION
==================

Sources of truth:
- Scheduled shift
- Actual clock-in / clock-out
- Booking/service completion
- Manager approval (optional)

Rules:
- Hours must match bookings or shifts
- Edits require reason + audit log
- Retroactive changes flagged

Statuses:
- pending
- verified
- disputed
- locked
