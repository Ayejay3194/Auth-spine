import type { PrismaClient } from "@prisma/client";

/**
 * Enforce tenantId on Prisma queries for models that include tenantId.
 * This is a guardrail, not a silver bullet.
 *
 * Usage:
 *   import { withTenant } from "@/src/tenant/prismaTenantMiddleware";
 *   const prisma = withTenant(basePrisma, () => currentTenantId);
 */
const TENANT_MODELS = new Set([
  "AssistantConversation",
  "AssistantAuditEvent",
  "DataSubjectRequest",
  "SupportTicket",
  "Subscription",
  "FileObject",
  "Integration",
  "CalendarAccount",
  // Add your business tables here: Booking, Client, Invoice, etc.
]);

export function withTenant(prisma: PrismaClient, getTenantId: () => string) {
  prisma.$use(async (params, next) => {
    if (!TENANT_MODELS.has(params.model ?? "")) return next(params);

    const tenantId = getTenantId();

    // Inject tenant filter for reads
    if (["findFirst","findMany","findUnique","count","aggregate","groupBy"].includes(params.action)) {
      params.args = params.args ?? {};
      params.args.where = params.args.where ?? {};
      // Don't override if explicitly set
      if (params.args.where.tenantId == null) params.args.where.tenantId = tenantId;
    }

    // Inject tenant for writes
    if (["create","createMany","upsert"].includes(params.action)) {
      params.args = params.args ?? {};
      params.args.data = params.args.data ?? {};
      if (Array.isArray(params.args.data)) {
        params.args.data = params.args.data.map((d: any) => ({ tenantId, ...d }));
      } else {
        params.args.data = { tenantId, ...params.args.data };
      }
    }

    if (["update","updateMany","delete","deleteMany"].includes(params.action)) {
      params.args = params.args ?? {};
      params.args.where = params.args.where ?? {};
      if (params.args.where.tenantId == null) params.args.where.tenantId = tenantId;
    }

    return next(params);
  });

  return prisma;
}
