import { z } from "zod";
import { api } from "@/src/core/api";
import { prisma } from "@/lib/prisma";
import { getTenant } from "@/src/tenant/tenant";
import { getActor } from "@/src/core/auth";

const Q = z.object({ plan: z.string().min(1), provider: z.enum(["stripe","manual"]).default("manual") });
export async function POST(req: Request) {
  return api(async () => {
    const actor = getActor(req);
    const { tenantId } = getTenant(req);
    const body = Q.parse(await req.json());
    const sub = await prisma.subscription.create({ data: { tenantId, userId: actor.userId, plan: body.plan, provider: body.provider, status: "active" } });
    return { subscriptionId: sub.id, status: sub.status };
  });
}
