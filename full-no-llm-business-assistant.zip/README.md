FULL NO-LLM BUSINESS ASSISTANT SUITE

Includes:
- Agent runtime (no LLM)
- Booking / CRM / Payments / Marketing / Analytics / Ops / Admin spines
- Policy + audit + rate limiting
- Next.js API routes
- Provider interfaces + Prisma-ready adapters
- Conversation state + audit persistence
- Deterministic intent + flow engine

This is a BUILD-ONCE architecture.
