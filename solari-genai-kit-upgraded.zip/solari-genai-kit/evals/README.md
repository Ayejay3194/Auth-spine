# evals/

Golden tests that hit `runtime/` and produce `results/results.json`.

## Run
```bash
npm i
API_KEY=change-me MODEL_BASE_URL=http://localhost:8080 RUNTIME_URL=http://localhost:7777/generate npm run run
```

Outputs:
- console summary
- `results/results.json` with parse/schema/repair rates + per-test details
