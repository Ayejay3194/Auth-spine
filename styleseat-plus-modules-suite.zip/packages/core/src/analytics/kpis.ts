import type { ID, ISODateTime } from "../shared/types.js";

export type MetricPoint = { at: ISODateTime; value: number };
export type MetricSeries = { key: string; label: string; unit?: string; points: MetricPoint[] };

export interface KPIDataSource {
  revenueSeries(businessId: ID, sinceISO: ISODateTime): Promise<MetricSeries>;
  bookingsSeries(businessId: ID, sinceISO: ISODateTime): Promise<MetricSeries>;
  cancellationsSeries(businessId: ID, sinceISO: ISODateTime): Promise<MetricSeries>;
  newClientsSeries(businessId: ID, sinceISO: ISODateTime): Promise<MetricSeries>;
}

export type Dashboard = { businessId: ID; sinceISO: ISODateTime; series: MetricSeries[] };

export async function buildDashboard(ds: KPIDataSource, businessId: ID, sinceISO: ISODateTime): Promise<Dashboard> {
  const [r,b,c,n] = await Promise.all([
    ds.revenueSeries(businessId, sinceISO),
    ds.bookingsSeries(businessId, sinceISO),
    ds.cancellationsSeries(businessId, sinceISO),
    ds.newClientsSeries(businessId, sinceISO),
  ]);
  return { businessId, sinceISO, series: [r,b,c,n] };
}
