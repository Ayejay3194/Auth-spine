// ai_insights intents.ts
