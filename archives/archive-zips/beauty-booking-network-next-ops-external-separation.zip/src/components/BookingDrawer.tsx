"use client";
import { useEffect, useMemo, useState } from "react";
import clsx from "clsx";
import { useBooking } from "@/booking/bookingStore";

type Service = { id: string; name: string; durationMin: number; basePriceCents: number; priceCentsFinal?: number };
type Stylist = { id: string; slug: string; displayName: string; services: Service[]; membership?: { salonId?: string; salonSlug?: string; approvalRequired?: boolean } };

const fmt = (c:number)=>`$${Math.round(c/100)}`;

function Chip({ active, children, onClick }:{active?:boolean; children:any; onClick?:()=>void}){
  return (
    <button onClick={onClick}
      className={clsx("rounded-full border px-3 py-2 text-sm transition", active ? "font-semibold":"")}
      style={{
        borderColor: active ? "var(--accent)" : "var(--border)",
        background: active ? "var(--accent)" : "var(--panel)",
        color: active ? "var(--accentText)" : "var(--text)",
      }}>
      {children}
    </button>
  );
}

export function BookingDrawer(){
  const { state, close, set, reset } = useBooking();
  const [stylist, setStylist] = useState<Stylist | null>(null);
  const [slots, setSlots] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [note, setNote] = useState<string>("");

  const date = state.date || new Date().toISOString().slice(0,10);

  useEffect(()=>{ if(state.open) document.body.style.overflow="hidden"; return ()=>{document.body.style.overflow="";}; },[state.open]);

  useEffect(()=>{
    if(!state.open || !state.stylistId) return;
    (async()=>{
      const r = await fetch(`/api/stylists/by-id/${state.stylistId}`, { cache:"no-store" });
      if(!r.ok) return;
      const data = await r.json();
      setStylist(data.stylist);
      if(!state.serviceId && data.stylist.services?.[0]) {
        set({ serviceId: data.stylist.services[0].id, serviceName: data.stylist.services[0].name });
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[state.open, state.stylistId]);

  useEffect(()=>{
    if(!state.open || !state.stylistId || !state.serviceId) return;
    (async()=>{
      setLoading(true);
      setSlots([]);
      const qs = new URLSearchParams({ stylistId: state.stylistId!, serviceId: state.serviceId!, date });
      const r = await fetch(`/api/availability?${qs.toString()}`, { cache:"no-store" });
      const data = await r.json();
      setSlots(data.slots || []);
      setLoading(false);
    })();
  },[state.open, state.stylistId, state.serviceId, date]);

  const service = useMemo(()=> stylist?.services.find(s=>s.id===state.serviceId) || null, [stylist, state.serviceId]);
  const approvalRequired = stylist?.membership?.approvalRequired;

  if(!state.open) return null;

  const canConfirm = Boolean(state.stylistId && state.serviceId && state.slot);

  async function confirm(){
    setNote("");
    if(!canConfirm) return;
    const payload = { stylistId: state.stylistId, serviceId: state.serviceId, startAt: state.slot, salonId: stylist?.membership?.salonId ?? null };
    const r = await fetch("/api/bookings", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify(payload) });
    if(!r.ok){
      setNote("That slot just got snatched. Pick another time.");
      return;
    }
    const data = await r.json();
    setNote(data.booking.status === "PENDING_APPROVAL" ? "Request sent. Waiting on approval." : "Booked. Quiet luxury. Loud results.");
    setTimeout(()=>{ reset(); close(); }, 900);
  }

  return (
    <>
      <div className="fixed inset-0 z-50" onClick={close} style={{background:"color-mix(in srgb, var(--text) 22%, transparent)"}}/>
      <aside className="fixed right-0 top-0 z-50 h-full w-[min(520px,92vw)] border-l p-4" style={{borderColor:"var(--border)", background:"var(--panel)"}}>
        <div className="flex items-center justify-between border-b pb-3" style={{borderColor:"var(--border)"}}>
          <div>
            <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Book</div>
            <div className="serif text-lg">Appointment</div>
          </div>
          <button className="rounded-xl border px-3 py-2 text-sm" style={{borderColor:"var(--border)"}} onClick={close}>✕</button>
        </div>

        <div className="space-y-4 overflow-auto py-4" style={{maxHeight:"calc(100vh - 190px)"}}>
          <section className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
            <div className="text-xs tracking-[.14em] uppercase" style={{color:"var(--dim)"}}>Stylist</div>
            <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>
              <div><b style={{color:"var(--text)"}}>{state.stylistName || stylist?.displayName || "Stylist"}</b></div>
              {stylist?.membership?.salonSlug ? <div>At {stylist.membership.salonSlug.replaceAll("-"," ")}</div> : <div>Independent</div>}
            </div>
          </section>

          <section className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
            <div className="flex items-center justify-between">
              <div className="text-xs tracking-[.14em] uppercase" style={{color:"var(--dim)"}}>Service</div>
              {service ? <div className="text-xs" style={{color:"var(--dim)"}}>{service.durationMin}m · {fmt((service as any).priceCentsFinal ?? service.basePriceCents)}</div> : null}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {(stylist?.services || []).map(s => (
                <Chip key={s.id} active={state.serviceId===s.id} onClick={()=>set({ serviceId: s.id, serviceName: s.name, slot: undefined })}>
                  {s.name}
                </Chip>
              ))}
            </div>
          </section>

          <section className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
            <div className="flex items-center justify-between">
              <div className="text-xs tracking-[.14em] uppercase" style={{color:"var(--dim)"}}>Date</div>
              <input type="date" value={date} onChange={(e)=>set({ date: e.target.value, slot: undefined })}
                className="rounded-xl border px-3 py-2 text-sm" style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}} />
            </div>
          </section>

          <section className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
            <div className="text-xs tracking-[.14em] uppercase" style={{color:"var(--dim)"}}>Time</div>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {loading ? <div className="col-span-3 text-sm" style={{color:"var(--muted)"}}>Loading availability…</div> :
                (slots.length ? slots.map(iso => {
                  const d = new Date(iso);
                  const label = d.toLocaleTimeString([], { hour:"numeric", minute:"2-digit" });
                  return <Chip key={iso} active={state.slot===iso} onClick={()=>set({ slot: iso })}>{label}</Chip>;
                }) : <div className="col-span-3 text-sm" style={{color:"var(--muted)"}}>No slots. Try another date.</div>)
              }
            </div>
          </section>
        </div>

        <div className="border-t pt-3" style={{borderColor:"var(--border)"}}>
          {approvalRequired ? <div className="mb-2 text-sm" style={{color:"var(--muted)"}}>This stylist requires approval for some bookings.</div> : null}
          {note ? <div className="mb-2 text-sm" style={{color:"var(--muted)"}}>{note}</div> : null}
          <button className="w-full rounded-2xl px-4 py-3 text-sm font-semibold transition disabled:opacity-50"
            style={{background:"var(--accent)", color:"var(--accentText)"}} disabled={!canConfirm} onClick={confirm}>
            {approvalRequired ? "Request booking" : "Confirm booking"}
          </button>
        </div>
      </aside>
    </>
  );
}
