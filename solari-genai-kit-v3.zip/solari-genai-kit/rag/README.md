Postgres+pgvector compose and schema. Add embeddings + ingest next.
