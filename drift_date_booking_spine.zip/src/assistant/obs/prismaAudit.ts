import type { PrismaClient } from "@prisma/client";
import type { AuditLogger, AuditEvent } from "../runtimeTypes.js";

export class PrismaAuditLogger implements AuditLogger {
  constructor(private prisma: PrismaClient) {}

  async write(ev: AuditEvent): Promise<void> {
    await this.prisma.assistantAuditEvent.create({
      data: {
        businessId: ev.businessId,
        actorId: ev.actorId,
        role: ev.role,
        type: ev.type,
        detailsJson: ev.details as any,
        createdAt: ev.at,
      },
    });
  }
}
