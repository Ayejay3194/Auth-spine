import fs from "node:fs";

const progressPath = process.argv[2] ?? "../data/progress_template.json";
const id = process.argv[3];
const status = process.argv[4] ?? "done";
const notes = process.argv.slice(5).join(" ") ?? "";

if (!id) {
  console.error("Usage: node set-status.js <progress.json> <itemId> <status> [notes...]");
  process.exit(1);
}

const progress = JSON.parse(fs.readFileSync(progressPath, "utf-8"));
progress.overrides = progress.overrides ?? [];

const idx = progress.overrides.findIndex(o => o.id === id);
const entry = { id, status, notes };

if (idx >= 0) progress.overrides[idx] = entry;
else progress.overrides.push(entry);

progress.meta.updated_at = new Date().toISOString();
fs.writeFileSync(progressPath, JSON.stringify(progress, null, 2));
console.log(`Set ${id} -> ${status}`);
