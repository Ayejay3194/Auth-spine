import type { Flow } from "./flowTypes.js";
import { runTool } from "../tools/registry.js";

export function makeConfirmFlow(audit: any): Flow {
  return {
    id: "confirm",
    async handle({ ctx, text, state, tools }) {
      const af = state.activeFlow;
      const phrase = String(af?.confirmPhrase ?? "YES");
      if (text.trim().toUpperCase() !== phrase) {
        if (/\bcancel\b/i.test(text)) return { state: { ...state, activeFlow: undefined }, reply: { text: "Canceled.", done: true } };
        return { state, reply: { text: `Type **${phrase}** to confirm, or say cancel.`, done: false } };
      }
      const pending = af?.pendingAction;
      const tool = tools.get(pending.toolId);
      const res = await runTool({ tool, ctx, input: pending.input, audit });
      return { state: { ...state, activeFlow: undefined }, reply: res.ok ? { text: "Done.", done: true } : { text: `Failed: ${res.error.message}`, done: true } };
    }
  };
}
