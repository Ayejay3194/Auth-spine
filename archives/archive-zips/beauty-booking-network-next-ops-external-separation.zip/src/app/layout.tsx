import "./globals.css";
import "@/theme/tokens.css";
import { Providers } from "./providers";
import { Topbar } from "@/components/Topbar";
import { Footer } from "@/components/Footer";
import { BookingDrawer } from "@/components/BookingDrawer";

export const metadata = { title: "LUXBOOK", description: "Stylist portfolios with bookings behind them." };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="light">
      <body>
        <Providers>
          <Topbar />
          {children}
          <Footer />
          <BookingDrawer />
        </Providers>
      </body>
    </html>
  );
}
