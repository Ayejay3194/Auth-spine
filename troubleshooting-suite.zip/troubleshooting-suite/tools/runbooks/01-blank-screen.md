# Blank screen / white page

## Fast isolation (5 minutes)
1. DevTools Console: any red errors at load?
2. DevTools Network: main JS bundle 404? CSS 404?
3. Disable extensions + hard reload.
4. If users report it but you can't reproduce: suspect **service worker** cache.

## Top causes
- runtime JS error prevents render
- wrong root mount ID
- missing env var causing crash in init
- asset path/basePath mismatch (subpath deploy)
- stale service worker cache

## Fix patterns
- reproduce with `npm run build && npm run preview/start`
- clear SW: devtools Application > Service Workers > Unregister, then hard reload
- ensure assets are hashed, and SW update flow exists
