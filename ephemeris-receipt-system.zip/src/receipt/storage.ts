
import fs from "node:fs";
import path from "node:path";
import { EphemerisReceipt, EphemerisReceipt as ReceiptSchema } from "./types.js";

/**
 * Append-only JSONL ledger: one receipt per line.
 * This is intentionally simple, durable, and git-friendly.
 */
export function appendReceiptToLedger(ledgerPath: string, receipt: EphemerisReceipt) {
  const dir = path.dirname(ledgerPath);
  fs.mkdirSync(dir, { recursive: true });
  fs.appendFileSync(ledgerPath, JSON.stringify(receipt) + "\n", "utf-8");
}

export function readLedger(ledgerPath: string): EphemerisReceipt[] {
  if (!fs.existsSync(ledgerPath)) return [];
  const lines = fs.readFileSync(ledgerPath, "utf-8").split(/\r?\n/).filter(Boolean);
  return lines.map((line) => ReceiptSchema.parse(JSON.parse(line)));
}
