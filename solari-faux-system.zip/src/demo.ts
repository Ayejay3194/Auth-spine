import readline from "node:readline";
import { SolariFaux } from "./orchestrator.js";

const paths = [
  process.env.SOLARI_JSONL_PATH,
  process.env.SOLARI_JSONL_PATH_2,
].filter(Boolean) as string[];

const solari = new SolariFaux({ jsonlPaths: paths });

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log("Solari Faux System (no LLM). Type messages. Ctrl+C to exit.");

function ask() {
  rl.question("> ", async (line) => {
    const out = await solari.respondTo(line);
    console.log("\n" + out.message.content + "\n");
    // Uncomment for debug:
    // console.log(out.debug);
    ask();
  });
}

ask();
