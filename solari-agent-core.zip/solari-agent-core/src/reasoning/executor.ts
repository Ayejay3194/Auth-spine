import { AuditLog } from "../governance/audit";
import { Plan, PlanStep, WorkingState } from "../types";
import { requireAuditForStep } from "../governance/policy";

export interface ExecuteResult {
  completedStepIds: string[];
  notes: string[];
}

export function executePlan(args: {
  plan: Plan;
  working: WorkingState;
  audit: AuditLog;
  onRespond: (step: PlanStep) => void;
  onWriteFile: (step: PlanStep) => void;
  onTool?: (step: PlanStep) => void;
}): ExecuteResult {
  const completed: string[] = [];
  const notes: string[] = [];

  for (const step of args.plan.steps) {
    if (requireAuditForStep(step)) {
      args.audit.append({
        ts: new Date().toISOString(),
        conversationId: args.working.conversationId,
        sessionId: args.working.conversationId,
        kind: "tool",
        payload: { stepId: step.id, action: step.action, toolName: step.toolName ?? null },
      });
    }

    if (step.action === "respond") args.onRespond(step);
    if (step.action === "write_file") args.onWriteFile(step);
    if (step.action === "tool") args.onTool?.(step);

    completed.push(step.id);
  }

  return { completedStepIds: completed, notes };
}
