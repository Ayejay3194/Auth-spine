DEGENERATION SIGNALS
====================

Watch for:
- rising refunds without complaints
- increased admin overrides
- shortened support resolution times
- higher manual intervention rates
- silent churn

If triggered, require review.
