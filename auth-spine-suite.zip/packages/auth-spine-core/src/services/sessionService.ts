import type { SessionStore, SessionRecord, SessionRevocationReason } from "../ports/sessionStore.js";
import type { ClockPort } from "../ports/clockPort.js";
import { AuthError } from "../model/errors.js";
import type { EventBus } from "../model/events.js";
import type { AuthCapabilities } from "../model/capabilities.js";
import { randomId } from "../util/crypto.js";

export class SessionService {
  constructor(private sessions: SessionStore, private clock: ClockPort, private bus: EventBus, private caps: AuthCapabilities) {}

  async create(userId: string, meta?: { deviceId?: string; ip?: string; userAgent?: string }): Promise<SessionRecord> {
    if (this.caps.maxConcurrentSessions > 0) await this.sessions.enforceConcurrency(userId, this.caps.maxConcurrentSessions);
    const now = this.clock.nowIso();
    return this.sessions.create({
      id: randomId("sess_"),
      userId,
      deviceId: meta?.deviceId,
      ip: meta?.ip,
      userAgent: meta?.userAgent,
      createdAt: now,
      lastSeenAt: now,
    } as any);
  }

  async assertActive(sessionId: string): Promise<SessionRecord> {
    const s = await this.sessions.byId(sessionId);
    if (!s) throw new AuthError("SESSION_EXPIRED", "Session not found", 401);
    if (s.revokedAt) throw new AuthError("SESSION_REVOKED", "Session revoked", 401, { reason: s.revokedReason });
    return s;
  }

  async revoke(session: SessionRecord, reason: SessionRevocationReason, revokedBy?: string): Promise<void> {
    const at = this.clock.nowIso();
    await this.sessions.revoke(session.id, reason, revokedBy, at);
    await this.bus.publish({ type: "auth.session.revoked", userId: session.userId, sessionId: session.id, reason, at });
  }

  async revokeAll(userId: string, reason: SessionRevocationReason, revokedBy?: string): Promise<number> {
    return this.sessions.revokeAllForUser(userId, reason, revokedBy);
  }
}
