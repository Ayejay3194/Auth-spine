// discovery intents.ts
