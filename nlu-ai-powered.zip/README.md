# AI-Powered NLU System (Next.js + Tailwind)

This is a plug-and-play NLU editor + tester:
- Edit intents/entities + descriptions
- Classify text using server-side API routes
- Export/import model JSON
- Import JSONL datasets (auto-creates intents/entities)
- Generate JSONL training data (20 lines) and auto-merge

## Setup

1) Install
```bash
npm install
```

2) Add env
```bash
cp .env.example .env.local
# put your ANTHROPIC_API_KEY in .env.local
```

3) Run
```bash
npm run dev
```

Open: http://localhost:3000

## Files

- `components/NLUSystem.tsx` UI
- `app/api/nlu/classify/route.ts` server-side classification proxy
- `app/api/nlu/generate/route.ts` server-side JSONL generator proxy
- `lib/anthropic.ts` Anthropic fetch helper + JSON parsing

## JSONL expected format
Each line:
```json
{"text":"book a flight to NYC","intent":"book_flight","entities":[{"entity":"location","value":"NYC"}]}
```
