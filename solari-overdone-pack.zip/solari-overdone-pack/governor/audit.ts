import { ToneDecisionInput, ToneLine } from "./types";

export interface ToneAuditEvent {
  ts: string;
  sessionId: string;
  product: string;
  intent: string;
  trigger: string;
  confidence: number;
  risk: string;
  selectedIds: string[];
  selectedCategories: string[];
  selectedIntensities: number[];
  reason: string;
  diagnostics?: Record<string, unknown>;
}

export function makeToneAuditEvent(args: {
  sessionId: string;
  input: ToneDecisionInput;
  selected: ToneLine[];
  reason: string;
  diagnostics?: Record<string, unknown>;
}): ToneAuditEvent {
  return {
    ts: new Date().toISOString(),
    sessionId: args.sessionId,
    product: args.input.product,
    intent: args.input.intent,
    trigger: args.input.trigger,
    confidence: args.input.confidence,
    risk: args.input.risk,
    selectedIds: args.selected.map(s => s.id),
    selectedCategories: args.selected.map(s => s.category),
    selectedIntensities: args.selected.map(s => s.intensity),
    reason: args.reason,
    diagnostics: args.diagnostics,
  };
}
