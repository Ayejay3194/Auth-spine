"use client";
import React from "react";
import { getConsent, setConsent, Consent } from "../privacy/consent";

export function CookieBanner(){
  const [c,setC]=React.useState<Consent| null>(null);
  React.useEffect(()=>setC(getConsent()),[]);
  if(!c || c.dismissed) return null;

  const accept=()=>{ const n:{v:"v1";necessary:true;functional:boolean;analytics:boolean;marketing:boolean;dismissed:boolean}={v:"v1",necessary:true,functional:true,analytics:true,marketing:true,dismissed:true}; setConsent(n); setC(n); };
  const reject=()=>{ const n:Consent={v:"v1",necessary:true,functional:true,analytics:false,marketing:false,dismissed:true}; setConsent(n); setC(n); };

  return (
    <div style={{position:"fixed",bottom:16,left:16,right:16,zIndex:999,border:"1px solid #ddd",borderRadius:12,padding:16,background:"white"}}>
      <strong>Cookies & tracking</strong>
      <div style={{fontSize:14,marginTop:8}}>Necessary cookies run the site. Analytics are optional.</div>
      <div style={{display:"flex",gap:8,marginTop:12,flexWrap:"wrap"}}>
        <button onClick={accept}>Accept all</button>
        <button onClick={reject}>Reject non-essential</button>
        <a href="/privacy" style={{alignSelf:"center"}}>Privacy Settings</a>
      </div>
    </div>
  );
}
