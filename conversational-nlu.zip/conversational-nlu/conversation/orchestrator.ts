import { classify } from "../nlu/classifier";
import { validateNLU } from "../nlu/validators";
import { policyDecide } from "./policy";
import { render } from "./renderer";
import { writeReceipt } from "./receipts";

export async function handleTurn(input, state) {
  const nlu = await classify(input);
  const validated = validateNLU(nlu);
  const decision = policyDecide(validated, state);
  const response = render(decision, state);

  writeReceipt({ input, nlu, decision, response });
  return { response, newState: decision.state };
}
