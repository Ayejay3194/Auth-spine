export type User = { id: string; email: string; roles: string[]; };
export type AuthState = { user: User | null; loading: boolean; };
