import UITroubleshootKit from "@/components/UITroubleshootKit";
export default function Page() { return <UITroubleshootKit />; }
