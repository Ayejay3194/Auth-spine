NIST CSF CROSSWALK

Identify:
- Protect
- Detect
- Respond
- Recover

Maps technical controls to framework outcomes.