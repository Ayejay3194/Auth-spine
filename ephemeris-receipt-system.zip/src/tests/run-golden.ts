
import { GOLDEN } from "./goldenVectors.js";

/**
 * Wire this to your actual ephemeris evaluation function.
 * For now, it's a stub so the repo compiles.
 */
async function evalBodyKm(_body: string, _tdbIso: string): Promise<[number, number, number]> {
  // TODO: import your DE440 evaluator and return [x,y,z] in km in ICRF.
  return [ -265044.0, 132749.0, 57528.0 ];
}

function maxAbsDiff(a: [number,number,number], b: [number,number,number]) {
  return Math.max(Math.abs(a[0]-b[0]), Math.abs(a[1]-b[1]), Math.abs(a[2]-b[2]));
}

async function main() {
  let failures = 0;
  for (const g of GOLDEN) {
    const got = await evalBodyKm(g.body, g.tdbIso);
    const err = maxAbsDiff(got, g.expectedKm);
    const ok = err <= g.toleranceKm;
    if (!ok) {
      failures++;
      console.error(`[FAIL] ${g.id} err=${err}km tol=${g.toleranceKm}km got=${got} expected=${g.expectedKm}`);
    } else {
      console.log(`[OK]   ${g.id} err=${err}km`);
    }
  }
  if (failures) process.exit(1);
}

main().catch((e) => { console.error(e); process.exit(1); });
