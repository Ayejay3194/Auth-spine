# Module 4 – Auth Patterns

Goal:
- Understand how to protect pages, identify users, and store sessions.

Tasks:
- Read stubbed auth routes in `app/api/auth`.
- Replace mocks with real auth provider (NextAuth or Lucia).
- Add "requireAuth" wrapper to dashboard routes.
