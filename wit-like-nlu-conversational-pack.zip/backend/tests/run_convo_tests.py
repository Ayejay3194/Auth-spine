import json
import pathlib
from backend.app.nlu.pipeline import NLUPipeline
from backend.app.dialogue.manager import DialogueManager
from backend.app.nlg.renderer import NLGRenderer
from backend.app.store.sessions import SessionStore

root = pathlib.Path(__file__).resolve().parent
files = list((root / "conversations").glob("*.jsonl"))

nlu = NLUPipeline()
dm = DialogueManager()
nlg = NLGRenderer()
sessions = SessionStore()

def run_case(case: dict, sid: str):
    resp = None
    for turn in case["turns"]:
        state = sessions.get(sid)
        nlu_out = nlu.parse(turn)
        dm_out = dm.next(state, turn, nlu_out)
        resp = nlg.render(dm_out)
        sessions.set(sid, dm_out["state"])
    return resp

def main():
    total = 0
    failed = 0
    for f in files:
        for line in f.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            total += 1
            case = json.loads(line)
            resp = run_case(case, f"t{total}")
            exp = case.get("expect", {})
            ok = True
            if "contains" in exp:
                ok = exp["contains"].lower() in resp["text"].lower()
            if not ok:
                failed += 1
                print(f"[FAIL] {f.name}: expected {exp} got {resp['text']}")
    print(f"Done. total={total} failed={failed}")
    raise SystemExit(1 if failed else 0)

if __name__ == "__main__":
    main()
