import { section, ok, fail, readJson, exists, findFiles, run } from "./_util.mjs";

const cfg = readJson("./infra.config.json");

async function optional(cmd, args, name){
  section(name);
  const code = await run(cmd, args);
  if(code===127 || code===9009){
    console.log(`⚠️  ${cmd} not found. Skipping ${name}. Install it to enforce this check.`);
    return 0;
  }
  if(code!==0) fail(`${name} failed`);
  else ok(`${name} passed`);
  return code;
}

section("Prometheus rule validation (if you have it)");
for(const dir of (cfg.paths.observability ?? [])){
  if(!exists(dir)) continue;
  const rules = findFiles(dir, [".yml",".yaml"]);
  if(!rules.length) continue;
  // promtool checks for rule files
  await optional("promtool", ["check", "rules", dir], `promtool check rules (${dir})`);
  await optional("amtool", ["check-config", `${dir}/alertmanager.yml`], `amtool check-config (${dir}/alertmanager.yml)`);
}

section("Structured logging expectations (lightweight)");
if(exists("./apps")){
  const logs = findFiles("./apps", [".ts",".js",".mjs"]).filter(f=>!f.includes("node_modules"));
  let foundStructured = 0;
  for(const f of logs){
    // crude: look for JSON logging or pino/winston base
    const t = (await import("node:fs")).default.readFileSync(f,"utf-8").toLowerCase();
    if(t.includes("pino") || t.includes("winston") || t.includes("logger.") || t.includes("trace_id") || t.includes("span_id")) foundStructured++;
  }
  if(foundStructured===0) {
    console.log("⚠️  Couldn't find obvious structured logging patterns. Maybe it's elsewhere. Maybe it doesn't exist. Both are fun.");
  } else {
    ok(`Found likely structured logging usage in ${foundStructured} file(s)`);
  }
}
