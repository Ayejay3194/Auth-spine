import { NextRequest, NextResponse } from "next/server";
import { tenantGuard } from "../../../security/middleware/tenantGuard";
import { enforceRateLimit } from "../../../security/ratelimit/middleware";
import { safeReturn } from "../../../security/assistant/safeReturn";

export async function GET(req: NextRequest) {
  const ctx = await tenantGuard(req);
  await enforceRateLimit(ctx, "example:get", 60, 60_000);

  const data = {
    tenantId: ctx.tenantId,
    hello: "world",
    internalNotes: "this should never leak",
  };

  const out = await safeReturn(ctx, "api:example:get", data);
  return NextResponse.json(out);
}
