# Engineer Growth Ladder – Career Levels Pack
Includes:
- Career ladder levels 0–5 + Meta Engineer
- Game skill tree
- Salary mapping
- Onboarding version
