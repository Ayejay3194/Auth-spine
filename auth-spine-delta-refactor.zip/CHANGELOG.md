## v1.0
- Added optional security delta modules
- Updated architecture layout