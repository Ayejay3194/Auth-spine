import { ToneDecisionInput, ToneLine } from "./types";

export interface ToneAuditEvent {
  ts: string;
  sessionId: string;
  intent: string;
  trigger: string;
  confidence: number;
  risk: string;
  selectedIds: string[];
  selectedCategories: string[];
  selectedIntensities: number[];
  reason: string;
}

export function makeToneAuditEvent(args: {
  sessionId: string;
  input: ToneDecisionInput;
  selected: ToneLine[];
  reason: string;
}): ToneAuditEvent {
  return {
    ts: new Date().toISOString(),
    sessionId: args.sessionId,
    intent: args.input.intent,
    trigger: args.input.trigger,
    confidence: args.input.confidence,
    risk: args.input.risk,
    selectedIds: args.selected.map(s => s.id),
    selectedCategories: args.selected.map(s => s.category),
    selectedIntensities: args.selected.map(s => s.intensity),
    reason: args.reason,
  };
}
