# Shipping Gates (Stop-Ship Rules)

If any item below is **unknown**, **unverified**, or **broken**, you don't ship. Yes, it hurts. No, prod does not care.

## Gate 0 — Secrets & Access
- [ ] No secrets in repo history (scanned + rotated if ever leaked)
- [ ] Production secrets separate from dev/staging
- [ ] Least-privilege roles for DB, storage, jobs, CI
- [ ] Admin routes protected (auth + authorization), not "hidden"

## Gate 1 — Auth, Sessions, Authorization
- [ ] Auth required on all protected endpoints (server-enforced)
- [ ] RBAC/ABAC enforced server-side (no frontend-only checks)
- [ ] Session/JWT expiry, rotation, logout invalidation
- [ ] Rate limiting on auth endpoints + abuse monitoring
- [ ] Password reset + email verification tokens expire + are one-time

## Gate 2 — Data Access & Isolation
- [ ] IDOR tests pass (cannot access another user's/tenant's resources)
- [ ] RLS (or equivalent) enabled + policies for every table (CRUD)
- [ ] Tenant isolation validated (no cross-tenant reads/writes)
- [ ] Audit logging for sensitive reads/writes (who/what/when/where)

## Gate 3 — Payments & Billing (if you charge money)
- [ ] Idempotency on payment webhooks + retries
- [ ] No card data stored (processor only)
- [ ] Subscription state machine consistent (upgrade/downgrade/cancel)
- [ ] Receipts/invoices generated + accessible
- [ ] Reconciliation: you can explain every transaction in your DB

## Gate 4 — Privacy & Legal
- [ ] ToS + Privacy Policy exist and are accepted (timestamp + version)
- [ ] Data export + deletion works end-to-end (user + tenant)
- [ ] Cookie consent respects tracking preferences where required
- [ ] Breach response plan exists (owners + timeline + comms)

## Gate 5 — Reliability & Ops
- [ ] Backups enabled + restore tested + RPO/RTO defined
- [ ] Migrations tested + rollback plan documented
- [ ] Monitoring: errors, latency, saturation, logs searchable
- [ ] SLOs defined + alerts route somewhere humans will see

## Gate 6 — UX & Accessibility
- [ ] Loading/error/empty states implemented
- [ ] Keyboard navigation works; labels/ARIA present where needed
- [ ] Mobile: core flows tested on small screens + iOS Safari quirks checked

## Gate 7 — Testing & CI
- [ ] Lint + typecheck + unit tests in CI
- [ ] Integration tests for auth/payments/critical flows
- [ ] Dependency audit + lockfile enforced
