import test from "node:test";
import assert from "node:assert/strict";
import { IntentDetector } from "../nlu/intents.js";

test("intent detector identifies reset password", () => {
  const det = new IntentDetector(
    [{ intent: "auth.password_reset_request", any: ["reset password", "forgot password"], all: [] }],
    [{ intent: "auth.password_reset_request", utterance: "reset my password" }],
    { minScore: 0.2 }
  );
  const r = det.detect("i forgot password help");
  assert.equal(r.intent, "auth.password_reset_request");
});
