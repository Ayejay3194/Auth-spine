Decans Auth Ops – Final Connectors
=================================

Adds:
- Real DB-backed auth metrics source
- Slack webhook notifications

Steps:
1) Run migration in /migrations
2) Write auth events to auth_ops_logs
3) Swap stub log source with getAuthLogEventsFromDb()
4) Create Slack Incoming Webhook and wire provider

This removes the last fake parts of the ops spine.
