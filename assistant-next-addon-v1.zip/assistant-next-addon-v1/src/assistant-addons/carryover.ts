import type { ConversationState, NluResult } from "./types";

const CORRECTION_MARKERS = ["actually", "no wait", "i meant", "sorry", "correction"];

export function detectCorrection(text: string) {
  const lower = text.toLowerCase();
  return CORRECTION_MARKERS.some((m) => lower.includes(m));
}

export function applyCarryover(state: ConversationState, nlu: NluResult): NluResult {
  const merged = { ...nlu, entities: { ...(state.lastEntities ?? {}), ...(nlu.entities ?? {}) } };

  // Track useful shortcuts
  if (merged.entities?.service) state.lastService = merged.entities.service;
  if (merged.entities?.professional) state.lastProfessional = merged.entities.professional;
  if (merged.entities?.booking_ref) state.lastBookingRef = merged.entities.booking_ref;

  state.activeIntent = merged.intent;
  state.lastEntities = merged.entities;

  return merged;
}

/**
 * If a user corrects themselves, prefer the newest entities, but keep everything else.
 * Call this BEFORE applyCarryover if you have raw text.
 */
export function applyRepair(state: ConversationState, nlu: NluResult, isCorrection: boolean): NluResult {
  if (!isCorrection) return nlu;

  // Correction: don't carry over times/dates blindly if the user is changing them.
  const dropOnCorrection = ["date", "time", "time_window"];
  const cleanedLast = { ...(state.lastEntities ?? {}) };
  for (const k of dropOnCorrection) delete cleanedLast[k];

  return { ...nlu, entities: { ...cleanedLast, ...(nlu.entities ?? {}) } };
}
