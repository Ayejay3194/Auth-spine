import "./globals.css";
import { UIProvider } from "@/components/ui/UIContext";
import { TopNav } from "@/components/nav/TopNav";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <UIProvider>
          <TopNav />
          <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
        </UIProvider>
      </body>
    </html>
  );
}
