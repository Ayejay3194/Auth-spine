Decans Auth Ops + Admin Notifications Kit
=======================================

What this is
------------
A plug-in kit that connects the Ops Spine to your Auth Spine in a deterministic, non-LLM way.

Flow
----
1) POST auth metrics to `/api/ops/auth`
2) Derive incidents from thresholds (alert rules)
3) Run the Auth Ops Spine (Decision/Steps/Risk/Rollback)
4) Notify admin via log / webhook / email (stub)

Key paths
---------
- `app/api/ops/auth/route.ts`
- `lib/ops/alerts/authAlertRules.ts`
- `lib/ops/spine/authOpsSpine.ts`
- `lib/ops/alerts/notifyAdmin.ts`
- `lib/ops/providers/notify.ts`
- `app/admin/auth-ops/page.tsx`
- `components/admin/AuthOpsPanel.tsx`

Environment variables
---------------------
- `OPSSPINE_NOTIFY_MODE` = `log` | `webhook` | `email` | `webhook+email`
- `OPSSPINE_ADMIN_EMAIL` = destination email (email modes)
- `OPSSPINE_WEBHOOK_URL` = destination webhook (webhook modes)

Quick test (curl)
-----------------
```bash
curl -X POST http://localhost:3000/api/ops/auth   -H "Content-Type: application/json"   -d '{
    "metrics": { "failed_logins_5m": 72 },
    "context": { "scope": { "tenant_id": "tenant_demo" } }
  }'
```

Notes
-----
- Email provider is a stub by design. Wire it to your transactional email provider.
- You can replace `runAuthOpsSpine()` with JSONL retrieval or an LLM later, without changing the API/UI.
