import fs from "node:fs";
import path from "node:path";

const exts = new Set([".ts", ".mjs", ".json", ".md"]);
const root = new URL("../", import.meta.url).pathname;

function normalize(s) {
  // Don't get fancy: strip trailing whitespace.
  return s.split("\n").map(l => l.replace(/\s+$/g, "")).join("\n") + "\n";
}

function walk(dir) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ent.name === "node_modules" || ent.name === "dist") continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p);
    else if (exts.has(path.extname(ent.name))) {
      const s = fs.readFileSync(p, "utf8");
      const n = normalize(s.replace(/\r\n/g, "\n"));
      if (n !== s) fs.writeFileSync(p, n, "utf8");
    }
  }
}
walk(root);
console.log("format-lite: done");
