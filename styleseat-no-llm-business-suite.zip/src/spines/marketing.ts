import { FlowDefinition } from "../flows/types.js";
import { Tool } from "../tools/types.js";
import { MarketingProvider } from "../providers/types.js";

export function marketingSpine(opts: { provider: MarketingProvider }) {
  const { provider } = opts;

  const tools: Tool<any, any>[] = [
    {
      id: "marketing.createPromo",
      description: "Create promo code",
      validate: (i) => { if (!i.code) throw new Error("Missing code"); if (!i.percentOff || i.percentOff <= 0 || i.percentOff > 100) throw new Error("Bad percent"); },
      run: async (_ctx, input) => ({ ok: true, data: { promo: await provider.createPromo({ code: input.code, percentOff: input.percentOff }) } }),
      timeoutMs: 2500,
    },
    {
      id: "marketing.endPromo",
      description: "End promo",
      validate: (i) => { if (!i.code) throw new Error("Missing code"); },
      run: async (_ctx, input) => ({ ok: true, data: { promo: await provider.endPromo({ code: input.code }) } }),
      timeoutMs: 2500,
    },
    {
      id: "marketing.referralStatus",
      description: "Referral status",
      validate: (i) => { if (!i.code) throw new Error("Missing code"); },
      run: async (_ctx, input) => ({ ok: true, data: { referral: await provider.referralStatus({ code: input.code }) } }),
      timeoutMs: 2500,
    },
    {
      id: "marketing.sendCampaign",
      description: "Send campaign to segment",
      validate: (i) => { if (!i.segment) throw new Error("Missing segment"); if (!i.message) throw new Error("Missing message"); },
      run: async (_ctx, input) => ({ ok: true, data: await provider.sendCampaign({ segment: input.segment, message: input.message }) }),
      timeoutMs: 5000,
    },
  ];

  const flows: FlowDefinition[] = [
    {
      intent: "marketing.create_promo",
      slots: [{ name: "code", required: true, fromEntity: (e) => e.find(x => x.type === "promoCode")?.value ?? null }, { name: "percentOff", required: true }, { name: "confirm", required: true }],
      steps: (s) => [
        { ask: { slot: "code", prompt: "Promo code?", hint: "promo_new10" } },
        { ask: { slot: "percentOff", prompt: "Percent off (1-100)?", hint: "10" } },
        { ask: { slot: "confirm", prompt: `Type YES to create ${s.code} for ${s.percentOff}% off.`, hint: "YES" } },
        { call: { toolId: "marketing.createPromo", commitIntent: "marketing.create_promo", confirmSlot: "confirm", inputFromSlots: (x) => ({ code: x.code, percentOff: Number(x.percentOff) }) } },
        { done: { message: "Promo created." } },
      ],
    },
    {
      intent: "marketing.send_campaign",
      slots: [{ name: "segment", required: true }, { name: "message", required: true }, { name: "confirm", required: true }],
      steps: () => [
        { ask: { slot: "segment", prompt: "Segment? (new|inactive|vip|all)", hint: "inactive" } },
        { ask: { slot: "message", prompt: "Message to send?", hint: "Open slots this week..." } },
        { ask: { slot: "confirm", prompt: "Type YES to send campaign.", hint: "YES" } },
        { call: { toolId: "marketing.sendCampaign", commitIntent: "marketing.send_campaign", confirmSlot: "confirm", inputFromSlots: (s) => ({ segment: s.segment, message: s.message }) } },
        { done: { message: "Campaign sent (or queued)." } },
      ],
    },
  ];

  return { tools, flows };
}
