# Security Headers Baseline
- Content-Security-Policy (CSP) tuned to your assets
- Strict-Transport-Security (HSTS)
- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY or SAMEORIGIN
- Referrer-Policy: strict-origin-when-cross-origin
- Permissions-Policy: restrict sensors/camera/mic
