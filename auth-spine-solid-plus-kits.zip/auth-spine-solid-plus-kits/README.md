# Auth-Spine Solid + UI Kits

This repo bundles:
- Docs: "Making Auth-Spine Super Solid" checklist
- UI Toolkit (authority labels)
- HTML→TS Conflict Resolver
- Health endpoint demo + logger/errors/env validation scaffolding
- Test scaffolding (Vitest + Playwright)

## Run
```bash
npm install
cp .env.example .env
# set JWT_SECRET to 32+ chars
npm run env:check
npm run dev
```

## Pages
- `/docs`
- `/ui-toolkit`
- `/html-to-ts`
- `/health`
- `/api/health`

## Scripts
- `npm run security:audit`
- `npm run env:check`
- `npm test`
- `npm run e2e`
