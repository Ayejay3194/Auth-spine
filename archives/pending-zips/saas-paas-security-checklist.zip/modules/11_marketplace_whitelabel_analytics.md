MARKETPLACE + WHITE-LABEL + ANALYTICS

Integration Marketplace
- Vetting + security review
- Developer verification
- Sandbox requirements
- Monitoring + suspension for malicious behavior
- Update review + deprecation

White-Label
- Domain verification (DNS TXT)
- TLS provisioning + renewal
- Prevent subdomain takeover
- Custom CSS/HTML sanitization (no JS injection)

Analytics
- Tenant-scoped analytics
- Minimize PII; opt-out options
- Secure pipelines + retention policy
- A/B test + session replay privacy controls
