
-- USERS
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  role text not null check (role in ('CLIENT','STYLIST','RECEPTION','MANAGER','OWNER','ADMIN','SUPPORT')),
  created_at timestamp with time zone default now()
);

-- SALONS
create table salons (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null
);

-- MEMBERSHIPS
create table salon_memberships (
  id uuid primary key default gen_random_uuid(),
  salon_id uuid references salons(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  role text not null,
  settings jsonb default '{}'
);

-- BOOKINGS
create table bookings (
  id uuid primary key default gen_random_uuid(),
  stylist_id uuid references profiles(id),
  salon_id uuid references salons(id),
  client_id uuid references profiles(id),
  status text,
  starts_at timestamp with time zone,
  ends_at timestamp with time zone,
  created_at timestamp with time zone default now()
);
