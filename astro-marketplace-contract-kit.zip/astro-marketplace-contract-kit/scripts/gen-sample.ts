import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { computeChartIntegrity } from '../src/hash.js';
import { formatChartLikeSolarFire } from '../src/format.js';
import { ChartDataV1 } from '../src/types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const fixturePath = path.join(__dirname, '..', 'fixtures', 'sample.chart.v1.json');
const outPath = path.join(__dirname, '..', 'fixtures', 'sample.chart.v1.txt');

const chart = JSON.parse(fs.readFileSync(fixturePath, 'utf8')) as ChartDataV1;
const integrity = computeChartIntegrity(chart);

const text =
  formatChartLikeSolarFire(chart) +
  '\n\n' +
  'Integrity (canonical sha256):\n' +
  integrity.hashHex +
  '\n';

fs.writeFileSync(outPath, text, 'utf8');
console.log('Wrote', outPath);
