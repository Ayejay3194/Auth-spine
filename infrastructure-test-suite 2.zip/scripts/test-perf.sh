#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

BASE_URL="${PERF_BASE_URL:-}"
if [ -z "$BASE_URL" ]; then
  log "PERF_BASE_URL not set. Skipping."
  exit 0
fi

log "k6 perf test"
docker_run grafana/k6:latest run -e BASE_URL="$BASE_URL" tests/perf/basic.k6.js
