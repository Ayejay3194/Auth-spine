import type { HouseSystem, Zodiac } from "../contract/enums.js";
import type { ChartDataV1 } from "../contract/schema.js";

export type ChartRequest = {
  chartType: ChartDataV1["chartType"];
  dobUtc: string; // ISO Z
  geo: { lat: number; lon: number; tz: string; label?: string };
  houseSystem: HouseSystem;
  zodiac: Zodiac;
  ayanamsa?: string;
  flags?: string[];
};

export interface EphemerisEngine {
  readonly engineId: string;
  computeNatal(req: ChartRequest): Promise<Omit<ChartDataV1, "integrity">>;
}
