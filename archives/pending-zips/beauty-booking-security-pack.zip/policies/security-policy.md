# Information Security Policy (Starter)

## Scope
Applies to all systems, employees, contractors, vendors.

## Principles
- Least privilege
- Separation of duties
- Defense in depth
- Secure by default
- Audit everything in ops

## Access
- MFA required for ops/admin
- Access granted by role + approved request
- Quarterly access reviews

## Data
- PII classified and protected
- Logs sanitized and retained per policy
- Encryption in transit and at rest

## Change management
- PR reviews required
- CI security gates
- Emergency changes logged and reviewed within 24h
