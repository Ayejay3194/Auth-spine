# WEBSOCKET & REALTIME DISASTERS

## WebSocket Problems

- [ ] WebSocket connections dropping
- [ ] No reconnection logic
- [ ] Reconnection storms
- [ ] Connection leak
- [ ] Too many open connections
- [ ] Message ordering issues
- [ ] Lost messages
- [ ] Duplicate messages
- [ ] Message delivery not guaranteed
- [ ] No message acknowledgment
- [ ] Heartbeat/ping-pong missing
- [ ] No connection timeout
- [ ] Zombie connections
- [ ] Broadcasting to wrong clients
- [ ] Broadcasting too frequently
- [ ] Message payload too large
- [ ] No message queuing
- [ ] Backpressure not handled
- [ ] WebSocket endpoints not secured
- [ ] Authentication on initial connection only

## Realtime Sync Issues

- [ ] Clients out of sync
- [ ] Conflict resolution missing
- [ ] Last write wins (data loss)
- [ ] Optimistic updates failing
- [ ] Rollback not working
- [ ] Version vectors wrong
- [ ] Merge conflicts
- [ ] Split brain scenarios
- [ ] Data inconsistency across clients
- [ ] Presence status wrong
- [ ] Typing indicators not clearing
- [ ] Live cursors desynchronized
- [ ] Collaborative editing conflicts

---
