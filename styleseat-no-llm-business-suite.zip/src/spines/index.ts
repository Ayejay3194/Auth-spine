import { InMemoryToolRegistry } from "../tools/registry.js";
import { FlowDefinition } from "../flows/types.js";
import { SessionStore } from "../memory/session.js";
import { bookingSpine } from "./booking.js";
import { crmSpine } from "./crm.js";
import { paymentsSpine } from "./payments.js";
import { marketingSpine } from "./marketing.js";
import { analyticsSpine } from "./analytics.js";
import { opsSpine } from "./ops.js";
import { adminSpine } from "./admin.js";
import {
  BookingProvider, CRMProvider, PaymentsProvider, MarketingProvider, AnalyticsProvider, OpsProvider, AdminProvider
} from "../providers/types.js";

export function loadAllSpines(opts: {
  providers: {
    booking: BookingProvider;
    crm: CRMProvider;
    payments: PaymentsProvider;
    marketing: MarketingProvider;
    analytics: AnalyticsProvider;
    ops: OpsProvider;
    admin: AdminProvider;
  };
  slotCache: SessionStore<any>;
}) {
  const tools = new InMemoryToolRegistry();
  const flows: FlowDefinition[] = [];

  const sp = [
    bookingSpine({ provider: opts.providers.booking, slotCache: opts.slotCache }),
    crmSpine({ provider: opts.providers.crm }),
    paymentsSpine({ provider: opts.providers.payments }),
    marketingSpine({ provider: opts.providers.marketing }),
    analyticsSpine({ provider: opts.providers.analytics }),
    opsSpine({ provider: opts.providers.ops }),
    adminSpine({ provider: opts.providers.admin }),
  ];

  for (const s of sp) {
    for (const t of s.tools) tools.register(t as any);
    flows.push(...s.flows);
  }

  return { tools, flows };
}
