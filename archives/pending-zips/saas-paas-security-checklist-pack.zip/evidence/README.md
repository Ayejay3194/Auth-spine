
Evidence folder structure (suggested)

- architecture/
- threat-models/
- pentest/
- scans/
- incident-response/
- access-reviews/
- change-management/
- backups/
- vendor/
- compliance/
