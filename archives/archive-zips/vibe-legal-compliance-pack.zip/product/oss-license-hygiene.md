# OSS License Hygiene

## Rules
- keep a top-level LICENSE for *your* code
- track dependency licenses (SBOM)
- avoid copyleft mixing (GPL/AGPL) unless you intend to comply

## Tooling suggestions
- `license-checker` / `pnpm licenses list`
- dependency scanning in CI
- block forbidden licenses via policy
