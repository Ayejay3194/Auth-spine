-- Closure table for hierarchies
create table if not exists nodes (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  name text not null
);

create table if not exists node_closure (
  tenant_id uuid not null,
  ancestor uuid not null,
  descendant uuid not null,
  depth int not null,
  primary key (tenant_id, ancestor, descendant)
);

-- Insert a node: add (node,node,0) and connect to parent closure rows.
