# Security Add-ons Pack (Business Spine / API)

This pack adds the "adult supervision" layer to your stack:

- Idempotency keys for write endpoints (prevents double booking/charging on retries)
- HMAC request signing + replay protection (timestamp + nonce)
- TenantGuard (fail-closed tenant isolation)
- Tamper-evident audit log (hash chain + checkpoints)
- Tool-call budget / anti-agent-loop guard
- Abuse controls: rate limiting helpers, per-tenant/per-user keys
- Golden test vectors + drift tests (source-of-truth outputs)
- CI supply-chain hardening (SBOM + dependency scanning + secret scanning templates)

## Quick start

1. Copy `src/security` into your repo (or mount as package).
2. Wire middleware in your server:
   - `idempotencyMiddleware`
   - `tenantGuardMiddleware`
   - `signedRequestMiddleware` (optional for internal calls)
   - `toolBudgetMiddleware`

3. Configure storage adapters:
   - `IdempotencyStore` (Redis recommended, in-memory provided for tests)
   - `AuditStore` (append-only DB table recommended, file/in-memory provided for tests)
   - `NonceStore` (Redis recommended)

## Notes

- Everything is written to fail closed (reject when uncertain).
- This pack is framework-agnostic: Express/Fastify/Next API routes can adapt the middleware.
