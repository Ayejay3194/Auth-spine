import type { TroubleshootData } from '@/components/types';

export const troubleshootData: TroubleshootData = {
  "State & React Issues": [
    {
      "id": "state-1",
      "problem": "UI toggles reset when navigating",
      "symptomSignals": [
        "Theme/glow/radius changes then snaps back"
      ],
      "authority": [
        "GLOBAL_STORE",
        "ROUTE"
      ],
      "rootCauses": [
        "State stored inside a page that unmounts on route change",
        "Multiple components own the same toggle"
      ],
      "solutions": [
        "Move global toggles to a provider above routes (layout.tsx)",
        "Delete duplicate state owners"
      ],
      "verifySteps": [
        "Navigate pages and confirm provider does not remount",
        "Search for duplicate useState for the same toggle"
      ],
      "antiPatterns": [
        "activeTab plus routing"
      ],
      "code": "// Put global UI state above routes (layout.tsx).\n// One source of truth. Delete duplicates."
    }
  ],
  "Z-Index & Overlays": [
    {
      "id": "z-1",
      "problem": "Dropdown/modal appears behind other UI",
      "authority": [
        "CSS_ONLY"
      ],
      "rootCauses": [
        "New stacking context from transform/filter/opacity",
        "Random z-index values"
      ],
      "solutions": [
        "Use a z-index ladder",
        "Avoid transform on high-level wrappers"
      ],
      "verifySteps": [
        "Inspect ancestors for transform/filter/opacity",
        "Compare computed z-index"
      ],
      "code": ":root{--z-content:1;--z-nav:20;--z-modal:60;--z-toast:80;}"
    }
  ]
} as const;
