import fs from "node:fs/promises";
import { LakeConfig, registryPath } from "../io/paths.js";
import { Registry, DatasetEntry, FeatureSetEntry, ModelEntry } from "./types.js";

function nowISO() { return new Date().toISOString(); }

export async function loadRegistry(cfg: LakeConfig): Promise<Registry> {
  try {
    const raw = await fs.readFile(registryPath(cfg), "utf8");
    return JSON.parse(raw) as Registry;
  } catch {
    return { datasets: [], featureSets: [], models: [] };
  }
}

export async function saveRegistry(cfg: LakeConfig, reg: Registry): Promise<void> {
  await fs.mkdir(cfg.root, { recursive: true });
  await fs.writeFile(registryPath(cfg), JSON.stringify(reg, null, 2));
}

function setLatest<T extends { latest?: boolean }>(arr: T[], predicate: (x: T) => boolean) {
  for (const x of arr) x.latest = false;
  const found = arr.find(predicate);
  if (found) found.latest = true;
}

export async function registerDataset(
  cfg: LakeConfig,
  entry: Omit<DatasetEntry, "createdAtISO">
): Promise<void> {
  const reg = await loadRegistry(cfg);
  reg.datasets = reg.datasets.filter(d => !(d.dataset === entry.dataset && d.version === entry.version));
  reg.datasets.push({ ...entry, createdAtISO: nowISO() });
  setLatest(reg.datasets.filter(d => d.dataset === entry.dataset), d => (d as any).version === entry.version);
  await saveRegistry(cfg, reg);
}

export async function registerFeatureSet(
  cfg: LakeConfig,
  entry: Omit<FeatureSetEntry, "createdAtISO">
): Promise<void> {
  const reg = await loadRegistry(cfg);
  reg.featureSets = reg.featureSets.filter(f => !(f.name === entry.name && f.version === entry.version));
  reg.featureSets.push({ ...entry, createdAtISO: nowISO() });
  await saveRegistry(cfg, reg);
}

export async function registerModel(
  cfg: LakeConfig,
  entry: Omit<ModelEntry, "createdAtISO">
): Promise<void> {
  const reg = await loadRegistry(cfg);
  reg.models = reg.models.filter(m => !(m.name === entry.name && m.version === entry.version));
  reg.models.push({ ...entry, createdAtISO: nowISO() });
  await saveRegistry(cfg, reg);
}
