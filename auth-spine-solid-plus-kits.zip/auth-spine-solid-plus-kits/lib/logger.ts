type Ctx = Record<string, any> | undefined;

function base(level: "info" | "warn" | "error", message: string, context?: Ctx) {
  const payload = { level, message, context, ts: new Date().toISOString() };
  if (level === "error") console.error(JSON.stringify(payload));
  else if (level === "warn") console.warn(JSON.stringify(payload));
  else console.log(JSON.stringify(payload));
}

export const logger = {
  info: (message: string, context?: Ctx) => base("info", message, context),
  warn: (message: string, context?: Ctx) => base("warn", message, context),
  error: (err: Error, context?: Ctx) =>
    base("error", err.message, { ...context, name: err.name, stack: err.stack })
};
