import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function GET(_:Request, { params }:{ params:{ stylistId:string } }){
  const session = await auth();
  if(!session?.user?.email) return Response.json({ following:false });
  const user = await prisma.user.findUnique({ where:{ email: session.user.email } });
  if(!user) return Response.json({ following:false });
  const f = await prisma.follow.findUnique({ where:{ followerUserId_stylistId: { followerUserId: user.id, stylistId: params.stylistId } } });
  return Response.json({ following: Boolean(f) });
}
