// Minimal in-memory state store placeholder.
const store = new Map<string, any>();

export function getState(sessionId: string) {
  return store.get(sessionId) ?? null;
}

export function setState(sessionId: string, state: any) {
  store.set(sessionId, state);
  return state;
}

export function clearState(sessionId: string) {
  store.delete(sessionId);
}
