export type DatasetEntry = {
  dataset: string;
  version: string;
  schemaVersion: string;
  createdAtISO: string;
  description?: string;
  latest?: boolean;
  tags?: string[];
};

export type ModelEntry = {
  name: string;
  version: string;
  createdAtISO: string;
  datasetRef?: { dataset: string; version: string };
  featureSetRef?: { name: string; version: string };
  metricsRef?: { dataset: string; version: string };
  notes?: string;
};

export type FeatureSetEntry = {
  name: string;
  version: string;
  createdAtISO: string;
  sourceDataset?: { dataset: string; version: string };
  schemaVersion: string;
  notes?: string;
};

export type Registry = {
  datasets: DatasetEntry[];
  featureSets: FeatureSetEntry[];
  models: ModelEntry[];
};
