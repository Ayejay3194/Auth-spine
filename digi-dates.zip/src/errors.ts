export class DigiDatesError extends Error {
  override name = "DigiDatesError";
}

export class ParseError extends DigiDatesError {
  override name = "ParseError";
}

export class ValidationError extends DigiDatesError {
  override name = "ValidationError";
}
