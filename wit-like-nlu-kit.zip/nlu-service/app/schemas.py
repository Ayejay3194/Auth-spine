from pydantic import BaseModel, Field
from typing import List, Literal

class EntityIn(BaseModel):
    entity: str
    value: str

class TrainExample(BaseModel):
    text: str
    intent: str
    entities: List[EntityIn] = Field(default_factory=list)

class ParseRequest(BaseModel):
    text: str

class EntityOut(BaseModel):
    entity: str
    value: str
    start: int
    end: int
    confidence: float
    source: Literal["regex","lookup","ml","rule"]

class IntentOut(BaseModel):
    name: str
    confidence: float

class ParseResponse(BaseModel):
    text: str
    intent: IntentOut
    intents: List[IntentOut]
    entities: List[EntityOut]
