import fs from "node:fs";

const checklistPath = process.argv[2] ?? "../data/supabase_features_checklist.json";
const progressPath = process.argv[3] ?? "../data/progress_template.json";

const checklist = JSON.parse(fs.readFileSync(checklistPath, "utf-8"));
const progress = JSON.parse(fs.readFileSync(progressPath, "utf-8"));
const overrides = new Map((progress.overrides ?? []).map(o => [o.id, o]));

let total = 0, done = 0, inProgress = 0, blocked = 0;

for (const sec of checklist.sections) {
  for (const g of sec.groups) {
    for (const item of g.items) {
      total++;
      const o = overrides.get(item.id);
      const status = (o?.status ?? item.status ?? "todo");
      if (status === "done") done++;
      else if (status === "in_progress") inProgress++;
      else if (status === "blocked") blocked++;
    }
  }
}

const pct = total ? Math.round((done/total)*1000)/10 : 0;
console.log(JSON.stringify({ total, done, in_progress: inProgress, blocked, percent_done: pct }, null, 2));
