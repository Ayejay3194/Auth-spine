import { section, ok, fail, exists, findFiles } from "./_util.mjs";

section("Compliance evidence pack presence");
const required = [
  "./compliance/policies/security-policy.md",
  "./compliance/policies/privacy-policy.md",
  "./compliance/policies/retention-policy.md",
  "./compliance/policies/acceptable-use.md",
  "./compliance/ropa/processing-activities.csv",
  "./compliance/subprocessors.md",
  "./compliance/incident-response.md",
];

const missing = required.filter(p=>!exists(p));
if(missing.length){
  for(const m of missing) console.log("Missing: " + m);
  fail("Compliance evidence missing. If you ever need SOC2/GDPR/CPRA, this will hurt.");
} else {
  ok("Core compliance artifacts exist");
}

section("Accessibility checks (basic)");
const a11y = ["./compliance/accessibility/wcag-notes.md"];
const aMissing = a11y.filter(p=>!exists(p));
if(aMissing.length){
  for(const m of aMissing) console.log("Missing: " + m);
  console.log("⚠️  Add WCAG/ADA notes and testing steps. This is not optional when money is involved.");
} else {
  ok("Accessibility notes present");
}
