
# Supabase Incident Playbook

1. Rotate anon + service_role keys
2. Force logout (auth admin)
3. Inspect RLS logs
4. Review audit tables
5. Notify affected users
6. Patch policy
