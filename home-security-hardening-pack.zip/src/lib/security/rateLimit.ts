type Key = string;

type Hit = { count: number; resetAt: number };

const store = new Map<Key, Hit>();

export function rateLimit(key: string, opts?: { windowMs?: number; max?: number }) {
  const windowMs = opts?.windowMs ?? Number(process.env.RATE_LIMIT_WINDOW_MS ?? 60_000);
  const max = opts?.max ?? Number(process.env.RATE_LIMIT_MAX ?? 60);

  const now = Date.now();
  const hit = store.get(key);

  if (!hit || hit.resetAt <= now) {
    store.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, remaining: max - 1, resetAt: now + windowMs };
  }

  hit.count += 1;
  store.set(key, hit);

  if (hit.count > max) {
    return { ok: false, remaining: 0, resetAt: hit.resetAt };
  }

  return { ok: true, remaining: max - hit.count, resetAt: hit.resetAt };
}
