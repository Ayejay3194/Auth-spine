# Accessibility QA Checklist (Practical)

- all inputs have labels
- modals have focus trap + ESC close
- keyboard navigable menus
- color contrast passes
- `prefers-reduced-motion` supported
- error messages announced (aria-live)
