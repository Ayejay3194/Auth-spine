export type Sentiment = "pos" | "neu" | "neg";
export type Urgency = "low" | "medium" | "high";

export type Intent =
  | "book_service"
  | "check_availability"
  | "reschedule_booking"
  | "cancel_booking"
  | "pricing_quote"
  | "service_info"
  | "help"
  | "complaint"
  | "contact_support"
  | "unknown"
  | (string & {});

export interface NluResult {
  intent: Intent;
  entities: Record<string, any>;
  confidence: number; // 0..1
  sentiment?: Sentiment;
  urgency?: Urgency;
  alternatives?: Array<{ intent: Intent; confidence: number }>;
}

export interface ConversationState {
  sessionId: string;
  activeIntent?: Intent;
  pendingSlots?: string[];
  lastEntities?: Record<string, any>;
  lastService?: string;
  lastProfessional?: string;
  lastBookingRef?: string;
  lastSeenAt: number; // epoch ms
}

export type ToolOutcome =
  | "ok"
  | "needs_more_info"
  | "conflict"
  | "not_found"
  | "payment_required"
  | "blocked"
  | "error";

export interface ToolResult<T = any> {
  outcome: ToolOutcome;
  data?: T;
  missing?: string[];
  message?: string;
}

export type GateDecision =
  | { type: "act" }
  | { type: "clarify"; missing: string[] }
  | { type: "disambiguate"; options: Array<{ intent: Intent; confidence: number }> };
