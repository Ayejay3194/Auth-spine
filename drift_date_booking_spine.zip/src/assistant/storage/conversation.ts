import type { PrismaClient } from "@prisma/client";

export async function getConversation(prisma: PrismaClient, businessId: string, userId: string) {
  const existing = await prisma.assistantConversation.findFirst({ where: { businessId, userId } });
  if (!existing) {
    return prisma.assistantConversation.create({
      data: { businessId, userId, stateJson: {} },
    });
  }
  return existing;
}

export async function setConversationState(prisma: PrismaClient, id: string, stateJson: any) {
  return prisma.assistantConversation.update({
    where: { id },
    data: { stateJson },
  });
}
