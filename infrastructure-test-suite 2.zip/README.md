# Infrastructure Test Suite (Full Coverage Starter)

This repo is a **drop-in, CI-ready test suite** for the infrastructure guideline you posted.

It catches the boring-but-deadly stuff:
- public exposure (DBs, buckets, SGs)
- missing encryption, weak IAM
- unsafe k8s configs
- secrets accidentally committed
- contract drift (OpenAPI)
- performance regressions
- DR “we totally have backups” lies (restore rehearsals)

## Run locally
```bash
./scripts/test-all.sh
```

## Run in CI
GitHub Actions workflow is included in `.github/workflows/ci.yml`.

## Wire it to your stack
- Terraform -> `infra/terraform/`
- Kubernetes -> `infra/k8s/`
- OpenAPI specs -> `apis/openapi/`
- Extend OPA policies -> `policies/opa/`
