import { latestCommitId } from "../delta/log.js";
import { compileTrainingSnapshotFromCommit } from "../training/compileFromCommit.js";

async function run() {
  const cfg = { root: "./lake" };

  const inputTable = "de440_residuals";
  const inputVer = "v3";

  const head = await latestCommitId(cfg, inputTable, inputVer);
  if (!head) throw new Error("No commits yet. Run dev:write first.");

  const res = await compileTrainingSnapshotFromCommit({
    cfg,
    input: { table: inputTable, tableVersion: inputVer, commitId: head, schemaVersion: "1" },
    output: { table: "training_residuals", tableVersion: "v1", schemaVersion: "1" },
    generator: "compileWithLogDemo@local"
  });

  console.log(res);
}

run().catch((e) => { console.error(e); process.exit(1); });
