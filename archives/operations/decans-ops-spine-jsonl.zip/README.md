Decans Ops Spine JSONL
=====================

File: decans_ops_spine.jsonl
Records: 13

Format: JSONL, each line is an object with a `messages` array (system/user/assistant).
Use it for fine-tuning or as a canonical ops-response template set.

Guarantees:
- Every answer includes: Decision, Steps, Risk notes, Rollback plan
- Enforces feature flags + kill switches
- Enforces privacy + anti-rogue language rules
