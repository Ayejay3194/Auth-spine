# Plan gating (server-side only)
- Store `tenants.plan`
- Never trust client plan
- Use webhooks as source of truth for subscription status
- Apply feature flags based on plan and tenant settings

Patterns:
- `requireFeature(tenant.plan, 'custom.branding')`
- hard limits enforced via quotas table
