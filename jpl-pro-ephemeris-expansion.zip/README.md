
# JPL Professional Ephemeris Expansion Kit

This package expands the Professional Ephemeris system with:
- JPL DE440/DE441 integration (Chebyshev SPK kernels)
- IAU 2000B / 2006 standards compliance
- Canonical source-of-truth output contracts
- Unbreakable validation & regression suite
- Horizons-grade verification tooling

This is NOT a demo. This is a production-grade scientific architecture.

## Philosophy
- Kernels are immutable truth
- All outputs are deterministic
- Refactors cannot silently change results
- Every number is auditable

## Modules
See /src for core implementations.
