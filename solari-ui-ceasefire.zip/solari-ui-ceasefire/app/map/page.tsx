import { Shell } from "@/components/layout/Shell";

export default function Map() {
  return (
    <Shell>
      <div className="border border-white/10 rounded-xl p-6 h-[60vh]">
        <h2 className="text-2xl font-black">Map</h2>
        <p className="text-white/70 mt-2">Rail switches to feed here.</p>
      </div>
    </Shell>
  );
}
