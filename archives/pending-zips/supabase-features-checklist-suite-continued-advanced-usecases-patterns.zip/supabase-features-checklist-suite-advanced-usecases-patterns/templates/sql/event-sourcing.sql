-- Event Sourcing (Event Store + Snapshot)
create table if not exists public.event_store (
  id bigserial primary key,
  occurred_at timestamptz not null default now(),
  aggregate_type text not null,
  aggregate_id uuid not null,
  sequence bigint not null,
  event_type text not null,
  event_version int not null default 1,
  payload jsonb not null
);

create unique index if not exists event_store_agg_seq on public.event_store(aggregate_id, sequence);

create table if not exists public.event_snapshots (
  aggregate_id uuid primary key,
  sequence bigint not null,
  state jsonb not null,
  created_at timestamptz not null default now()
);
