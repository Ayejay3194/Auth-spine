BRAND NARRATIVE
===============

Core story:
- What problem we exist to solve
- Who we are for (and who we are not)
- Why our approach is different
- What we refuse to optimize for

Rules:
- No hype language
- No defensiveness
- Confidence through clarity
