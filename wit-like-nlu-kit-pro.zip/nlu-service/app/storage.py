import json
from pathlib import Path
from typing import Iterable, List, Dict, Any
from .config import settings

DATA_FILE = Path(settings.data_dir) / "examples.jsonl"
DATA_FILE.parent.mkdir(parents=True, exist_ok=True)

def append_examples(items: List[Dict[str, Any]]) -> None:
    with DATA_FILE.open("a", encoding="utf-8") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")

def load_examples(limit: int | None = None) -> List[Dict[str, Any]]:
    if not DATA_FILE.exists():
        return []
    out = []
    with DATA_FILE.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
            if limit and len(out) >= limit:
                break
    return out

def overwrite_examples(items: Iterable[Dict[str, Any]]) -> None:
    tmp = DATA_FILE.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")
    tmp.replace(DATA_FILE)
