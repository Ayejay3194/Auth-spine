import { Container } from "@/components/Container";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { requirePerm } from "@/lib/rbac";

export default async function AuditPage(){
  const session = await auth();
  const user = session?.user?.email ? await prisma.user.findUnique({ where:{ email: session.user.email } }) : null;
  await requirePerm(user, "ops.read.bookings");

  const logs = await prisma.auditLog.findMany({ orderBy:{ at:"desc" }, take: 100 });

  return (
    <main className="py-10">
      <Container>
        <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Ops</div>
        <h1 className="serif mt-2 text-3xl">Audit Log</h1>
        <div className="mt-6 space-y-2">
          {logs.map(l => (
            <div key={l.id} className="rounded-2xl border p-4" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-sm font-semibold">{l.action}</div>
                <div className="text-xs" style={{color:"var(--dim)"}}>{new Date(l.at).toLocaleString()}</div>
              </div>
              <div className="mt-2 text-xs" style={{color:"var(--muted)"}}>
                actor: {l.actorUserId || "—"} ({l.actorRole || "—"}) · {l.entityType}:{l.entityId}
              </div>
              {l.reason ? <div className="mt-2 text-xs" style={{color:"var(--dim)"}}>reason: {l.reason}</div> : null}
            </div>
          ))}
        </div>
      </Container>
    </main>
  );
}
