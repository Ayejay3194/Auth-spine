-- State Machine Pattern
create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  state text not null default 'new',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ticket_state_transitions (
  id bigserial primary key,
  ticket_id uuid not null references public.tickets(id) on delete cascade,
  from_state text,
  to_state text not null,
  actor uuid,
  occurred_at timestamptz not null default now()
);

-- Enforce allowed transitions (example)
create or replace function public.enforce_ticket_transition()
returns trigger language plpgsql as $$
begin
  if old.state = new.state then
    return new;
  end if;

  if old.state = 'new' and new.state in ('in_progress','closed') then
    insert into public.ticket_state_transitions(ticket_id, from_state, to_state, actor)
    values (new.id, old.state, new.state, nullif(current_setting('request.jwt.claim.sub', true), '')::uuid);
    return new;
  end if;

  if old.state = 'in_progress' and new.state in ('blocked','closed') then
    insert into public.ticket_state_transitions(ticket_id, from_state, to_state, actor)
    values (new.id, old.state, new.state, nullif(current_setting('request.jwt.claim.sub', true), '')::uuid);
    return new;
  end if;

  raise exception 'Invalid state transition % -> %', old.state, new.state;
end;
$$;

drop trigger if exists trg_enforce_ticket_transition on public.tickets;
create trigger trg_enforce_ticket_transition
before update on public.tickets
for each row execute function public.enforce_ticket_transition();
