import fs from "node:fs";
import path from "node:path";

const exts = new Set([".ts", ".mjs", ".json", ".md"]);
const root = new URL("../", import.meta.url).pathname;
function walk(dir) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ent.name === "node_modules" || ent.name === "dist") continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p);
    else if (exts.has(path.extname(ent.name))) {
      const s = fs.readFileSync(p, "utf8");
      if (s.includes("\r\n")) {
        console.error("CRLF line endings found:", p);
        process.exitCode = 1;
      }
      if (s.includes("\t")) {
        console.error("Tab character found:", p);
        process.exitCode = 1;
      }
      if (!s.endsWith("\n")) {
        console.error("Missing trailing newline:", p);
        process.exitCode = 1;
      }
    }
  }
}
walk(root);
if (process.exitCode) process.exit(1);
console.log("lint-lite: ok");
