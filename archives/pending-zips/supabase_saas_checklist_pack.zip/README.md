# Supabase SaaS/PaaS Features Checklist Pack

You wanted the whole Supabase-flavored SaaS checklist in a form you can actually *use* (track, diff, import, search),
not just stare at in a giant markdown blob and pretend you’ll remember it later.

## Files
- `data/supabase_features_checklist.json`  
  Hierarchical checklist (sections → groups → items).
- `data/supabase_features_checklist.jsonl`  
  Flattened JSONL (one item per line) for importing into your own tooling.
- `data/progress_template.json`  
  Store your project’s status overrides here.
- `tools/`  
  Tiny Node CLIs to compute completion % and set item status.

## CLI
```bash
cd tools
npm i
npm run completion -- ../data/supabase_features_checklist.json ../data/progress_template.json

# Mark something complete
npm run set -- ../data/progress_template.json auth.providers.001 done "Email/password live"
npm run completion -- ../data/supabase_features_checklist.json ../data/progress_template.json
```

## Status values
- `todo`
- `in_progress`
- `blocked`
- `done`
