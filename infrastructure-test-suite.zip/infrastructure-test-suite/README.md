# Infrastructure Testing Suite (React + Tailwind)

Drop-in checklist UI component.

## Install deps
```bash
npm i lucide-react
```

## Use (Next.js / React)
```tsx
import InfrastructureTestSuite from "./src/InfrastructureTestSuite";

export default function Page() {
  return <InfrastructureTestSuite />;
}
```
