# Access Control Policy

## Purpose
Define how access is granted, reviewed, and revoked across environments.

## Scope
All production systems, admin tooling, customer data, and support operations.

## Standards
- MFA required for privileged accounts
- Least privilege (role + scope based)
- Just-in-time elevation for support/debug
- Quarterly access reviews (monthly for admins)
- Break-glass accounts: stored offline, audited, time-limited

## Procedures
1. Access request: ticket + manager approval
2. Provision: SSO group / IAM role assignment
3. Review: export membership + attest
4. Deprovision: automated offboarding within 24h

## Logging
All auth events, privilege changes, and admin actions must be logged to an append-only store.
