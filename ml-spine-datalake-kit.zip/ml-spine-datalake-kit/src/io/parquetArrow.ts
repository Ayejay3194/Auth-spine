import fs from "node:fs/promises";
import path from "node:path";
import initWasm, {
  readParquet,
  writeParquet,
  WriterPropertiesBuilder,
  Compression,
} from "parquet-wasm";
import { tableFromIPC, tableToIPC, Table as ArrowTable } from "apache-arrow";

let WASM_READY = false;
export async function initParquetArrow(): Promise<void> {
  if (!WASM_READY) {
    await initWasm();
    WASM_READY = true;
  }
}

export type ParquetWriteOptions = {
  compression?: "snappy" | "zstd" | "gzip" | "uncompressed";
  metadata?: Record<string, string>;
};

function toCompression(c?: ParquetWriteOptions["compression"]) {
  switch (c) {
    case "zstd": return Compression.ZSTD;
    case "gzip": return Compression.GZIP;
    case "uncompressed": return Compression.UNCOMPRESSED;
    case "snappy":
    default: return Compression.SNAPPY;
  }
}

export async function writeArrowTableToParquet(
  filePath: string,
  table: ArrowTable,
  opts: ParquetWriteOptions = {}
): Promise<void> {
  await initParquetArrow();
  const ipc = tableToIPC(table, "stream");
  const props = new WriterPropertiesBuilder().setCompression(toCompression(opts.compression)).build();
  const parquetBytes = writeParquet(ipc, props);

  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, parquetBytes);

  if (opts.metadata && Object.keys(opts.metadata).length) {
    await fs.writeFile(filePath + ".meta.json", JSON.stringify(opts.metadata, null, 2));
  }
}

export async function readParquetToArrowTable(filePath: string): Promise<ArrowTable> {
  await initParquetArrow();
  const parquetBytes = await fs.readFile(filePath);
  const wasmTable = readParquet(parquetBytes);
  const ipc = wasmTable.intoIPCStream();
  return tableFromIPC(ipc);
}
