import { Command } from "commander";
import { promises as fs } from "node:fs";
import type { BodyName } from "./types.js";
import { loadTeacherCsv } from "./io_teacher.js";
import { fitBodySegments } from "./fit.js";
import { readSegmentsParquet, storePath, writeSegmentsParquet } from "./store_parquet.js";
import { SegmentIndex, evalState } from "./runtime.js";
import { auditBody } from "./audit.js";

const program = new Command();
program.name("ephemeris-parquet-ts");

program.command("fit")
  .requiredOption("--teacher <path>")
  .requiredOption("--out <dir>")
  .requiredOption("--body <name>")
  .requiredOption("--span <span>")
  .option("--segmentDays <n>", "segment length days", "32")
  .option("--order <n>", "chebyshev order", "12")
  .action(async (opts) => {
    const teacherText = await fs.readFile(opts.teacher, "utf8");
    const samples = loadTeacherCsv(teacherText);
    const body = opts.body as BodyName;
    const span = String(opts.span);
    const segmentDays = parseFloat(opts.segmentDays);
    const order = parseInt(opts.order, 10);

    const segs = fitBodySegments(samples, body, span, { segmentDays, order });
    const path = storePath(opts.out, body, span);
    await writeSegmentsParquet(path, segs, order);
    console.log(`Wrote ${segs.length} segments -> ${path}`);
  });

program.command("eval")
  .requiredOption("--store <dir>")
  .requiredOption("--body <name>")
  .requiredOption("--span <span>")
  .requiredOption("--jd <n>")
  .option("--order <n>", "chebyshev order", "12")
  .action(async (opts) => {
    const body = opts.body as BodyName;
    const span = String(opts.span);
    const jd = Number(opts.jd);
    const order = parseInt(opts.order, 10);

    const path = storePath(opts.store, body, span);
    const segs = await readSegmentsParquet(path, order);
    const idx = new SegmentIndex(segs);
    const st = evalState(idx, jd);
    console.log(JSON.stringify({ jd, body, r: st.r, v: st.v }, null, 2));
  });

program.command("audit")
  .requiredOption("--teacher <path>")
  .requiredOption("--store <dir>")
  .requiredOption("--body <name>")
  .requiredOption("--span <span>")
  .option("--order <n>", "chebyshev order", "12")
  .action(async (opts) => {
    const teacherText = await fs.readFile(opts.teacher, "utf8");
    const samples = loadTeacherCsv(teacherText);
    const body = opts.body as BodyName;
    const span = String(opts.span);
    const order = parseInt(opts.order, 10);

    const path = storePath(opts.store, body, span);
    const segs = await readSegmentsParquet(path, order);
    const idx = new SegmentIndex(segs);
    const res = auditBody(samples, body, idx);
    console.log(JSON.stringify(res, null, 2));
  });

await program.parseAsync(process.argv);
