# SEV1: Breach Runbook

## 0) Stop the bleeding
- Rotate credentials (DB, API keys, webhook secrets)
- Invalidate sessions globally
- Disable suspicious accounts/admins
- Block abusive IPs at edge/WAF
- Pause payouts/refunds if compromised

## 1) Preserve evidence
- Snapshot logs
- Preserve DB backups
- Record exact timestamps
- Export audit trail

## 2) Triage
- What data? Which users? Which endpoints?
- How did they get in? (credential stuffing, webhook forgery, bug)

## 3) Containment + remediation
- Patch exploit
- Backfill logs
- Add detections and rate limits

## 4) Communication
- Internal stakeholders
- Customer notifications (if required)
- Regulatory notifications (if required)

## 5) Post-incident
- Root cause
- Control updates
- Tests added to prevent regression
