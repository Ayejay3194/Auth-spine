export const CONTRACT_VERSION = "ChartDataV1" as const;
export const CANONICAL_VERSION = "AMJCS-1" as const;
export const TEXT_EXPORT_VERSION = "AMT-1" as const;
