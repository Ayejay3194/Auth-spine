# Vibe Coding Disaster Prevention Pack
Because "it worked on my machine" is not a deployment strategy.

This pack is a drop-in guardrail kit for Next.js/React + Supabase-ish apps:
- Security baseline (auth, sessions, headers, input validation)
- DB/RLS safety checklist + anti-footgun rules
- CI gates (lint, typecheck, tests, secret scan, dependency scan)
- Pre-commit hooks (format, lint, typecheck, secret detection)
- PR checklist + release checklist
- Logging/observability basics (request IDs, redaction)
- Webhook safety (signature verify + replay + idempotency)
- File upload safety

## Quick use
1) Copy `.github/`, `configs/`, `scripts/`, `docs/` into your repo
2) Install dev deps listed in `configs/DEV_DEPS.md`
3) Turn on CI required checks in your repo settings
