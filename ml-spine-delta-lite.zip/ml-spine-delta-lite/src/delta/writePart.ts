import path from "node:path";
import fs from "node:fs/promises";
import { Table as ArrowTable } from "apache-arrow";
import { LakeConfig, dataRoot } from "../io/paths.js";
import { writeArrowTableToParquet } from "../io/parquetArrow.js";
import { sha256File } from "../io/hash.js";
import { commitWrite } from "./log.js";

/**
 * Writes a new immutable parquet part file under:
 *   table=<name>/ver=<tableVersion>/data/<partition...>/part-XXXX.parquet
 * Then records it in the commit log.
 */
export async function writeParquetPartAndCommit(args: {
  cfg: LakeConfig;
  table: string;
  tableVersion: string;
  schemaVersion: string;
  partition?: Record<string, string>; // e.g. { day: "2026-02-27" }
  part: number;
  tableData: ArrowTable;
  generator: string;
  message?: string;
  tags?: string[];
  expectedHead?: string | null;
  compression?: "snappy" | "zstd" | "gzip" | "uncompressed";
}): Promise<{ filePath: string; commitId: string }> {
  const base = dataRoot(args.cfg, args.table, args.tableVersion);
  const parts = args.partition ? Object.entries(args.partition).map(([k,v]) => `${k}=${v}`) : [];
  const dir = path.join(base, ...parts);
  await fs.mkdir(dir, { recursive: true });
  const filePath = path.join(dir, `part-${String(args.part).padStart(4, "0")}.parquet`);

  await writeArrowTableToParquet(filePath, args.tableData, {
    compression: args.compression ?? "zstd",
    metadata: {
      table: args.table,
      tableVersion: args.tableVersion,
      schemaVersion: args.schemaVersion,
      ...(args.partition ?? {}),
    }
  });

  const rel = path.relative(args.cfg.root, filePath);
  const sha = await sha256File(filePath);

  const commit = await commitWrite(args.cfg, {
    table: args.table,
    tableVersion: args.tableVersion,
    schemaVersion: args.schemaVersion,
    add: [{ path: rel, sha256: sha, rows: args.tableData.numRows }],
    generator: args.generator,
    message: args.message,
    tags: args.tags,
    expectedHead: args.expectedHead,
  });

  return { filePath, commitId: commit.id };
}
