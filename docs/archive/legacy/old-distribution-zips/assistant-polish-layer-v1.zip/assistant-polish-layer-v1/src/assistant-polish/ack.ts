import type { PolishState } from "./types";

const ACKS = ["Got it.", "Okay.", "One sec.", "Alright.", "Makes sense."];
const COOLDOWN_MS = 2500;

/**
 * Adds a short acknowledgment fragment sometimes.
 * Uses cooldown so it doesn't spam "Got it." like a nervous intern.
 */
export function maybeAcknowledge(state: PolishState, prob = 0.35) {
  const now = Date.now();
  if (state.lastAckAt && now - state.lastAckAt < COOLDOWN_MS) return "";
  if (Math.random() >= prob) return "";

  state.lastAckAt = now;
  return ACKS[Math.floor(Math.random() * ACKS.length)] + " ";
}
