import { NextRequest, NextResponse } from 'next/server'
import { getToken } from 'next-auth/jwt'

export async function middleware(request: NextRequest) {
  const token = await getToken({ req: request })
  const { pathname } = request.nextUrl

  // Log API requests for audit purposes
  if (pathname.startsWith('/api/') && !pathname.startsWith('/api/auth/')) {
    const ip = request.ip || request.headers.get('x-forwarded-for') || 'unknown'
    const userAgent = request.headers.get('user-agent') || 'unknown'
    
    // In a real implementation, you'd store this in your audit log
    console.log('API Request:', {
      method: request.method,
      path: pathname,
      userId: token?.sub || 'anonymous',
      ip,
      userAgent,
      timestamp: new Date().toISOString(),
    })
  }

  // Protect admin routes
  if (pathname.startsWith('/admin') || pathname.startsWith('/api/admin/')) {
    if (!token || !token.isAdmin) {
      return NextResponse.redirect(new URL('/dashboard', request.url))
    }
  }

  // Protect dashboard routes
  if (pathname.startsWith('/dashboard')) {
    if (!token) {
      return NextResponse.redirect(new URL('/auth/signin', request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    '/admin/:path*',
    '/api/admin/:path*',
    '/dashboard/:path*',
    '/api/:path*',
  ],
}