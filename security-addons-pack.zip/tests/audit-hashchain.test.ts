import { describe, it, expect } from "vitest";
import { InMemoryAuditStore } from "../src/security/audit/store";
import { AuditLogger, computeEntryHash } from "../src/security/audit/hashchain";

describe("Audit hash chain", () => {
  it("chains hashes correctly", async () => {
    const store = new InMemoryAuditStore();
    const logger = new AuditLogger(store);

    const e1 = await logger.log({ tenantId: "t1", entityType: "txn", entityId: "1", action: "create", metadata: { a: 1 } });
    const e2 = await logger.log({ tenantId: "t1", entityType: "txn", entityId: "1", action: "update", metadata: { a: 2 } });

    expect(e2.prevHash).toBe(e1.entryHash);

    // recompute hash
    const recomputed = computeEntryHash({
      id: e2.id,
      tsISO: e2.tsISO,
      tenantId: e2.tenantId,
      actor: e2.actor,
      entityType: e2.entityType,
      entityId: e2.entityId,
      action: e2.action,
      summary: e2.summary,
      metadata: e2.metadata,
      prevHash: e2.prevHash,
    });
    expect(recomputed).toBe(e2.entryHash);
  });
});
