type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export async function http(method: HttpMethod, url: string, opts?: {
  headers?: Record<string, string>;
  body?: any;
}) {
  const headers: Record<string, string> = {
    ...(opts?.headers || {}),
  };

  let body: string | undefined;
  if (opts?.body !== undefined) {
    headers['content-type'] = headers['content-type'] || 'application/json';
    body = typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body);
  }

  const res = await fetch(url, { method, headers, body });

  const text = await res.text();
  let json: any = undefined;
  try { json = text ? JSON.parse(text) : undefined; } catch {}

  return {
    ok: res.ok,
    status: res.status,
    text,
    json,
    headers: Object.fromEntries(res.headers.entries()),
  };
}
