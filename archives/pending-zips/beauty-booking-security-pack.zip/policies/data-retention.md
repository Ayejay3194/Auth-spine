# Data Retention Policy (Starter)

- Auth logs: 90 days hot, 1 year cold
- Audit logs: 2 years (or per compliance)
- Bookings: 7 years (financial/business needs)
- Support chats: 1 year
- Media uploads: until user deletes or account closes + 30 days grace
- Backups: 35 days rolling + monthly snapshots 12 months

Deletion:
- Automated deletion jobs
- Legal hold supported
