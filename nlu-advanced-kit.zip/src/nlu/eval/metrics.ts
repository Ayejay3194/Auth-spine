export type EvalRow = {
  text: string;
  intent: string;
  entities?: { entity: string; value: string }[];
};

export type EvalResult = {
  total: number;
  intentAccuracy: number;
};

export function computeMetrics(gold: EvalRow[], pred: { intent: string }[]): EvalResult {
  const total = gold.length;
  let correct = 0;
  for (let i = 0; i < total; i++) if (gold[i].intent === pred[i]?.intent) correct++;
  return { total, intentAccuracy: total ? correct / total : 0 };
}
