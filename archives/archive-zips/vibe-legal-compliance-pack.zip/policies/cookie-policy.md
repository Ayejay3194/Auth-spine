# Cookie Policy (Template)

**Last updated:** {{DATE}}

## What are cookies?
Small files stored on your device. Some are essential; others are optional.

## Categories
### Essential
Authentication, session security, load balancing, CSRF tokens.

### Preferences
Theme, language, notification preferences.

### Analytics (optional)
Counts visits and feature usage to improve the Service. Disabled until consent where required.

### Marketing (optional)
Used only if you run marketing pixels. Disabled until consent where required.

## Manage cookies
Use the in-app cookie preferences panel: {{COOKIE_PREFERENCES_URL}}

## Do Not Track
We do not currently respond to “Do Not Track” signals in a standardized way (industry reality), but we honor consent choices in supported regions.
