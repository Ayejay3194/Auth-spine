import { Skill } from "./base.js";
import { SkillContext, SkillResult } from "../types.js";

export class FileHelperSkill implements Skill {
  name = "FileHelperSkill";

  async run(ctx: SkillContext): Promise<SkillResult> {
    return {
      kind: "text",
      text: "File requests noted. In faux mode, I can generate folder structures, code, and JSONL splits. If you need actual downloads, your runtime should package artifacts server-side (zip) and return a signed URL.",
      tags: ["files","architecture"]
    };
  }
}
