import { api } from "@/src/core/api";
import { getTenant } from "@/src/tenant/tenant";
import { reportQueue } from "@/src/queue/queues";
import { getActor } from "@/src/core/auth";
import { assertRole } from "@/src/core/policy";

export async function POST(req: Request) {
  return api(async () => {
    const actor = getActor(req);
    assertRole(actor.role, ["owner","admin"]);
    const { tenantId } = getTenant(req);
    await reportQueue.add("reindex_all_providers", { tenantId }, { attempts: 3 });
    return { ok: true };
  });
}
