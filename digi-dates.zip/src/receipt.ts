import { formatISO, parseISO } from "./iso.js";
import { ValidationError } from "./errors.js";

export type ReceiptTimestamp = {
  isoUtc: string;
  epochMs: number;
  seq?: number;
};

export function makeReceiptTimestamp(d: Date = new Date(), seq?: number): ReceiptTimestamp {
  const isoUtc = formatISO(d);
  const epochMs = d.getTime();
  if (!Number.isFinite(epochMs)) throw new ValidationError("Invalid date for receipt timestamp");
  if (seq !== undefined && (!Number.isInteger(seq) || seq < 0)) {
    throw new ValidationError("seq must be a non-negative integer");
  }
  return seq === undefined ? { isoUtc, epochMs } : { isoUtc, epochMs, seq };
}

export function parseReceiptTimestamp(r: ReceiptTimestamp): Date {
  if (typeof r?.isoUtc !== "string") throw new ValidationError("receipt.isoUtc must be string");
  const d = parseISO(r.isoUtc);
  if (d.getTime() !== r.epochMs) throw new ValidationError("Receipt timestamp mismatch (isoUtc != epochMs)");
  return d;
}
