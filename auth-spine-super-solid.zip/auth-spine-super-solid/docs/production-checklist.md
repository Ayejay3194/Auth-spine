# Production Checklist (starter)

- env vars in secrets manager
- strong JWT_SECRET (32+ random)
- HTTPS + security headers
- rate limits on auth endpoints
- health monitoring external ping
- backups daily + restore tested
- npm audit clean (high+)
- logs aggregated + alerting
