import readline from "node:readline";
import { buildRuntime } from "../assistant/runtime.js";
import { makeMockProviders } from "./mockProviders.js";

const auditEvents: any[] = [];
const audit = { async write(ev: any) { auditEvents.unshift({ at: ev.at.toISOString(), type: ev.type, details: ev.details }); } };
const clock = { now: () => new Date() };

const { assistant } = buildRuntime({ providers: makeMockProviders(), audit, clock });

const ctx = { businessId: "platform_1", userId: "user_1", role: "owner", timezone: "America/New_York", locale: "en-US", channel: "web" as const };
let state: any = {};

console.log("Marketplace Assistant Demo.");
console.log("Try:");
console.log("- search providers for braids near atlanta");
console.log("- search slots for prov_1");
console.log("- hold prov_1 cl_1 2026-01-05 evening");
console.log("- create payment for hold hold_1 $120");
console.log("- confirm hold hold_1  (will ask YES for some actions)");
console.log("- open dispute bk_1 open: client no show");
console.log("- show revenue");
console.log("");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.setPrompt("> "); rl.prompt();

rl.on("line", async (line) => {
  const out = await assistant.handle(ctx, state, line);
  state = out.state;
  console.log(out.reply.text);
  if (out.reply.ui) console.log(JSON.stringify(out.reply.ui, null, 2));
  rl.prompt();
});
