# ephemeris-parquet-ts

A **TypeScript** ephemeris storage + runtime system built “DE-style” but **Parquet-native**:

- Fit **Chebyshev segments** from sampled teacher states (e.g., DE440-derived CSV).
- Store compact segments in **Parquet** (one file per body + span).
- Runtime evaluator loads only needed segments and computes position/velocity quickly.
- Includes an **audit** pipeline (compare runtime vs teacher, quantify errors, flag drifts).

## Install

```bash
npm i
```

## Teacher CSV format

(AU, AU/day preferred)

- `jd`
- `<body>_x,<body>_y,<body>_z,<body>_vx,<body>_vy,<body>_vz`

Bodies:
`sun, mercury, venus, earth, moon, mars, jupiter, saturn, uranus, neptune, pluto`

## CLI

### Fit Parquet coefficients

```bash
npm run dev -- fit \
  --teacher ./data/teacher_states.csv \
  --out ./eph_store \
  --body mercury \
  --span 1900_2000 \
  --segmentDays 32 \
  --order 12
```

### Evaluate a state

```bash
npm run dev -- eval \
  --store ./eph_store \
  --body mercury \
  --span 1900_2000 \
  --jd 2451545.0 \
  --order 12
```

### Audit vs teacher

```bash
npm run dev -- audit \
  --teacher ./data/teacher_states.csv \
  --store ./eph_store \
  --body mercury \
  --span 1900_2000 \
  --order 12
```
