"use client";
import React from "react";

export function MapCanvas() {
  const ref = React.useRef<HTMLDivElement | null>(null);
  const [pin, setPin] = React.useState({ x: 52, y: 46 });
  const [extras, setExtras] = React.useState<Array<{ x: number; y: number; o: number }>>([]);

  function onClick(e: React.MouseEvent) {
    const el = ref.current;
    if (!el) return;
    const box = el.getBoundingClientRect();
    const x = ((e.clientX - box.left) / box.width) * 100;
    const y = ((e.clientY - box.top) / box.height) * 100;
    setPin({ x, y });
  }

  function dropPins() {
    const next = Array.from({ length: 6 }).map(() => ({
      x: 15 + Math.random() * 70,
      y: 15 + Math.random() * 70,
      o: 0.55 + Math.random() * 0.4
    }));
    setExtras((p) => [...p, ...next]);
  }

  return (
    <div>
      <div
        ref={ref}
        onClick={onClick}
        className="relative h-[60vh] min-h-[420px] rounded-[26px] border border-white/10 bg-white/5 overflow-hidden"
        style={{
          background:
            "radial-gradient(140px 100px at 30% 35%, rgba(231,199,118,.28), transparent 62%), radial-gradient(220px 140px at 70% 60%, rgba(243,241,236,.10), transparent 70%), linear-gradient(180deg, rgba(11,12,14,.35), rgba(7,8,9,.62))"
        }}
      >
        <Pin x={pin.x} y={pin.y} />
        {extras.map((p, i) => (
          <Pin key={i} x={p.x} y={p.y} o={p.o} />
        ))}
      </div>

      <div className="mt-4 flex flex-wrap gap-3">
        <button className="btn btn-primary" onClick={dropPins}>Drop pins</button>
        <button className="btn" onClick={() => setExtras([])}>Clear</button>
        <span className="text-xs text-white/60 self-center">Click map to move main pin.</span>
      </div>
    </div>
  );
}

function Pin({ x, y, o }: { x: number; y: number; o?: number }) {
  return (
    <div
      className="absolute h-2.5 w-2.5 rounded-full bg-yellow-100 shadow-[0_0_0_7px_rgba(231,199,118,.16),0_0_28px_rgba(231,199,118,.45)]"
      style={{ left: `${x}%`, top: `${y}%`, transform: "translate(-50%,-50%)", opacity: o ?? 1 }}
    />
  );
}
