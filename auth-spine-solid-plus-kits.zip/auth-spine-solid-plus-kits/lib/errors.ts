export class AuthSpineError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode: number,
    public meta?: Record<string, any>
  ) {
    super(message);
    this.name = "AuthSpineError";
  }
}

export class AuthenticationError extends AuthSpineError {
  constructor(message = "Authentication failed", meta?: Record<string, any>) {
    super(message, "AUTH_ERROR", 401, meta);
    this.name = "AuthenticationError";
  }
}

export class AuthorizationError extends AuthSpineError {
  constructor(message = "Not allowed", meta?: Record<string, any>) {
    super(message, "AUTHZ_ERROR", 403, meta);
    this.name = "AuthorizationError";
  }
}
