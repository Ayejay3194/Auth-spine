PRIORITIZATION TEMPLATE (SMB -> ENTERPRISE)

CRITICAL (Ship-blockers)
- Tenant isolation + tenant context validation on every request
- Server-side plan/permission enforcement (no UI-only gating)
- Webhook signature verification + idempotency keys
- Secrets management + rotation + repo scanning
- Central logging + alerting + incident playbooks
- Backup + restore drills + RTO/RPO set
- Export + deletion flows (privacy rights readiness)

HIGH (First 90 days)
- Per-tenant quotas + abuse detection
- Admin MFA + break-glass procedures
- Status page + on-call rotations
- Audit logging + export
- SSO/SCIM if selling to enterprise

MEDIUM (After PMF)
- BYOK / customer-managed keys
- Dedicated infra options
- Multi-region residency selection
- SIEM streaming integrations
