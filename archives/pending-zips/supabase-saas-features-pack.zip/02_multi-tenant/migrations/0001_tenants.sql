create extension if not exists pgcrypto;

create table if not exists tenants (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  status text not null default 'ACTIVE', -- ACTIVE | SUSPENDED | DELETED
  plan text not null default 'FREE',
  region text not null default 'US',
  created_at timestamptz default now()
);

create table if not exists tenant_domains (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  domain text unique not null,
  verified_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists tenant_memberships (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('OWNER','ADMIN','MEMBER','SUPPORT_READ','SUPPORT_WRITE')),
  created_at timestamptz default now(),
  unique (tenant_id, user_id)
);
