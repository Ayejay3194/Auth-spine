import type { Role, TenantId, UserId } from "../types.js";

export type Session = {
  userId: UserId;
  tenantId?: TenantId;
  roles: Role[];
  issuedAtISO: string;
  expiresAtISO: string;
};

export function hasRole(session: Session, role: Role): boolean {
  return session.roles.includes(role);
}

export function requireRole(session: Session, role: Role) {
  if (!hasRole(session, role)) {
    const err = new Error(`FORBIDDEN: missing role ${role}`);
    (err as any).code = "FORBIDDEN";
    throw err;
  }
}

export function requireTenant(session: Session, tenantId: TenantId) {
  if (session.tenantId !== tenantId) {
    const err = new Error(`FORBIDDEN: tenant boundary`);
    (err as any).code = "TENANT_FORBIDDEN";
    throw err;
  }
}
