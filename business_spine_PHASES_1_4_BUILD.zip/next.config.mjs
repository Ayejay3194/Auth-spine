export default { experimental: { serverActions: true } };
