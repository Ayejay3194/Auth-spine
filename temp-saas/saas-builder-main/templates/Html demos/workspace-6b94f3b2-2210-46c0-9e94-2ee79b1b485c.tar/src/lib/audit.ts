import { db } from '@/lib/db'
import { NextRequest } from 'next/server'
import { getClientIP } from './security'

interface AuditLogData {
  userId?: string
  workspaceId?: string
  action: string
  resource: string
  resourceId?: string
  oldValues?: any
  newValues?: any
  ipAddress?: string
  userAgent?: string
}

export async function createAuditLog(data: AuditLogData, request?: NextRequest) {
  try {
    await db.auditLog.create({
      data: {
        ...data,
        ipAddress: request ? getClientIP(request) : data.ipAddress,
        userAgent: request ? request.headers.get('user-agent') || undefined : data.userAgent,
      }
    })
  } catch (error) {
    console.error('Failed to create audit log:', error)
    // In production, you might want to send this to a logging service
  }
}

// Predefined audit actions
export const AUDIT_ACTIONS = {
  // Workspace actions
  WORKSPACE_CREATED: 'workspace.created',
  WORKSPACE_UPDATED: 'workspace.updated',
  WORKSPACE_DELETED: 'workspace.deleted',
  
  // Member actions
  MEMBER_INVITED: 'member.invited',
  MEMBER_JOINED: 'member.joined',
  MEMBER_ROLE_UPDATED: 'member.role_updated',
  MEMBER_REMOVED: 'member.removed',
  
  // Project actions
  PROJECT_CREATED: 'project.created',
  PROJECT_UPDATED: 'project.updated',
  PROJECT_DELETED: 'project.deleted',
  
  // Task actions
  TASK_CREATED: 'task.created',
  TASK_UPDATED: 'task.updated',
  TASK_DELETED: 'task.deleted',
  
  // Billing actions
  SUBSCRIPTION_CREATED: 'subscription.created',
  SUBSCRIPTION_UPDATED: 'subscription.updated',
  SUBSCRIPTION_CANCELLED: 'subscription.cancelled',
  
  // Admin actions
  ADMIN_IMPERSONATE: 'admin.impersonate',
  ADMIN_USER_UPDATED: 'admin.user_updated',
  ADMIN_WORKSPACE_UPDATED: 'admin.workspace_updated',
  
  // Auth actions
  USER_LOGIN: 'user.login',
  USER_LOGOUT: 'user.logout',
  USER_REGISTERED: 'user.registered',
  PASSWORD_RESET: 'user.password_reset',
} as const

// Audit middleware for API routes
export function auditMiddleware(action: string, resource: string) {
  return async (
    userId: string | undefined,
    workspaceId: string | undefined,
    resourceId: string | undefined,
    oldValues?: any,
    newValues?: any,
    request?: NextRequest
  ) => {
    await createAuditLog({
      userId,
      workspaceId,
      action,
      resource,
      resourceId,
      oldValues,
      newValues,
    }, request)
  }
}

// Get audit logs for a workspace
export async function getWorkspaceAuditLogs(
  workspaceId: string,
  options: {
    limit?: number
    offset?: number
    startDate?: Date
    endDate?: Date
    actions?: string[]
  } = {}
) {
  const { limit = 50, offset = 0, startDate, endDate, actions } = options
  
  const where: any = { workspaceId }
  
  if (startDate || endDate) {
    where.createdAt = {}
    if (startDate) where.createdAt.gte = startDate
    if (endDate) where.createdAt.lte = endDate
  }
  
  if (actions && actions.length > 0) {
    where.action = { in: actions }
  }
  
  return await db.auditLog.findMany({
    where,
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
        }
      }
    },
    orderBy: {
      createdAt: 'desc'
    },
    take: limit,
    skip: offset,
  })
}

// Get audit logs for a user
export async function getUserAuditLogs(
  userId: string,
  options: {
    limit?: number
    offset?: number
    startDate?: Date
    endDate?: Date
  } = {}
) {
  const { limit = 50, offset = 0, startDate, endDate } = options
  
  const where: any = { userId }
  
  if (startDate || endDate) {
    where.createdAt = {}
    if (startDate) where.createdAt.gte = startDate
    if (endDate) where.createdAt.lte = endDate
  }
  
  return await db.auditLog.findMany({
    where,
    include: {
      workspace: {
        select: {
          id: true,
          name: true,
        }
      }
    },
    orderBy: {
      createdAt: 'desc'
    },
    take: limit,
    skip: offset,
  })
}