import { describe, it, expect } from "vitest";
import { BASE_URL } from "../tools/config";
import { http } from "../tools/http";
import { expectForbiddenOrNotFound } from "../tools/assertions";

describe("security: authz deny-by-default", () => {
  const protectedEndpoints = [
    "/auth/sessions",
    "/api/auth/me",
    "/api/metrics",
    "/admin",
    "/admin/auth-ops",
  ];

  it("protected endpoints reject anonymous requests", async () => {
    for (const path of protectedEndpoints) {
      const r = await http("GET", `${BASE_URL}${path}`);
      // Some endpoints might legitimately be public (eg /api/metrics in dev), so treat 2xx as a finding.
      if (r.status >= 200 && r.status < 300) {
        throw new Error(`Endpoint ${path} is accessible without auth. status=${r.status}`);
      }
      expectForbiddenOrNotFound(r.status);
    }
    expect(true).toBe(true);
  });
});
