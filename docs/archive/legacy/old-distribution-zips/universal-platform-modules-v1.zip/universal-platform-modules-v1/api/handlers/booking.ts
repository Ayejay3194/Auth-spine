import type { EventName } from "@/events/catalog";

export interface BookingCreateInput {
  clientId: string;
  professionalId: string;
  serviceId: string;
  startTime: string; // ISO
  notes?: string;
}

export async function createBooking(input: BookingCreateInput) {
  // TODO:
  // 1) validate
  // 2) check availability
  // 3) create hold or confirmed booking
  // 4) emit event: booking.created (+ maybe booking.confirmed)
  const emitted: EventName[] = ["booking.created"];
  return { bookingId: "TODO", emitted };
}
