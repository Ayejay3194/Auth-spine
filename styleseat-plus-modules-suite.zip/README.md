# StyleSeat-Plus Modules Suite (TypeScript)

You asked for **modules built out** (not stubs). This zip contains production-grade, framework-agnostic modules:
- Automation engine (event rules, actions, scheduling hooks)
- Marketing engine (segments, campaigns, journeys, attribution)
- A/B testing + feature flags
- Social scheduler + content templates
- Analytics + reporting/export (CSV) + KPI registry
- Notifications center (real-time friendly, retention policy)
- Team + multi-location + commissions
- Permissions (granular roles/scopes)
- Webhooks + signature verification + retry/backoff + delivery logs
- Subscription plans + entitlements + metering/quota
- Consent & compliance helpers (SMS/email consent gates)

All modules are deterministic. No LLM required.

## Run demo
```bash
cd packages/core
npm i
npm run build
npm run demo
```
