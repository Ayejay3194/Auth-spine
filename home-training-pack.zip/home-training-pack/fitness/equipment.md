# Minimal Equipment List
- Comfortable shoes (for walks/intervals)
- A backpack you can load (books/water jugs)
- Optional: resistance bands (loop + long band)
- Optional: cheap adjustable dumbbells or kettlebell
- A chair + a towel

## Safety basics
- Don’t do jump stuff on slippery floors.
- If your chair wobbles, it’s not “functional training”, it’s a trip to the ER.
