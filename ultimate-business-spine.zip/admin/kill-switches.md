KILL SWITCHES
=============

Global switches:
- Pause bookings
- Pause payments
- Freeze payroll
- Pause notifications (except critical)
- Lock admin writes

Requirements:
- One click
- Logged
- Permission-gated
- Reversible
