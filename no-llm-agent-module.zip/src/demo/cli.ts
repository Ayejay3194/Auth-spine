import readline from "node:readline";
import crypto from "node:crypto";
import { createNoLlmAgent } from "../agent/agent.js";
import { IntentDetector } from "../nlu/intents.js";
import { ConsoleAuditLogger } from "./audit.js";
import { buildDemoTools } from "./tools.js";

const audit = new ConsoleAuditLogger();
const tools = buildDemoTools(audit);

const detector = new IntentDetector(
  [
    { intent: "auth.forgot_username", any: ["forgot username", "login name"], all: [] },
    { intent: "auth.password_reset_request", any: ["reset password", "forgot password", "can't log in"], all: [] },
    { intent: "gdpr.export_request", any: ["download my data", "export my data", "gdpr"], all: [] },
    { intent: "billing.change_plan", any: ["change plan", "upgrade", "downgrade"], all: [] },
  ],
  [
    { intent: "auth.forgot_username", utterance: "I forgot my username" },
    { intent: "auth.forgot_username", utterance: "send my login name to my email" },
    { intent: "auth.password_reset_request", utterance: "forgot my password" },
    { intent: "auth.password_reset_request", utterance: "reset my password please" },
    { intent: "gdpr.export_request", utterance: "export my account data" },
    { intent: "billing.change_plan", utterance: "upgrade me to paid plan" },
    { intent: "billing.change_plan", utterance: "downgrade to free" },
  ],
  { minScore: 0.35 }
);

const agent = createNoLlmAgent({ tools, audit, clock: { now: () => new Date() }, intent: detector });

let state = { flow: null as any };
const ctx = { userId: "user_" + crypto.randomBytes(4).toString("hex"), role: "user" as const };

console.log("No-LLM Agent demo. Try: 'I forgot my username', 'reset my password', 'export my data', 'upgrade to paid'.");
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.setPrompt("> ");
rl.prompt();

rl.on("line", async (line) => {
  const { state: next, reply } = await agent.handle(ctx, state, line);
  state = next;
  console.log(reply.text);
  rl.prompt();
});
