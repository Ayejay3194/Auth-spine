Decans Auth Ops Upgrades Kit
===========================

This adds the 3 "ship it and suffer less" upgrades:
1) Metrics ingestion (pull endpoint + compute helper)
2) Correlation IDs (X-Request-Id middleware)
3) Guarded action runner (apply mitigations with step-up auth)

1) Correlation IDs
------------------
- Adds `middleware.ts` that sets `X-Request-Id` on every response.
- Use this `request_id` in logs/audit records to correlate incidents to actions.

2) Metrics ingestion (pull model)
---------------------------------
- `GET /api/ops/auth/metrics` returns a computed snapshot from auth log events.
- Replace the stub log query in `getAuthLogEvents()` with your real source.

3) Action runner (guarded)
--------------------------
- `POST /api/ops/auth/actions` applies mitigations (feature flags) with policy gates.
- High-risk actions require `step_up_token`.
- Every action is appended to an audit log (demo in-memory store).

Suggested next step
-------------------
- Replace the in-memory flag store with your DB table or feature-flag provider.
- Replace the audit log store with an append-only DB table.
- Replace step-up validation with your auth provider (re-auth/MFA).
