export type Flow = { id: string; handle(args: any): Promise<any> };
