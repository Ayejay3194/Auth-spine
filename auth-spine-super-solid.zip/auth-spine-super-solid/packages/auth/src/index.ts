import { SignJWT, jwtVerify } from 'jose'
import { AuthError, ErrorCode, validateEnv } from '@auth-spine/core'

export type JwtPayload = {
  userId: string
  email?: string
  role?: string
}

function getKey() {
  const cfg = validateEnv()
  return new TextEncoder().encode(cfg.JWT_SECRET)
}

export async function generateToken(payload: JwtPayload, opts?: { expiresIn?: string }) {
  const cfg = validateEnv()
  const exp = opts?.expiresIn || cfg.JWT_EXPIRES_IN
  return new SignJWT(payload as any)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(exp)
    .sign(getKey())
}

export async function verifyToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, getKey(), { algorithms: ['HS256'] })
    return payload as any as JwtPayload
  } catch (e: any) {
    throw new AuthError(e?.message || 'Invalid token', ErrorCode.AUTH_UNAUTHORIZED)
  }
}
