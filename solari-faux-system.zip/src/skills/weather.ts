import { Skill } from "./base.js";
import { SkillContext, SkillResult } from "../types.js";

export class WeatherSkill implements Skill {
  name = "WeatherSkill";

  async run(ctx: SkillContext): Promise<SkillResult> {
    // Faux: no web calls. Return a deterministic, honest response.
    const loc = ctx.nlu.entities.find(e => e.kind === "location")?.value;
    if (!loc) {
      return { kind: "clarify", question: "Which location?", options: ["New York, NY", "Los Angeles, CA"], tags: ["weather","clarify"] };
    }
    return {
      kind: "text",
      text: `Weather for ${loc}: this faux system can’t fetch live forecasts yet. If you want real weather, you’ll wire an API as a skill. Right now I can help you structure the request + caching + response format.`,
      tags: ["weather","faux"]
    };
  }
}
