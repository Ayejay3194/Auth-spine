import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PUT(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get('session-token')?.value

    if (!sessionToken) {
      return NextResponse.json(
        { error: 'No session found' },
        { status: 401 }
      )
    }

    // Find session and user
    const session = await db.session.findUnique({
      where: { sessionToken },
      include: { user: true }
    })

    if (!session || session.expires < new Date()) {
      return NextResponse.json(
        { error: 'Invalid or expired session' },
        { status: 401 }
      )
    }

    const preferences = await request.json()

    // In a real application, you'd store preferences in a separate table
    // For now, we'll just return success
    // const updatedPreferences = await db.userPreferences.upsert({
    //   where: { userId: session.user.id },
    //   update: preferences,
    //   create: { userId: session.user.id, ...preferences }
    // })

    return NextResponse.json({
      message: 'Preferences saved successfully',
      preferences
    })
  } catch (error) {
    console.error('Save preferences error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}