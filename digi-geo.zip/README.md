# @solari/digi-geo

A provider-agnostic geocoding + caching module with **receipts** and **schema validation**.

## What it does
- Forward geocode: "New York, NY" → lat/lon + structured parts
- Reverse geocode: lat/lon → best label + parts
- Caching:
  - L1: in-memory (fast, per-process)
  - L2: pluggable (Redis-style interface), optional
- Receipts: every call returns a receipt you can log/store to prove behavior.

## Quick start
```ts
import { createDigiGeo, InMemoryCache, envKeyProvider } from "./src";

const geo = createDigiGeo({
  provider: {
    kind: "nominatim",
    userAgent: "your-app-name/1.0 (you@domain.com)",
    endpoint: "https://nominatim.openstreetmap.org"
  },
  cache: {
    l1: new InMemoryCache({ maxEntries: 5000, defaultTtlMs: 1000 * 60 * 60 * 24 * 14 }),
    l2: undefined // plug in Redis adapter if you want
  },
  policy: {
    minConfidence: 0.55,
    negativeCacheTtlMs: 1000 * 60 * 10
  }
});

const res = await geo.forward({ query: "1600 Pennsylvania Ave NW, Washington, DC" });
console.log(res.best?.point, res.receipt);
```

## Providers
Included:
- Nominatim (OpenStreetMap) via HTTP fetch

You can add:
- Mapbox, HERE, Google, etc. by implementing `GeoProvider`.

## Cache keys
- Forward: normalized query + locale + country bias
- Reverse: rounded lat/lon + locale

## Notes
- Respect provider rate limits.
- Nominatim requires a real User-Agent identifying your app.
