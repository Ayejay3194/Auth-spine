import { z } from "zod";

export const LatLonSchema = z.object({
  lat: z.number().min(-90).max(90),
  lon: z.number().min(-180).max(180),
});

export const ForwardRequestSchema = z.object({
  query: z.string().min(1).max(500),
  locale: z.string().min(2).max(20).optional(),
  countryCodes: z.array(z.string().min(2).max(2)).optional(),
  limit: z.number().int().min(1).max(20).optional(),
});

export const ReverseRequestSchema = z.object({
  point: LatLonSchema,
  locale: z.string().min(2).max(20).optional(),
  zoom: z.number().int().min(0).max(22).optional(),
});

export const DigiGeoPolicySchema = z.object({
  minConfidence: z.number().min(0).max(1),
  negativeCacheTtlMs: z.number().int().min(0),
});
