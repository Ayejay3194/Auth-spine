import type { ClockPort } from '@spine/auth-core';
export class SystemClock implements ClockPort { nowIso(){return new Date().toISOString()} nowMs(){return Date.now()} }
