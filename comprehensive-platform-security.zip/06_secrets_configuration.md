SECRETS & CONFIGURATION MANAGEMENT

Covers:
- Secrets managers
- Rotation & access logging
- IaC security
- Config drift detection