import fs from "node:fs/promises";
import path from "node:path";
import { lockPath, LakeConfig } from "../io/paths.js";

/**
 * Best-effort exclusive lock (local FS):
 * - Creates a lock file with 'wx' (fails if exists)
 * - Deletes it when done
 *
 * Not distributed locking. It's to prevent accidental concurrent writers.
 */
export async function withTableLock<T>(
  cfg: LakeConfig,
  table: string,
  tableVersion: string,
  fn: () => Promise<T>
): Promise<T> {
  const lp = lockPath(cfg, table, tableVersion);
  await fs.mkdir(path.dirname(lp), { recursive: true });

  const handle = await fs.open(lp, "wx").catch(() => null);
  if (!handle) throw new Error(`Lock held for ${table}@${tableVersion}. If it's stale, delete: ${lp}`);

  try {
    await handle.writeFile(JSON.stringify({ pid: process.pid, at: new Date().toISOString() }));
    return await fn();
  } finally {
    await handle.close().catch(() => {});
    await fs.unlink(lp).catch(() => {});
  }
}
