/**
 * Tiny script to remind humans what matters.
 * Real linting belongs in the monorepo's tooling.
 */
console.log("digi-wit: keep Wit.ai as a parser. No execution. Enforce schema + receipts.");
