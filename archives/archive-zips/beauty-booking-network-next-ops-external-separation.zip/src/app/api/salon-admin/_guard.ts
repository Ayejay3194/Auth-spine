import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function requireAdmin(){
  const session = await auth();
  if(!session?.user?.email) return { ok:false as const, status:401, user:null };
  const user = await prisma.user.findUnique({ where:{ email: session.user.email } });
  if(!user || !["OWNER","MANAGER","ADMIN"].includes(user.role)) return { ok:false as const, status:403, user:null };
  return { ok:true as const, status:200, user };
}
