# Supabase Feature Map (your checklist, translated)

Legend:
- ✅ Native: Supabase does it (mostly config)
- 🟨 Partial: Supabase helps, you still implement logic
- 🧱 Custom: you build it

## Social platform bits
- Content moderation: 🧱 (tables + workflows; can trigger Edge Functions)
- Hashtags / mentions: 🧱 (DB + search)
- Trending algorithm: 🧱 (materialized views, jobs, external compute)
- Stories/ephemeral: 🟨 (soft-delete/ttl via cron + storage policies)
- Live streaming: 🧱 (external streaming provider; Supabase stores metadata)
- Groups/communities: 🧱 (DB + RLS)
- User verification badges: 🧱 (admin workflow + audit)
- Per-post analytics: 🟨 (event tables in Postgres; aggregation jobs)

## Marketplace
- Profiles/listings/categories/search: 🧱 (DB + RLS + indexes)
- Payouts: 🧱 (payment provider)
- Fraud detection: 🧱 (rules + signals)
- Reviews/ratings: 🧱 (DB + anti-abuse)
- Commission calc: 🧱 (server-side only)
- Escrow: 🧱 (payment provider)

## Booking/reservation
- Availability/calendar/rules: 🧱 (core product logic)
- Notifications: 🟨 (Realtime + Edge Functions + email/SMS provider)
- Payments/deposits: 🧱 (payment provider + webhooks)
- Capacity management: 🧱 (DB constraints + logic)

## Advanced DB patterns
- Soft delete: ✅ (schema pattern + policies)
- Audit trail: ✅ (triggers + partitioning)
- Versioning: ✅ (history tables + triggers)
- Hierarchies: ✅ (closure table / recursive CTE)
- Event sourcing: ✅ (event store table)
- CQRS: 🟨 (views/materialized views; read models)
- Temporal: ✅ (valid_from/valid_to + queries)
- Polymorphic assoc: ✅ (type + id + constraints)
- State machine: ✅ (check constraints + transition log)

## Auth patterns
- Social login: ✅ (Auth providers)
- Passwordless: ✅ (magic links); Passkeys/WebAuthn: 🟨 (depends on client + custom)
- Enterprise SSO (SAML/SCIM): 🟨/🧱 (often external IdP + custom glue)

## Storage patterns
- Large files/chunking: 🧱 (client implementation)
- Media processing pipeline: 🟨 (Storage events + Edge Functions + worker)
- Signed sharing links: ✅ (signed URLs), advanced sharing rules: 🧱

## Realtime patterns
- Presence/chat/basic notifications: ✅ (Realtime + tables)
- E2E encryption: 🧱 (client-side crypto)
- Collaborative editing (CRDT/OT): 🧱 (client libs + persistence)

## Edge Functions
- API gateway patterns: 🟨 (Edge Functions can do some; gateway is more infra)
- Webhook handlers: ✅ (great use case)
- Background jobs: 🟨 (cron + queues external; DB scheduled functions)

## Security patterns
- Zero trust: 🧱 (architecture)
- Defense in depth: 🧱 (architecture)
- Tenant isolation: ✅/🟨 (RLS + your tenant context)
