import type { Node, AuditFinding } from "@solari/schema";
import { Node as NodeSchema } from "@solari/schema";

export function validateNodes(nodes: any[], version: string) {
  const out: Node[] = [];
  const findings: AuditFinding[] = [];

  for (const raw of nodes) {
    const parsed = NodeSchema.safeParse(raw);
    if (!parsed.success) {
      findings.push({ level:"error", code:"INVALID_NODE", message: parsed.error.message, meta:{ raw } });
      continue;
    }
    const node = { ...parsed.data, version: parsed.data.version ?? version };
    out.push(node);
  }

  return { nodes: out, findings };
}

export function auditGraph(nodes: Node[]) {
  const findings: AuditFinding[] = [];
  const byId = new Map(nodes.map(n => [n.id, n] as const));

  // orphaned links
  for (const n of nodes) {
    for (const link of n.links ?? []) {
      if (!byId.has(link)) {
        findings.push({
          level:"warn",
          code:"BROKEN_LINK",
          message:`${n.id} links to missing ${link}`,
          nodeId: n.id,
          meta:{ missing: link }
        });
      }
    }
  }

  // singleton nodes
  const inbound = new Map<string, number>();
  for (const n of nodes) {
    for (const link of n.links ?? []) inbound.set(link, (inbound.get(link) ?? 0) + 1);
  }
  for (const n of nodes) {
    const inb = inbound.get(n.id) ?? 0;
    const outb = (n.links ?? []).length;
    if (inb === 0 && outb === 0) {
      findings.push({ level:"info", code:"SINGLETON", message:`${n.id} has no links`, nodeId:n.id });
    }
  }

  // alias collisions
  const aliasToId = new Map<string, string>();
  for (const n of nodes) {
    for (const a of n.aliases ?? []) {
      const key = a.trim().toLowerCase();
      const existing = aliasToId.get(key);
      if (existing && existing !== n.id) {
        findings.push({ level:"warn", code:"ALIAS_COLLISION", message:`Alias '${a}' used by ${existing} and ${n.id}`, nodeId:n.id, meta:{ alias:a, other: existing } });
      } else aliasToId.set(key, n.id);
    }
  }

  return findings;
}
