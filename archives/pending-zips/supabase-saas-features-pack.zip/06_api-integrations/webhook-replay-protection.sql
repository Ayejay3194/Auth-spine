-- Store webhook delivery IDs to prevent replay
create table if not exists webhook_deliveries (
  id bigserial primary key,
  tenant_id uuid not null,
  provider text not null,
  delivery_id text not null,
  received_at timestamptz default now(),
  unique (tenant_id, provider, delivery_id)
);
