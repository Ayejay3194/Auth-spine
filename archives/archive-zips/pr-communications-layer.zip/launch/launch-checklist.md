LAUNCH CHECKLIST
================

Before:
- Messaging approved
- Support briefed
- Monitoring heightened
- FAQ updated

During:
- Single source of truth for updates
- No reactive tweeting
- Issues routed internally

After:
- Debrief
- Metrics review
- Narrative adjustments
