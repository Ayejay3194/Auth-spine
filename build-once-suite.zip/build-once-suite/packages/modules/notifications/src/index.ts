import type { EventBus } from "@suite/core-events";

export type Notification = {
  id: string;
  userId: string;
  type: string;
  title: string;
  body?: string;
  url?: string;
  createdAt: string;
  readAt?: string;
};

export interface NotificationStore {
  add(n: Omit<Notification,"id"|"createdAt">): Promise<Notification>;
  list(userId: string, limit?: number): Promise<Notification[]>;
  markRead(userId: string, id: string): Promise<void>;
}

export interface RealtimeAdapter {
  publish(userId: string, payload: unknown): Promise<void>; // SSE/WS adapter
}

export class NotificationService {
  constructor(private store: NotificationStore, private realtime: RealtimeAdapter, private bus?: EventBus) {}

  async publish(userId: string, n: Omit<Notification,"id"|"createdAt"|"userId">) {
    const created = await this.store.add({ ...n, userId });
    await this.realtime.publish(userId, { kind: "notification", notification: created });
    if (this.bus) await this.bus.publish({ id:`evt_${Math.random().toString(16).slice(2)}`, type:"notification.created", ts:new Date().toISOString(), actor:{actorType:"system"}, payload: created });
    return created;
  }
}
