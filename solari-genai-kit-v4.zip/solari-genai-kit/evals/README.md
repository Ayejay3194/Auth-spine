# evals/

Runs **golden** + **edge-case** suites against `runtime/` and writes `evals/results/results.json`
including a **failure taxonomy** and any confidence outputs from runtime.

## Run
```bash
npm i
API_KEY=change-me MODEL_BASE_URL=http://localhost:8080 RUNTIME_URL=http://localhost:7777/generate npm run run
```

## What to watch
- `passRate`
- `repairedRate` (should be low)
- `taxonomy` (JSON_PARSE and SCHEMA should trend toward zero)
- `details[].confidence` (LOW means your pipeline doesn't trust itself)


### Token pressure suite
Runs `token_pressure.json` to catch truncation/JSON breakage under long outputs.
