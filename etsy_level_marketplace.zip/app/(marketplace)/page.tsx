import Link from "next/link";

export default async function Marketplace() {
  const res = await fetch(process.env.NEXT_PUBLIC_BASE_URL + "/api/marketplace/products");
  const products = await res.json();

  return (
    <main>
      <h1>Marketplace</h1>
      <ul>
        {products.map((p: any) => (
          <li key={p.id}>
            <Link href={`/product/${p.id}`}>{p.name}</Link> – ${p.price}
          </li>
        ))}
      </ul>
    </main>
  );
}
