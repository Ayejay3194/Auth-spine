import { bag, cosine, tokenize } from "./tokenize.js";

export type IntentId =
  | "booking.create" | "booking.reschedule" | "booking.cancel" | "booking.list" | "availability.search"
  | "crm.find_client" | "crm.add_note" | "crm.tag_client" | "crm.history"
  | "payments.create_invoice" | "payments.refund" | "payments.apply_credit"
  | "marketing.create_promo" | "marketing.end_promo" | "marketing.referral_status" | "marketing.send_campaign"
  | "analytics.kpi" | "analytics.report_export"
  | "ops.create_task" | "ops.list_tasks" | "ops.start_checklist" | "ops.mark_done"
  | "admin.show_audit" | "admin.manage_role" | "gdpr.export_request"
  | "unknown";

export interface IntentExample { intent: IntentId; utterance: string; }
export interface IntentRule { intent: IntentId; any: string[]; all?: string[]; }

export interface IntentResult {
  intent: IntentId;
  score: number;
  matchedBy: "rule" | "similarity" | "none";
  alternatives: Array<{ intent: IntentId; score: number }>;
}

export class IntentDetector {
  private ex: Array<{ intent: IntentId; vec: Map<string, number> }> = [];
  constructor(private rules: IntentRule[], examples: IntentExample[], private cfg: { minScore: number } = { minScore: 0.33 }) {
    for (const e of examples) this.ex.push({ intent: e.intent, vec: bag(tokenize(e.utterance)) });
  }
  detect(text: string): IntentResult {
    const norm = text.toLowerCase();
    for (const r of this.rules) {
      const anyOk = r.any.some((p) => norm.includes(p));
      const allOk = (r.all ?? []).every((p) => norm.includes(p));
      if (anyOk && allOk) return { intent: r.intent, score: 1, matchedBy: "rule", alternatives: [] };
    }
    const v = bag(tokenize(text));
    const scores = new Map<IntentId, number>();
    for (const e of this.ex) scores.set(e.intent, Math.max(scores.get(e.intent) ?? 0, cosine(v, e.vec)));
    const ranked = Array.from(scores.entries()).map(([intent, score]) => ({ intent, score })).sort((a,b) => b.score - a.score);
    const top = ranked[0] ?? { intent: "unknown" as const, score: 0 };
    const intent = top.score >= this.cfg.minScore ? top.intent : ("unknown" as const);
    return { intent, score: top.score, matchedBy: intent === "unknown" ? "none" : "similarity", alternatives: ranked.slice(0, 5) };
  }
}
