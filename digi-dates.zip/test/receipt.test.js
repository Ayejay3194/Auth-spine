import test from "node:test";
import assert from "node:assert/strict";
import { makeReceiptTimestamp, parseReceiptTimestamp } from "../dist/index.js";

test("receipt timestamp roundtrips", () => {
  const d = new Date(Date.UTC(2025, 11, 16, 5, 6, 7, 8));
  const r = makeReceiptTimestamp(d, 1);
  const d2 = parseReceiptTimestamp(r);
  assert.equal(d2.getTime(), d.getTime());
});
