
import { sha256Hex } from "./crypto.js";

/**
 * Redact any sensitive inputs by hashing them.
 * Use this BEFORE persisting receipts.
 */
export function hashInputsForReceipt(raw: unknown): { inputSha256: string } {
  // Intentionally stringify raw here, but never store raw.
  return { inputSha256: sha256Hex(JSON.stringify(raw)) };
}

/**
 * Extremely blunt PII guard: prevent obvious fields from being stored.
 * Add/adjust for your domain.
 */
export function assertNoPIIKeys(obj: Record<string, unknown>) {
  const banned = ["name","email","phone","address","dob","birth","ssn","passport"];
  const keys = Object.keys(obj).map(k => k.toLowerCase());
  for (const b of banned) {
    if (keys.some(k => k.includes(b))) {
      throw new Error(`PII-like key detected in receipt payload: "${b}"`);
    }
  }
}
