// Edge Function: api-gateway (Deno)
// Pattern: route + auth + validation + caching hints (stub)
// Deploy: supabase functions deploy api-gateway
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

function json(data: unknown, status = 200, headers: HeadersInit = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...headers },
  });
}

function getBearer(req: Request) {
  const h = req.headers.get("authorization") ?? "";
  const m = h.match(/^Bearer\s+(.+)$/i);
  return m?.[1] ?? null;
}

serve(async (req) => {
  const url = new URL(req.url);

  // Basic routing
  if (url.pathname === "/health") return json({ ok: true });

  // Example: require auth for everything else
  const token = getBearer(req);
  if (!token) return json({ error: "missing_token" }, 401, { "cache-control": "no-store" });

  // TODO: verify JWT (use Supabase JWT secret or call /auth/v1/user with token)
  // TODO: input validation per route
  // TODO: rate limiting (Upstash/Redis or gateway-level)

  return json({ ok: true, path: url.pathname, method: req.method });
});
