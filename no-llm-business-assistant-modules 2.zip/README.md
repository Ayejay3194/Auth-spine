# No‑LLM Business Assistant Modules (TypeScript)

This is the **actual module suite**, not a placeholder.

What you get:
- Deterministic “agentic” assistant runtime (no LLM)
- NLU: intent detection + entity extraction + slot filling
- Policy engine: permissions, confirmations for sensitive actions, rate limiting
- Tools registry + audited tool execution
- Spines (plugins): booking, CRM, payments/invoicing, marketing (promo/referrals), analytics/export, ops (tasks/checklists), admin, GDPR export, audit log
- Next.js API route templates (App Router)
- Provider interfaces + mock providers so you can run demo immediately

Run locally:
```bash
npm i
npm run build
npm run demo
```

Integrate:
- Copy `src/assistant/**` into your repo
- Implement providers in `src/assistant/providers/real/*`
- Use the route template under `src/next-api-templates/app/api/assistant/message/route.ts`
