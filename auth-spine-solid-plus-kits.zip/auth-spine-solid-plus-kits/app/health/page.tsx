async function getHealth() {
  const res = await fetch(process.env.NEXT_PUBLIC_BASE_URL ? `${process.env.NEXT_PUBLIC_BASE_URL}/api/health` : "http://localhost:3000/api/health", { cache: "no-store" });
  const json = await res.json();
  return { ok: res.ok, status: res.status, json };
}

export default async function Page() {
  const data = await getHealth();
  return (
    <div className="bg-white rounded-2xl shadow-soft p-6 md:p-8 border border-slate-200/60">
      <h1 className="text-3xl font-black text-slate-900">Health Check Demo</h1>
      <p className="mt-2 text-slate-700">This page calls <code className="bg-slate-100 px-1 rounded">/api/health</code>.</p>
      <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-4">
        <div className="font-semibold text-slate-900">HTTP: {data.status} ({data.ok ? "ok" : "not ok"})</div>
        <pre className="mt-2 overflow-x-auto text-sm"><code>{JSON.stringify(data.json, null, 2)}</code></pre>
      </div>
      <p className="mt-4 text-sm text-slate-600">
        For production, replace placeholder checks with real DB/Redis calls and add timeouts.
      </p>
    </div>
  );
}
