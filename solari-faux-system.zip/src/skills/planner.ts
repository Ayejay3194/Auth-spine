import { Skill } from "./base.js";
import { SkillContext, SkillResult } from "../types.js";

export class PlannerSkill implements Skill {
  name = "PlannerSkill";

  async run(ctx: SkillContext): Promise<SkillResult> {
    const recentUser = [...ctx.memory.recent].reverse().find(m => m.role === "user")?.content ?? "";
    const topic = recentUser.length ? recentUser : "your project";
    const steps = [
      "Define the goal in one sentence (no poetry).",
      "List constraints (time, budget, dependencies).",
      "Break into 3 phases: MVP, Hardening, Polish.",
      "Pick one measurable success metric per phase.",
      "Schedule the next concrete action (under 30 minutes)."
    ];
    return { kind: "text", text: `Planning for: ${topic}\n\n` + steps.map((s,i)=>`${i+1}. ${s}`).join("\n"), tags: ["planning"] };
  }
}
