DECISION LOG
============

Decision:
---------
(What was decided)

Context:
--------
(Why this came up)

Alternatives Considered:
------------------------
- Option A
- Option B

Risks Accepted:
---------------
- Risk 1
- Risk 2

Owner:
------
(Name)

Date:
-----

Revisit Date:
-------------
(Optional)

This document exists so future-you doesn’t hate past-you.
