// analytics intents.ts
