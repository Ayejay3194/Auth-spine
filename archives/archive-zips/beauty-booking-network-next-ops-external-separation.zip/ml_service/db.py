import os
import psycopg
import pandas as pd

DATABASE_URL = os.environ.get("DATABASE_URL")
if not DATABASE_URL:
  raise RuntimeError("DATABASE_URL is required")

def fetch_df(sql: str, params=None) -> pd.DataFrame:
  with psycopg.connect(DATABASE_URL) as conn:
    return pd.read_sql(sql, conn, params=params)
