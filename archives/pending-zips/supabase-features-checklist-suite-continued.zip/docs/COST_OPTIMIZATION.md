# Cost Optimization Checklist (Supabase)

- Monitor DB size growth weekly; purge or archive.
- Delete orphaned storage objects (scheduled cleanup).
- Use CDN caching headers for heavy media.
- Batch realtime events; avoid chatty presence updates.
- Keep Edge Functions light: minimal deps, reuse connections.
- Add index only when query requires it; unused indexes cost money.
- Put analytics behind sampling or opt-in when possible.

