import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerMarketReputationTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "market.review.submit",
    title: "Submit review",
    description: "Submits a review for a completed booking.",
    inputSchema: { type: "object", properties: { bookingId: { type: "string" }, rating: { type: "number" }, text: { type: "string" } }, required: ["bookingId","rating"] },
    async run(ctx, input) { return { ok: true, data: await p.marketReputation.submitReview(input) }; }
  });
}
