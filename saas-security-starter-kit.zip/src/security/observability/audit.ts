export type AuditEvent = {
  event: string;
  tenantId?: string;
  actorId?: string;
  requestId?: string;
  at?: string;
  meta?: Record<string, any>;
};

let lastHash = "GENESIS";

function cheapHash(s: string): string {
  // Placeholder: use SHA-256 in production and store in append-only log store.
  let h = 0;
  for (let i=0;i<s.length;i++) h = ((h<<5)-h) + s.charCodeAt(i);
  return `a_${Math.abs(h)}`;
}

/**
 * Tamper-evident audit event. Replace sink with:
 * - append-only DB table
 * - WORM storage
 * - SIEM pipeline
 */
export async function audit(e: AuditEvent) {
  const at = new Date().toISOString();
  const payload = { ...e, at, prev: lastHash };
  const hash = cheapHash(JSON.stringify(payload));
  lastHash = hash;

  // eslint-disable-next-line no-console
  console.log("[AUDIT]", { ...payload, hash });
}
