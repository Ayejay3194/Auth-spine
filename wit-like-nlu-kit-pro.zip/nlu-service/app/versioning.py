import json, time
from pathlib import Path
from typing import Dict, Any, Optional
from .config import settings

MODEL_DIR = Path(settings.model_dir)
MODEL_DIR.mkdir(parents=True, exist_ok=True)
ACTIVE_FILE = MODEL_DIR / "active.json"

def get_active_id() -> Optional[str]:
    if not ACTIVE_FILE.exists():
        return None
    return json.loads(ACTIVE_FILE.read_text(encoding="utf-8")).get("active_id")

def set_active_id(model_id: str) -> None:
    ACTIVE_FILE.write_text(json.dumps({"active_id": model_id}, indent=2), encoding="utf-8")

def new_model_id() -> str:
    return time.strftime("%Y%m%d-%H%M%S")

def model_path(model_id: str) -> Path:
    return MODEL_DIR / model_id

def write_metadata(model_id: str, meta: Dict[str, Any]) -> None:
    mp = model_path(model_id)
    mp.mkdir(parents=True, exist_ok=True)
    (mp / "metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

def read_metadata(model_id: str) -> Dict[str, Any]:
    mp = model_path(model_id)
    return json.loads((mp / "metadata.json").read_text(encoding="utf-8"))

def list_models() -> list[str]:
    return sorted([p.name for p in MODEL_DIR.iterdir() if p.is_dir()], reverse=True)
