# Terraform

To enable OPA policy checks, generate plan JSON:

```bash
cd infra/terraform
terraform init -backend=false
terraform plan -out=tfplan
terraform show -json tfplan > ../../artifacts/terraform-plan.json
```

Then run:

```bash
./scripts/test-policies.sh
```
