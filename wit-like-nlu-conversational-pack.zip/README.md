# Wit-like NLU Kit — Conversational Upgrade Pack

You wanted it to be **conversational**, not “classify intent and stare into space.” This pack adds:
- Dialogue manager (multi-turn, slot-filling, corrections)
- Short-term session memory
- Clarifying questions + confirmations
- Response templates with variation (so it doesn’t sound like a robot with one line)
- Smalltalk + better fallback
- Conversation regression tests (JSONL)

## Run it
```bash
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload --port 8080
```

## Endpoint
POST `/v1/message`
```json
{"session_id":"s1","text":"book me a haircut tomorrow at 3","user_id":"u1"}
```

## Customize
- `backend/app/dialogue/intents.py` slot schemas
- `backend/app/dialogue/policy.py` decision logic + thresholds
- `backend/app/nlg/templates.yaml` tone + copy
- `backend/tests/conversations/*.jsonl` multi-turn regression cases
