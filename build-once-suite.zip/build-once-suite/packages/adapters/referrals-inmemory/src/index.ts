import type { ReferralClick, Referral, ReferralStore } from "@suite/modules-referrals";

export class InMemoryReferralStore implements ReferralStore {
  private codes = new Map<string,string>(); // userId -> code
  private clicks: ReferralClick[] = [];
  private refs: Referral[] = [];

  async createCode(userId: string): Promise<string> {
    const existing = this.codes.get(userId);
    if (existing) return existing;
    const code = "REF" + Math.random().toString(36).slice(2,8).toUpperCase();
    this.codes.set(userId, code);
    this.refs.push({ id:`ref_${Math.random().toString(16).slice(2)}`, code, referrerUserId: userId });
    return code;
  }

  async logClick(c: ReferralClick): Promise<void> { this.clicks.push(c); }

  async attachSignup(newUserId: string, code: string): Promise<Referral | null> {
    const r = this.refs.find(x => x.code === code);
    if (!r) return null;
    r.refereeUserId = newUserId;
    r.convertedAt = new Date().toISOString();
    return r;
  }
}
