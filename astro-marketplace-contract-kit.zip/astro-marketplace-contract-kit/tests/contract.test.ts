import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { canonicalizeChart } from '../src/canonicalize.js';
import { computeChartIntegrity } from '../src/hash.js';
import { validateChartData } from '../src/validate.js';
import { formatChartLikeSolarFire } from '../src/format.js';
import type { ChartDataV1 } from '../src/types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const fixture = JSON.parse(
  fs.readFileSync(path.join(__dirname, '..', 'fixtures', 'sample.chart.v1.json'), 'utf8')
) as ChartDataV1;

test('validate: fixture warns on missing coords but is not error', () => {
  const res = validateChartData(fixture);
  assert.equal(res.ok, true);
  assert.ok(res.issues.some(i => i.code === 'GEO_MISSING'));
});

test('canonicalize: stable output is deterministic', () => {
  const a = canonicalizeChart(fixture);
  const b = canonicalizeChart(JSON.parse(JSON.stringify(fixture)) as ChartDataV1);
  assert.equal(a, b);
});

test('integrity: hash is deterministic and 64 hex chars', () => {
  const r1 = computeChartIntegrity(fixture);
  const r2 = computeChartIntegrity(fixture);
  assert.equal(r1.hashHex, r2.hashHex);
  assert.equal(r1.hashHex.length, 64);
  assert.match(r1.hashHex, /^[0-9a-f]{64}$/);
});

test('format: includes key headers', () => {
  const out = formatChartLikeSolarFire(fixture);
  assert.match(out, /Date of Birth:/);
  assert.match(out, /Universal Time:/);
  assert.match(out, /Local Sidereal Time:/);
  assert.match(out, /House system:/);
  assert.match(out, /Latitude, Longitude:/);
  assert.match(out, /Sun,/);
  assert.match(out, /ASC,/);
  assert.match(out, /MC,/);
});
