Browser & Client-Side Security

- Secure headers
- CSP, HSTS
- CORS restrictions
- Clickjacking prevention
- Script isolation
