import { AuthService, SessionService, StepUpService, ComplianceService, CAPABILITIES } from "@spine/auth-core";
import { MemoryUserStore, MemorySessionStore, MemoryRateLimit, MemoryAudit, MemoryBus, SystemClock, ConsoleEmail } from "@spine/auth-adapter-memory";

async function main() {
  const caps = CAPABILITIES.lite;

  const clock = new SystemClock();
  const bus = new MemoryBus();
  const users = new MemoryUserStore();
  const sessionsStore = new MemorySessionStore();
  const rate = new MemoryRateLimit();
  const audit = new MemoryAudit();
  const email = new ConsoleEmail();

  const sessions = new SessionService(sessionsStore, clock, bus, caps);
  const stepUp = new StepUpService(clock, bus, { windowMinutes: 10 });
  const gdpr = new ComplianceService(clock, bus);
  const auth = new AuthService({ users, rate, email, audit, clock, bus, sessions, caps });

  console.log("\n--- register ---");
  const { userId } = await auth.register("aj@example.com", "pw1234", "aj");
  console.log("userId:", userId);

  console.log("\n--- verify email ---");
  await auth.verifyEmail(userId);

  console.log("\n--- login ---");
  const ctx = await auth.login("aj@example.com", "pw1234", { ip: "1.2.3.4", userAgent: "demo", deviceId: "dev_iphone" });
  console.log("ctx:", ctx);

  console.log("\n--- step-up satisfy ---");
  const ctx2 = await stepUp.satisfy(ctx);
  console.log("stepUpSatisfiedUntil:", ctx2.stepUpSatisfiedUntil);

  console.log("\n--- change email (alerts + revoke sessions) ---");
  await auth.changeEmail(ctx2, "aj+new@example.com");

  console.log("\n--- GDPR export request ---");
  console.log(await gdpr.requestExport(userId));

  console.log("\n--- audit tail ---");
  console.log(await audit.list({ limit: 20 }));

  console.log("\n--- events ---");
  console.log(bus.events);
}
main().catch(e=>{ console.error(e); process.exit(1); });
