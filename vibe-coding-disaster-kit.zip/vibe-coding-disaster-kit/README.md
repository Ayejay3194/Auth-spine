# Vibe Coding Disaster Kit 😇🔥

This pack turns the "things that can go wrong" list into **trackable checklists + templates** you can actually use.

## What's inside
- `checklists/` Trackable markdown checklists (copy into Notion/GitHub issues/Jira)
- `templates/` Registers, runbooks, PR checklists, and definitions
- `snippets/` Drop-in snippets for common guardrails (security headers, auth/session rules)

## How to use (fast)
1. Start with `templates/PR_CHECKLIST.md` and make it required in every PR.
2. Run `templates/PRE_DEPLOY_CHECKLIST.md` before any production deploy.
3. Track risk in `templates/RISK_REGISTER.csv` (owners + due dates or it doesn't exist).
