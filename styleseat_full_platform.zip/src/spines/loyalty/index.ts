// loyalty index.ts
