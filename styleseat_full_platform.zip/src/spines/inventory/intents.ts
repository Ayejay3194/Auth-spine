// inventory intents.ts
