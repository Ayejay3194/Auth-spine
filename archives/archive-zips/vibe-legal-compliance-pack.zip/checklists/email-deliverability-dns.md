# Email Deliverability DNS Checklist

- SPF: include your email provider(s)
- DKIM: enable signing in provider dashboard
- DMARC: start with `p=none`, then `quarantine`, then `reject`
- Dedicated sending domain/subdomain recommended
- Bounce + complaint handling enabled
