import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "UI Troubleshoot Kit",
  description: "Searchable UI troubleshooting + UI authority rules"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/80 backdrop-blur">
          <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
            <Link href="/" className="font-black tracking-tight text-slate-900">
              UI Troubleshoot Kit
            </Link>
            <nav className="flex items-center gap-3 text-sm font-semibold text-slate-700">
              <Link className="hover:text-slate-900" href="/">Toolkit</Link>
              <Link className="hover:text-slate-900" href="/authority">Authority Rules</Link>
              <Link className="hover:text-slate-900" href="/quickfix">Quick Fix Pack</Link>
            </nav>
          </div>
        </header>

        <main className="mx-auto max-w-5xl px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
