# Troubleshooting Suite (TypeScript)

This is a **full troubleshooting suite** you can drop into any TS web repo:
- **auditor CLI** (static checks + optional command execution)
- **local preview + route crawl simulation** (catches refresh/deep-link 404s)
- **client-side "doctor" widget** you can mount in your app to collect browser diagnostics
- **runbooks** (copy-paste playbooks for blank screen, 404s, env failures, SW cache issues, CI-only failures)
- **CI workflows** to run audits on PRs and upload reports as artifacts
- **scripts** for clean installs, environment snapshots, and log collection

## Quick start
1) Copy the `tools/` folder into your repo
2) Run the auditor:
```bash
cd tools/auditor
npm i
npm run build
node dist/cli.js --root ../.. --serve auto --crawl --format md --out ../../audit-report.md
```

3) (Optional) Add the browser doctor widget:
- Copy `tools/browser-doctor/src/doctor.ts` into your app and mount it on an internal `/diagnostics` page.

## Layout
- `tools/auditor/`          - CLI auditor (v0.3 strong)
- `tools/browser-doctor/`   - client diagnostic collector + UI widget
- `tools/runbooks/`         - troubleshooting playbooks
- `tools/ci/`               - GitHub Actions workflows (copy into .github/workflows)
- `tools/scripts/`          - helper scripts (bash + node)

Everything is dependency-light on purpose.
