export type AuthEvent =
  | { type: "auth.user.created"; userId: string; email: string; at: string }
  | { type: "auth.email.verified"; userId: string; at: string }
  | { type: "auth.login.succeeded"; userId: string; sessionId: string; ip?: string; at: string }
  | { type: "auth.login.failed"; email: string; ip?: string; reason: string; at: string }
  | { type: "auth.stepup.satisfied"; userId: string; sessionId: string; until: string; at: string }
  | { type: "auth.password.changed"; userId: string; sessionId: string; at: string }
  | { type: "auth.email.changed"; userId: string; oldEmail: string; newEmail: string; at: string }
  | { type: "auth.session.revoked"; userId: string; sessionId: string; reason: string; at: string }
  | { type: "auth.device.trusted"; userId: string; deviceId: string; at: string }
  | { type: "auth.device.revoked"; userId: string; deviceId: string; at: string }
  | { type: "auth.gdpr.export.requested"; userId: string; exportId: string; at: string }
  | { type: "auth.gdpr.delete.requested"; userId: string; deleteId: string; at: string };

export interface EventBus {
  publish(evt: AuthEvent): Promise<void>;
}
