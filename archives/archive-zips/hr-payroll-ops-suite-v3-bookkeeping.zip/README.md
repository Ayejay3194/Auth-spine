
# HR + Payroll + Ops + Bookkeeping Suite (V3)

Adds a full bookkeeping backbone:
- Chart of Accounts
- Customers/Vendors
- Invoices/Bills + payments
- Bank accounts + transactions
- Double-entry journal posting
- Trial balance + P&L + Balance Sheet (basic)

## Run
1) cp .env.example .env (set DATABASE_URL)
2) npm i
3) npm run db:push && npm run db:generate
4) npm run seed
5) npm run dev

## Demo auth (header)
Send header: x-user-email = admin@demo.com | hr@demo.com | payroll@demo.com | manager@demo.com | employee@demo.com | accountant@demo.com

## Bookkeeping pages
- /books/accounts
- /books/journal
- /books/invoices
- /books/bills
- /books/banking
- /books/reports
