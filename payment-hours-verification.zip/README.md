PAYMENT & HOURS VERIFICATION MODULE
==================================

Purpose:
- Verify worked hours before payroll
- Verify completed services before payouts
- Prevent disputes, overpayments, and fraud

Snaps into:
- Booking spine
- Payroll spine
- Instant payout addon
- Admin/ops spine
