import type { DeviceStore } from "../ports/deviceStore.js";
import type { ClockPort } from "../ports/clockPort.js";
import type { EventBus } from "../model/events.js";

export class DeviceService {
  constructor(private devices: DeviceStore, private clock: ClockPort, private bus: EventBus) {}

  async markSeen(userId: string, deviceId: string, name?: string): Promise<void> {
    const now = this.clock.nowIso();
    await this.devices.upsert({ id: deviceId, userId, name, trusted: false, createdAt: now, lastSeenAt: now } as any);
  }

  async trust(userId: string, deviceId: string, trusted: boolean): Promise<void> {
    await this.devices.trust(userId, deviceId, trusted);
    await this.bus.publish({ type: trusted ? "auth.device.trusted" : "auth.device.revoked", userId, deviceId, at: this.clock.nowIso() } as any);
  }

  async revoke(userId: string, deviceId: string): Promise<void> {
    await this.devices.revoke(userId, deviceId, this.clock.nowIso());
    await this.bus.publish({ type: "auth.device.revoked", userId, deviceId, at: this.clock.nowIso() });
  }
}
