"use client";
import Link from "next/link";

export function SideHub() {
  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-center gap-2">
      <HubBtn href="/map" primary label="Map" />
      <HubBtn href="/inbox" label="Inbox" />
      <HubBtn href="/boards" label="Boards" />
      <HubBtn href="/profile" label="Me" />
    </div>
  );
}

function HubBtn({ href, label, primary }: { href: string; label: string; primary?: boolean }) {
  return (
    <Link
      href={href}
      aria-label={label}
      title={label}
      className={
        "grid h-11 w-11 place-items-center rounded-full border border-white/10 backdrop-blur-md shadow-glass transition hover:-translate-y-0.5 " +
        (primary ? "bg-gradient-to-b from-yellow-200/90 to-yellow-400/60 text-black border-0" : "bg-white/5 text-white")
      }
    >
      <span className="text-xs font-black">{label[0]}</span>
    </Link>
  );
}
