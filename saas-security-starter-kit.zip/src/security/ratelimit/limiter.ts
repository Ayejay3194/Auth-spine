type Key = string;

export type RateLimitResult = {
  allowed: boolean;
  remaining: number;
  resetAt: number; // epoch ms
};

export interface RateLimiter {
  limit(key: Key, max: number, windowMs: number): Promise<RateLimitResult>;
}

/**
 * In-memory limiter for local dev only.
 * Replace with Redis or managed KV for production (distributed).
 */
export class MemoryRateLimiter implements RateLimiter {
  private buckets = new Map<Key, { count: number; resetAt: number }>();

  async limit(key: Key, max: number, windowMs: number): Promise<RateLimitResult> {
    const now = Date.now();
    const b = this.buckets.get(key);
    if (!b || b.resetAt <= now) {
      const resetAt = now + windowMs;
      this.buckets.set(key, { count: 1, resetAt });
      return { allowed: true, remaining: max - 1, resetAt };
    }
    if (b.count >= max) return { allowed: false, remaining: 0, resetAt: b.resetAt };
    b.count += 1;
    return { allowed: true, remaining: max - b.count, resetAt: b.resetAt };
  }
}
