import { describe, it, expect } from "vitest";
import { InMemoryIdempotencyStore } from "../src/security/idempotency/store";
import { withIdempotency } from "../src/security/idempotency/middleware";

describe("Idempotency", () => {
  it("replays completed response for same key", async () => {
    const store = new InMemoryIdempotencyStore();
    let calls = 0;

    const handler = withIdempotency(store, async (_req, _ctx) => {
      calls++;
      return { status: 200, body: { ok: true, calls } };
    });

    const ctx = { tenantId: "t1" } as any;

    const req = { method: "POST", headers: { "idempotency-key": "abc" } };
    const r1 = await handler(req as any, ctx);
    const r2 = await handler(req as any, ctx);

    expect(r1.body.calls).toBe(1);
    expect(r2.body.calls).toBe(1);
    expect(calls).toBe(1);
    expect(r2.headers?.["Idempotency-Replay"]).toBe("true");
  });
});
