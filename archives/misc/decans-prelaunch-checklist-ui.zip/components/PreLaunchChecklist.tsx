"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Check, AlertCircle, ChevronDown, ChevronRight } from "lucide-react";
import { checklistData } from "../data/checklistData";

const STORAGE_KEY = "decans.prelaunchChecklist.v1";

const badgeClass = (priority: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW") => {
  switch (priority) {
    case "CRITICAL":
      return "bg-red-500/20 text-red-300";
    case "HIGH":
      return "bg-orange-500/20 text-orange-300";
    case "MEDIUM":
      return "bg-yellow-500/20 text-yellow-300";
    default:
      return "bg-slate-500/20 text-slate-300";
  }
};

export default function PreLaunchChecklist() {
  const [expandedSections, setExpandedSections] = useState<Record<number, boolean>>({});
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as {
          checkedItems?: Record<string, boolean>;
          expandedSections?: Record<number, boolean>;
        };
        if (parsed.checkedItems) setCheckedItems(parsed.checkedItems);
        if (parsed.expandedSections) setExpandedSections(parsed.expandedSections);
      }
    } catch {
      // ignore
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ checkedItems, expandedSections }));
    } catch {
      // ignore
    }
  }, [checkedItems, expandedSections, loaded]);

  const toggleSection = (idx: number) => {
    setExpandedSections((prev) => ({
      ...prev,
      [idx]: !((prev[idx] ?? true) as boolean),
    }));
  };

  const toggleItem = (itemId: string) => {
    setCheckedItems((prev) => ({
      ...prev,
      [itemId]: !prev[itemId],
    }));
  };

  const stats = useMemo(() => {
    const totalItems = checklistData.reduce((sum, cat) => sum + cat.items.length, 0);
    const checkedCount = Object.values(checkedItems).filter(Boolean).length;

    const criticalItems = checklistData.reduce(
      (sum, cat) => sum + cat.items.filter((i) => i.critical).length,
      0
    );
    const criticalChecked = checklistData.reduce(
      (sum, cat) => sum + cat.items.filter((i) => i.critical && checkedItems[i.id]).length,
      0
    );

    const percentComplete = totalItems ? Math.round((checkedCount / totalItems) * 100) : 0;
    const criticalPercent = criticalItems ? (criticalChecked / criticalItems) * 100 : 0;

    return { totalItems, checkedCount, percentComplete, criticalItems, criticalChecked, criticalPercent };
  }, [checkedItems]);

  const resetAll = () => {
    setCheckedItems({});
    setExpandedSections({});
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="mx-auto max-w-5xl">
        <div className="mb-6 rounded-lg border border-slate-700 bg-slate-800 p-6 shadow-xl">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="mb-2 text-3xl font-bold text-white">🚀 Pre-Launch Checklist</h1>
              <p className="mb-4 text-slate-300">Complete this before shipping to production</p>
            </div>
            <button
              type="button"
              onClick={resetAll}
              className="rounded-md border border-slate-600 bg-slate-900/40 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900/70"
            >
              Reset
            </button>
          </div>

          <div className="space-y-3">
            <div>
              <div className="mb-1 flex justify-between text-sm">
                <span className="text-slate-300">Overall Progress</span>
                <span className="font-semibold text-white">
                  {stats.checkedCount} / {stats.totalItems} ({stats.percentComplete}%)
                </span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-700">
                <div
                  className="h-3 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 transition-all duration-500"
                  style={{ width: `${stats.percentComplete}%` }}
                />
              </div>
            </div>

            <div>
              <div className="mb-1 flex justify-between text-sm">
                <span className="text-red-300">Critical Items</span>
                <span className="font-semibold text-white">
                  {stats.criticalChecked} / {stats.criticalItems}
                </span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-700">
                <div
                  className="h-3 rounded-full bg-gradient-to-r from-red-500 to-orange-500 transition-all duration-500"
                  style={{ width: `${stats.criticalPercent}%` }}
                />
              </div>
            </div>
          </div>

          {stats.criticalChecked < stats.criticalItems && (
            <div className="mt-4 flex items-start gap-2 rounded border border-red-500/30 bg-red-500/10 p-3">
              <AlertCircle className="mt-0.5 flex-shrink-0 text-red-400" size={18} />
              <p className="text-sm text-red-300">
                <strong>Warning:</strong> {stats.criticalItems - stats.criticalChecked} critical items remaining.
                Do NOT launch until these are complete.
              </p>
            </div>
          )}
        </div>

        <div className="space-y-4">
          {checklistData.map((category, idx) => {
            const isExpanded = expandedSections[idx] ?? true;
            const categoryTotal = category.items.length;
            const categoryChecked = category.items.filter((item) => checkedItems[item.id]).length;
            const categoryPercent = categoryTotal ? Math.round((categoryChecked / categoryTotal) * 100) : 0;

            return (
              <div key={category.category} className="overflow-hidden rounded-lg border border-slate-700 bg-slate-800 shadow-lg">
                <button
                  type="button"
                  onClick={() => toggleSection(idx)}
                  className="flex w-full items-center justify-between px-6 py-4 transition-colors hover:bg-slate-700/40"
                >
                  <div className="flex items-center gap-3">
                    {isExpanded ? (
                      <ChevronDown size={20} className="text-slate-400" />
                    ) : (
                      <ChevronRight size={20} className="text-slate-400" />
                    )}
                    <h2 className="text-xl font-semibold text-white">{category.category}</h2>
                    <span className={`rounded px-2 py-1 text-xs ${badgeClass(category.priority)}`}>{category.priority}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-sm text-slate-300">{categoryChecked}/{categoryTotal}</span>
                    <div className="h-2 w-24 rounded-full bg-slate-700">
                      <div className="h-2 rounded-full bg-cyan-500 transition-all duration-300" style={{ width: `${categoryPercent}%` }} />
                    </div>
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-6 pb-4">
                    {category.items.map((item) => (
                      <label key={item.id} className="group flex cursor-pointer items-start gap-3 rounded px-3 py-2 transition-colors hover:bg-slate-700/40">
                        <input
                          type="checkbox"
                          checked={checkedItems[item.id] || false}
                          onChange={() => toggleItem(item.id)}
                          className="mt-1 h-5 w-5 cursor-pointer rounded border-slate-600 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-slate-800"
                        />
                        <div className="flex-1">
                          <span className={checkedItems[item.id] ? "text-slate-500 line-through" : "text-slate-200"}>{item.text}</span>
                          {item.critical && (
                            <span className="ml-2 rounded bg-red-500/20 px-2 py-0.5 text-xs text-red-300">CRITICAL</span>
                          )}
                        </div>
                        {checkedItems[item.id] && <Check size={20} className="mt-0.5 flex-shrink-0 text-green-400" />}
                      </label>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-8 rounded-lg border border-slate-700 bg-slate-800 p-6">
          <h3 className="mb-2 text-lg font-semibold text-white">📋 Next Steps</h3>
          <ul className="space-y-2 text-sm text-slate-300">
            <li>• Complete all <span className="font-semibold text-red-300">CRITICAL</span> items before launch</li>
            <li>• Test in staging first</li>
            <li>• Have a rollback plan ready</li>
            <li>• Monitor errors closely for the first 24–48 hours</li>
            <li>• Keep support channel ready for early users</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
