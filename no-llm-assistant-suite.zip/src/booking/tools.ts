import { Tool } from "../tools/types.js";
import { SessionStore } from "../memory/types.js";
import { BookingProvider } from "./types.js";

export interface SlotCache { slots: Array<{ slotId: string; label: string }>; }

export function bookingTools(opts: {
  provider: BookingProvider;
  slotCache: SessionStore<SlotCache>;
}) {
  const { provider, slotCache } = opts;

  const availabilityFind: Tool<{ service: string; dateISO?: string; partOfDay?: string; durationMin: number }, { slots: Array<{ slotId: string; label: string }> }> = {
    id: "availability.findSlots",
    description: "Find available booking slots",
    validate: (i) => {
      if (!i.service) throw new Error("Missing service");
      if (!i.durationMin || i.durationMin < 15) throw new Error("Bad duration");
    },
    run: async (ctx, input) => {
      const slots = await provider.findAvailableSlots({ ...input, timezone: ctx.timezone });
      const labeled = slots.slice(0, 6).map((s, idx) => ({ slotId: s.slotId, label: `${idx+1}) ${s.startISO} (${s.durationMin}m)` }));
      await slotCache.set(`slots:${ctx.userId}`, { slots: labeled }, 10 * 60);
      return { ok: true, data: { slots: labeled } };
    },
    timeoutMs: 2500,
    retries: 1,
  };

  const bookingCreate: Tool<{ slotChoice: string; service: string; contactMethod: string; notes?: string }, { bookingId: string }> = {
    id: "booking.create",
    description: "Create a booking",
    validate: (i) => {
      const n = Number(i.slotChoice);
      if (!Number.isFinite(n) || n < 1 || n > 6) throw new Error("Pick a slot number 1-6");
      if (!i.service) throw new Error("Missing service");
      if (!["video","phone","chat"].includes(i.contactMethod)) throw new Error("Bad contact method");
    },
    run: async (ctx, input) => {
      const cache = await slotCache.get(`slots:${ctx.userId}`);
      if (!cache) return { ok: false, error: { code: "NO_SLOTS", message: "No slots cached. Ask for availability first." } };
      const idx = Number(input.slotChoice) - 1;
      const slotId = cache.slots[idx]?.slotId;
      if (!slotId) return { ok: false, error: { code: "BAD_SLOT", message: "Invalid slot selection." } };
      const bk = await provider.createBooking({ userId: ctx.userId, slotId, service: input.service, contactMethod: input.contactMethod as any, notes: input.notes });
      return { ok: true, data: { bookingId: bk.bookingId } };
    },
    timeoutMs: 2500,
    retries: 0,
  };

  const bookingReschedule: Tool<{ bookingId: string; slotChoice: string }, { bookingId: string }> = {
    id: "booking.reschedule",
    description: "Reschedule a booking",
    validate: (i) => {
      if (!i.bookingId.startsWith("bk_")) throw new Error("Bad bookingId");
      const n = Number(i.slotChoice);
      if (!Number.isFinite(n) || n < 1 || n > 6) throw new Error("Pick a slot number 1-6");
    },
    run: async (ctx, input) => {
      const cache = await slotCache.get(`slots:${ctx.userId}`);
      if (!cache) return { ok: false, error: { code: "NO_SLOTS", message: "No slots cached. Ask for availability first." } };
      const idx = Number(input.slotChoice) - 1;
      const newSlotId = cache.slots[idx]?.slotId;
      if (!newSlotId) return { ok: false, error: { code: "BAD_SLOT", message: "Invalid slot selection." } };
      const bk = await provider.rescheduleBooking({ userId: ctx.userId, bookingId: input.bookingId, newSlotId });
      return { ok: true, data: { bookingId: bk.bookingId } };
    },
    timeoutMs: 2500,
  };

  const bookingCancel: Tool<{ bookingId: string; reason?: string }, { bookingId: string }> = {
    id: "booking.cancel",
    description: "Cancel a booking",
    validate: (i) => { if (!i.bookingId.startsWith("bk_")) throw new Error("Bad bookingId"); },
    run: async (ctx, input) => {
      const bk = await provider.cancelBooking({ userId: ctx.userId, bookingId: input.bookingId, reason: input.reason });
      return { ok: true, data: { bookingId: bk.bookingId } };
    },
    timeoutMs: 2500,
  };

  const bookingList: Tool<{}, { bookings: any[] }> = {
    id: "booking.list",
    description: "List bookings",
    validate: () => {},
    run: async (ctx) => {
      const list = await provider.listBookings({ userId: ctx.userId });
      return { ok: true, data: { bookings: list } };
    },
    timeoutMs: 2500,
  };

  return [availabilityFind, bookingCreate, bookingReschedule, bookingCancel, bookingList];
}
