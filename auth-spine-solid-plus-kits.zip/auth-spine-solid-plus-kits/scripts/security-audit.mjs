import { execSync } from "node:child_process";

function run(cmd) {
  try {
    execSync(cmd, { stdio: "inherit" });
    return true;
  } catch {
    return false;
  }
}

const ok = run("npm audit --audit-level=high");
process.exit(ok ? 0 : 1);
