export default function SettingsPage(){return <div>Settings placeholder</div>;}
