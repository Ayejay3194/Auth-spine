import type { AgentContext, AssistantState, Reply } from "../core/types.js";
import type { ToolRegistry } from "../tools/registry.js";

export type FlowHandler = (args: {
  ctx: AgentContext;
  text: string;
  state: AssistantState;
  tools: ToolRegistry;
  intentId: string;
  entities: any;
}) => Promise<{ state: AssistantState; reply: Reply }>;

export type Flow = { id: string; handle: FlowHandler };
