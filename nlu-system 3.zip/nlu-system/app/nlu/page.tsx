import NLUSystem from "@/components/NLUSystem";

export default function Page() {
  return <NLUSystem />;
}
