import { ChartDataV1 } from "../contract/schema.js";

console.log("ChartDataV1 (zod) keys:");
console.log(Object.keys((ChartDataV1 as any)._def.shape()).sort().join("\n"));
