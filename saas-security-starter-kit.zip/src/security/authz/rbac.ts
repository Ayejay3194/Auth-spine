export type Permission =
  | "tenant:read"
  | "tenant:admin"
  | "billing:manage"
  | "apiKeys:manage"
  | "audit:read"
  | "support:jit"
  | "data:export"
  | "data:delete";

export const RolePermissions: Record<string, Permission[]> = {
  SUPER_ADMIN: ["tenant:admin","billing:manage","apiKeys:manage","audit:read","support:jit","data:export","data:delete","tenant:read"],
  TENANT_ADMIN: ["tenant:read","billing:manage","apiKeys:manage","audit:read","data:export","data:delete"],
  MEMBER: ["tenant:read","data:export"],
};

export function hasPermission(roles: string[], perm: Permission): boolean {
  return roles.some(r => (RolePermissions[r] ?? []).includes(perm));
}
