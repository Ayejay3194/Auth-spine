# Analytics, i18n, Mobile Checklist

## Analytics
- [ ] Consent-respecting analytics (no PII)
- [ ] Event schemas documented (names, properties)
- [ ] Dedup to avoid double-counting
- [ ] Bot filtering strategy

## i18n
- [ ] No hardcoded strings in UI
- [ ] Dates/numbers/currency localized
- [ ] RTL tested if supported
- [ ] Input validation respects regional formats

## Mobile
- [ ] Core flows tested on iOS Safari + Android Chrome
- [ ] Keyboard overlays don't break forms
- [ ] Safe areas respected
