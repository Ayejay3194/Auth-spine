import fs from "node:fs/promises";
import path from "node:path";
import { Table as ArrowTable, Utf8Vector, Float64Vector, Int32Vector } from "apache-arrow";
import { writeArrowTableToParquet } from "../io/parquetArrow.js";
import { compileTrainingSet } from "../training/compileTrainingSet.js";
import { LakeConfig, datasetBase } from "../io/paths.js";

async function seed(cfg: LakeConfig) {
  const dir = datasetBase(cfg, "de440_residuals", "v3");
  await fs.mkdir(dir, { recursive: true });

  const mk = async (file: string, rows: any[]) => {
    const t = ArrowTable.new({
      ts: Utf8Vector.from(rows.map(r => r.ts)),
      body: Utf8Vector.from(rows.map(r => r.body)),
      dx: Float64Vector.from(rows.map(r => r.dx)),
      dy: Float64Vector.from(rows.map(r => r.dy)),
      model_version: Int32Vector.from(rows.map(r => r.model_version))
    });
    await writeArrowTableToParquet(file, t, { compression: "zstd" });
    return file;
  };

  const f1 = await mk(path.join(dir, "part-0001.parquet"), [
    { ts: "2026-02-27T00:00:00Z", body: "Mercury", dx: 1.36, dy: 0.44, model_version: 3 },
    { ts: "2026-02-27T00:10:00Z", body: "Venus", dx: 0.44, dy: 0.12, model_version: 3 },
  ]);
  const f2 = await mk(path.join(dir, "part-0002.parquet"), [
    { ts: "2026-02-27T00:20:00Z", body: "Mercury", dx: 0.82, dy: 0.21, model_version: 3 },
  ]);
  return [f1, f2];
}

async function run() {
  const cfg = { root: "./lake" };

  const files = await seed(cfg);

  const res = await compileTrainingSet({
    cfg,
    input: { dataset: "de440_residuals", version: "v3", files, schemaVersion: "1" },
    output: { dataset: "training_residuals", version: "v1", schemaVersion: "1" },
    generator: "compileTrainingSet@local",
    compression: "zstd"
  });

  console.log(res);
}

run().catch((e) => { console.error(e); process.exit(1); });
