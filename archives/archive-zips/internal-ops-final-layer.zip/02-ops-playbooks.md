OPS DISASTER PLAYBOOKS
======================

These are not suggestions. These are muscle memory.

1. PAYMENT PROVIDER OUTAGE
--------------------------
Trigger:
- Charge failures spike >5%

Actions:
- Disable new bookings
- Switch to offline/manual mode
- Notify admin + banner users
- Reconcile after provider recovery

Do NOT:
- Retry charges blindly
- Change pricing

2. PAYROLL FAILURE
------------------
Trigger:
- Payroll run fails or mismatches totals

Actions:
- Freeze payroll
- Notify admin immediately
- Switch to manual approval
- Communicate delay to staff

Do NOT:
- Re-run without understanding discrepancy

3. DOUBLE BOOKING INCIDENT
--------------------------
Trigger:
- Two confirmed bookings same slot

Actions:
- Lock affected schedule
- Notify manager
- Offer priority rebooking/refund

Do NOT:
- Auto-cancel silently

4. DATA DISCREPANCY
-------------------
Trigger:
- Revenue != payouts

Actions:
- Freeze reports
- Generate dispute packet
- Notify finance admin

Do NOT:
- “Fix” numbers manually

5. SECURITY BREACH SUSPECTED
----------------------------
Trigger:
- Unusual admin actions

Actions:
- Lock admin writes
- Rotate credentials
- Preserve logs
- Notify security contact

Do NOT:
- Delete logs
