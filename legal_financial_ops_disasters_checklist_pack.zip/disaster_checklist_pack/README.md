# Disaster Checklist Pack

Turns the disaster checklist into machine-readable JSON + JSONL, plus a tiny CLI to track completion.

## Files
- data/disasters_checklist.md
- data/disasters_checklist.json
- data/disasters_checklist.jsonl
- data/progress_template.json
- tools/cli.js
- tools/parse_md.js

## Track completion
cd tools
npm i
npm run completion -- ../data/disasters_checklist.json ../data/progress_template.json

## Mark an item done
npm run set -- ../data/progress_template.json <ITEM_ID> done "fixed"

## Rebuild JSON/JSONL after editing the .md
npm run parse
