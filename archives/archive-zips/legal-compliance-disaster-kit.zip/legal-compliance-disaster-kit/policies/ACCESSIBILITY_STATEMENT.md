# Accessibility Statement (Template)

We aim to meet WCAG 2.1 AA where feasible and prioritize accessibility in new features.
Report issues: [accessibility email] with page URL + description + assistive tech used.

Last updated: [date]
