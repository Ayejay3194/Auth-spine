# Alert Rules Checklist

## Availability
- API 5xx rate > 1% for 5 minutes
- Edge Function error rate > 2% for 5 minutes
- Realtime disconnect spike > baseline + 3σ

## Latency
- API p95 latency > target for 10 minutes
- DB p95 query time > target for 10 minutes
- Edge Function p95 execution > target for 10 minutes

## Saturation
- DB connections > 80% max
- Storage bandwidth > 80% quota
- Realtime connections near cap

## Security
- Failed login bursts (per IP / per account)
- Repeated RLS denies (possible probing)
- Admin actions outside expected hours

## Cost
- Unexpected egress spikes
- Function invocations spike
- Unbounded log growth

