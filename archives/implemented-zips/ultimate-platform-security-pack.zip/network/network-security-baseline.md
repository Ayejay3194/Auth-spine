Network Security Baseline

- Firewalls and WAF active
- Private subnets for internal services
- Zero trust networking
- DDoS protection
- DNS and email security records configured
