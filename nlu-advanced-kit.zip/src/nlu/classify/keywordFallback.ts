import type { NLUModel, IntentMatch } from "../types";
import { tokenize } from "./tokenize";

export function keywordClassify(model: NLUModel, text: string): IntentMatch {
  const lower = text.toLowerCase();
  let best: { name: string; score: number } | null = null;

  const words = new Set(tokenize(lower));

  for (const intent of model.intents) {
    let score = 0;
    for (const ex of intent.examples) {
      const exWords = tokenize(ex.toLowerCase());
      for (const w of exWords) if (words.has(w)) score += 1;
      if (lower === ex.toLowerCase()) score += 10;
    }
    if (!best || score > best.score) best = { name: intent.name, score };
  }

  const confidence = best ? Math.min(1, best.score / 8) : 0;
  return {
    name: best?.name ?? "unknown",
    confidence: best?.score ? confidence : 0,
    method: "keyword",
    reasoning: best ? `keyword score=${best.score}` : "no match",
  };
}
