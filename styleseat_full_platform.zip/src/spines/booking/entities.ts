// booking entities.ts
