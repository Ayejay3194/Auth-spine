Incident Response Playbook

1. Detect and contain
2. Revoke credentials
3. Snapshot systems
4. Notify stakeholders
5. Postmortem with corrective actions
