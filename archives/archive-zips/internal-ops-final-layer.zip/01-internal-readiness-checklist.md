INTERNAL READINESS CHECKLIST
============================

This is the “can we sleep at night?” list.

GREEN = safe to operate
YELLOW = annoying but survivable
RED = do not ship

AUTH & ACCESS
-------------
[ ] All admin actions audited
[ ] Role escalation requires approval
[ ] Emergency admin account exists (offline creds)
[ ] Kill switch tested

MONEY
-----
[ ] Fake-money mode exists
[ ] Refund path tested
[ ] Payout reconciliation tested
[ ] Double-charge prevention tested

PAYROLL
-------
[ ] Dry-run payroll mode works
[ ] Approval required before finalization
[ ] Rollback procedure documented
[ ] Payroll discrepancies alert admin

SCHEDULING
----------
[ ] Double-book protection tested
[ ] Cancellation edge cases tested
[ ] Timezone handling verified
[ ] Capacity limits enforced

DATA
----
[ ] Backups run automatically
[ ] Restore tested
[ ] Export permissions locked
[ ] Data deletion logged

NOTIFICATIONS
-------------
[ ] Alert fatigue thresholds set
[ ] Critical alerts bypass mute
[ ] Admin escalation path works

If all GREEN: ship.
If any RED: stop.
