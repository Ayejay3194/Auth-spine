Architecture Notes
- TenantId everywhere (rows, events, indices)
- Background queue for indexing/campaigns/backups/rollups
- Realtime for notifications + booking updates
- Compliance: DSAR + export + consent
