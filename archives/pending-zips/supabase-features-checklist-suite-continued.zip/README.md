# Supabase Features Checklist Suite (Continued)

This pack extends the earlier "supabase-features-checklist-suite" with **advanced** capabilities:
- Advanced DB administration & performance introspection
- Extended auth/session hardening patterns
- Storage lifecycle, metadata, and signed upload patterns
- Realtime scaling + reliability patterns
- Edge Functions middleware, cron patterns, background jobs scaffolding
- Testing matrix + CI hooks
- Monitoring/observability + alerting scaffolding
- Migration/import/export playbooks
- Multi-region/HA + DR runbook outlines
- Cost optimization checklists
- Compliance/audit trail expansions

## What to do
1. Copy this into your repo root (or into your `/spine/`).
2. Read `docs/IMPLEMENTATION_GUIDE.md` and pick a target slice (DB, Auth, Storage, Realtime, Functions).
3. Track adoption in `catalog/feature_catalog_continued.json`.

## Safety rails for agents
- `ai/AI_GUARDRAILS_PROMPT.md` is meant to be pasted into Cursor/Windsurf/Claude/etc.
- It forces: no deletions, explicit diffs, and per-change synopsis.

