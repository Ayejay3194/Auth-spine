export type TenantId = string & { readonly __brand: "TenantId" };
export type UserId = string & { readonly __brand: "UserId" };

export type TenantContext = {
  tenantId: TenantId;
  userId: UserId;
  roles: string[];
  plan: string;
  region?: string; // data residency / sovereignty
  requestId: string;
};
