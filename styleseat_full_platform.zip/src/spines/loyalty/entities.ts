// loyalty entities.ts
