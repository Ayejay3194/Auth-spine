import { createAssistant } from "./assistant/assistant/assistant.js";
import { IntentDetector } from "./nlu/intents.js";
import { PolicyEngine, InMemoryRateStore } from "./policy/policy.js";
import { loadAllSpines } from "./spines/index.js";
import { makeSlotFillFlow } from "./flows/slotFillFlow.js";
import { makeConfirmFlow } from "./flows/confirmFlow.js";
import type { Providers } from "./providers/types.js";
import type { AuditLogger, Clock } from "./core/types.js";

export function buildRuntime(opts: { providers: Providers; audit: AuditLogger; clock: Clock }) {
  const { tools } = loadAllSpines(opts.providers);

  const detector = new IntentDetector(
    [
      { intent: "booking.list", any: ["bookings", "appointments", "upcoming"], all: [] },
      { intent: "booking.cancel", any: ["cancel"], all: [] },
      { intent: "crm.find_client", any: ["find", "client"], all: [] },
      { intent: "payments.create_invoice", any: ["invoice"], all: [] },
      { intent: "payments.refund", any: ["refund"], all: [] },
      { intent: "marketing.create_promo", any: ["promo", "discount"], all: [] },
      { intent: "analytics.kpi", any: ["kpi", "revenue", "metrics"], all: [] },
      { intent: "ops.list_tasks", any: ["tasks", "todo"], all: [] },
      { intent: "gdpr.export_request", any: ["gdpr", "export"], all: [] },
      { intent: "admin.show_audit", any: ["audit"], all: [] },
    ],
    [
      { intent: "payments.create_invoice", utterance: "create invoice $75 for cl_123" },
      { intent: "marketing.create_promo", utterance: "make promo promo_new10 10%" },
      { intent: "analytics.kpi", utterance: "show revenue this week" },
      { intent: "ops.list_tasks", utterance: "show my tasks" },
      { intent: "booking.cancel", utterance: "cancel bk_123" },
    ],
    { minScore: 0.28 }
  );

  const policy = new PolicyEngine(new InMemoryRateStore(), {
    allow: {
      owner: tools.list().map(t => t.id),
      admin: tools.list().map(t => t.id),
      staff: tools.list().filter(t => !t.id.startsWith("admin.")).map(t => t.id),
      assistant: tools.list().filter(t => !t.id.startsWith("admin.") && !t.id.startsWith("payments.refund")).map(t => t.id),
      accountant: tools.list().filter(t => t.id.startsWith("payments") || t.id.startsWith("analytics") || t.id === "admin.show_audit").map(t => t.id),
    },
    rate: { windowSeconds: 10, max: 60 },
    confirmIntents: [
      "booking.cancel",
      "payments.create_invoice",
      "payments.refund",
      "marketing.send_campaign",
      "analytics.report_export",
      "gdpr.export_request"
    ],
    confirmPhrase: "YES"
  });

  const flows = [makeSlotFillFlow(opts.audit), makeConfirmFlow(opts.audit)];

  const assistant = createAssistant({
    tools,
    policy,
    audit: opts.audit,
    clock: opts.clock,
    detector,
    flows
  });

  return { assistant };
}
