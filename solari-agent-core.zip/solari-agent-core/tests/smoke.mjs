import { classifyIntent } from "../dist/reasoning/intent.js";
import { makePlan } from "../dist/reasoning/planner.js";
import { critiquePlan } from "../dist/reasoning/critic.js";

const intent = classifyIntent("zip this and build it");
const plan = makePlan({ intent: intent.intent, risk: intent.risk });
const crit = critiquePlan(plan);

if (!crit.ok) {
  console.error("Plan critique failed:", crit.issues);
  process.exit(1);
}

console.log("✅ smoke test ok", { intent, planId: plan.id, steps: plan.steps.length });
