export default function AdminPage(){return <div>Admin dashboard placeholder</div>;}
