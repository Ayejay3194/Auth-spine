// Edge Function: cron job scaffold (idempotent)
//
// Use an idempotency key (job_name + date bucket) to avoid duplicate work.
// You can store the key in a table (e.g. cron_runs) with unique constraint.

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

serve(async (req) => {
  if (req.method !== "POST") return new Response("method_not_allowed", { status: 405 });

  const job = new URL(req.url).searchParams.get("job") ?? "unknown";
  const bucket = new Date().toISOString().slice(0, 13); // hourly bucket
  const idempotencyKey = `${job}:${bucket}`;

  // TODO: insert into cron_runs (unique on idempotency_key); if conflict, exit.
  // TODO: perform work
  return new Response(JSON.stringify({ ok: true, job, idempotencyKey }), {
    headers: { "content-type": "application/json" },
  });
});
