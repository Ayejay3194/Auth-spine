\
$ErrorActionPreference = "Stop"

Write-Host "== Preflight: basic repo sanity =="

$fail = $false

function Check($name, $script) {
  Write-Host "-- $name"
  try {
    & $script
    Write-Host "   OK"
  } catch {
    Write-Host "   FAIL"
    $script:fail = $true
  }
}

Check "No .env committed" {
  $files = git ls-files
  if ($files -match "^\.(env)(\.|$)") { throw "env tracked" }
}

Check "No obvious secrets committed (basic regex)" {
  $hits = git grep -nE "(SUPABASE_SERVICE_ROLE_KEY|AWS_SECRET_ACCESS_KEY|BEGIN PRIVATE KEY|sk-[A-Za-z0-9]{20,})" -- . ":!package-lock.json" ":!pnpm-lock.yaml" ":!yarn.lock"
  if ($LASTEXITCODE -eq 0) { throw "possible secret found" }
}

if (Test-Path "package.json") {
  Check "Install deps" { npm ci --silent }
  Check "Lint" { npm run -s lint }
  Check "Typecheck" { npm run -s typecheck }
  Check "Tests" { npm test --silent }
} else {
  Write-Host "No package.json found. Skipping JS checks."
}

if ($fail) {
  Write-Host ""
  Write-Host "Preflight failed. Fix the problems before you ship chaos."
  exit 1
}

Write-Host ""
Write-Host "Preflight passed. You may proceed to disappoint users at scale."
