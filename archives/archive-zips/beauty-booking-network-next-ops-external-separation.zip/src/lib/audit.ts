import { prisma } from "@/lib/prisma";
import type { User } from "@prisma/client";

type AuditInput = {
  actor: Pick<User,"id"|"role"> | null;
  action: string;
  entityType: string;
  entityId: string;
  reason?: string;
  before?: any;
  after?: any;
  ip?: string | null;
  userAgent?: string | null;
};

export async function audit(input: AuditInput) {
  try{
    await prisma.auditLog.create({
      data: {
        at: new Date(),
        actorUserId: input.actor?.id ?? null,
        actorRole: input.actor?.role ?? null,
        action: input.action,
        entityType: input.entityType,
        entityId: input.entityId,
        reason: input.reason ?? null,
        before: input.before ?? undefined,
        after: input.after ?? undefined,
        ip: input.ip ?? null,
        userAgent: input.userAgent ?? null,
      }
    });
  } catch {}
}

export async function piiReadLog(input: {
  actor: Pick<User,"id"|"role"> | null;
  subjectType: string;
  subjectId: string;
  fields: string[];
  purpose?: string;
  ip?: string | null;
  userAgent?: string | null;
}) {
  try{
    await prisma.pIIAccessLog.create({
      data: {
        at: new Date(),
        actorUserId: input.actor?.id ?? null,
        actorRole: input.actor?.role ?? null,
        subjectType: input.subjectType,
        subjectId: input.subjectId,
        fields: input.fields.join(","),
        purpose: input.purpose ?? null,
        ip: input.ip ?? null,
        userAgent: input.userAgent ?? null,
      }
    });
  } catch {}
}
