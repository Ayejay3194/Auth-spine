import { z } from "zod";

const envSchema = z.object({
  JWT_SECRET: z.string().min(32),
  NODE_ENV: z.enum(["development", "production", "test"]).optional(),
  DATABASE_URL: z.string().url().optional(),
  REDIS_URL: z.string().url().optional()
});

try {
  envSchema.parse(process.env);
  console.log("env ok");
  process.exit(0);
} catch (e) {
  console.error("env invalid");
  console.error(e.errors ?? e);
  process.exit(1);
}
