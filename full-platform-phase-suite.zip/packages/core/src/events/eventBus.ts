import type { ID, ISODateTime } from "../shared/types.js";

export type AppEvent = { id: ID; tenantId: ID; type: string; at: ISODateTime; payload: any };

export interface EventSink { emit(ev: AppEvent): Promise<void>; }

export class InMemoryEventSink implements EventSink {
  private events: AppEvent[] = [];
  async emit(ev: AppEvent) { this.events.unshift(ev); }
  list(limit=200) { return this.events.slice(0, limit); }
}
