export const isProd = () => process.env.NODE_ENV === "production";

export const envBool = (v: string | undefined, fallback = false) => {
  if (v == null) return fallback;
  return ["1", "true", "yes", "on"].includes(v.toLowerCase());
};

export const envList = (v: string | undefined) =>
  (v ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

export const safeEqual = (a: string, b: string) => {
  // constant-ish time compare for short secrets
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
};
