# Shipping Gates (Stop-Ship Triggers)

If **any** item below fails, you do **not** deploy.

## Gate A: Auth & Access Control
- [ ] All mutating endpoints require auth (server-side enforced).
- [ ] Authorization checks exist **server-side** for every resource (owner/role).
- [ ] No secrets, tokens, or DB creds exposed to client bundles.
- [ ] Sessions/tokens stored in **httpOnly** cookies (not localStorage).
- [ ] Password reset + email verification tokens **expire** and are **single-use**.
- [ ] Rate limiting exists on login/register/reset and webhook endpoints.
- [ ] RLS enabled + policies exist for every table that stores user data (Supabase).
- [ ] IDOR tests pass (cannot access another user’s resources by swapping IDs).

## Gate B: Data & DB
- [ ] Primary keys, foreign keys, NOT NULL, UNIQUE constraints on critical fields.
- [ ] No money stored as float; use integer cents or numeric.
- [ ] Indexes exist for common filters/sorts; no “index everything” nonsense.
- [ ] Pagination enforced on list endpoints.
- [ ] Migrations reviewed + reversible plan exists.

## Gate C: API & Integrations
- [ ] Input validation on every endpoint (schema-based).
- [ ] Consistent error format + correct HTTP status codes.
- [ ] Webhooks: signature verification + idempotency keys + replay handling.
- [ ] Timeouts + retries with backoff for external calls.

## Gate D: Frontend UX
- [ ] Loading + error states exist on all async screens.
- [ ] No `dangerouslySetInnerHTML` with untrusted content.
- [ ] Forms prevent double submit; destructive actions have confirmation.

## Gate E: Ops
- [ ] Secrets are in env vars; no `.env` committed; secret scanning is on.
- [ ] Monitoring: error tracking + basic metrics + logs searchable.
- [ ] Rollback plan exists; deploy checklist followed.
