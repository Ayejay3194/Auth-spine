import { ForwardRequestSchema, ReverseRequestSchema, DigiGeoPolicySchema } from "./schemas.js";
import type { DigiGeoConfig, DigiGeoResponse, ForwardRequest, ReverseRequest, GeoProvider, GeoResult } from "./types.js";
import { baseReceipt } from "./receipt.js";
import { buildForwardKey, buildReverseKey, safeJsonParse } from "./util.js";
import { createNominatimProvider } from "./providers/nominatim.js";

function providerFromConfig(cfg: DigiGeoConfig["provider"]): GeoProvider {
  if (cfg.kind === "nominatim") return createNominatimProvider(cfg);
  // exhaustive
  // @ts-expect-error
  throw new Error(`Unsupported provider kind: ${cfg.kind}`);
}

function pickBest(results: GeoResult[], minConfidence: number): { best?: GeoResult; outcome: DigiGeoResponse["receipt"]["outcome"] } {
  if (!results.length) return { best: undefined, outcome: "no_match" };
  // Sort by confidence desc, fallback stable
  const sorted = [...results].sort((a,b) => (b.confidence ?? 0) - (a.confidence ?? 0));
  const best = sorted[0];
  const conf = best.confidence ?? 0.5; // unknown treated as middling
  if (conf < minConfidence) return { best: undefined, outcome: "blocked_low_confidence" };
  return { best, outcome: "ok" };
}

export function createDigiGeo(config: DigiGeoConfig) {
  DigiGeoPolicySchema.parse(config.policy);
  const provider = providerFromConfig(config.provider);

  async function forward(req: ForwardRequest): Promise<DigiGeoResponse> {
    const parsed = ForwardRequestSchema.parse(req);
    const key = buildForwardKey(parsed);
    const receipt = baseReceipt("forward", key, provider.name, { minConfidence: config.policy.minConfidence, negativeCacheTtlMs: config.policy.negativeCacheTtlMs });

    // L1
    const l1 = config.cache.l1.get(key);
    if (l1) {
      receipt.cache.hitL1 = true;
      const cached = safeJsonParse<DigiGeoResponse>(l1);
      if (cached) {
        receipt.outcome = "ok";
        receipt.provider.ms = 0;
        receipt.provider.status = 200;
        receipt.notes = ["served_from_l1"];
        return { ...cached, receipt };
      }
    }

    // L2
    if (config.cache.l2) {
      const l2 = await config.cache.l2.get(key);
      if (l2) {
        receipt.cache.hitL2 = true;
        const cached = safeJsonParse<DigiGeoResponse>(l2);
        if (cached) {
          config.cache.l1.set(key, JSON.stringify(cached), 1000 * 60 * 60 * 24 * 7);
          receipt.cache.wroteL1 = true;
          receipt.outcome = "ok";
          receipt.provider.ms = 0;
          receipt.provider.status = 200;
          receipt.notes = ["served_from_l2"];
          return { ...cached, receipt };
        }
      }
    }

    const t0 = Date.now();
    try {
      const resp = await provider.forward(parsed);
      receipt.provider.ms = Date.now() - t0;
      receipt.provider.status = resp.status;
      receipt.provider.url = resp.url;

      const { best, outcome } = pickBest(resp.results, config.policy.minConfidence);
      receipt.outcome = outcome;

      const out: DigiGeoResponse = { best, results: resp.results, receipt };

      // Cache: cache ok + no_match (negative cache) separately
      const ttl = outcome === "no_match" ? config.policy.negativeCacheTtlMs : 1000 * 60 * 60 * 24 * 30;
      const payload = JSON.stringify({ ...out, receipt: undefined as any }); // do not persist receipt
      config.cache.l1.set(key, payload, ttl);
      receipt.cache.wroteL1 = true;
      if (config.cache.l2) {
        await config.cache.l2.set(key, payload, ttl);
        receipt.cache.wroteL2 = true;
      }
      return out;
    } catch (e: any) {
      receipt.provider.ms = Date.now() - t0;
      receipt.outcome = "error";
      receipt.notes = [String(e?.message ?? e)];
      return { best: undefined, results: [], receipt };
    }
  }

  async function reverse(req: ReverseRequest): Promise<DigiGeoResponse> {
    const parsed = ReverseRequestSchema.parse(req);
    const key = buildReverseKey({ lat: parsed.point.lat, lon: parsed.point.lon, locale: parsed.locale });
    const receipt = baseReceipt("reverse", key, provider.name, { minConfidence: config.policy.minConfidence, negativeCacheTtlMs: config.policy.negativeCacheTtlMs });

    const l1 = config.cache.l1.get(key);
    if (l1) {
      receipt.cache.hitL1 = true;
      const cached = safeJsonParse<DigiGeoResponse>(l1);
      if (cached) {
        receipt.outcome = "ok";
        receipt.provider.ms = 0;
        receipt.provider.status = 200;
        receipt.notes = ["served_from_l1"];
        return { ...cached, receipt };
      }
    }

    if (config.cache.l2) {
      const l2 = await config.cache.l2.get(key);
      if (l2) {
        receipt.cache.hitL2 = true;
        const cached = safeJsonParse<DigiGeoResponse>(l2);
        if (cached) {
          config.cache.l1.set(key, JSON.stringify(cached), 1000 * 60 * 60 * 24 * 7);
          receipt.cache.wroteL1 = true;
          receipt.outcome = "ok";
          receipt.provider.ms = 0;
          receipt.provider.status = 200;
          receipt.notes = ["served_from_l2"];
          return { ...cached, receipt };
        }
      }
    }

    const t0 = Date.now();
    try {
      const resp = await provider.reverse(parsed);
      receipt.provider.ms = Date.now() - t0;
      receipt.provider.status = resp.status;
      receipt.provider.url = resp.url;

      const { best, outcome } = pickBest(resp.results, config.policy.minConfidence);
      receipt.outcome = outcome;

      const out: DigiGeoResponse = { best, results: resp.results, receipt };

      const ttl = outcome === "no_match" ? config.policy.negativeCacheTtlMs : 1000 * 60 * 60 * 24 * 30;
      const payload = JSON.stringify({ ...out, receipt: undefined as any });
      config.cache.l1.set(key, payload, ttl);
      receipt.cache.wroteL1 = true;
      if (config.cache.l2) {
        await config.cache.l2.set(key, payload, ttl);
        receipt.cache.wroteL2 = true;
      }
      return out;
    } catch (e: any) {
      receipt.provider.ms = Date.now() - t0;
      receipt.outcome = "error";
      receipt.notes = [String(e?.message ?? e)];
      return { best: undefined, results: [], receipt };
    }
  }

  return { forward, reverse, providerName: provider.name };
}
