All external communications must pass PR approval.
No real-time incident posting. No speculation. No internal timelines.