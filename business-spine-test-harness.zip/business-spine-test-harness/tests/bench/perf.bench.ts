import { describe, test, expect } from "vitest";

const RUN_PERF = process.env.RUN_PERF === "1";

describe("Performance benchmarks (gated)", () => {
  test.skipIf(!RUN_PERF)("intent detection should be fast-ish on this machine", async () => {
    const { createBusinessSpine } = await import("../../dist/index.js");
    const spine = await createBusinessSpine({ tenantId: "perf-tenant" });

    try {
      const ctx = {
        actor: { userId: "test", role: "admin" as const },
        tenantId: "perf-tenant",
        nowISO: new Date().toISOString()
      };

      const detect = spine.getOrchestrator().detect.bind(spine.getOrchestrator());
      const queries = [
        "book appointment for Alex tomorrow at 2pm",
        "find client Sarah Johnson",
        "create invoice for $150",
        "show weekly report",
        "audit system logs"
      ];

      const N = 200;
      const t0 = performance.now();
      for (let i = 0; i < N; i++) detect(queries[i % queries.length], ctx);
      const dt = performance.now() - t0;

      // Invariant: should not be absurdly slow.
      // Use a generous limit because CI runners vary wildly.
      expect(dt).toBeLessThan(4000);
    } finally {
      await spine.shutdown?.();
    }
  });
});