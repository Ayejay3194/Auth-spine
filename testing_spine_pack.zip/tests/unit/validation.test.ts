import { describe, it, expect } from "vitest";
import { z } from "zod";

const BookingCreate = z.object({
  serviceName: z.string().min(1).max(120),
  startAt: z.string().datetime(),
  endAt: z.string().datetime(),
});

describe("zod validation", () => {
  it("rejects missing fields", () => {
    const r = BookingCreate.safeParse({ serviceName: "Cut" });
    expect(r.success).toBe(false);
  });
});
