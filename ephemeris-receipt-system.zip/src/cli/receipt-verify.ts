import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { verifyLedgerEntry, type LedgerEntry } from "../receipt/ledger.js";

function arg(name: string): string | undefined {
  const idx = process.argv.indexOf(name);
  return idx >= 0 ? process.argv[idx + 1] : undefined;
}

const ledgerPath = arg("--ledger") ?? "./receipts/ledger.jsonl";
const secret = process.env.RECEIPT_HMAC_SECRET ?? "dev-secret-change-me";

const raw = readFileSync(resolve(ledgerPath), "utf-8").trim();
if (!raw) {
  console.error("Ledger is empty.");
  process.exit(1);
}

const lines = raw.split("\n").filter(Boolean);
let prev: string | null = null;

for (let i = 0; i < lines.length; i++) {
  const entry = JSON.parse(lines[i]) as LedgerEntry;
  const res = verifyLedgerEntry({ entry, expectedPrevChainHash: prev, secret });
  if (!res.ok) {
    console.error(JSON.stringify({ ok: false, index: i, reason: res.reason }, null, 2));
    process.exit(2);
  }
  prev = entry.chainHash;
}

console.log(JSON.stringify({ ok: true, entries: lines.length, lastChainHash: prev }, null, 2));
