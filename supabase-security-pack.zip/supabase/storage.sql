
-- Private bucket
insert into storage.buckets (id, name, public)
values ('portfolio', 'portfolio', false);

-- Only owner can upload
create policy "stylist uploads"
on storage.objects for insert
with check (
  bucket_id = 'portfolio'
  and auth.uid()::text = owner
);

-- Signed URL read only
create policy "signed reads"
on storage.objects for select
using (bucket_id = 'portfolio');
