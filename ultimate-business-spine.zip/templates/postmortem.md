POSTMORTEM (BLAMELESS)
======================

Incident Title:
Date/Time:
Severity:
Owners:

What happened (timeline):
-

Impact:
- Who was affected?
- How many users?
- Money impact?

Root Cause:
-

Detection:
- How did we find out?
- Why didn’t we see it earlier?

Resolution:
-

Prevention (action items):
- [ ] Short-term fix:
- [ ] Long-term fix:
- [ ] Monitoring/alerts:
- [ ] Process/policy:

Links:
- Logs:
- Dashboards:
- PRs:
