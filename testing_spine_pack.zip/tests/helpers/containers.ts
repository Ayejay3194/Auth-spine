import { GenericContainer, StartedTestContainer, Wait } from "testcontainers";

export type Started = {
  pg: StartedTestContainer;
  redis: StartedTestContainer;
  postgresUrl: string;
  redisUrl: string;
};

export async function startContainers(): Promise<Started> {
  const pg = await new GenericContainer("postgres:16-alpine")
    .withEnvironment({
      POSTGRES_USER: "test",
      POSTGRES_PASSWORD: "test",
      POSTGRES_DB: "testdb",
    })
    .withExposedPorts(5432)
    .withWaitStrategy(Wait.forLogMessage("database system is ready to accept connections"))
    .start();

  const redis = await new GenericContainer("redis:7-alpine")
    .withExposedPorts(6379)
    .withWaitStrategy(Wait.forLogMessage("Ready to accept connections"))
    .start();

  const postgresUrl = `postgresql://test:test@${pg.getHost()}:${pg.getMappedPort(5432)}/testdb?schema=public`;
  const redisUrl = `redis://${redis.getHost()}:${redis.getMappedPort(6379)}`;
  return { pg, redis, postgresUrl, redisUrl };
}

export async function stopContainers(s: Started) {
  await Promise.allSettled([s.pg.stop(), s.redis.stop()]);
}
