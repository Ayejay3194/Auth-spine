import { hmacSha256Hex, sha256Hex, randomNonce, timingSafeEqualHex } from "./crypto";
import { NonceStore } from "./nonce-store";

export type SigningKey = { keyId: string; secret: string };

export type SignOptions = {
  nonce?: string;
  ts?: number; // unix seconds
};

export function canonicalString(input: {
  method: string;
  path: string;
  ts: number;
  nonce: string;
  bodySha256: string;
}): string {
  const method = input.method.toUpperCase();
  const path = input.path; // already canonical
  return [
    method,
    path,
    String(input.ts),
    input.nonce,
    input.bodySha256,
  ].join("\n");
}

export function signRequest(key: SigningKey, req: { method: string; path: string; body?: any }, opts: SignOptions = {}) {
  const ts = opts.ts ?? Math.floor(Date.now()/1000);
  const nonce = opts.nonce ?? randomNonce(16);
  const bodyStr = req.body == null ? "" : (typeof req.body === "string" ? req.body : JSON.stringify(req.body));
  const bodySha256 = sha256Hex(bodyStr);
  const canon = canonicalString({ method: req.method, path: req.path, ts, nonce, bodySha256 });
  const signature = hmacSha256Hex(key.secret, canon);
  return { keyId: key.keyId, ts, nonce, bodySha256, signature };
}

export type VerifyOptions = {
  maxSkewSeconds?: number; // default 120
  nonceTtlSeconds?: number; // default 300
};

/**
 * Verify HMAC signature + replay protection.
 * Fail closed by default.
 */
export async function verifySignedRequest(
  keys: Record<string, SigningKey>,
  nonceStore: NonceStore,
  req: { method: string; path: string; body?: any; keyId: string; ts: number; nonce: string; bodySha256: string; signature: string },
  opts: VerifyOptions = {}
): Promise<{ ok: true } | { ok: false; error: string }> {
  const maxSkew = opts.maxSkewSeconds ?? 120;
  const nonceTtl = opts.nonceTtlSeconds ?? 300;

  const key = keys[req.keyId];
  if (!key) return { ok: false, error: "Unknown keyId" };

  const now = Math.floor(Date.now()/1000);
  if (Math.abs(now - req.ts) > maxSkew) return { ok: false, error: "Timestamp skew too large" };

  const seen = await nonceStore.seen(req.keyId, req.nonce);
  if (seen) return { ok: false, error: "Replay detected (nonce already used)" };

  const bodyStr = req.body == null ? "" : (typeof req.body === "string" ? req.body : JSON.stringify(req.body));
  const bodySha = sha256Hex(bodyStr);
  if (bodySha !== req.bodySha256) return { ok: false, error: "Body hash mismatch" };

  const canon = canonicalString({ method: req.method, path: req.path, ts: req.ts, nonce: req.nonce, bodySha256: req.bodySha256 });
  const expected = hmacSha256Hex(key.secret, canon);
  if (!timingSafeEqualHex(expected, req.signature)) return { ok: false, error: "Bad signature" };

  await nonceStore.mark(req.keyId, req.nonce, nonceTtl);
  return { ok: true };
}
