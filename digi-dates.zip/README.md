# digi-dates

A zero-dependency TypeScript date/time utility module for *boring, correct* handling of:
- strict ISO parsing/formatting
- UTC-first storage
- timezone-safe formatting via `Intl.DateTimeFormat`
- validation helpers for user input
- deterministic “receipt timestamps” (ISO + epoch + optional monotonic counter)

## Install
```bash
npm i
npm run test
```

## Quick use
```ts
import { parseISO, formatISO, formatInTimeZone, makeReceiptTimestamp } from "./dist/index.js";

const d = parseISO("2000-01-01T00:00:00Z");
console.log(formatISO(d)); // 2000-01-01T00:00:00.000Z
console.log(formatInTimeZone(d, "America/New_York"));

console.log(makeReceiptTimestamp(d, 7));
```

## Rules
- Store timestamps as UTC (`Date` or epoch ms).
- Accept user input only via strict parsers (no “new Date(userString)”).
- Format for display with explicit IANA zones.
