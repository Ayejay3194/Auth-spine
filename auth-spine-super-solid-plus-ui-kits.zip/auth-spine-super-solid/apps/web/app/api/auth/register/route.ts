import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { validate, schemas, ValidationError } from '@auth-spine/core'
import { hashPassword, generateToken, setAuthCookie } from '@auth-spine/auth'
import { prisma } from '@/lib/prisma'
import { errorHandler } from '@auth-spine/core'

const registerSchema = z.object({
  email: schemas.email,
  password: schemas.password,
  name: z.string().min(1).max(100).optional(),
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const data = validate(registerSchema, body)

    const existing = await prisma.user.findUnique({ where: { email: data.email } })
    if (existing) throw new ValidationError('Email already in use')

    const user = await prisma.user.create({
      data: {
        email: data.email,
        name: data.name,
        password: await hashPassword(data.password),
      },
      select: { id: true, email: true, name: true, role: true },
    })

    const token = await generateToken({ userId: user.id, email: user.email, role: user.role })

    const res = NextResponse.json({ user }, { status: 201 })
    setAuthCookie(res, token)
    return res
  } catch (e) {
    return errorHandler(e as Error, req)
  }
}
