export type RoleId = string;
export type Permission = string;

export interface AuthContext {
  userId: string;
  sessionId: string;
  orgId?: string;
  roles: RoleId[];
  permissions: Permission[];
  authProfile: "lite" | "standard" | "enterprise";
  stepUpSatisfiedUntil?: string; // ISO timestamp if satisfied
}
