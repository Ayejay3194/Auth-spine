# No‑LLM Assistant Suite (TypeScript)
A full deterministic assistant framework that **does not require any large model**.

This suite is built for:
- booking flows (create/reschedule/cancel/list)
- support workflows (password reset, data export, etc.)
- tool execution with strict governance and audit logs

## What it is
A **state machine assistant**:
- NLU (rules + lightweight similarity classifier)
- entity extraction (regex + date/time parser)
- dialogue manager (slot-filling flows)
- tool router (permissions, validation, timeouts, retries)
- memory/session store interfaces
- policy engine (step-up confirm, allowlists, rate limits)
- observability (audit events, traces-ish spans, error codes)

## Run demo
```bash
corepack enable
corepack prepare pnpm@9.0.0 --activate
pnpm i
pnpm build
pnpm demo:booking
```

## Notes
- No external deps (besides TypeScript).
- Date parsing is pragmatic (today/tomorrow/next Tue/Dec 15/2025-12-15 + time like 3pm / 15:30 / evening).
- Plug your own DB/calendar/email/payment implementations via interfaces.
