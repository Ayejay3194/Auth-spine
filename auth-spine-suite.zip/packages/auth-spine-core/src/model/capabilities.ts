export type AuthProfile = "lite" | "standard" | "enterprise";

export interface AuthCapabilities {
  profile: AuthProfile;
  mfa: boolean;
  passwordless: boolean;
  sso: boolean;
  maxConcurrentSessions: number; // 0 = unlimited
  sessionIdleTimeoutMinutes: number; // 0 = disabled
  sessionAbsoluteTimeoutMinutes: number; // 0 = disabled
  trustedDevices: boolean;
  riskSignals: boolean;
  impossibleTravel: boolean;
  auditRetentionDays: number;
  gdprTools: boolean;
}

export const CAPABILITIES: Record<AuthProfile, AuthCapabilities> = {
  lite: {
    profile: "lite",
    mfa: false,
    passwordless: false,
    sso: false,
    maxConcurrentSessions: 5,
    sessionIdleTimeoutMinutes: 60 * 24 * 7,
    sessionAbsoluteTimeoutMinutes: 60 * 24 * 30,
    trustedDevices: true,
    riskSignals: false,
    impossibleTravel: false,
    auditRetentionDays: 30,
    gdprTools: true,
  },
  standard: {
    profile: "standard",
    mfa: true,
    passwordless: true,
    sso: false,
    maxConcurrentSessions: 10,
    sessionIdleTimeoutMinutes: 60 * 24 * 7,
    sessionAbsoluteTimeoutMinutes: 60 * 24 * 30,
    trustedDevices: true,
    riskSignals: true,
    impossibleTravel: true,
    auditRetentionDays: 180,
    gdprTools: true,
  },
  enterprise: {
    profile: "enterprise",
    mfa: true,
    passwordless: true,
    sso: true,
    maxConcurrentSessions: 0,
    sessionIdleTimeoutMinutes: 60 * 12,
    sessionAbsoluteTimeoutMinutes: 60 * 24 * 14,
    trustedDevices: true,
    riskSignals: true,
    impossibleTravel: true,
    auditRetentionDays: 365,
    gdprTools: true,
  },
};
