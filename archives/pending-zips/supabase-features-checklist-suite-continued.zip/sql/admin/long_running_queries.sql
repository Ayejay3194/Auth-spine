-- Long running queries (tune the interval threshold as needed)
create or replace view admin_long_running_queries as
select *
from admin_active_queries
where state in ('active','idle in transaction')
  and query_age > interval '30 seconds'
order by query_age desc;
