import { computeEnablement } from "@/modules/enablement";

const result = computeEnablement({
  tier: "grow",
  vertical: "beauty_wellness",
  flags: {},
});

console.log(result.enabled);
console.log(result.disabled);
