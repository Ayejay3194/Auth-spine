import React, { useMemo, useState } from "react";

const API = import.meta.env.VITE_SOLARI_API ?? "http://localhost:4399";

type Node = {
  id: string;
  kind: string;
  title: string;
  summary?: string;
  body?: string;
  tags?: string[];
  links?: string[];
  provenance?: any;
};

export function App() {
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("");
  const [results, setResults] = useState<Node[]>([]);
  const [selected, setSelected] = useState<Node | null>(null);
  const [audit, setAudit] = useState<any[]>([]);

  async function search() {
    const url = new URL(API + "/search");
    url.searchParams.set("q", q);
    if (kind.trim()) url.searchParams.set("kind", kind.trim());
    const res = await fetch(url.toString());
    const json = await res.json();
    setResults(json.nodes ?? []);
  }

  async function loadNode(id: string) {
    const res = await fetch(API + "/node/" + encodeURIComponent(id));
    const json = await res.json();
    setSelected(json.node ?? null);
  }

  async function loadAudit() {
    const res = await fetch(API + "/audit");
    const json = await res.json();
    setAudit(json.audit ?? []);
  }

  const kinds = useMemo(() => Array.from(new Set(results.map(r => r.kind))).sort(), [results]);

  return (
    <div style={{ fontFamily: "system-ui", padding: 16, maxWidth: 1100, margin: "0 auto" }}>
      <h1>Solari Admin</h1>
      <p style={{opacity:0.75}}>Search nodes, inspect links, and see audit findings. Yes, it’s boring. That’s the point.</p>

      <div style={{ display: "flex", gap: 8, alignItems:"center" }}>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="search text..." style={{ flex: 1, padding: 10 }} />
        <input value={kind} onChange={e=>setKind(e.target.value)} placeholder="kind (optional) e.g. hd:gate" style={{ width: 260, padding: 10 }} />
        <button onClick={search} style={{ padding: "10px 14px" }}>Search</button>
        <button onClick={loadAudit} style={{ padding: "10px 14px" }}>Audit</button>
      </div>

      {kinds.length ? (
        <div style={{ marginTop: 8, opacity: 0.7, fontSize: 12 }}>
          Kinds in results: {kinds.join(", ")}
        </div>
      ) : null}

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap: 12, marginTop: 16 }}>
        <div>
          <h3>Results</h3>
          <div style={{ border:"1px solid #ddd", borderRadius: 8, overflow:"hidden" }}>
            {results.map(r => (
              <button key={r.id} onClick={()=>loadNode(r.id)} style={{
                display:"block", width:"100%", textAlign:"left",
                padding: 10, border: "none", borderBottom:"1px solid #eee", background:"white", cursor:"pointer"
              }}>
                <div style={{ fontWeight: 600 }}>{r.title}</div>
                <div style={{ fontSize: 12, opacity: 0.7 }}>{r.id} · {r.kind}</div>
                {r.summary ? <div style={{ fontSize: 12, opacity: 0.85, marginTop: 4 }}>{r.summary}</div> : null}
              </button>
            ))}
            {!results.length ? <div style={{ padding: 10, opacity: 0.7 }}>No results.</div> : null}
          </div>
        </div>

        <div>
          <h3>Node</h3>
          <div style={{ border:"1px solid #ddd", borderRadius: 8, padding: 12, minHeight: 240 }}>
            {selected ? (
              <>
                <div style={{ fontSize: 12, opacity: 0.7 }}>{selected.id} · {selected.kind}</div>
                <h2 style={{ margin: "6px 0 8px" }}>{selected.title}</h2>
                {selected.summary ? <p>{selected.summary}</p> : null}
                {selected.body ? <pre style={{ whiteSpace:"pre-wrap", fontFamily:"inherit" }}>{selected.body}</pre> : null}

                {selected.links?.length ? (
                  <>
                    <h4>Links</h4>
                    <ul>
                      {selected.links.map(l => (
                        <li key={l}><button onClick={()=>loadNode(l)}>{l}</button></li>
                      ))}
                    </ul>
                  </>
                ) : null}

                {selected.provenance ? (
                  <>
                    <h4>Provenance</h4>
                    <pre style={{ whiteSpace:"pre-wrap" }}>{JSON.stringify(selected.provenance, null, 2)}</pre>
                  </>
                ) : null}
              </>
            ) : <div style={{ opacity: 0.7 }}>Select a node.</div>}
          </div>

          <h3 style={{ marginTop: 16 }}>Audit Findings</h3>
          <div style={{ border:"1px solid #ddd", borderRadius: 8, padding: 12, maxHeight: 260, overflow:"auto" }}>
            {audit.length ? audit.map((a,i) => (
              <div key={i} style={{ padding: "6px 0", borderBottom:"1px solid #eee" }}>
                <div><b>{a.level}</b> {a.code} {a.nodeId ? `· ${a.nodeId}` : ""}</div>
                <div style={{ fontSize: 12, opacity: 0.8 }}>{a.message}</div>
              </div>
            )) : <div style={{ opacity: 0.7 }}>No audit loaded.</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
