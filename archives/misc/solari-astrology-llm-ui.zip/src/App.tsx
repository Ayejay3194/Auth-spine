import React, { useEffect, useMemo, useState } from 'react'
import { Search, BookOpen, Stars, Upload } from 'lucide-react'

type AstroRecord = {
  id: string
  book: string
  topic?: string
  sign?: string
  house?: number
  text: string
}

const sampleDatabase: AstroRecord[] = [
  {
    id: 'book1_scorpio_sun',
    book: 'The Inner Sky',
    topic: 'sun',
    sign: 'scorpio',
    text:
      'Scorpio Sun individuals possess extraordinary emotional depth and penetrating insight. They see beneath surface appearances instantly and are often aware of hidden motivations others miss. Their intensity can be both magnetic and overwhelming. They form deep bonds but only with those who pass their stringent authenticity tests. Scorpio refuses superficiality and demands truth, even when uncomfortable.'
  },
  {
    id: 'book2_scorpio_traits',
    book: 'Planets in Signs',
    topic: 'sun',
    sign: 'scorpio',
    text:
      "The Scorpio native is fundamentally transformative. They experience life at extremes and are comfortable with the shadowy aspects of existence that others avoid. Control and power dynamics fascinate them. They're loyal to the death but unforgiving of betrayal. Their emotional nature is volcanic - calm surface, molten core. They choose their connections carefully and give affection on their own terms."
  },
  {
    id: 'book3_mars_aries',
    book: 'The Mars Book',
    topic: 'mars',
    sign: 'aries',
    text:
      "Mars in Aries is the warrior incarnate. Direct action, immediate response, no hesitation. These individuals lead with courage and sometimes recklessness. They're competitive, pioneering, and thrive on challenge. Patience is not their virtue. They initiate but may not always follow through. Their anger burns hot and fast, then dissipates."
  },
  {
    id: 'book4_moon_pisces',
    book: 'Moon Signs',
    topic: 'moon',
    sign: 'pisces',
    text:
      'Moon in Pisces absorbs everything. These individuals are emotional sponges, picking up on collective moods and individual pain. Boundaries blur. They need solitude to process what they have absorbed. Creative, compassionate, sometimes escapist. They feel too much and may retreat into fantasy or substances to cope. Their empathy is both gift and burden.'
  },
  {
    id: 'book5_saturn_7th',
    book: 'Houses and Planets',
    topic: 'saturn',
    house: 7,
    text:
      'Saturn in the seventh house creates delays and tests in partnerships. These individuals often marry late or experience significant age differences in relationships. They take commitment seriously, perhaps too seriously. Fear of rejection can lead to choosing unavailable partners or avoiding intimacy altogether. Relationships are where they do their hardest work and greatest growth.'
  }
]

function safeLower(s: string) {
  return s.trim().toLowerCase()
}

function tokenize(q: string) {
  return safeLower(q)
    .replace(/[^a-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
}

function applySolariTone(passages: AstroRecord[], originalQuery: string) {
  if (passages.length === 0) {
    return (
      "okay… i'm not finding anything in the texts about that. " +
      "either you're asking something obscure or you haven't loaded the right books. " +
      'try being more specific (planet + sign, or planet + house).'
    )
  }

  const insights: string[] = []
  passages.forEach((p) => {
    const sentences = p.text
      .split('.')
      .map((s) => s.trim())
      .filter(Boolean)
    insights.push(...sentences)
  })

  let reading = 'okay... '

  const transformed = insights.map((insight) =>
    insight
      .toLowerCase()
      .replace(/these individuals/g, 'you')
      .replace(/they are/g, "you're")
      .replace(/\bthey\b/g, 'you')
      .replace(/\btheir\b/g, 'your')
      .replace(/\bthem\b/g, 'you')
      .replace(/the native/g, 'you')
      .replace(/such people/g, 'you')
  )

  reading += transformed.slice(0, 8).join('. ') + '.'

  const q = safeLower(originalQuery)
  if (q.includes('scorpio')) {
    reading +=
      " the thing about scorpio is you're a mystery wrapped in intensity. " +
      "you're probably not telling me something. you're plotting something or at least thinking about it. " +
      "so yeah. there's something worth interrogating here."
  } else if (q.includes('mars')) {
    reading +=
      " you don't wait for permission and you don't apologize for taking up space. " +
      "that's both your superpower and why some people find you exhausting. " +
      "you already know that and you're not changing."
  } else if (q.includes('moon')) {
    reading +=
      " your emotional world is more complex than you let on. you feel everything but show selective pieces. " +
      "people think they know you. they don't. you've already decided who gets access."
  } else {
    reading +=
      " there's more going on here than surface level. you know it. i know it. " +
      "the question is what you're actually going to do with this information."
  }

  return reading
}

export default function App() {
  const [query, setQuery] = useState('')
  const [response, setResponse] = useState('')
  const [loading, setLoading] = useState(false)
  const [database, setDatabase] = useState<AstroRecord[]>([])
  const [tokensUsed, setTokensUsed] = useState(0)

  useEffect(() => {
    setDatabase(sampleDatabase)
  }, [])

  const dbStats = useMemo(() => {
    const byBook = new Map<string, number>()
    database.forEach((r) => byBook.set(r.book, (byBook.get(r.book) ?? 0) + 1))
    return { count: database.length, books: Array.from(byBook.entries()).sort((a, b) => b[1] - a[1]) }
  }, [database])

  const queryDatabase = (searchQuery: string) => {
    const q = safeLower(searchQuery)
    const keywords = tokenize(searchQuery)

    const results: Array<AstroRecord & { relevance: number }> = []

    database.forEach((record) => {
      let score = 0

      if (record.sign && q.includes(record.sign)) score += 10
      if (record.topic && q.includes(record.topic)) score += 10

      if (typeof record.house === 'number') {
        const h = String(record.house)
        if (
          q.includes(`${h}th`) ||
          q.includes(`${h}st`) ||
          q.includes(`${h}nd`) ||
          q.includes(`${h}rd`) ||
          q.includes(`house ${h}`)
        ) {
          score += 10
        }
      }

      const hay = safeLower(record.text)
      for (const kw of keywords) {
        if (kw.length < 2) continue
        if (hay.includes(kw)) score += 1
      }

      if (score > 0) results.push({ ...record, relevance: score })
    })

    return results.sort((a, b) => b.relevance - a.relevance)
  }

  const handleQuery = async () => {
    if (!query.trim()) return
    setLoading(true)
    setResponse('')

    await new Promise((r) => setTimeout(r, 600))

    const results = queryDatabase(query)
    const reading = applySolariTone(results.slice(0, 3), query)

    const tokens = Math.max(1, Math.floor(reading.split(/\s+/).length * 1.5))
    setTokensUsed(tokens)
    setResponse(reading)
    setLoading(false)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const raw = String(e.target?.result ?? '')
        const lines = raw.split(/\r?\n/)
        const newRecords: AstroRecord[] = []

        for (const line of lines) {
          if (!line.trim()) continue
          const obj = JSON.parse(line)

          const rec: AstroRecord = {
            id: String(obj.id ?? `${file.name}:${newRecords.length}`),
            book: String(obj.book ?? 'Unknown'),
            topic: obj.topic ? String(obj.topic).toLowerCase() : undefined,
            sign: obj.sign ? String(obj.sign).toLowerCase() : undefined,
            house: obj.house != null ? Number(obj.house) : undefined,
            text: String(obj.text ?? '')
          }

          if (!rec.text) continue
          newRecords.push(rec)
        }

        setDatabase((prev) => [...prev, ...newRecords])
        window.alert(`Loaded ${newRecords.length} records from ${file.name}`)
      } catch {
        window.alert('Error parsing JSONL file. Make sure each line is valid JSON.')
      } finally {
        event.target.value = ''
      }
    }
    reader.readAsText(file)
  }

  const examples = ['What does my Scorpio Sun mean?', 'Tell me about Mars in Aries', "What's Moon in Pisces like?", 'Explain Saturn in 7th house']

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Stars className="w-8 h-8 text-purple-400" />
            <h1 className="text-3xl font-bold text-purple-400">Solari</h1>
          </div>
          <p className="text-gray-400">astrology consultation system. no sugarcoating.</p>
          <div className="mt-4 flex items-center gap-2 text-sm text-gray-500">
            <BookOpen className="w-4 h-4" />
            <span>{dbStats.count} records loaded</span>
          </div>

          {dbStats.books.length > 0 && (
            <div className="mt-2 text-xs text-gray-500">
              {dbStats.books.slice(0, 3).map(([b, c]) => (
                <span key={b} className="mr-3">
                  {b}: {c}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="mb-6 p-4 bg-gray-800 rounded-lg border border-gray-700">
          <label className="flex items-center gap-2 cursor-pointer">
            <Upload className="w-5 h-5 text-gray-400" />
            <span className="text-gray-300">Load JSONL book data</span>
            <input type="file" accept=".jsonl,.json" onChange={handleFileUpload} className="hidden" />
          </label>
          <p className="text-xs text-gray-500 mt-2">
            Upload JSONL (one JSON object per line). Fields supported:{' '}
            <span className="text-gray-300">topic</span>, <span className="text-gray-300">sign</span>,{' '}
            <span className="text-gray-300">house</span>, <span className="text-gray-300">text</span>,{' '}
            <span className="text-gray-300">book</span>.
          </p>
        </div>

        <div className="mb-6">
          <div className="flex gap-2">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleQuery()}
              placeholder="What does my Scorpio Sun mean?"
              className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 placeholder-gray-500 focus:outline-none focus:border-purple-500"
            />
            <button
              onClick={handleQuery}
              disabled={loading}
              className="px-6 py-3 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 rounded-lg font-medium flex items-center gap-2 transition-colors"
            >
              <Search className="w-4 h-4" />
              {loading ? 'Processing...' : 'Ask'}
            </button>
          </div>
        </div>

        {response ? (
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="mb-3 flex items-center gap-2 text-purple-400 font-semibold">
              <span>Solari:</span>
            </div>
            <div className="text-gray-200 leading-relaxed whitespace-pre-wrap">{response}</div>
            <div className="mt-4 pt-4 border-t border-gray-700 text-sm text-gray-500">
              Tokens charged: {tokensUsed} | Remaining: {Math.max(0, 2755 - tokensUsed)}
            </div>
          </div>
        ) : (
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h3 className="text-lg font-semibold mb-3 text-purple-400">Try asking:</h3>
            <div className="space-y-2">
              {examples.map((example) => (
                <button
                  key={example}
                  onClick={() => setQuery(example)}
                  className="block w-full text-left px-4 py-2 bg-gray-750 hover:bg-gray-700 rounded text-gray-300 transition-colors"
                >
                  {example}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-8 p-4 bg-gray-800 rounded-lg border border-gray-700">
          <h3 className="text-sm font-semibold mb-2 text-purple-400">How to use:</h3>
          <ol className="text-sm text-gray-400 space-y-1 list-decimal list-inside">
            <li>Upload your astrology books in JSONL format (one JSON object per line).</li>
            <li>Each record should include: topic (sun/moon/mars/etc), sign, house (optional), text, book name.</li>
            <li>Ask questions about placements in natural language.</li>
            <li>Solari pulls relevant passages and delivers them in its signature tone.</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
