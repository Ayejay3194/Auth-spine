import { cryptoRandomId } from "@suite/core-events";

export type AuditActor = { actorType: "user" | "admin" | "system"; userId?: string };

export type AuditEvent = {
  id: string;
  ts: string;
  actor: AuditActor;
  action: string;        // "billing.subscription.updated"
  targetType?: string;   // "user" | "subscription" | ...
  targetId?: string;
  ip?: string;
  userAgent?: string;
  metadata?: Record<string, unknown>;

  // compliance enhancement: hash chaining (optional)
  prevHash?: string;
  hash?: string;
};

export interface AuditStore {
  append(e: Omit<AuditEvent, "id" | "ts" | "hash">): Promise<AuditEvent>;
  query(filter?: Partial<Pick<AuditEvent, "actor" | "action" | "targetType" | "targetId">> & { limit?: number }): Promise<AuditEvent[]>;
}

export interface AuditHasher {
  hash(e: Omit<AuditEvent, "hash">): string;
}

export class Sha256JsonHasher implements AuditHasher {
  hash(e: Omit<AuditEvent, "hash">): string {
    const data = JSON.stringify(e);
    // tiny, dependency-free hash for demo. swap with crypto module in prod.
    let h = 0;
    for (let i = 0; i < data.length; i++) h = (h * 31 + data.charCodeAt(i)) >>> 0;
    return "demo_" + h.toString(16);
  }
}

export class InMemoryAuditStore implements AuditStore {
  private rows: AuditEvent[] = [];
  constructor(private hasher: AuditHasher = new Sha256JsonHasher()) {}

  async append(e: Omit<AuditEvent, "id" | "ts" | "hash">): Promise<AuditEvent> {
    const prev = this.rows.at(-1);
    const full: AuditEvent = {
      ...e,
      id: cryptoRandomId(18),
      ts: new Date().toISOString(),
      prevHash: prev?.hash,
    };
    full.hash = this.hasher.hash(full);
    this.rows.push(full);
    return full;
  }

  async query(filter?: any): Promise<AuditEvent[]> {
    const limit = filter?.limit ?? 200;
    return this.rows.slice(-limit).reverse();
  }
}
