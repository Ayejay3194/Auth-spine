import { describe, it, expect } from "vitest";
import { BASE_URL, EXPECT as EXPECT_CFG } from "../tools/config";

/**
 * Abuse tests: rate limiting is a control, not a suggestion.
 * If your test env doesn't enforce it, keep RATE_LIMIT_EXPECT_429=0.
 */
describe("security: rate limiting (abuse)", () => {
  it("bursty requests eventually get 429 (if enforced)", async () => {
    const url = `${BASE_URL}/api/providers`;
    const N = 200;

    const res = await Promise.all(
      Array.from({ length: N }, async () => fetch(url))
    );

    const statuses = res.map(r => r.status);
    const saw429 = statuses.includes(429);

    if (EXPECT_CFG.rateLimit429) {
      expect(saw429).toBe(true);
    } else {
      // Not enforced in this env: still report for visibility
      expect([true, false]).toContain(saw429);
    }
  });
});
