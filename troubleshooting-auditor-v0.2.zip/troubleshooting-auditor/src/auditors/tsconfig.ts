import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readJson } from "../utils/fs.js";

type TsConfig = { compilerOptions?: Record<string, unknown>; include?: string[]; exclude?: string[]; };

export function auditTsconfig(root: string): AuditSection {
  const section: AuditSection = { id: "tsconfig", title: "TypeScript Config", findings: [] };
  const p = path.join(root, "tsconfig.json");

  if (!exists(p)) {
    section.findings.push({
      id: "tsconfig.missing",
      title: "tsconfig.json missing",
      severity: "ERROR",
      details: "TypeScript tooling/builds become inconsistent without a tsconfig.json.",
      fix: "Add a tsconfig.json (minimal is fine).",
      evidence: { tsconfigPath: p },
    });
    return section;
  }

  let cfg: TsConfig;
  try { cfg = readJson<TsConfig>(p); } catch (e) {
    section.findings.push({
      id: "tsconfig.invalid",
      title: "tsconfig.json is not valid JSON",
      severity: "ERROR",
      details: "Your tsconfig.json failed to parse.",
      fix: "Fix JSON syntax.",
      evidence: { tsconfigPath: p, error: String(e) },
    });
    return section;
  }

  const co = cfg.compilerOptions ?? {};
  const target = String(co["target"] ?? "");
  const module = String(co["module"] ?? "");
  const moduleResolution = String(co["moduleResolution"] ?? "");
  const strict = co["strict"];

  if (!target) section.findings.push({
    id: "tsconfig.target",
    title: "No compilerOptions.target set",
    severity: "WARN",
    details: "Missing target can create inconsistent output depending on defaults/tooling.",
    fix: "Set target to ES2020/ES2022.",
  });

  if (!module) section.findings.push({
    id: "tsconfig.module",
    title: "No compilerOptions.module set",
    severity: "WARN",
    details: "Module output affects runtime imports (ESM vs CJS). Missing module can cause prod-only failures.",
    fix: "Set module to NodeNext/ESNext (ESM) or CommonJS (CJS).",
  });

  if (module && moduleResolution && /node/i.test(module) && !/node/i.test(moduleResolution)) {
    section.findings.push({
      id: "tsconfig.moduleResolution",
      title: "Module and moduleResolution may be mismatched",
      severity: "WARN",
      details: "Mismatches cause 'Cannot use import statement outside a module' and similar runtime errors.",
      fix: "If module is NodeNext/Node16, set moduleResolution to NodeNext/Node16 too.",
      evidence: { module, moduleResolution },
    });
  }

  if (strict !== true) {
    section.findings.push({
      id: "tsconfig.strict",
      title: "TypeScript strict mode is off",
      severity: "INFO",
      details: "Not a failure by itself, but strict catches runtime landmines earlier.",
      fix: "Consider enabling strict and fixing errors gradually.",
      evidence: { strict },
    });
  }

  const exclude = cfg.exclude ?? [];
  const hasBuildExcludes = exclude.some((x) => /dist|build|\.next/i.test(x));
  if (!hasBuildExcludes) section.findings.push({
    id: "tsconfig.exclude.build",
    title: "Build output folders not excluded",
    severity: "INFO",
    details: "Compiling output folders can cause duplicate type errors and slow builds.",
    fix: "Add 'dist', 'build', '.next' to exclude if they exist.",
    evidence: { exclude },
  });

  return section;
}
