import { IdempotencyRecord, ISO8601 } from "../types";

export interface IdempotencyStore {
  get(tenantId: string, key: string): Promise<IdempotencyRecord | null>;
  put(record: IdempotencyRecord): Promise<void>;
  update(record: IdempotencyRecord): Promise<void>;
  delete(tenantId: string, key: string): Promise<void>;
}

export class InMemoryIdempotencyStore implements IdempotencyStore {
  private m = new Map<string, IdempotencyRecord>();
  private k(t: string, key: string) { return `${t}::${key}`; }

  async get(tenantId: string, key: string) {
    const rec = this.m.get(this.k(tenantId, key)) ?? null;
    if (!rec) return null;
    // Expiry check
    if (Date.parse(rec.expiresAtISO) <= Date.now()) {
      this.m.delete(this.k(tenantId, key));
      return null;
    }
    return rec;
  }

  async put(record: IdempotencyRecord) {
    this.m.set(this.k(record.tenantId, record.key), record);
  }

  async update(record: IdempotencyRecord) {
    this.m.set(this.k(record.tenantId, record.key), record);
  }

  async delete(tenantId: string, key: string) {
    this.m.delete(this.k(tenantId, key));
  }
}

export function isoNow(): ISO8601 {
  return new Date().toISOString();
}
