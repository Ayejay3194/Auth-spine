"use client";
import Link from "next/link";
import { Container } from "./Container";
import { useTheme } from "@/theme/ThemeProvider";
import { useSession, signOut } from "next-auth/react";

export function Topbar(){
  const { mode, setMode, resolved } = useTheme();
  const { data } = useSession();
  return (
    <header className="sticky top-0 z-30 border-b backdrop-blur" style={{borderColor:"var(--border)", background:"color-mix(in srgb, var(--bg) 92%, transparent)"}}>
      <Container>
        <div className="flex h-16 items-center justify-between gap-3">
          <Link href="/" className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-xl border" style={{borderColor:"var(--border)", background:"var(--panel)"}}>✦</div>
            <div className="serif text-sm tracking-[.28em] font-semibold">LUXBOOK</div>
          </Link>

          <nav className="hidden md:flex items-center gap-2 text-sm" style={{color:"var(--muted)"}}>
            <Link className="rounded-xl px-3 py-2 border border-transparent hover:border-[var(--border)] hover:bg-[var(--panel2)]" href="/discover">Discover</Link>
            <Link className="rounded-xl px-3 py-2 border border-transparent hover:border-[var(--border)] hover:bg-[var(--panel2)]" href="/salons">Salons</Link>
            <Link className="rounded-xl px-3 py-2 border border-transparent hover:border-[var(--border)] hover:bg-[var(--panel2)]" href="/me/following">My Stylists</Link>
            <Link className="rounded-xl px-3 py-2 border border-transparent hover:border-[var(--border)] hover:bg-[var(--panel2)]" href="/studio">Studio</Link>
            <Link className="rounded-xl px-3 py-2 border border-transparent hover:border-[var(--border)] hover:bg-[var(--panel2)]" href="/salon-admin/luxe-salon">Admin</Link>
            <Link className="rounded-xl px-3 py-2 border border-transparent hover:border-[var(--border)] hover:bg-[var(--panel2)]" href="/admin/patterns">Patterns</Link>
          </nav>

          <div className="flex items-center gap-2">
            <select value={mode} onChange={(e)=>setMode(e.target.value as any)} className="rounded-xl border px-3 py-2 text-sm"
                    style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}} title={`Resolved: ${resolved}`}>
              <option value="system">System</option>
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>

            {data?.user ? (
              <button onClick={()=>signOut({ callbackUrl: "/" })} className="rounded-xl border px-3 py-2 text-sm"
                style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}}>
                Sign out
              </button>
            ) : (
              <Link href="/auth/sign-in" className="rounded-xl border px-3 py-2 text-sm"
                style={{borderColor:"var(--border)", background:"var(--panel)", color:"var(--text)"}}>
                Sign in
              </Link>
            )}
          </div>
        </div>
      </Container>
    </header>
  );
}
