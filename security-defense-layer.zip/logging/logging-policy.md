Logging Rules

- All auth, permission checks, and assistant calls logged
- Logs sanitized (no PII, no tokens)
- Centralized SIEM ingestion
- 90-day hot retention, 1-year cold storage
