import type { NLUModel } from "../types";
import { MODEL_VERSION } from "./schema";

export const defaultModel: NLUModel = {
  version: MODEL_VERSION,
  updatedAt: new Date().toISOString(),
  settings: {
    temperature: 0.3,
    minConfidenceToAct: 0.55,
    minConfidenceToSkipClarify: 0.75,
  },
  intents: [
    {
      name: "greeting",
      description: "User is greeting or saying hello",
      examples: ["hello", "hi", "hey", "good morning", "howdy", "yo", "what's up"],
      confirmationStyle: "auto",
    },
    {
      name: "weather",
      description: "User is asking about weather conditions",
      examples: ["what is the weather", "weather forecast", "will it rain today", "how is the weather in", "is it hot outside"],
      slots: [
        { name: "location", entity: "location", required: false, prompt: "Which city?" },
        { name: "date", entity: "date", required: false, prompt: "For which day?" , validate: "date"},
      ],
      confirmationStyle: "auto",
    },
    {
      name: "book_flight",
      description: "User wants to book or search for flights",
      examples: ["book a flight", "find flights", "flight to", "plane ticket", "get me a ticket to"],
      slots: [
        { name: "from_location", entity: "location", required: true, prompt: "Leaving from which city?" },
        { name: "to_location", entity: "location", required: true, prompt: "Going to which city?" },
        { name: "date", entity: "date", required: false, prompt: "When do you want to travel?" , validate: "date"},
        { name: "trip_type", entity: "trip_type", required: false, prompt: "One-way or round trip?" },
      ],
      confirmationStyle: "ask",
    },
  ],
  entities: [
    {
      name: "location",
      description: "A place, city, country, or geographic location",
      examples: ["new york", "london", "paris", "tokyo", "san francisco", "nyc", "sf", "la"],
      synonyms: { "nyc": "new york", "sf": "san francisco", "sfo": "san francisco", "la": "los angeles" },
      normalizer: "location",
    },
    {
      name: "date",
      description: "A specific date or time reference",
      examples: ["today", "tomorrow", "yesterday", "next week", "monday", "next friday"],
      normalizer: "date",
    },
    {
      name: "trip_type",
      description: "One-way vs round trip",
      examples: ["one way", "one-way", "round trip", "return", "roundtrip"],
      normalizer: "string",
    },
    {
      name: "email",
      description: "Email address",
      examples: ["me@example.com"],
      normalizer: "string",
    },
  ],
};
