import { AgentContext, AgentReply, AuditLogger, Clock, Tracer } from "../core/types.js";
import { Entity } from "../nlu/entities.js";
import { ToolRegistry } from "../tools/types.js";
import { PolicyEngine } from "../policy/types.js";

export type SlotValue = string;

export interface FlowStep {
  ask?: { slot: string; prompt: string; hint?: string };
  call?: { toolId: string; inputFromSlots: (slots: Record<string, SlotValue>) => any; commitIntent?: string; confirmSlot?: string };
  done?: { message: string };
}

export interface FlowDefinition {
  intent: string;
  slots: Array<{ name: string; required: boolean; fromEntity?: (entities: Entity[]) => string | null }>;
  steps: (slots: Record<string, SlotValue>) => FlowStep[];
}

export interface FlowState {
  intent: string;
  stepIndex: number;
  slots: Record<string, SlotValue>;
  completed: boolean;
}

export interface FlowEngineDeps {
  tools: ToolRegistry;
  policy: PolicyEngine;
  audit: AuditLogger;
  clock: Clock;
  tracer: Tracer;
}

export interface FlowEngine {
  start(ctx: AgentContext, def: FlowDefinition, entities: Entity[]): Promise<{ state: FlowState; reply: AgentReply }>;
  continue(ctx: AgentContext, def: FlowDefinition, state: FlowState, userText: string, entities: Entity[]): Promise<{ state: FlowState; reply: AgentReply }>;
}
