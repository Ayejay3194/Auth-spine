#!/usr/bin/env bash
set -euo pipefail
echo "TODO: restore to scratch instance + run smoke checks"
