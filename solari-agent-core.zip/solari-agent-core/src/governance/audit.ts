import { AuditEvent } from "../types";

export class AuditLog {
  private events: AuditEvent[] = [];

  append(e: AuditEvent) {
    this.events.push(e);
  }

  list(): AuditEvent[] {
    return [...this.events];
  }

  exportJsonl(): string {
    return this.events.map(e => JSON.stringify(e)).join("\n") + (this.events.length ? "\n" : "");
  }
}
