Security Governance & Enforcement Layer

This repository turns security requirements into ENFORCED controls.
No control = no deploy.

Key concepts:
- Control Registry (authoritative)
- CI Security Gates
- AI Trust Boundary Enforcement
- Explicit Risk Acceptance

This repo should live alongside (not inside) your app repo.
