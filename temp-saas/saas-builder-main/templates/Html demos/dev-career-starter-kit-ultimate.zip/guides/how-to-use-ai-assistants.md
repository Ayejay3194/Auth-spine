# How to Use AI Assistants

- Ask for explanations, refactors, tests, and plans.
- Do not paste entire repos asking "fix it".
- Keep control: you decide structure and patterns.
