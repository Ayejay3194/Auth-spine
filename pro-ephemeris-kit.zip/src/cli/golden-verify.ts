import path from "node:path";
import fs from "node:fs";
import { runOne } from "./_common.js";

const reqDir = path.resolve("fixtures/requests");
const outDir = path.resolve("fixtures/outputs");

let failed = 0;

for (const file of fs.readdirSync(reqDir).filter(f => f.endsWith(".json"))) {
  const reqPath = path.join(reqDir, file);
  const base = file.replace(/\.json$/,"");

  const expectedJsonPath = path.join(outDir, `${base}.canonical.json`);
  const expectedTxtPath = path.join(outDir, `${base}.amt1.txt`);

  if (!fs.existsSync(expectedJsonPath) || !fs.existsSync(expectedTxtPath)) {
    console.error("Missing expected outputs for", base, "run `npm run golden:run` first");
    failed++;
    continue;
  }

  const expectedJson = fs.readFileSync(expectedJsonPath, "utf8");
  const expectedTxt = fs.readFileSync(expectedTxtPath, "utf8");

  const { chart, text } = await runOne(reqPath);

  const gotJson = JSON.stringify(chart, null, 2) + "\n";
  if (gotJson !== expectedJson) {
    console.error("Mismatch JSON:", base);
    failed++;
  }
  if (text !== expectedTxt) {
    console.error("Mismatch TXT:", base);
    failed++;
  }
}

if (failed) {
  console.error(`golden verify failed: ${failed} case(s)`);
  process.exit(1);
}
console.log("golden verify: ok");
