import { section, ok, fail, readJson, exists, run } from "./_util.mjs";

const cfg = readJson("./infra.config.json");

section("Receipt/ledger verification");
let ran = false;
for(const dir of (cfg.paths.receipts ?? [])){
  if(!exists(dir)) continue;
  // expects a CLI from your receipt system OR you can use the node script below
  if(exists(`${dir}/ledger.jsonl`)){
    ran = true;
    const code = await run("node", ["./scripts/receipt-verify-local.mjs", `${dir}/ledger.jsonl`]);
    if(code!==0) fail(`Receipt ledger verification failed for ${dir}`);
    else ok(`Receipt ledger verified for ${dir}`);
  }
}
if(!ran){
  console.log("No receipts found. Put your ledger at ./receipts/ledger.jsonl (or update infra.config.json).");
}
