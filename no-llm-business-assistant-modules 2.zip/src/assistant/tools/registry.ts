import type { AgentContext, ToolResult, AuditLogger } from "../core/types.js";

export type ToolDef<I = any, O = any> = {
  id: string;
  title: string;
  description: string;
  inputSchema: any; // lightweight, for UI + validation
  run(ctx: AgentContext, input: I): Promise<ToolResult<O>>;
};

export class ToolRegistry {
  private tools = new Map<string, ToolDef>();

  register(def: ToolDef) {
    if (this.tools.has(def.id)) throw new Error(`Duplicate tool id: ${def.id}`);
    this.tools.set(def.id, def);
  }

  get(id: string) {
    return this.tools.get(id);
  }

  list() {
    return Array.from(this.tools.values());
  }
}

export async function runTool(opts: {
  tool: ToolDef;
  ctx: AgentContext;
  input: any;
  audit: AuditLogger;
}): Promise<ToolResult> {
  const { tool, ctx, input, audit } = opts;
  await audit.write({
    at: new Date(),
    businessId: ctx.businessId,
    actorId: ctx.userId,
    role: ctx.role,
    type: "tool.invoke",
    details: { toolId: tool.id, input }
  });

  const res = await tool.run(ctx, input);

  await audit.write({
    at: new Date(),
    businessId: ctx.businessId,
    actorId: ctx.userId,
    role: ctx.role,
    type: "tool.result",
    details: { toolId: tool.id, ok: res.ok, error: res.ok ? null : res.error }
  });

  return res;
}
