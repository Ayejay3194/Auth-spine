Secrets Management Rules

- No secrets in code or repos
- Central secrets manager
- Automatic rotation
- Per-environment separation
- Access logging mandatory
