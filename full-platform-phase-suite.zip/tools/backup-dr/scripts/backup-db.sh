#!/usr/bin/env bash
set -euo pipefail
# TODO: pg_dump + upload
