import { FlowDefinition } from "../flows/types.js";

export const supportFlows: FlowDefinition[] = [
  {
    intent: "auth.forgot_username",
    slots: [{ name: "email", required: true, fromEntity: (e) => e.find(x => x.type === "email")?.value ?? null }],
    steps: () => [
      { ask: { slot: "email", prompt: "Email on the account?", hint: "you@domain.com" } },
      { call: { toolId: "auth.send_forgot_username", inputFromSlots: (s) => ({ email: s.email }) } },
      { done: { message: "Sent. Check your inbox." } },
    ],
  },
  {
    intent: "auth.password_reset_request",
    slots: [{ name: "identifier", required: true, fromEntity: (e) => e.find(x => x.type === "email")?.value ?? e.find(x => x.type === "username")?.value ?? null }],
    steps: () => [
      { ask: { slot: "identifier", prompt: "Email or username?", hint: "you@domain.com" } },
      { call: { toolId: "auth.send_password_reset", inputFromSlots: (s) => ({ identifier: s.identifier }) } },
      { done: { message: "If that account exists, a reset message was sent." } },
    ],
  },
  {
    intent: "gdpr.export_request",
    slots: [],
    steps: () => [
      { call: { toolId: "gdpr.queue_export", inputFromSlots: () => ({}) } },
      { done: { message: "Queued your data export." } },
    ],
  },
  {
    intent: "billing.change_plan",
    slots: [{ name: "plan", required: true, fromEntity: (e) => e.find(x => x.type === "plan")?.value ?? null }, { name: "confirm", required: true }],
    steps: (s) => [
      { ask: { slot: "plan", prompt: "Which plan? (free | paid | pro | starter)", hint: "paid" } },
      { ask: { slot: "confirm", prompt: `Type YES to confirm change to "${s.plan}".`, hint: "YES" } },
      { call: { toolId: "billing.change_plan", commitIntent: "billing.change_plan", confirmSlot: "confirm", inputFromSlots: (x) => ({ plan: x.plan, confirm: x.confirm }) } },
      { done: { message: "Plan updated." } },
    ],
  },
];
