import crypto from "node:crypto";

export function verifyWebhookSignature(secret: string, body: string, ts: string, signature: string) {
  const expected = crypto.createHmac("sha256", secret).update(ts + "." + body).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(signature, "hex");
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}
