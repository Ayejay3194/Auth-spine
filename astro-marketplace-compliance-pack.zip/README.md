# Astro Marketplace Compliance Pack

This pack implements the boring stuff that prevents the fun parts from turning into fines:
- Cookie consent + analytics gating
- Privacy center (export + delete)
- Versioned ToS/Privacy acceptance
- Audit log helper + schema
- PII-redacting logger
- Security headers middleware + basic rate limiting
- Retention cleanup job scaffold
- IR + ROPA templates

## Wire-up (App Router)
- Add `<CookieBanner />` near your root layout.
- Wrap analytics scripts/components in `<AnalyticsGate>`.
- Mount `/privacy` page.
- Merge Prisma additions then migrate.
