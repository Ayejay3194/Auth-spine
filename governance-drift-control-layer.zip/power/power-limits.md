POWER ACCUMULATION LIMITS
=========================

Rules:
- No user can approve + execute + audit the same action
- Elevated access expires automatically
- Permission reviews every 90 days
- Sensitive actions require dual control
