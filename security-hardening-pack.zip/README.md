# Security Hardening Pack

Auth, tenant isolation, secrets, headers, and runtime guards.