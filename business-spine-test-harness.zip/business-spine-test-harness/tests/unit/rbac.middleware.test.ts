import { describe, it, expect, beforeEach, vi } from "vitest";

// These tests assume you're in a Next.js repo with `next/server` available.
// If not, keep the hasPermission unit tests and skip middleware integration.
let NextRequest: any;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  NextRequest = require("next/server").NextRequest;
} catch {
  NextRequest = null;
}

import { hasPermission, Role, rbacMiddleware, withRBAC } from "../../src/rbac/middleware";

// Mock next-auth/jwt
vi.mock("next-auth/jwt", () => ({ getToken: vi.fn() }));
const mockGetToken = async () => (await import("next-auth/jwt")).getToken as any;

// Mock prisma
vi.mock("../../src/lib/prisma", () => ({
  prisma: {
    user: { findUnique: vi.fn() },
    auditLog: { create: vi.fn() }
  }
}));

describe("RBAC", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("hasPermission", () => {
    it("owner can do anything", () => {
      expect(hasPermission(Role.OWNER, "users", "delete")).toBe(true);
    });

    it("admin cannot do owner-only actions", () => {
      expect(hasPermission(Role.ADMIN, "users", "delete")).toBe(false);
    });
  });

  describe("middleware", () => {
    it.skipIf(!NextRequest)("returns 401 when no token", async () => {
      const { getToken } = await import("next-auth/jwt");
      (getToken as any).mockResolvedValue(null);

      const req = new NextRequest("http://localhost/api/test", { method: "GET" });
      const res = await rbacMiddleware(req, { resource: "users", action: "read" });

      expect(res?.status).toBe(401);
    });

    it.skipIf(!NextRequest)("returns 403 when lacking permission and logs", async () => {
      const { getToken } = await import("next-auth/jwt");
      const { prisma } = await import("../../src/lib/prisma");

      (getToken as any).mockResolvedValue({ userId: "user-123" });
      (prisma.user.findUnique as any).mockResolvedValue({ id: "user-123", role: "staff" });

      const req = new NextRequest("http://localhost/api/test", { method: "GET" });
      const res = await rbacMiddleware(req, { resource: "users", action: "delete" });

      expect(res?.status).toBe(403);
      expect(prisma.auditLog.create).toHaveBeenCalled();
    });

    it.skipIf(!NextRequest)("withRBAC passes through when authorized", async () => {
      const { getToken } = await import("next-auth/jwt");
      const { prisma } = await import("../../src/lib/prisma");

      (getToken as any).mockResolvedValue({ userId: "admin-123" });
      (prisma.user.findUnique as any).mockResolvedValue({ id: "admin-123", role: "admin" });

      const handler = vi.fn().mockResolvedValue(new Response(JSON.stringify({ ok: true }), { status: 200 }));
      const wrapped = withRBAC(handler, { resource: "users", action: "read" });

      const req = new NextRequest("http://localhost/api/test", { method: "GET" });
      const res = await wrapped(req);

      expect(handler).toHaveBeenCalled();
      expect(res.status).toBe(200);
    });
  });
});