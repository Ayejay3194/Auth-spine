// ops entities.ts
