export type QuotaName =
  | "api_calls"
  | "storage_bytes"
  | "bandwidth_bytes"
  | "seats"
  | "webhooks"
  | "exports";

export type Quota = { name: QuotaName; limit: number; used: number; resetAt?: number };
