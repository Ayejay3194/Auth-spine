/**
 * Stable stringify with:
 * - sorted object keys
 * - arrays kept in given order (so we must sort key arrays upstream)
 */
export function stableStringify(value: unknown): string {
  return JSON.stringify(value, (_k, v) => {
    if (v && typeof v === "object" && !Array.isArray(v)) {
      const obj = v as Record<string, unknown>;
      const out: Record<string, unknown> = {};
      for (const key of Object.keys(obj).sort()) out[key] = obj[key];
      return out;
    }
    return v;
  });
}
