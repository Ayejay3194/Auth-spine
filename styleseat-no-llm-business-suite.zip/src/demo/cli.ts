import readline from "node:readline";
import crypto from "node:crypto";
import { ConsoleAuditLogger } from "../obs/consoleAudit.js";
import { SimpleTracer } from "../obs/simpleTracer.js";
import { InMemorySessionStore } from "../memory/session.js";
import { SimplePolicyEngine } from "../policy/simplePolicy.js";
import { IntentDetector } from "../nlu/intents.js";
import { createAssistant } from "../assistant/assistant.js";
import { loadAllSpines } from "../spines/index.js";
import { ProviderMock } from "./providerMock.js";

const audit = new ConsoleAuditLogger();
const tracer = new SimpleTracer();
const sessions = new InMemorySessionStore<{ count: number }>();
const slotCache = new InMemorySessionStore<any>();

const provider = new ProviderMock();
const { tools, flows } = loadAllSpines({
  providers: { booking: provider, crm: provider, payments: provider, marketing: provider, analytics: provider, ops: provider, admin: provider },
  slotCache
});

const policy = new SimplePolicyEngine(sessions, {
  allow: {
    owner: tools.list().map(t => t.id),
    staff: tools.list().map(t => t.id),
    assistant: tools.list().map(t => t.id),
    accountant: tools.list().map(t => t.id),
    admin: tools.list().map(t => t.id),
    system: []
  },
  rate: { windowSeconds: 10, max: 60 },
  confirmIntents: ["booking.create","booking.cancel","payments.create_invoice","payments.refund","marketing.create_promo","marketing.send_campaign","analytics.report_export","gdpr.export_request"]
});

const detector = new IntentDetector(
  [
    { intent: "booking.create", any: ["book","schedule","appointment"], all: [] },
    { intent: "booking.cancel", any: ["cancel"], all: [] },
    { intent: "booking.list", any: ["my bookings","upcoming","appointments"], all: [] },
    { intent: "crm.find_client", any: ["find client","look up client","client"], all: [] },
    { intent: "payments.create_invoice", any: ["invoice","bill"], all: [] },
    { intent: "marketing.create_promo", any: ["promo","discount"], all: [] },
    { intent: "analytics.kpi", any: ["kpi","metrics","how did i do","revenue"], all: [] },
    { intent: "analytics.report_export", any: ["export report","download report"], all: [] },
    { intent: "ops.list_tasks", any: ["tasks","to do"], all: [] },
    { intent: "gdpr.export_request", any: ["gdpr","export my data"], all: [] },
    { intent: "admin.show_audit", any: ["audit log","show audit"], all: [] },
  ],
  [
    { intent: "booking.create", utterance: "book me an astrology reading next tuesday evening" },
    { intent: "payments.create_invoice", utterance: "create an invoice for $75 for client cl_1" },
    { intent: "marketing.create_promo", utterance: "make promo promo_new10 for 10 percent off" },
    { intent: "analytics.kpi", utterance: "show my revenue this week" },
    { intent: "ops.list_tasks", utterance: "show my tasks" },
  ],
  { minScore: 0.30 }
);

const assistant = createAssistant({ tools, policy, audit, clock: { now: () => new Date() }, tracer, detector, flows });

const ctx = { userId: "user_" + crypto.randomBytes(3).toString("hex"), role: "owner" as const, businessId: "biz_1", timezone: "America/New_York", channel: "cli" as const };
let state: any = {};

console.log("StyleSeat-like No-LLM Business Assistant (demo).");
console.log("Try: 'book astrology next tuesday evening', 'create invoice $75', 'make promo promo_new10 10', 'show my revenue', 'show my tasks'");
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.setPrompt("> ");
rl.prompt();

rl.on("line", async (line) => {
  const res = await assistant.handle(ctx, state, line);
  state = res.state;

  // Print a little more when availability ran (slots are stored in slotCache)
  if (line.toLowerCase().includes("book") || line.toLowerCase().includes("schedule")) {
    const cache = await slotCache.get(`slots:${ctx.userId}`);
    if (cache?.slots?.length) {
      console.log("Available slots:");
      for (const s of cache.slots) console.log("  " + s.label);
    }
  }

  console.log(res.reply.text);
  rl.prompt();
});
