import type { EmailAdapter } from "@suite/modules-email";

export class ConsoleEmailAdapter implements EmailAdapter {
  async send(msg: { to: string; subject: string; html: string; text: string; headers?: Record<string,string> }): Promise<void> {
    console.log("\n[EMAIL]");
    console.log("To:", msg.to);
    console.log("Subject:", msg.subject);
    if (msg.headers) console.log("Headers:", msg.headers);
    console.log("Text:", msg.text);
    console.log("HTML:", msg.html.slice(0, 300) + (msg.html.length > 300 ? "..." : ""));
  }
}
