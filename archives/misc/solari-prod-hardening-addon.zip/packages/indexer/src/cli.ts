import path from "node:path";
import fs from "node:fs";
import { readJson, ensureDir, listFiles, readLines } from "./fs.js";
import { deriveId } from "./ids.js";
import { validateNodes, auditGraph } from "./audit.js";
import { packToSqlite } from "./sqlite.js";

type Config = {
  dataDir: string;
  outDir: string;
  idRules: { namespace: string; version: string; requireStableIds: boolean; };
  aliasMap?: Record<string,string>;
  requiredCoverage?: any[];
};

function loadConfig(): Config {
  const p = path.resolve(process.cwd(), "solari.config.json");
  return readJson(p);
}

function loadJsonlFiles(dir: string) {
  const files = listFiles(dir, ".jsonl");
  const nodes: any[] = [];
  for (const f of files) {
    for (const line of readLines(f)) {
      try { nodes.push(JSON.parse(line)); }
      catch (e) { nodes.push({ __parseError: String(e), __line: line, __file: f }); }
    }
  }
  return { files, nodes };
}

function applyAliases(nodes: any[], aliasMap: Record<string,string> | undefined) {
  if (!aliasMap) return nodes;
  // aliasMap maps free text -> canonical id; apply to node.aliases for discoverability
  const map = new Map(Object.entries(aliasMap).map(([k,v]) => [k.trim().toLowerCase(), v]));
  for (const n of nodes) {
    if (!n || typeof n !== "object") continue;
    if (Array.isArray(n.aliases)) continue;
    n.aliases = [];
  }
  for (const [alias, id] of map.entries()) {
    const target = nodes.find(n => n?.id === id);
    if (target) {
      target.aliases = Array.from(new Set([...(target.aliases ?? []), alias]));
    }
  }
  return nodes;
}

function stabilizeIds(nodes: any[], version: string) {
  for (const n of nodes) {
    if (!n || typeof n !== "object") continue;
    if (n.__parseError) continue;
    if (!n.id) n.id = deriveId(n.kind ?? "solari:node", n.title ?? "untitled");
    if (!n.version) n.version = version;
    // normalize link arrays
    if (!Array.isArray(n.links)) n.links = [];
    if (!Array.isArray(n.tags)) n.tags = [];
    if (!Array.isArray(n.aliases)) n.aliases = [];
  }
  return nodes;
}

function checkCoverage(nodes: any[], rules: any[] | undefined) {
  const findings: any[] = [];
  if (!rules) return findings;
  const byKind = new Map<string, any[]>();
  for (const n of nodes) byKind.set(n.kind, [...(byKind.get(n.kind) ?? []), n]);

  for (const rule of rules) {
    if (rule.kind && rule.ids) {
      for (const id of rule.ids) {
        if (!nodes.some(n => n.id === id)) {
          findings.push({ level:"error", code:"MISSING_REQUIRED_ID", message:`Missing required node ${id}`, nodeId: id });
        }
      }
    }
    if (rule.kind && rule.minCount) {
      const count = (byKind.get(rule.kind) ?? []).length;
      if (count < rule.minCount) {
        findings.push({ level:"warn", code:"LOW_COVERAGE", message:`Kind ${rule.kind} has ${count}, expected >= ${rule.minCount}`, meta:{ kind: rule.kind, count } });
      }
    }
  }
  return findings;
}

async function main() {
  const cmd = process.argv[2] ?? "help";
  const cfg = loadConfig();
  const dataDir = path.resolve(process.cwd(), cfg.dataDir);
  const outDir = path.resolve(process.cwd(), cfg.outDir);
  ensureDir(outDir);

  if (cmd === "ingest" || cmd === "audit" || cmd === "pack") {
    const { files, nodes: raw } = loadJsonlFiles(dataDir);

    // trap parse errors
    const parseErrors = raw.filter(n => n.__parseError);
    if (parseErrors.length) {
      fs.writeFileSync(path.join(outDir, "parse.errors.json"), JSON.stringify(parseErrors, null, 2));
      console.error(`Parse errors: ${parseErrors.length}. See out/parse.errors.json`);
    }

    const nodes = applyAliases(stabilizeIds(raw.filter(n => !n.__parseError), cfg.idRules.version), cfg.aliasMap);

    const { nodes: valid, findings: valFindings } = validateNodes(nodes, cfg.idRules.version);
    const graphFindings = auditGraph(valid);
    const coverageFindings = checkCoverage(valid, cfg.requiredCoverage);

    const audit = [...valFindings, ...graphFindings, ...coverageFindings];
    fs.writeFileSync(path.join(outDir, "nodes.valid.json"), JSON.stringify(valid, null, 2));
    fs.writeFileSync(path.join(outDir, "audit.report.json"), JSON.stringify(audit, null, 2));
    fs.writeFileSync(path.join(outDir, "ingest.meta.json"), JSON.stringify({ files, count: valid.length }, null, 2));

    if (cmd === "pack") {
      const sqliteFile = path.join(outDir, "index.sqlite");
      packToSqlite(valid, sqliteFile);
      console.log(`Packed SQLite index: ${sqliteFile}`);
    } else {
      console.log(`Ingested ${valid.length} nodes from ${files.length} files.`);
    }
    return;
  }

  console.log("Commands: ingest | audit | pack");
}
main().catch(e => { console.error(e); process.exit(1); });
