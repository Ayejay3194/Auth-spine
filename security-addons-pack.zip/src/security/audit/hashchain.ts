import { sha256Hex } from "../signing/crypto";
import { AuditAction, AuditCheckpoint, AuditEntry, Actor } from "../types";
import { AuditStore } from "./store";

function stableJson(obj: any): string {
  // stable stringify: sort keys recursively
  if (obj === null || typeof obj !== "object") return JSON.stringify(obj);
  if (Array.isArray(obj)) return "[" + obj.map(stableJson).join(",") + "]";
  const keys = Object.keys(obj).sort();
  return "{" + keys.map(k => JSON.stringify(k)+":"+stableJson(obj[k])).join(",") + "}";
}

export function computeEntryHash(input: Omit<AuditEntry, "entryHash">): string {
  const payload = stableJson({
    id: input.id,
    tsISO: input.tsISO,
    tenantId: input.tenantId,
    actor: input.actor ?? null,
    entityType: input.entityType,
    entityId: input.entityId,
    action: input.action,
    summary: input.summary ?? null,
    metadata: input.metadata ?? null,
    prevHash: input.prevHash ?? null,
  });
  return sha256Hex(payload);
}

export function computeCheckpointHash(cp: Omit<AuditCheckpoint, "checkpointHash">): string {
  const payload = stableJson(cp);
  return sha256Hex(payload);
}

export class AuditLogger {
  constructor(private store: AuditStore) {}

  async log(params: {
    tenantId: string;
    actor?: Actor;
    entityType: string;
    entityId: string;
    action: AuditAction;
    summary?: string;
    metadata?: Record<string, any>;
  }): Promise<AuditEntry> {
    const prevHash = await this.store.lastHash(params.tenantId);
    const id = `aud_${Math.random().toString(36).slice(2,10)}`;
    const tsISO = new Date().toISOString();

    const base: Omit<AuditEntry,"entryHash"> = {
      id, tsISO,
      tenantId: params.tenantId,
      actor: params.actor,
      entityType: params.entityType,
      entityId: params.entityId,
      action: params.action,
      summary: params.summary,
      metadata: params.metadata,
      prevHash: prevHash ?? undefined,
    };

    const entryHash = computeEntryHash(base);
    const entry: AuditEntry = { ...base, entryHash };
    await this.store.append(entry);
    return entry;
  }

  async checkpoint(tenantId: string): Promise<AuditCheckpoint> {
    // Create checkpoint from last entry hash (or from last checkpoint if no entries)
    const lastHash = await this.store.lastHash(tenantId);
    const lastCp = await this.store.getLatestCheckpoint(tenantId);
    const lastEntryHash = lastHash ?? lastCp?.lastEntryHash ?? "GENESIS";
    const lastEntryId = "LAST"; // you can store real last entry id in DB impl

    const base: Omit<AuditCheckpoint,"checkpointHash"> = {
      id: `cp_${Math.random().toString(36).slice(2,10)}`,
      tsISO: new Date().toISOString(),
      tenantId,
      lastEntryId,
      lastEntryHash,
    };
    const checkpointHash = computeCheckpointHash(base);
    const cp: AuditCheckpoint = { ...base, checkpointHash };
    await this.store.saveCheckpoint(cp);
    return cp;
  }

  async verifyTenantIntegrity(tenantId: string): Promise<{ ok: boolean; issues: string[] }> {
    // For InMemory store only we don't have full scan API, so this is a stub pattern.
    // In a DB store, you would stream entries ordered by time and verify chain.
    // We still expose the shape so callers can enforce it.
    return { ok: true, issues: [] };
  }
}
