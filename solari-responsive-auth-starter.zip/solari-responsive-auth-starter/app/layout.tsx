import "./globals.css";
import { AuthProvider } from "@/components/auth/AuthProvider";
import { TopNav } from "@/components/nav/TopNav";

export const metadata = {
  title: "Solari Starter",
  description: "Responsive layout + auth/authorization gate starter"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <TopNav />
          <div className="mx-auto max-w-6xl px-4 pb-20 pt-6">{children}</div>
        </AuthProvider>
      </body>
    </html>
  );
}
