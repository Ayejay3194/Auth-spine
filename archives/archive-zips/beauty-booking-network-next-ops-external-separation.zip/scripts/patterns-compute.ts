import { prisma } from "../src/lib/prisma";
import { computeClientFeatures, computeStylistFeatures } from "../src/patterns/featureBuilder";
import { scoreNoShowRisk, scoreDemandIndexForStylist, priceMultiplierFromDemand } from "../src/patterns/scoring";

async function upsertFeatures(entityType: any, entityId: string, features: any){
  await prisma.entityFeatures.upsert({
    where:{ entityType_entityId: { entityType, entityId } },
    update:{ computedAt: new Date(), features },
    create:{ entityType, entityId, computedAt: new Date(), features },
  });
}

async function writeScore(entityType:any, entityId:string, scopeKey:string, scoreType:string, scoreValue:number, metadata:any){
  await prisma.entityScore.create({
    data:{ entityType, entityId, scopeKey, computedAt: new Date(), scoreType, scoreValue, metadata }
  });
}

async function main(){
  const clients = await prisma.user.findMany({ where:{ role:"CLIENT" } });
  for(const c of clients){
    const feats = await computeClientFeatures(c.id);
    await upsertFeatures("USER", c.id, feats);
    const risk = await scoreNoShowRisk(c.id);
    await writeScore("USER", c.id, "GLOBAL", "NO_SHOW_RISK", risk, { v:"heuristic_v1", feats });
  }

  const stylists = await prisma.stylistProfile.findMany();
  for(const s of stylists){
    const feats = await computeStylistFeatures(s.id);
    await upsertFeatures("STYLIST", s.id, feats);
    const demand = await scoreDemandIndexForStylist(s.id);
    await writeScore("STYLIST", s.id, "GLOBAL", "DEMAND_INDEX", demand, { v:"heuristic_v1", feats });
    await writeScore("STYLIST", s.id, "GLOBAL", "PRICE_MULTIPLIER", priceMultiplierFromDemand(demand), { v:"heuristic_v1" });
  }

  console.log("Pattern compute complete.");
}

main().catch((e)=>{ console.error(e); process.exit(1); });
