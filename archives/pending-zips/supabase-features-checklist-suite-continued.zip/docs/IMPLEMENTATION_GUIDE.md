# Implementation Guide (Continued Pack)

## 1) Database Administration (Postgres/Supabase)
- Install/enable recommended extensions where applicable (pg_stat_statements, pg_cron, pg_trgm, pgcrypto, postgis, pgvector).
- Apply the views in `sql/admin/` to get quick introspection:
  - active queries
  - long-running queries
  - bloat indicators (approx)
  - index usage
  - WAL/checkpoint pressure
- Add scheduled maintenance via `pg_cron` (if available) using templates in `sql/admin/cron_jobs.sql`.

## 2) Performance Guardrails
- Use `sql/perf/index_recommendations.md` as an index playbook.
- Add query plan snapshots for critical endpoints (see `testing/query_plan_snapshots.md`).

## 3) Edge Functions Middleware + Cron + Jobs
- `functions/middleware/` provides small composable pieces:
  - auth (JWT/role)
  - rate limit stub (KV/Redis placeholder)
  - validation (zod-style placeholder)
  - tracing (request id + timing)
- `functions/cron/` shows how to structure scheduled jobs.
- `functions/jobs/` provides a minimal queue interface (you can swap in your provider).

## 4) Realtime Reliability
- `realtime/patterns.md` contains: dedupe keys, ack flows, backoff, message ordering notes.

## 5) Monitoring/Alerting
- `observability/` includes:
  - event taxonomy
  - log fields
  - alert rules checklist
  - Sentry wiring notes (framework-agnostic)

## 6) Compliance/Audit
- `sql/audit/` extends audit logging with:
  - admin actions
  - auth events
  - config changes
  - tamper-evident hash chaining (optional)

## 7) Testing Matrix
- `testing/TEST_MATRIX.md` tells you what to test, when, and how to keep it cheap.

