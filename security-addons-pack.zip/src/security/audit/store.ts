import { AuditCheckpoint, AuditEntry } from "../types";

export interface AuditStore {
  append(entry: AuditEntry): Promise<void>;
  list(tenantId: string, entityType: string, entityId: string, limit?: number): Promise<AuditEntry[]>;
  lastHash(tenantId: string): Promise<string | null>;
  saveCheckpoint(cp: AuditCheckpoint): Promise<void>;
  getLatestCheckpoint(tenantId: string): Promise<AuditCheckpoint | null>;
}

export class InMemoryAuditStore implements AuditStore {
  private entries: AuditEntry[] = [];
  private checkpoints: AuditCheckpoint[] = [];

  async append(entry: AuditEntry) { this.entries.push(entry); }
  async list(tenantId: string, entityType: string, entityId: string, limit = 100) {
    return this.entries.filter(e => e.tenantId===tenantId && e.entityType===entityType && e.entityId===entityId).slice(-limit);
  }
  async lastHash(tenantId: string) {
    const last = [...this.entries].reverse().find(e => e.tenantId===tenantId);
    return last?.entryHash ?? null;
  }
  async saveCheckpoint(cp: AuditCheckpoint) { this.checkpoints.push(cp); }
  async getLatestCheckpoint(tenantId: string) {
    const last = [...this.checkpoints].reverse().find(c => c.tenantId===tenantId);
    return last ?? null;
  }
}
