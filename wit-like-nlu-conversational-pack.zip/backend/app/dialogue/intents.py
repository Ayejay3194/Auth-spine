INTENT_SLOTS = {
  "book_appointment": {"required": ["service", "date", "time"], "optional": ["stylist"]},
  "cancel_appointment": {"required": ["appointment_id"], "optional": []},
  "price_quote": {"required": ["service"], "optional": []},
  "hours": {"required": [], "optional": []},
}

# Put destructive/high-impact intents here if you want a yes/no confirmation step.
CONFIRM_INTENTS = set([])
