import type { ChartContract } from "./types.js";
import { sortPointsInPlace } from "./order.js";
import { fmtLonSign } from "./format.js";
import { computeIntegrity } from "./canonical.js";

function upper(s: string): string {
  return s.toUpperCase();
}

export function toCanonicalText(chart: ChartContract): string {
  const c: ChartContract = structuredClone(chart);
  sortPointsInPlace(c);
  const integ = computeIntegrity(c);

  const lines: string[] = [];
  lines.push(`SCHEMA: ${c.schema_version}`);
  lines.push(
    `ENGINE: ${c.engine.name}@${c.engine.version} (${c.engine.ephemeris}) HOUSE=${upper(c.engine.house_system)} ZODIAC=${upper(c.engine.zodiac)}`
  );
  lines.push("");
  lines.push(`DOB: ${c.input.dob_display} (${c.input.timezone_display})`);
  lines.push(`UTC: ${c.input.utc_datetime}`);
  if (c.derived?.local_sidereal_time?.hms) lines.push(`LST: ${c.derived.local_sidereal_time.hms}`);
  lines.push("");

  const geoLabel = c.input.geo?.label ? ` label="${c.input.geo.label}"` : "";
  if (c.input.geo?.is_missing) {
    lines.push(`GEO: MISSING (lat=${c.input.lat.toFixed(6)} lon=${c.input.lon.toFixed(6)}${geoLabel})`);
  } else {
    lines.push(`GEO: OK (lat=${c.input.lat.toFixed(6)} lon=${c.input.lon.toFixed(6)} source=${c.input.geo.source}${geoLabel})`);
  }

  lines.push("");
  lines.push("POINTS:");
  for (const b of c.points.bodies) {
    const lonFmt = b.lon_fmt ?? fmtLonSign(b.lon);
    const r = b.retrograde ? 1 : 0;
    lines.push(`${upper(b.key)}: ${upper(lonFmt)}  lon=${b.lon.toFixed(6)}  R=${r}`);
  }

  lines.push("");
  lines.push("HOUSES:");
  for (const h of c.points.houses) {
    const lonFmt = h.lon_fmt ?? fmtLonSign(h.lon);
    lines.push(`${upper(h.key)}: ${upper(lonFmt)}  lon=${h.lon.toFixed(6)}`);
  }

  lines.push("");
  lines.push("INTEGRITY:");
  lines.push(`CANONICAL: ${integ.canonicalization}`);
  lines.push(`SHA256: ${integ.hash_sha256}`);

  return lines.join("\n");
}
