import { Tool, ToolRegistry } from "./types.js";

export class InMemoryToolRegistry implements ToolRegistry {
  private tools = new Map<string, Tool<any, any>>();
  register<TI, TO>(tool: Tool<TI, TO>) { this.tools.set(tool.id, tool); return this; }
  get(id: string) {
    const t = this.tools.get(id);
    if (!t) throw new Error(`Tool not found: ${id}`);
    return t;
  }
}
