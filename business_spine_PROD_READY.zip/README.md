# StyleSeat-Level Platform


## PLUS Pack
- Waitlist + matching + gapfill slots
- Staff + commissions (rules + ledger)
- Loyalty points + tiers
- Referrals + gift cards
- MessageLog queue + basic delivery worker stubs
- Dash pages under /dashboard


## Production Hardening Pack
- JWT auth + middleware
- Redis cache + rate limiting
- BullMQ queues + worker
- Prometheus metrics + /api/metrics
- OpenAPI JSON + /api/openapi.json
- Sentry stubs
- docker-compose (Postgres + Redis)
- backup script
- unit test scaffolding (vitest)
