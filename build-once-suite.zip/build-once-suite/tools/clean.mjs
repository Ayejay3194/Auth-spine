import fs from "node:fs";
import path from "node:path";

const rm = (p) => fs.existsSync(p) && fs.rmSync(p, { recursive: true, force: true });

const roots = ["packages", "apps"];
for (const r of roots) {
  const base = path.join(process.cwd(), r);
  if (!fs.existsSync(base)) continue;
  for (const name of fs.readdirSync(base)) {
    const dist = path.join(base, name, "dist");
    rm(dist);
  }
}
console.log("Cleaned dist folders.");
