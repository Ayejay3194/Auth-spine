export function generateICS(event: { uid: string; startISO: string; endISO: string; summary: string }) {
  const fmt = (iso: string) => iso.replace(/[-:]/g, "").replace(".000Z", "Z");
  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//BusinessSpine//EN",
    "BEGIN:VEVENT",
    `UID:${event.uid}`,
    `DTSTART:${fmt(event.startISO)}`,
    `DTEND:${fmt(event.endISO)}`,
    `SUMMARY:${event.summary}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
}
