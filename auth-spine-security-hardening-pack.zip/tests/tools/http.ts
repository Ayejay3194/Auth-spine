export type HttpResult = {
  ok: boolean;
  status: number;
  json: any;
  text: string;
  headers: Headers;
};

type HttpOpts = {
  headers?: Record<string, string>;
  body?: any;
  timeoutMs?: number;
};

export async function http(method: string, url: string, opts: HttpOpts = {}): Promise<HttpResult> {
  const controller = new AbortController();
  const timeoutMs = opts.timeoutMs ?? 20_000;
  const t = setTimeout(() => controller.abort(), timeoutMs);

  const headers = new Headers(opts.headers || {});
  let body: any = undefined;

  if (opts.body !== undefined) {
    if (!headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    body = headers.get("Content-Type")?.includes("application/json")
      ? JSON.stringify(opts.body)
      : opts.body;
  }

  try {
    const res = await fetch(url, { method, headers, body, signal: controller.signal });
    const text = await res.text();
    let json: any = {};
    try { json = text ? JSON.parse(text) : {}; } catch { json = {}; }
    return { ok: res.ok, status: res.status, json, text, headers: res.headers };
  } finally {
    clearTimeout(t);
  }
}
