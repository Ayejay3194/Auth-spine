export class PaymentsService {
  async createDepositLink(_input: { artistId: string; clientId: string; amountCents: number }): Promise<string> {
    return "https://example.com/deposit (stub)";
  }

  async handleStripeEvent(_event: unknown): Promise<void> {}

  async chargeNoShowFee(_bookingId: string): Promise<void> {}
}
