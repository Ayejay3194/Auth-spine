export function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}
export function safeJson(x: unknown) {
  try { return JSON.stringify(x); } catch { return ""<unserializable>""; }
}
