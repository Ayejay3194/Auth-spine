import fetch from "node-fetch";
import fs from "fs";
import path from "path";

const runtimeUrl = process.env.RUNTIME_URL || "http://localhost:7777/generate";
const modelBaseUrl = process.env.MODEL_BASE_URL || "http://localhost:8080";
const apiKey = process.env.API_KEY || undefined;

const goldens = JSON.parse(fs.readFileSync(new URL("./golden_prompts.json", import.meta.url)));

const resultsDir = new URL("../results/", import.meta.url);
fs.mkdirSync(resultsDir, { recursive: true });

let pass=0, fail=0;
let repaired=0;
const details = [];

for (const g of goldens) {
  const started = Date.now();
  const res = await fetch(runtimeUrl, {
    method:"POST",
    headers:{"content-type":"application/json"},
    body: JSON.stringify({ mode:g.mode, schemaName:g.schemaName, modelBaseUrl, apiKey, input:g.input, context:g.context })
  });

  const body = await res.json().catch(()=>({}));
  const ms = Date.now() - started;

  const ok = !!body.ok;
  if (ok) pass++; else fail++;
  if (ok && body.repaired) repaired++;

  details.push({
    name: g.name,
    ok,
    status: res.status,
    ms,
    repaired: !!body.repaired,
    error: ok ? null : (body.error || "unknown"),
    schemaErrors: body.errors || null
  });

  console.log(ok ? "PASS" : "FAIL", g.name, ok ? "" : (body.error || ""));
}

const summary = {
  runtimeUrl,
  modelBaseUrl,
  total: goldens.length,
  pass,
  fail,
  passRate: goldens.length ? pass / goldens.length : 0,
  repaired,
  repairedRate: pass ? repaired / pass : 0,
  timestamp: new Date().toISOString(),
  details
};

const outPath = new URL("./results.json", resultsDir);
fs.writeFileSync(outPath, JSON.stringify(summary, null, 2));
console.log("wrote", outPath.pathname);
process.exit(fail ? 1 : 0);
