## SECURITY VULNERABILITIES

### Authentication & Authorization Disasters
- [ ] No authentication on critical endpoints
- [ ] Hardcoded admin credentials in code
- [ ] JWT tokens without expiration
- [ ] No token refresh mechanism
- [ ] Session tokens stored in localStorage (XSS vulnerable)
- [ ] Weak password requirements (no minimum length)
- [ ] No password hashing (storing plain text passwords)
- [ ] Using weak hashing algorithms (MD5, SHA1)
- [ ] No rate limiting on login attempts
- [ ] Missing CSRF protection
- [ ] No email verification on signup
- [ ] Authorization checks only on frontend
- [ ] User can edit their own role/permissions
- [ ] Missing authentication on API endpoints
- [ ] Anyone can access other users’ data
- [ ] No session timeout
- [ ] Forgot password without token expiration
- [ ] Password reset tokens never expire
- [ ] Using GET requests for sensitive operations
- [ ] No account lockout after failed attempts
- [ ] Predictable session IDs
- [ ] Session fixation vulnerabilities
- [ ] No logout functionality
- [ ] Logout doesn’t invalidate tokens
- [ ] Auth state only checked once on page load

### Injection Vulnerabilities
- [ ] SQL injection everywhere (string concatenation in queries)
- [ ] No parameterized queries
- [ ] Raw SQL with user input
- [ ] XSS attacks (no output encoding)
- [ ] Dangerously setting innerHTML with user content
- [ ] No input sanitization
- [ ] Command injection in system calls
- [ ] LDAP injection
- [ ] XML injection
- [ ] NoSQL injection
- [ ] GraphQL injection
- [ ] Template injection
- [ ] Server-side template injection (SSTI)
- [ ] Code injection in eval()
- [ ] Using eval() with user input
- [ ] Unsafe deserialization
- [ ] Path traversal vulnerabilities
- [ ] File inclusion vulnerabilities
- [ ] Header injection

### Data Exposure
- [ ] API returns all user data including passwords
- [ ] Exposing internal IDs that reveal system info
- [ ] Verbose error messages with stack traces in production
- [ ] Database credentials in frontend code
- [ ] API keys committed to Git
- [ ] .env files in version control
- [ ] Secrets in Docker images
- [ ] Debug mode enabled in production
- [ ] Source maps exposed in production
- [ ] Directory listing enabled
- [ ] Backup files accessible (.bak, .old)
- [ ] Git folder exposed (.git directory accessible)
- [ ] Internal API documentation publicly accessible
- [ ] GraphQL introspection enabled in production
- [ ] Database directly accessible from internet
- [ ] Admin panel at /admin with no protection
- [ ] Exposing user email addresses publicly
- [ ] PII in URLs or logs
- [ ] Sensitive data in query parameters
- [ ] Logging passwords or tokens
- [ ] Exposing server/framework version in headers
- [ ] CORS allowing all origins (*)
- [ ] No encryption for sensitive data
- [ ] Storing credit cards directly

### Access Control Issues
- [ ] Horizontal privilege escalation (access other users’ data by changing ID)
- [ ] Vertical privilege escalation (regular user accessing admin features)
- [ ] Insecure direct object references (IDOR)
- [ ] Missing authorization checks
- [ ] Only client-side authorization
- [ ] Can access resources by guessing IDs
- [ ] Sequential/predictable IDs
- [ ] No ownership verification
- [ ] Mass assignment vulnerabilities
- [ ] User can modify any field in update requests
- [ ] No role-based access control
- [ ] Everyone is admin by default
- [ ] Admin functionality accessible to all
- [ ] API endpoints with no access control
- [ ] File uploads accessible by direct URL
- [ ] Private files in public folder

### File Upload Vulnerabilities
- [ ] No file type validation
- [ ] Accepting any file extension
- [ ] No file size limits
- [ ] Files saved with original names
- [ ] Uploaded files executed by server
- [ ] PHP/executable files can be uploaded
- [ ] No virus scanning
- [ ] Files stored in web-accessible directory
- [ ] No filename sanitization
- [ ] Path traversal in file uploads
- [ ] Zip bombs
- [ ] XXE attacks via XML uploads
- [ ] Image processing vulnerabilities
- [ ] No content-type validation
- [ ] Accepting SVG with embedded JavaScript

---
