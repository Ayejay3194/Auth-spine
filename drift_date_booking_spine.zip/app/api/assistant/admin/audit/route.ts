import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const businessId = url.searchParams.get("businessId") ?? "biz_1";
  const limit = Math.min(Number(url.searchParams.get("limit") ?? 50), 200);

  const rows = await prisma.assistantAuditEvent.findMany({
    where: { businessId },
    orderBy: { createdAt: "desc" },
    take: limit,
  });

  return NextResponse.json({
    events: rows.map(r => ({
      at: r.createdAt.toISOString(),
      type: r.type,
      details: r.detailsJson,
      actorId: r.actorId,
      role: r.role,
    })),
  });
}
