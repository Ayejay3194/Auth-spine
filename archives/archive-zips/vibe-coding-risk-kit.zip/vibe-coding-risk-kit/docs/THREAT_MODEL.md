# Threat Model (Template)

## System summary
- App: ______________________
- Data types: (PII, payments, health, location, etc.) ______________________
- Auth: (sessions/JWT/OAuth) ______________________
- Storage: ______________________

## Assets to protect
- User accounts
- Session tokens
- PII
- Payment intents / payout accounts
- Private files

## Trust boundaries
- Browser -> API
- API -> Database
- API -> third-party services (email/payments/video/etc.)
- Realtime channels (presence, chat)

## Top risks (fill in)
1. IDOR / broken authorization
2. Token theft (XSS/localStorage)
3. RLS bypass (Supabase service key leakage)
4. Webhook replay/forgery
5. File upload exploit / data exposure
6. Excessive permissions / role escalation

## Mitigations checklist
- [ ] Auth enforced server-side
- [ ] Resource ownership checks everywhere
- [ ] RLS policies tested for each table
- [ ] CSP set + output encoding
- [ ] Rate limiting + lockouts
- [ ] Webhook signature + idempotency
- [ ] Private storage + signed URLs + file validation

## Abuse cases
- What happens if a user tries 10k password resets?
- What happens if a user enumerates IDs?
- What happens if a user uploads SVG with JS?
- What happens if a webhook is replayed 1,000 times?
