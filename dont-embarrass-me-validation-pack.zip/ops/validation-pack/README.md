# Don’t Embarrass Me Out In Public: Validation & Hardening Pack

This pack is **practical**: repeatable scripts + a “receipt” report so you can prove you ran security + load + ops checks before you ship.

## What you get
- **Security scanning**: OWASP ZAP baseline (Docker), `npm audit`, optional Snyk
- **Abuse checks**: auth spam, RBAC boundary checks, bad payload resilience
- **Load testing**: k6 (preferred) or Artillery fallback
- **Ops readiness**: backup/restore drill template, incident runbook, rollback playbook
- **CI**: GitHub Actions workflow to run the suite on PR + main

## Quick start (local)
1) Copy this folder into your repo (or just copy the `ops/validation-pack` folder from the zip):
```bash
cp -R ops/validation-pack ./ops/validation-pack
```

2) Set your target base URL:
```bash
export TARGET_BASE_URL="http://localhost:3000"
```

3) Run the full suite:
```bash
bash ops/validation-pack/scripts/run-all.sh
```

Outputs:
- `ops/validation-pack/out/receipt.json`
- `ops/validation-pack/out/receipt.md`

## Customize
- `configs/endpoints.json` – your endpoints + sample payloads
- `configs/load/*` – load profiles
- `configs/zap/*` – ignore rules (if needed)
