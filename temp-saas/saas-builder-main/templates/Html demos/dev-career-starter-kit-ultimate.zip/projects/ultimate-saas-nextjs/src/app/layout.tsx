import '../styles/globals.css';
import type { ReactNode } from 'react';

export const metadata = {
  title: 'Ultimate SaaS Starter',
  description: 'Full-stack starter for learning modern web development.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-background text-foreground">
        {children}
      </body>
    </html>
  );
}
