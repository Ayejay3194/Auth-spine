import { stripSensitiveKeys } from "./policies";
import { deepRedact } from "./redact";

export type SanitizeResult<T> = {
  data: T;
  removedKeys: string[];
};

export function sanitizePayload<T>(payload: any): SanitizeResult<T> {
  const before = collectKeys(payload);
  const stripped = stripSensitiveKeys(payload);
  const after = collectKeys(stripped);
  const removed = before.filter(k => !after.includes(k));
  return {
    data: deepRedact(stripped) as T,
    removedKeys: removed
  };
}

function collectKeys(obj: any): string[] {
  if (!obj || typeof obj !== "object") return [];
  if (Array.isArray(obj)) return obj.flatMap(collectKeys);
  return Object.keys(obj).concat(
    Object.values(obj).flatMap(collectKeys)
  );
}
