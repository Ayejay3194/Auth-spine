# AI Doc + Trace Suite

A small "stop the AI from going feral" kit:
- Repo manifest (file inventory + hashes)
- Protected paths + allowlist
- Requires a CHANGELOG entry per run
- Auto report `.guardian/report.md`
- GitHub Actions workflow to enforce

## Quick start
```bash
npm i
npm run guardian:build
npm run guardian:scan
npm run guardian:enforce
npm run guardian:report
```
