import { BASE_URL, TEST } from "./config";
import { http } from "./http";

export async function ensureTenant(tenant: { id: string; name: string; slug: string }) {
  // Optional dev endpoint. If your API doesn't have it, this should no-op.
  const r = await http("POST", `${BASE_URL}/tenants`, { body: tenant });
  // 200/201/409 are all acceptable for "exists or created"
  if (![200, 201, 409, 404].includes(r.status)) {
    throw new Error(`Unexpected /tenants response: status=${r.status} body=${r.text}`);
  }
}

export async function loginUser(params: { tenantId: string; email: string; password?: string; deviceLabel?: string }) {
  const body: any = {
    tenantId: params.tenantId,
    email: params.email,
    deviceLabel: params.deviceLabel,
  };
  if (params.password) body.password = params.password;

  const r = await http("POST", `${BASE_URL}/auth/login`, { body });
  if (!r.ok) {
    throw new Error(`Login failed for ${params.email} tenant=${params.tenantId}. status=${r.status} body=${r.text}`);
  }
  const token = r.json?.token;
  if (typeof token !== "string" || token.length < 10) {
    throw new Error(`Login did not return token. body=${r.text}`);
  }
  return token as string;
}

export async function authHeaders(token: string) {
  return { authorization: `Bearer ${token}` };
}
