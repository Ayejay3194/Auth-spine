import { prisma } from "@/lib/prisma";
import { requireAdmin } from "../_guard";

export async function GET(req: Request){
  const g = await requireAdmin();
  if(!g.ok) return new Response("Forbidden", { status: g.status });

  const { searchParams } = new URL(req.url);
  const salonId = searchParams.get("salonId");
  if(!salonId) return new Response("Missing salonId", { status:400 });

  const bookings = await prisma.booking.findMany({
    where:{ salonId, status:"PENDING_APPROVAL" },
    include:{ service:true, stylist:true },
    orderBy:{ createdAt:"desc" }
  });

  return Response.json({
    bookings: bookings.map(b => ({
      id: b.id,
      startAt: b.startAt.toISOString(),
      status: b.status,
      service: { name: b.service.name },
      stylist: { displayName: b.stylist.displayName, slug: b.stylist.slug },
    }))
  });
}
