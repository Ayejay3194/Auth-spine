# Status page basics
- Public status page (components: API, auth, billing, webhooks, storage)
- Incident updates + postmortems
- Subscription notifications
- Enterprise: private status pages per tenant
