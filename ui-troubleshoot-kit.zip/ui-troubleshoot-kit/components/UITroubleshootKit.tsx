"use client";

import React, { useMemo, useState } from "react";
import { Search, AlertCircle, CheckCircle, Copy, ChevronDown, ChevronRight, ShieldAlert } from "lucide-react";
import { troubleshootData } from "@/components/data/troubleshootData";
import type { TroubleshootItem, UIAuthority } from "@/components/types";

const AUTHORITY_LABEL: Record<UIAuthority, { label: string; tone: string }> = {
  ROUTE: { label: "Route-owned", tone: "bg-indigo-50 text-indigo-700 border-indigo-200" },
  GLOBAL_STORE: { label: "Global store-owned", tone: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  LOCAL_COMPONENT: { label: "Local component-owned", tone: "bg-amber-50 text-amber-700 border-amber-200" },
  SERVER_STATE: { label: "Server-state", tone: "bg-sky-50 text-sky-700 border-sky-200" },
  CSS_ONLY: { label: "CSS-only", tone: "bg-slate-50 text-slate-700 border-slate-200" }
};

export default function UITroubleshootKit() {
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyCode = async (code: string, id: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1500);
    } catch {
      // clipboard may be blocked (non-https). ignore.
    }
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories((prev) => ({ ...prev, [category]: !prev[category] }));
  };

  const filteredData = useMemo(() => {
    if (!searchTerm) return troubleshootData;

    const term = searchTerm.toLowerCase();
    const filtered: Record<string, TroubleshootItem[]> = {};
    for (const category of Object.keys(troubleshootData)) {
      const items = troubleshootData[category].filter((item) => {
        const inProblem = item.problem.toLowerCase().includes(term);
        const inSolutions = item.solutions.some((s) => s.toLowerCase().includes(term));
        const inCauses = item.rootCauses.some((c) => c.toLowerCase().includes(term));
        const inVerify = item.verifySteps.some((v) => v.toLowerCase().includes(term));
        return inProblem || inSolutions || inCauses || inVerify;
      });
      if (items.length) filtered[category] = items;
    }
    return filtered;
  }, [searchTerm]);

  return (
    <div className="pb-10">
      <div className="bg-white rounded-2xl shadow-soft p-6 md:p-8 mb-6 border border-slate-200/60">
        <div className="flex items-center gap-3 mb-4">
          <AlertCircle className="w-8 h-8 text-blue-600" />
          <h1 className="text-3xl md:text-4xl font-bold text-slate-800">
            UI Troubleshooting Toolkit
          </h1>
        </div>
        <p className="text-slate-600 mb-6">
          Search by symptom, cause, or fix. Every issue includes an <span className="font-semibold">Authority</span> label so your UI stops fighting itself.
        </p>

        <div className="grid gap-4 md:grid-cols-[1fr_auto]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search: 'z-index', 'reset on navigation', 'hydration', 'overflow'..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border-2 border-slate-200 rounded-lg focus:border-blue-500 focus:outline-none text-slate-800"
            />
          </div>

          <a
            href="/authority"
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-100"
          >
            <ShieldAlert className="w-4 h-4" />
            Authority rules
          </a>
        </div>
      </div>

      <div className="space-y-4">
        {Object.keys(filteredData).length === 0 ? (
          <div className="bg-white rounded-lg p-8 text-center border border-slate-200/60">
            <p className="text-slate-600">No results found. Try a different search term.</p>
          </div>
        ) : (
          Object.entries(filteredData).map(([category, items]) => (
            <div key={category} className="bg-white rounded-xl shadow-soft overflow-hidden border border-slate-200/60">
              <button
                onClick={() => toggleCategory(category)}
                className="w-full px-6 py-4 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 transition-colors"
              >
                <h2 className="text-xl font-bold text-slate-800">{category}</h2>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-600 bg-white px-3 py-1 rounded-full border border-slate-200">
                    {items.length} {items.length === 1 ? "issue" : "issues"}
                  </span>
                  {expandedCategories[category] ? (
                    <ChevronDown className="w-5 h-5 text-slate-600" />
                  ) : (
                    <ChevronRight className="w-5 h-5 text-slate-600" />
                  )}
                </div>
              </button>

              {expandedCategories[category] && (
                <div className="p-6 space-y-6">
                  {items.map((item) => (
                    <IssueCard key={item.id} item={item} copiedId={copiedId} onCopy={copyCode} />
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      <div className="mt-8 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
        <h3 className="font-bold text-lg text-slate-800 mb-3">Quick Debugging Tips (the stuff that actually works)</h3>
        <ul className="space-y-2 text-slate-700">
          <li className="flex items-start gap-2"><span className="text-blue-600 font-bold">•</span><span>Turn on DevTools “Highlight updates” to see re-render storms.</span></li>
          <li className="flex items-start gap-2"><span className="text-blue-600 font-bold">•</span><span>Add temporary outlines to visualize bounds: <code className="bg-white/70 px-1 rounded">outline: 1px solid red;</code></span></li>
          <li className="flex items-start gap-2"><span className="text-blue-600 font-bold">•</span><span>For “it resets”, hunt duplicate state owners: route vs store vs local.</span></li>
          <li className="flex items-start gap-2"><span className="text-blue-600 font-bold">•</span><span>For “it’s behind”, hunt stacking contexts: <code className="bg-white/70 px-1 rounded">transform</code>, <code className="bg-white/70 px-1 rounded">filter</code>, <code className="bg-white/70 px-1 rounded">opacity</code>.</span></li>
        </ul>
      </div>
    </div>
  );
}

function IssueCard({
  item,
  copiedId,
  onCopy
}: {
  item: TroubleshootItem;
  copiedId: string | null;
  onCopy: (code: string, id: string) => void;
}) {
  return (
    <div className="border-l-4 border-blue-500 pl-6 py-2">
      <h3 className="text-lg font-semibold text-slate-800 mb-2 flex items-center gap-2">
        <AlertCircle className="w-5 h-5 text-orange-500" />
        {item.problem}
      </h3>

      {!!item.symptomSignals?.length && (
        <div className="mb-3">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Common signals</p>
          <div className="flex flex-wrap gap-2">
            {item.symptomSignals.map((s, idx) => (
              <span key={idx} className="text-xs rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-slate-700">
                {s}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="mb-4">
        <p className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Authority</p>
        <div className="flex flex-wrap gap-2">
          {item.authority.map((a) => (
            <span key={a} className={`text-xs rounded-full border px-3 py-1 ${AUTHORITY_LABEL[a].tone}`}>
              {AUTHORITY_LABEL[a].label}
            </span>
          ))}
        </div>
        <p className="mt-2 text-sm text-slate-600">
          If you have the same “thing” owned by more than one authority, your UI will fight itself. Humans love doing this.
        </p>
      </div>

      <div className="mb-4">
        <p className="text-sm font-semibold text-slate-700 mb-2">Root causes</p>
        <ul className="space-y-2">
          {item.rootCauses.map((cause, idx) => (
            <li key={idx} className="flex items-start gap-2 text-slate-600">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-slate-400" />
              <span className="text-sm">{cause}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="mb-4">
        <p className="text-sm font-semibold text-slate-700 mb-2">Solutions</p>
        <ul className="space-y-2">
          {item.solutions.map((solution, idx) => (
            <li key={idx} className="flex items-start gap-2 text-slate-600">
              <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
              <span className="text-sm">{solution}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="mb-4">
        <p className="text-sm font-semibold text-slate-700 mb-2">Verify</p>
        <ul className="space-y-2">
          {item.verifySteps.map((step, idx) => (
            <li key={idx} className="flex items-start gap-2 text-slate-600">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-blue-500" />
              <span className="text-sm">{step}</span>
            </li>
          ))}
        </ul>
      </div>

      {!!item.antiPatterns?.length && (
        <div className="mb-4">
          <p className="text-sm font-semibold text-slate-700 mb-2">Anti-patterns</p>
          <ul className="space-y-2">
            {item.antiPatterns.map((ap, idx) => (
              <li key={idx} className="flex items-start gap-2 text-slate-600">
                <span className="mt-1 h-1.5 w-1.5 rounded-full bg-red-500" />
                <span className="text-sm">{ap}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="bg-slate-900 rounded-lg p-4 relative border border-slate-800">
        <button
          onClick={() => onCopy(item.code, item.id)}
          className="absolute top-2 right-2 p-2 bg-slate-700 hover:bg-slate-600 rounded transition-colors"
          title="Copy code"
        >
          {copiedId === item.id ? (
            <CheckCircle className="w-4 h-4 text-green-400" />
          ) : (
            <Copy className="w-4 h-4 text-slate-300" />
          )}
        </button>
        <pre className="text-sm text-slate-100 overflow-x-auto whitespace-pre-wrap">
          <code>{item.code}</code>
        </pre>
      </div>
    </div>
  );
}
