import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

async function getStylistId(){
  const session = await auth();
  if(!session?.user?.email) return null;
  const user = await prisma.user.findUnique({ where:{ email: session.user.email }, include:{ stylistProfile:true } });
  return user?.stylistProfile?.id ?? null;
}

export async function GET(){
  const stylistId = await getStylistId();
  if(!stylistId) return new Response("Unauthorized", { status:401 });

  const bookings = await prisma.booking.findMany({
    where:{ stylistId },
    include:{ service:true, client:true },
    orderBy:{ startAt:"desc" },
    take: 50
  });

  return Response.json({
    bookings: bookings.map(b => ({
      id: b.id,
      startAt: b.startAt.toISOString(),
      status: b.status,
      priceCentsFinal: b.priceCentsFinal,
      service: { name: b.service.name },
      client: b.client ? { email: b.client.email } : null,
    }))
  });
}
