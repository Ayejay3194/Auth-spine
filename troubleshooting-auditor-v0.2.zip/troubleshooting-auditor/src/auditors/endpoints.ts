import type { AuditSection } from "../types.js";

export async function auditEndpoints(endpoints: string[]): Promise<AuditSection> {
  const section: AuditSection = { id: "endpoints", title: "Endpoint Checks (Optional)", findings: [] };
  if (endpoints.length === 0) return section;

  for (const url of endpoints) {
    try {
      const res = await fetch(url, { method: "GET" });
      const text = await res.text();
      if (!res.ok) {
        section.findings.push({
          id: `endpoint.${url}.bad`,
          title: `Endpoint not OK: ${url}`,
          severity: "ERROR",
          details: `Received HTTP ${res.status}.`,
          fix: "Check server logs, auth, CORS, and deployment routing/rewrite rules.",
          evidence: { status: res.status, bodyTail: text.slice(-2000) },
        });
      } else {
        section.findings.push({
          id: `endpoint.${url}.ok`,
          title: `Endpoint OK: ${url}`,
          severity: "INFO",
          details: `Received HTTP ${res.status}.`,
          evidence: { status: res.status, bodyTail: text.slice(-1000) },
        });
      }
    } catch (e) {
      section.findings.push({
        id: `endpoint.${url}.err`,
        title: `Endpoint failed: ${url}`,
        severity: "ERROR",
        details: "Fetch failed (network/DNS/connection).",
        fix: "Confirm URL is reachable from your machine/CI environment.",
        evidence: { error: String(e) },
      });
    }
  }

  return section;
}
