#!/usr/bin/env bash
set -euo pipefail
echo "TODO: pg_dump $DATABASE_URL | gzip | upload to S3/R2"
