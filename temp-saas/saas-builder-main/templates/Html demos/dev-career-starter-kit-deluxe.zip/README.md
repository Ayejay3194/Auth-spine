# Dev Career Starter Kit — Deluxe

This is a **career starter pack** for a junior developer who wants to learn
full‑stack web development using a *real* project structure:

- Next.js (App Router) + TypeScript
- TailwindCSS design system
- Prisma ORM (SQLite)
- Minimal auth flow (mockable, upgradable later)
- Simple "Projects" CRUD feature
- AI‑assistant prompts + learning guides

The goal is to teach:
- how real repos are structured
- how to work with AI tools *without* losing your brain
- how to ship small, end‑to‑end features.
