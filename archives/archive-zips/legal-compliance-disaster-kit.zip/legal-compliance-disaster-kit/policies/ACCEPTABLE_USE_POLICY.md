# Acceptable Use Policy (Template)

You agree not to:
- Break laws, infringe IP, or violate privacy
- Attempt unauthorized access or probe security
- Upload malware or exploit code
- Spam, harass, or abuse others
- Overload the service (rate limits apply)

We may suspend accounts for violations to protect users and the platform.
