import { FlowDefinition } from "../flows/types.js";
import { Tool } from "../tools/types.js";
import { AdminProvider } from "../providers/types.js";

export function adminSpine(opts: { provider: AdminProvider }) {
  const { provider } = opts;

  const tools: Tool<any, any>[] = [
    {
      id: "admin.showAudit",
      description: "Show audit events",
      validate: (i) => { if (i.limit && i.limit > 500) throw new Error("Limit too high"); },
      run: async (_ctx, input) => ({ ok: true, data: { audit: await provider.showAudit({ limit: Number(input.limit ?? 50) }) } }),
      timeoutMs: 2500,
    },
    {
      id: "admin.manageRole",
      description: "Change a user's role",
      validate: (i) => { if (!i.targetUserId) throw new Error("Missing target"); if (!i.role) throw new Error("Missing role"); },
      run: async (_ctx, input) => ({ ok: true, data: await provider.manageRole({ targetUserId: input.targetUserId, role: input.role }) }),
      timeoutMs: 2500,
    },
    {
      id: "gdpr.export",
      description: "GDPR export",
      validate: (i) => { if (!i.userId) throw new Error("Missing userId"); },
      run: async (_ctx, input) => ({ ok: true, data: await provider.gdprExport({ userId: input.userId }) }),
      timeoutMs: 5000,
    },
  ];

  const flows: FlowDefinition[] = [
    {
      intent: "admin.show_audit",
      slots: [{ name: "limit", required: false }],
      steps: () => [
        { call: { toolId: "admin.showAudit", inputFromSlots: (s) => ({ limit: s.limit ?? 50 }) } },
        { done: { message: "Audit shown." } },
      ],
    },
    {
      intent: "gdpr.export_request",
      slots: [{ name: "userId", required: true }, { name: "confirm", required: true }],
      steps: () => [
        { ask: { slot: "userId", prompt: "User ID to export?", hint: "user_123" } },
        { ask: { slot: "confirm", prompt: "Type YES to queue GDPR export.", hint: "YES" } },
        { call: { toolId: "gdpr.export", commitIntent: "gdpr.export_request", confirmSlot: "confirm", inputFromSlots: (s) => ({ userId: s.userId }) } },
        { done: { message: "GDPR export queued." } },
      ],
    },
  ];

  return { tools, flows };
}
