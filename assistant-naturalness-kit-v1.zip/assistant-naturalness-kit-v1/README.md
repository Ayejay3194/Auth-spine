# Assistant Naturalness Kit V1 (TS/React/Node)

This starter pack makes an assistant **sound natural** via:
- **Intent coverage** (40 intents)
- **1,200 JSONL phrases** (training/eval data)
- **Tone policy** + **template families** (natural variation at runtime)
- A minimal TS **router** that turns NLU output into replies

## Files
- `training/phrases.jsonl` (1,200 rows)
- `intents.json` (intent + slot schema)
- `src/assistant/tones.ts`
- `src/assistant/templates.ts`
- `src/assistant/router.ts`

## Use
1) Train your intent/slot model on `training/phrases.jsonl` (or use embeddings + nearest-neighbor)
2) Produce `NluResult` at runtime
3) Call `respond(nluResult)` to get a natural reply **without needing an LLM**
