// automation entities.ts
