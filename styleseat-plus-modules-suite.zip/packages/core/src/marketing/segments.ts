import type { ID, ISODateTime } from "../shared/types.js";

export type ClientProfile = {
  clientId: ID;
  businessId: ID;
  lastVisitAt?: ISODateTime;
  totalSpend?: number;
  tags?: string[];
  noShows?: number;
  rebookRate?: number; // 0..1
};

export type SegmentRule =
  | { op: "tag"; value: string }
  | { op: "spend_gte"; value: number }
  | { op: "inactive_days_gte"; value: number; now: ISODateTime }
  | { op: "no_shows_gte"; value: number };

export type Segment = { id: ID; businessId: ID; name: string; rules: SegmentRule[] };

export function inSegment(c: ClientProfile, s: Segment): boolean {
  return s.rules.every(r => {
    switch (r.op) {
      case "tag": return (c.tags ?? []).includes(r.value);
      case "spend_gte": return (c.totalSpend ?? 0) >= r.value;
      case "inactive_days_gte": {
        if (!c.lastVisitAt) return true;
        const days = (Date.parse(r.now) - Date.parse(c.lastVisitAt)) / 86400000;
        return days >= r.value;
      }
      case "no_shows_gte": return (c.noShows ?? 0) >= r.value;
    }
  });
}

export function segmentAudience(clients: ClientProfile[], seg: Segment): ID[] {
  return clients.filter(c => c.businessId === seg.businessId && inSegment(c, seg)).map(c => c.clientId);
}
