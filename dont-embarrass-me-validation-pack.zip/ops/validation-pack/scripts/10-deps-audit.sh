#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/out"

echo "== Dependency audit =="
if [[ -f package.json ]]; then
  npm audit --production --json > "$OUT/npm-audit.json" || true
else
  echo "{}" > "$OUT/npm-audit.json"
fi

if command -v snyk >/dev/null 2>&1; then
  snyk test --json > "$OUT/snyk.json" || true
else
  echo "{}" > "$OUT/snyk.json"
fi
