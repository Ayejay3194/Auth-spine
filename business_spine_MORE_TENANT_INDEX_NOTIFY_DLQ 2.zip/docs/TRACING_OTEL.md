Call startOtel() on server init. Set OTEL_EXPORTER_OTLP_ENDPOINT.
