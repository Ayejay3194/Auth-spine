Backup automation
-----------------
Hook these scripts into your scheduler (GitHub Actions cron, server cron, or your platform scheduler).

- snapshot-db.sh: dumps DB and uploads to object storage (TODO)
- verify-restore.sh: restores into a scratch DB and runs a minimal integrity check (TODO)
