import { section, run } from "./_util.mjs";

const suites = [
  ["Unit & policy sanity", "unit.mjs"],
  ["IaC checks", "iac.mjs"],
  ["Security checks", "security.mjs"],
  ["Observability checks", "observability.mjs"],
  ["Disaster Recovery checks", "disaster-recovery.mjs"],
  ["Cost checks", "cost.mjs"],
  ["Compliance evidence checks", "compliance.mjs"],
  ["Receipt/ledger verification", "receipt.mjs"],
];

let worst = 0;
for (const [name, file] of suites) {
  section(name);
  const code = await run("node", [`./scripts/${file}`]);
  worst = Math.max(worst, code);
}
process.exit(worst);
