import type { ID, ISODateTime } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type NotificationType =
  | "booking.confirmed" | "booking.canceled" | "payment.failed" | "campaign.sent"
  | "review.received" | "dispute.opened" | "admin.action";

export type Notification = {
  id: ID;
  businessId: ID;
  userId: ID;
  type: NotificationType;
  title: string;
  body?: string;
  url?: string;
  createdAt: ISODateTime;
  readAt?: ISODateTime;
  archivedAt?: ISODateTime;
};

export class NotificationCenter {
  private items: Notification[] = [];
  constructor(private retentionDays: number) {}

  push(n: Omit<Notification,"id">): Notification {
    const it: Notification = { ...n, id: cuid("ntf") };
    this.items.unshift(it);
    return it;
  }

  list(userId: ID, businessId: ID, opts?: { unreadOnly?: boolean; type?: NotificationType; limit?: number }): Notification[] {
    const limit = opts?.limit ?? 50;
    return this.items
      .filter(n => n.userId === userId && n.businessId === businessId)
      .filter(n => opts?.unreadOnly ? !n.readAt : true)
      .filter(n => opts?.type ? n.type === opts.type : true)
      .filter(n => !n.archivedAt)
      .slice(0, limit);
  }

  markRead(id: ID, atISO: ISODateTime) { const n = this.items.find(x => x.id === id); if (n) n.readAt = atISO; }
  markUnread(id: ID) { const n = this.items.find(x => x.id === id); if (n) n.readAt = undefined; }
  archive(id: ID, atISO: ISODateTime) { const n = this.items.find(x => x.id === id); if (n) n.archivedAt = atISO; }
  clearAll(userId: ID, businessId: ID, atISO: ISODateTime) { for (const n of this.items) if (n.userId===userId && n.businessId===businessId) n.archivedAt = atISO; }
  badgeCount(userId: ID, businessId: ID): number { return this.items.filter(n => n.userId===userId && n.businessId===businessId && !n.readAt && !n.archivedAt).length; }

  gc(nowISO: ISODateTime) {
    const cutoff = Date.parse(nowISO) - this.retentionDays*86400000;
    this.items = this.items.filter(n => Date.parse(n.createdAt) >= cutoff);
  }
}
