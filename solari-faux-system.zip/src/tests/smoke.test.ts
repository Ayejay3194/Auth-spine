import test from "node:test";
import assert from "node:assert/strict";
import { SolariFaux } from "../orchestrator.js";

test("responds to greeting", async () => {
  const s = new SolariFaux();
  const out = await s.respondTo("hello");
  assert.equal(out.message.role, "assistant");
  assert.ok(out.message.content.length > 0);
});
