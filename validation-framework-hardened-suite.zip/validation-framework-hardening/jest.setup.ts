import { jest } from '@jest/globals';

beforeAll(() => {
  jest.useFakeTimers();
  jest.setSystemTime(new Date('2024-01-15T12:00:00.000Z'));
});

afterAll(() => {
  jest.useRealTimers();
});
