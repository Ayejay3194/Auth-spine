import crypto from "node:crypto";
import type { ID, ISODateTime, Result } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type WebhookEndpoint = {
  id: ID;
  businessId: ID;
  url: string;
  secret: string;
  events: string[];
  active: boolean;
  createdAt: ISODateTime;
};

export type WebhookDelivery = {
  id: ID;
  endpointId: ID;
  eventType: string;
  payload: any;
  attempt: number;
  status: "pending" | "success" | "failed";
  lastError?: string;
  nextAttemptAt: ISODateTime;
  createdAt: ISODateTime;
};

export type Backoff = { baseSeconds: number; maxSeconds: number };

export class WebhookService {
  private endpoints: WebhookEndpoint[] = [];
  private deliveries: WebhookDelivery[] = [];

  constructor(private backoff: Backoff) {}

  createEndpoint(input: Omit<WebhookEndpoint,"id"|"createdAt"> & { createdAt: ISODateTime }): WebhookEndpoint {
    const ep: WebhookEndpoint = { ...input, id: cuid("wh"), createdAt: input.createdAt };
    this.endpoints.push(ep); return ep;
  }

  listEndpoints(businessId: ID): WebhookEndpoint[] { return this.endpoints.filter(e => e.businessId === businessId); }

  enqueue(eventType: string, payload: any, atISO: ISODateTime) {
    for (const ep of this.endpoints.filter(e => e.active && e.events.includes(eventType))) {
      const d: WebhookDelivery = {
        id: cuid("whd"),
        endpointId: ep.id,
        eventType,
        payload,
        attempt: 0,
        status: "pending",
        nextAttemptAt: atISO,
        createdAt: atISO
      };
      this.deliveries.push(d);
    }
  }

  sign(secret: string, payloadRaw: string): string {
    return crypto.createHmac("sha256", secret).update(payloadRaw).digest("hex");
  }

  verify(secret: string, payloadRaw: string, signature: string): boolean {
    const expected = this.sign(secret, payloadRaw);
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  }

  listDeliveries(endpointId: ID, limit = 50): WebhookDelivery[] {
    return this.deliveries.filter(d => d.endpointId === endpointId).slice(-limit).reverse();
  }

  // Worker hook: selects due deliveries. Your infra calls `attemptDelivery(...)`.
  due(atISO: ISODateTime, limit = 50): WebhookDelivery[] {
    const t = Date.parse(atISO);
    return this.deliveries.filter(d => d.status === "pending" && Date.parse(d.nextAttemptAt) <= t).slice(0, limit);
  }

  markSuccess(id: ID) { const d = this.deliveries.find(x => x.id === id); if (d) d.status = "success"; }

  markFailure(id: ID, error: string, atISO: ISODateTime) {
    const d = this.deliveries.find(x => x.id === id);
    if (!d) return;
    d.attempt += 1;
    d.lastError = error;
    d.status = d.attempt >= 8 ? "failed" : "pending";
    const delay = Math.min(this.backoff.maxSeconds, this.backoff.baseSeconds * (2 ** (d.attempt-1)));
    d.nextAttemptAt = new Date(Date.parse(atISO) + delay*1000).toISOString();
  }
}
