from .policy import next_action

class DialogueManager:
    def next(self, state: dict | None, text: str, nlu: dict) -> dict:
        state = state or {"active_intent": None, "slots": {}, "awaiting": None, "last_turn": None}
        action = next_action(state, text, nlu)
        state["last_turn"] = {"user": text, "intent": (nlu.get("intents") or [{}])[0].get("name"), "action": action.get("type")}
        return {"state": state, "next_action": action}
