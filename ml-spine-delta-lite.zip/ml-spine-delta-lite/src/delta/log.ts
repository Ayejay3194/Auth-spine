import fs from "node:fs/promises";
import path from "node:path";
import { LakeConfig, logRoot, headPath, commitPath } from "../io/paths.js";
import { sha256Text } from "../io/hash.js";
import { Commit, Head, FileRef } from "./types.js";
import { withTableLock } from "./lock.js";

/**
 * Read current head.
 */
export async function readHead(cfg: LakeConfig, table: string, tableVersion: string): Promise<Head> {
  const hp = headPath(cfg, table, tableVersion);
  try {
    const raw = await fs.readFile(hp, "utf8");
    return JSON.parse(raw) as Head;
  } catch {
    return { table, tableVersion, head: null, updatedAtISO: new Date().toISOString() };
  }
}

async function writeHead(cfg: LakeConfig, head: Head): Promise<void> {
  const hp = headPath(cfg, head.table, head.tableVersion);
  await fs.mkdir(path.dirname(hp), { recursive: true });
  await fs.writeFile(hp, JSON.stringify(head, null, 2));
}

/**
 * Write a commit with optimistic concurrency.
 * If expectedHead is provided and doesn't match current head, we refuse to write.
 */
export async function commitWrite(
  cfg: LakeConfig,
  args: {
    table: string;
    tableVersion: string;
    schemaVersion: string;
    add: FileRef[];
    remove?: { path: string }[];
    generator: string;
    message?: string;
    tags?: string[];
    expectedHead?: string | null;
  }
): Promise<Commit> {
  return withTableLock(cfg, args.table, args.tableVersion, async () => {
    const current = await readHead(cfg, args.table, args.tableVersion);

    if (typeof args.expectedHead !== "undefined" && args.expectedHead !== current.head) {
      throw new Error(
        `Conflict: expectedHead=${args.expectedHead} but currentHead=${current.head} for ${args.table}@${args.tableVersion}`
      );
    }

    // Build payload (id computed from payload without id)
    const payload = {
      commitVersion: "1" as const,
      table: args.table,
      tableVersion: args.tableVersion,
      parent: current.head ?? undefined,
      createdAtISO: new Date().toISOString(),
      schemaVersion: args.schemaVersion,
      add: args.add,
      remove: args.remove,
      generator: args.generator,
      message: args.message,
      tags: args.tags,
    };

    const id = sha256Text(JSON.stringify(payload));
    const commit: Commit = { ...payload, id };

    const cp = commitPath(cfg, args.table, args.tableVersion, id);
    await fs.mkdir(path.dirname(cp), { recursive: true });
    await fs.writeFile(cp, JSON.stringify(commit, null, 2));

    await writeHead(cfg, {
      table: args.table,
      tableVersion: args.tableVersion,
      head: id,
      updatedAtISO: new Date().toISOString(),
    });

    return commit;
  });
}

export async function readCommit(cfg: LakeConfig, table: string, tableVersion: string, id: string): Promise<Commit> {
  const cp = commitPath(cfg, table, tableVersion, id);
  const raw = await fs.readFile(cp, "utf8");
  return JSON.parse(raw) as Commit;
}

/**
 * Resolve the file set at a given commit (time travel):
 * - Walk commits from target back to root
 * - Apply adds/removes
 */
export async function resolveFilesAtCommit(
  cfg: LakeConfig,
  table: string,
  tableVersion: string,
  commitId: string
): Promise<FileRef[]> {
  const seen = new Set<string>();
  const removes = new Set<string>();
  const adds = new Map<string, FileRef>();

  let cur: string | undefined = commitId;
  while (cur) {
    if (seen.has(cur)) break;
    seen.add(cur);
    const c = await readCommit(cfg, table, tableVersion, cur);

    if (c.remove) for (const r of c.remove) removes.add(r.path);
    for (const a of c.add) {
      if (!removes.has(a.path) && !adds.has(a.path)) adds.set(a.path, a);
    }
    cur = c.parent;
  }

  // Stable order
  return [...adds.values()].sort((a,b) => a.path.localeCompare(b.path));
}

export async function latestCommitId(cfg: LakeConfig, table: string, tableVersion: string): Promise<string | null> {
  const h = await readHead(cfg, table, tableVersion);
  return h.head;
}
