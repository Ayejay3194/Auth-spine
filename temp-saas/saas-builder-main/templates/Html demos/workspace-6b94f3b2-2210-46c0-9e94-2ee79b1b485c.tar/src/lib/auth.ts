import { db } from '@/lib/db'

export async function signUp(name: string, email: string, password: string) {
  // Check if user already exists
  const existingUser = await db.user.findUnique({
    where: { email }
  })

  if (existingUser) {
    throw new Error('User already exists with this email')
  }

  // Create new user (in production, you'd hash the password)
  const user = await db.user.create({
    data: {
      name,
      email,
      // In production, store hashed password
      // password: await bcrypt.hash(password, 10)
    }
  })

  return user
}