# Repair Rules

- If user corrects assistant → acknowledge and fix
- If confidence < threshold → ask clarification with 2 options
- If user changes topic → acknowledge and switch
