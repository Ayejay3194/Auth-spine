import { z } from "zod";
import { api } from "@/src/core/api";
import { prisma } from "@/lib/prisma";
import { getTenant } from "@/src/tenant/tenant";
import { getActor } from "@/src/core/auth";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const Q = z.object({ filename: z.string().min(1), mime: z.string().optional() });
export async function POST(req: Request) {
  return api(async () => {
    const actor = getActor(req);
    const { tenantId } = getTenant(req);
    const body = Q.parse(await req.json());

    const bucket = process.env.UPLOADS_S3_BUCKET!;
    const region = process.env.AWS_REGION ?? "us-east-1";
    const key = `uploads/${tenantId}/${actor.userId}/${Date.now()}_${body.filename}`;

    const s3 = new S3Client({ region });
    const cmd = new PutObjectCommand({ Bucket: bucket, Key: key, ContentType: body.mime ?? "application/octet-stream" });
    const url = await getSignedUrl(s3, cmd, { expiresIn: 300 });

    const rec = await prisma.fileObject.create({ data: { tenantId, ownerId: actor.userId, key, mime: body.mime } });
    return { uploadUrl: url, key, fileId: rec.id };
  });
}
