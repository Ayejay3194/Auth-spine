import type { Notification, NotificationStore } from "@suite/modules-notifications";

export class InMemoryNotificationStore implements NotificationStore {
  private rows: Notification[] = [];

  async add(n: Omit<Notification,"id"|"createdAt">): Promise<Notification> {
    const row: Notification = { ...n, id:`n_${Math.random().toString(16).slice(2)}`, createdAt: new Date().toISOString() };
    this.rows.push(row);
    return row;
  }
  async list(userId: string, limit: number = 50) {
    return this.rows.filter(r => r.userId === userId).slice(-limit).reverse();
  }
  async markRead(userId: string, id: string) {
    const r = this.rows.find(x => x.userId === userId && x.id === id);
    if (r) r.readAt = new Date().toISOString();
  }
}
