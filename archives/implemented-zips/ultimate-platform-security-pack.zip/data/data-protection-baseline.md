Data Protection Baseline

- Encryption at rest and in transit
- Data minimization enforced
- Retention and deletion policies implemented
- PII masking outside production
- Logs sanitized
