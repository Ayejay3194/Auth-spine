# Vibe Coding Risk Kit (v2)

This kit turns the "things that can go wrong" list into practical, enforceable repo guardrails:
- Shipping gates (stop-ship rules)
- Checklists for legal/compliance, billing, ops, reliability, privacy, etc.
- PR templates + CI starter + test patterns

## How to use
1. Copy folders into your repo root.
2. Make `checklists/GATES.md` mandatory for every release (PR checklist + release checklist).
3. Treat every section doc in `/docs` as your "definition of done" for that domain.

## Files
- `checklists/` — go/no-go gates and per-domain release checklists
- `docs/` — policies + baselines + runbooks
- `.github/` — PR + issue templates
- `ci/` — GitHub Actions starter workflow
- `tests/` — security + reliability test patterns (how to write the tests)
