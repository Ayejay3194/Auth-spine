
/**
 * Golden vectors are the "receipt printer paper".
 * If a refactor moves a planet by 0.0001", CI fails and nobody ships lies.
 *
 * Replace these placeholders with YOUR audited vectors:
 * - from JPL Horizons snapshots you trust
 * - from DE440 kernel direct evaluation
 */
export type GoldenVector = {
  id: string;
  body: string;
  tdbIso: string;
  expectedKm: [number, number, number];
  toleranceKm: number; // max abs error per component
};

export const GOLDEN: GoldenVector[] = [
  {
    id: "EARTH_2000_01_01_TDB",
    body: "Earth",
    tdbIso: "2000-01-01T00:00:00Z",
    expectedKm: [ -265044.0, 132749.0, 57528.0 ],
    toleranceKm: 50.0,
  }
];
