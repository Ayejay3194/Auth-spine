export type ApiKeyScope = "read" | "write" | "admin";

export type ApiKeyRecord = {
  id: string;
  tenantId: string;
  name: string;
  keyPrefix: string;
  keyHash: string; // store hash only
  scopes: ApiKeyScope[];
  createdAt: string;
  revokedAt?: string;
  lastUsedAt?: string;
};
