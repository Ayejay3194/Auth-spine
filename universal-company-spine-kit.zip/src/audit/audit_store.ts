import type { AuditEntry } from "../types.js";

export interface IAuditStore {
  write(entry: AuditEntry): Promise<void>;
}
