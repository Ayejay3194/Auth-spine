import fs from "node:fs";
import path from "node:path";

export function exists(p: string) {
  try {
    fs.accessSync(p);
    return true;
  } catch {
    return false;
  }
}

export function readText(p: string) {
  return fs.readFileSync(p, "utf-8");
}

export function readJson<T = unknown>(p: string): T {
  return JSON.parse(readText(p)) as T;
}

export function safeStat(p: string) {
  try {
    return fs.statSync(p);
  } catch {
    return null;
  }
}

export function findFirstExisting(root: string, files: string[]) {
  for (const f of files) {
    const full = path.join(root, f);
    if (exists(full)) return full;
  }
  return null;
}
