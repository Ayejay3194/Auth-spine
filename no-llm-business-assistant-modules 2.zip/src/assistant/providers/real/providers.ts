import type { Providers } from "../types.js";

export function makeRealProviders(_db: any, _businessId: string): Providers {
  throw new Error("Implement real providers against your DB schema (booking/crm/payments/etc).");
}
