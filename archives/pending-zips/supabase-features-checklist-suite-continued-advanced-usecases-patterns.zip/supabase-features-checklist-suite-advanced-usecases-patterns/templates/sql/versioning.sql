-- Versioning Pattern (current row + history)
create table if not exists public.example (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  version int not null default 1,
  is_current boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.example_versions (
  id bigserial primary key,
  example_id uuid not null references public.example(id) on delete cascade,
  version int not null,
  snapshot jsonb not null,
  created_at timestamptz not null default now()
);

create unique index if not exists example_versions_uniq on public.example_versions(example_id, version);

create or replace function public.snapshot_example_version()
returns trigger language plpgsql as $$
begin
  insert into public.example_versions(example_id, version, snapshot)
  values (new.id, new.version, to_jsonb(new));
  return new;
end;
$$;

drop trigger if exists trg_snapshot_example_version on public.example;
create trigger trg_snapshot_example_version
after insert or update on public.example
for each row execute function public.snapshot_example_version();
