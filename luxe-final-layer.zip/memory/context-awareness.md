MEMORY & CONTEXT AWARENESS
==========================

Persist:
- prior disputes
- preferences
- escalation history
- sensitivity flags

Uses:
- adjust tone
- skip redundant questions
- tailor resolutions
