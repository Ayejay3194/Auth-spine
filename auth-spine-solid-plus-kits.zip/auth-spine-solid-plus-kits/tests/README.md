Tests scaffolding:
- Vitest for unit/integration
- Playwright for E2E
- MSW can be added for API mocks

Run:
- npm test
- npm run e2e
