# Solari Faux System (No-LLM Assistant)

A deterministic "assistant" that feels like an LLM without actually being one.
It uses:
- **NLU** (keyword + regex classifier)
- **Router/Policy** (decides what to do)
- **Skills** (deterministic engines)
- **Memory** (facts + preferences + recent turns)
- **Renderer** (voice/personality via templates + phrasebank)

## Quick start

```bash
npm i
npm run dev
```

## Plug in your JSONL phrasebank

Put your unified JSONL (or the GitHub-split parts) in `data/` and set env vars:

```bash
export SOLARI_JSONL_PATH=./data/solari_part_1.jsonl
# optionally also:
export SOLARI_JSONL_PATH_2=./data/solari_part_2.jsonl
npm run dev
```

The system will:
- load phrases / assistant examples
- tag them
- retrieve a few lines to season responses (openers, refusals, transitions)

## What this is (and isn't)

This is **not** a base model and it won't freestyle general knowledge.
It **will**:
- behave consistently
- follow a policy
- interpret astrology via a deterministic ruleset
- ask tight clarifying questions when confidence is low

## Folder map

- `src/nlu` intent/entity detection
- `src/router` policy + routing
- `src/skills` deterministic modules
- `src/memory` in-memory store (swap for DB later)
- `src/renderer` voice rendering + phrasebank retrieval
- `src/demo.ts` CLI demo loop
