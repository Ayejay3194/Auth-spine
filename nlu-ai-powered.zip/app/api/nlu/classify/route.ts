import { NextResponse } from "next/server";
import { callAnthropicJSON, type NLUResult } from "@/lib/anthropic";

export const runtime = "nodejs";

type IntentDef = { name: string; description: string; examples: string[] };
type EntityDef = { name: string; description: string; examples: string[] };

type Body = {
  text: string;
  intents: IntentDef[];
  entities: EntityDef[];
  temperature: number;
};

export async function POST(req: Request) {
  const body = (await req.json()) as Body;

  const text = (body.text || "").trim();
  if (!text) return NextResponse.json({ error: "Missing text" }, { status: 400 });

  const intents = Array.isArray(body.intents) ? body.intents : [];
  const entities = Array.isArray(body.entities) ? body.entities : [];
  const temperature = typeof body.temperature === "number" ? body.temperature : 0.3;

  const system = `You are an expert NLU (Natural Language Understanding) system. Your task is to analyze user input and extract:
1. The intent (what the user wants to do)
2. Entities (important information like names, dates, locations, etc.)

Available intents:
${intents.map(i => `- ${i.name}: ${i.description} Examples: ${i.examples.join(", ")}`).join("\n")}

Available entities:
${entities.map(e => `- ${e.name}: ${e.description} Examples: ${e.examples.join(", ")}`).join("\n")}

Respond ONLY with a JSON object in this exact format:
{
  "intent": "intent_name",
  "confidence": 0.95,
  "entities": [
    { "entity": "entity_name", "value": "extracted_value", "start": 0, "end": 5 }
  ],
  "reasoning": "Brief explanation of your classification"
}`;

  try {
    const result = await callAnthropicJSON<NLUResult>({
      system,
      user: `Analyze this user input: "${text}"`,
      temperature,
      maxTokens: 1000,
    });

    return NextResponse.json(result);
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message || "Classification failed" },
      { status: 500 }
    );
  }
}
