MONITORING, LOGGING & INCIDENT RESPONSE

Covers:
- SIEM
- Alerting
- Forensics
- Incident playbooks
- Disaster recovery