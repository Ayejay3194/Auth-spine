# Prompt: Zip Intake & Manifest Assistant
[...trimmed in explanation, full text to be customized by user...]
