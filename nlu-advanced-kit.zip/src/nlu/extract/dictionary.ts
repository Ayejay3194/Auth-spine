import type { EntitySpan, NLUModel } from "../types";

export function dictionaryEntities(model: NLUModel, text: string): EntitySpan[] {
  const lower = text.toLowerCase();
  const out: EntitySpan[] = [];

  for (const ent of model.entities) {
    const values = new Set<string>([
      ...ent.examples.map(e => e.toLowerCase()),
      ...Object.keys(ent.synonyms ?? {}).map(k => k.toLowerCase()),
      ...Object.values(ent.synonyms ?? {}).map(v => v.toLowerCase()),
    ]);

    for (const val of values) {
      const idx = lower.indexOf(val);
      if (idx >= 0) {
        const raw = text.slice(idx, idx + val.length);
        const canonical = ent.synonyms?.[val] ?? ent.synonyms?.[raw.toLowerCase()] ?? raw;
        out.push({
          entity: ent.name,
          value: canonical,
          start: idx,
          end: idx + val.length,
          source: "dictionary",
        });
      }
    }
  }

  return out;
}
