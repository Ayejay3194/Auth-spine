
import crypto from "node:crypto";

export function sha256Hex(data: string | Buffer): string {
  return crypto.createHash("sha256").update(data).digest("hex");
}

export function hmacSha256Hex(secret: string, msg: string): string {
  return crypto.createHmac("sha256", secret).update(msg).digest("hex");
}

/**
 * Canonical JSON serialization: stable key order.
 * This prevents "same object, different JSON" from breaking hashes.
 */
export function canonicalJson(obj: unknown): string {
  return JSON.stringify(obj, replacerSortKeys);
}

function replacerSortKeys(_key: string, value: any) {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const sorted: any = {};
    for (const k of Object.keys(value).sort()) sorted[k] = value[k];
    return sorted;
  }
  return value;
}
