
ETSY-LEVEL REMAINDER SUITE
=========================

This package adds the *remaining* Etsy-class components on top of the existing marketplace assistant:

- Seller onboarding & lifecycle
- Trust & safety / moderation
- Taxonomy & ranking
- Seller dashboards (data layer)
- Abuse & reliability scoring
- Admin enforcement tooling

All modules are deterministic, auditable, and no-LLM.
