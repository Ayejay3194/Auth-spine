import { WebSocketServer } from "ws";

type ClientMeta = { tenantId: string; userId: string };
export function startWsServer(port = 8081) {
  const wss = new WebSocketServer({ port });
  const clients = new Map<any, ClientMeta>();

  wss.on("connection", (ws) => {
    ws.on("message", (raw) => {
      try {
        const msg = JSON.parse(String(raw));
        if (msg.type === "hello") {
          clients.set(ws, { tenantId: msg.tenantId, userId: msg.userId });
          ws.send(JSON.stringify({ type: "hello_ack" }));
        }
      } catch {}
    });
    ws.on("close", () => clients.delete(ws));
  });

  function broadcast(tenantId: string, payload: any) {
    const data = JSON.stringify(payload);
    for (const [ws, meta] of clients.entries()) if (meta.tenantId === tenantId) ws.send(data);
  }
  return { wss, broadcast };
}
