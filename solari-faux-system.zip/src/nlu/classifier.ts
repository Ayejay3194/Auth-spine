import { Entity, Intent, NLUResult } from "../types.js";
import { clamp01, normalize } from "../utils/text.js";

type Rule = {
  intent: Intent;
  patterns: (RegExp | string)[];
  baseConfidence: number;
};

const RULES: Rule[] = [
  { intent: "greeting", baseConfidence: 0.85, patterns: ["hi", "hello", "hey", /good\s*(morning|afternoon|evening)/i] },
  { intent: "goodbye", baseConfidence: 0.85, patterns: ["bye", "goodbye", "later", /see\s*ya/i] },
  { intent: "ask_astrology", baseConfidence: 0.8, patterns: ["natal", "chart", "placement", "ascendant", "moon", "sun", "venus", "mars", "houses", "aspects", "transit", "synastry", "decan"] },
  { intent: "ask_weather", baseConfidence: 0.8, patterns: ["weather", "forecast", "rain", "snow", "temperature", "wind"] },
  { intent: "planning", baseConfidence: 0.7, patterns: ["plan", "schedule", "itinerary", "todo", "steps", "roadmap"] },
  { intent: "bug_report", baseConfidence: 0.7, patterns: ["bug", "error", "crash", "stack trace", "failed", "not working"] },
  { intent: "request_file", baseConfidence: 0.75, patterns: ["zip", "download", "file", "repo", "github"] },
  { intent: "smalltalk", baseConfidence: 0.55, patterns: ["how are you", "what's up", "wyd", "lol", "lmao"] },
];

const LOCATION_RE = /\b(in|at)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g;
const DATE_RE = /\b(today|tomorrow|yesterday)\b|\b(\d{4}-\d{2}-\d{2})\b/g;
const PLACEMENT_RE = /\b(sun|moon|mercury|venus|mars|jupiter|saturn|uranus|neptune|pluto)\s+(in)\s+([A-Za-z]+)\b/ig;

export function classify(text: string): NLUResult {
  const raw = text ?? "";
  const n = normalize(raw);

  let best: { intent: Intent; score: number } = { intent: "unknown", score: 0.2 };

  for (const r of RULES) {
    let hit = 0;
    for (const p of r.patterns) {
      if (typeof p === "string") {
        if (n.includes(p)) hit += 1;
      } else {
        if (p.test(raw)) hit += 1;
      }
    }
    const score = clamp01(r.baseConfidence + hit * 0.07);
    if (score > best.score) best = { intent: r.intent, score };
  }

  const entities: Entity[] = [];

  for (const m of raw.matchAll(LOCATION_RE)) {
    entities.push({ kind: "location", value: m[2] });
  }
  for (const m of raw.matchAll(DATE_RE)) {
    const v = m[0];
    if (v) entities.push({ kind: "date", value: v });
  }
  for (const m of raw.matchAll(PLACEMENT_RE)) {
    entities.push({ kind: "placement", value: `${capitalize(m[1])} in ${capitalize(m[3])}` });
  }

  // sentiment-ish (cheap but useful)
  const sentiment = (() => {
    const intense = ["literally", "actually", "wtf", "screaming", "dead", "obsessed", "hate", "love"];
    const neg = ["no", "not", "can't", "failed", "error", "broken"];
    const pos = ["thanks", "love", "perfect", "amazing", "good"];
    const i = intense.some(w => n.includes(w));
    if (i) return "intense";
    if (neg.some(w => n.includes(w))) return "negative";
    if (pos.some(w => n.includes(w))) return "positive";
    return "neutral";
  })();

  // style request detection (optional)
  const styleRequest = (() => {
    // user can type: "snark 0.8 warmth 0.2 verbose 0.3"
    const m = raw.match(/snark\s*(0\.\d+|1(?:\.0+)?)\b/i);
    const w = raw.match(/warmth\s*(0\.\d+|1(?:\.0+)?)\b/i);
    const v = raw.match(/verb(osity|ose)\s*(0\.\d+|1(?:\.0+)?)\b/i);
    if (!m && !w && !v) return undefined;
    return {
      snark: m ? clamp01(Number(m[1])) : 0.5,
      warmth: w ? clamp01(Number(w[1])) : 0.5,
      verbosity: v ? clamp01(Number(v[2])) : 0.5,
    };
  })();

  return {
    intent: best.intent,
    confidence: best.score,
    entities,
    sentiment,
    styleRequest,
  };
}

function capitalize(s: string): string {
  return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : s;
}
