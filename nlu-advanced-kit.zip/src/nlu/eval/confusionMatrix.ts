export function confusionMatrix(labels: string[], gold: string[], pred: string[]): number[][] {
  const idx = new Map(labels.map((l, i) => [l, i] as const));
  const m = Array.from({ length: labels.length }, () => Array.from({ length: labels.length }, () => 0));
  for (let i = 0; i < gold.length; i++) {
    const g = idx.get(gold[i]); const p = idx.get(pred[i]);
    if (g == null || p == null) continue;
    m[g][p] += 1;
  }
  return m;
}
