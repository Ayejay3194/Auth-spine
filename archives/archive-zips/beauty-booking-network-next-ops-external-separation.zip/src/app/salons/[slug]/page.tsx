import { Container } from "@/components/Container";
import { prisma } from "@/lib/prisma";
import { StylistCard } from "@/components/StylistCard";

export default async function SalonDetail({ params }:{ params:{ slug:string } }){
  const salon = await prisma.salon.findUnique({ where:{ slug: params.slug } });
  if(!salon) return <main className="py-10"><Container>Not found.</Container></main>;

  const members = await prisma.salonMembership.findMany({
    where:{ salonId: salon.id, status:"ACTIVE" },
    include:{ stylist:true }
  });

  return (
    <main className="py-10">
      <Container>
        <div className="overflow-hidden rounded-[28px] border" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
          <div className="h-56 w-full" style={{backgroundImage:`linear-gradient(to top, color-mix(in srgb, var(--bg) 78%, transparent), transparent), url(${salon.coverUrl||""})`, backgroundSize:"cover", backgroundPosition:"center"}}/>
          <div className="p-6">
            <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Salon</div>
            <h1 className="serif mt-2 text-3xl">{salon.name}</h1>
            <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>{salon.address} · {salon.hours} · ★ {salon.rating.toFixed(1)}</div>
          </div>
        </div>

        <div className="mt-10">
          <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Stylists</div>
          <h2 className="serif mt-2 text-2xl">Directory</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            {members.map(m => <StylistCard key={m.id} slug={m.stylist.slug} displayName={m.stylist.displayName} title={m.stylist.title} heroUrl={m.stylist.heroUrl} />)}
          </div>
        </div>
      </Container>
    </main>
  );
}
