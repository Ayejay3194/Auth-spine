# Observability Basics
- Correlation/request IDs on every request
- Structured logs (JSON)
- Redaction: never log tokens/passwords/secrets
- Error tracking tags: tenant_id, route, build sha
- Dashboards: latency p95, error rate, DB connections, queue depth
