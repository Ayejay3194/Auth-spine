import { IdempotencyStore, isoNow } from "./store";
import { RequestContext, Result, IdempotencyRecord } from "../types";

export type Handler<TReq, TRes> = (req: TReq, ctx: RequestContext) => Promise<{ status: number; body: any; headers?: Record<string,string> }>;

export type IdempotencyOptions = {
  headerName?: string; // default: Idempotency-Key
  ttlSeconds?: number; // default: 24h
  // Only enforce for these HTTP methods
  methods?: string[]; // default: POST, PUT, PATCH, DELETE
};

/**
 * Framework-agnostic idempotency wrapper.
 * - If request includes Idempotency-Key, we cache response.
 * - If in_progress, we return 409 with a Retry-After hint.
 * - Fail closed: missing tenantId -> throws.
 */
export function withIdempotency<TReq>(
  store: IdempotencyStore,
  handler: Handler<TReq, any>,
  opts: IdempotencyOptions = {}
): Handler<TReq & { headers?: Record<string,string>; method?: string }, any> {
  const headerName = (opts.headerName ?? "Idempotency-Key").toLowerCase();
  const ttlSeconds = opts.ttlSeconds ?? 86400;
  const methods = (opts.methods ?? ["POST","PUT","PATCH","DELETE"]).map(m => m.toUpperCase());

  return async (req, ctx) => {
    if (!ctx?.tenantId) throw new Error("Idempotency requires ctx.tenantId");

    const method = (req.method ?? "POST").toUpperCase();
    if (!methods.includes(method)) {
      return handler(req as any, ctx);
    }

    const key = req.headers?.[headerName] ?? req.headers?.[headerName.toUpperCase()] ?? req.headers?.[headerName.replace(/(^|-)(\w)/g, (_,a,b)=>a+b.toUpperCase())];
    if (!key) {
      // No idempotency requested. Proceed.
      return handler(req as any, ctx);
    }

    const existing = await store.get(ctx.tenantId, key);
    if (existing) {
      if (existing.status === "completed") {
        return {
          status: existing.responseStatus ?? 200,
          body: existing.responseBody,
          headers: {
            ...(existing.responseHeaders ?? {}),
            "Idempotency-Replay": "true",
          }
        };
      }
      if (existing.status === "in_progress") {
        return {
          status: 409,
          body: { error: "Request in progress. Retry with same Idempotency-Key.", key },
          headers: { "Retry-After": "2" }
        };
      }
      if (existing.status === "failed") {
        // let client retry with same key (we don't auto-replay failures)
        return handler(req as any, ctx);
      }
    }

    const createdAtISO = isoNow();
    const expiresAtISO = new Date(Date.now() + ttlSeconds*1000).toISOString();
    const record: IdempotencyRecord = {
      key,
      tenantId: ctx.tenantId,
      createdAtISO,
      expiresAtISO,
      status: "in_progress",
    };
    await store.put(record);

    try {
      const res = await handler(req as any, ctx);
      record.status = "completed";
      record.responseStatus = res.status;
      record.responseBody = res.body;
      record.responseHeaders = res.headers;
      await store.update(record);
      return res;
    } catch (err: any) {
      record.status = "failed";
      record.responseStatus = 500;
      record.responseBody = { error: "Handler error", message: String(err?.message ?? err) };
      await store.update(record);
      throw err;
    }
  };
}
