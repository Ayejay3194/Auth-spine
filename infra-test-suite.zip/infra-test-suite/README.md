# Infra Test Suite (Marketplace / Pro Ephemeris Grade)

This is a **runner** that checks the stuff that usually breaks silently:
- IaC sanity (Terraform/K8s/Helm YAML validation)
- Security posture (deps, secrets, container/IaC scanners)
- Monitoring/alert configs
- DR/backup drills (scripts + placeholders)
- Cost hygiene checks
- Compliance evidence checks
- **Receipt/ledger verification** (hash chain + HMAC)

## Quick start

```bash
npm i
npm test
```

## How it works

- `scripts/run-all.mjs` orchestrates everything
- Each domain test tries to run best-practice CLIs if installed.
- If a tool isn't installed, the check is skipped with a loud message.

You can wire this into your main repo via a submodule or copy/paste the folder.

## Required env vars (optional but recommended)

- `RECEIPT_HMAC_SECRET` for receipt verification (same secret used to sign receipts)

## Where to plug in your repo

Update `infra.config.json` to point at:
- `iac/` paths (terraform, helm, k8s manifests)
- `observability/` configs (prometheus rules, alertmanager, dashboards)
- `apps/` for API smoke tests
- `receipts/` ledger path
