# Architecture

Layers:
- apps/web: Next.js app (demo + docs + endpoints)
- packages/core: config, errors, logger, validation, middleware
- packages/auth: JWT helpers (jose)
- packages/create-auth-spine-app: CLI scaffold

Principles:
- typed inputs everywhere
- fail fast on env
- operational visibility (health + perf headers)
