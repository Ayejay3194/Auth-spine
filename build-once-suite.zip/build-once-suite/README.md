# Build-Once Suite (TypeScript Monorepo)

A reusable, vendor-swappable platform core containing:
- Analytics + dashboards (contracts + starter)
- A/B testing + feature flags
- Billing/subscriptions with tiered plans (provider-agnostic)
- Granular permissions (RBAC + ABAC hooks)
- Webhooks (signing, delivery logs, retries)
- i18n (multi-language)
- Email templates (HTML + text + preview text)
- API rate limiting + quotas
- Referrals + promo codes
- Reporting + exports
- Real-time notifications center (SSE contract + starter)
- SSO (SAML/LDAP contracts + stubs)
- GDPR tools (export/delete/consent/retention)
- Audit logs with compliance enhancements

This repo is structured so you **never rewrite the same enterprise features again**.
You swap adapters, not your architecture.

## Quick start
```bash
npm i
npm run build
npm run demo
```

## What you actually do in a new project
- Copy/clone this repo
- Replace adapters (Stripe/SES/S3/etc.) as needed
- Keep `packages/core` + `packages/modules` unchanged
- Your app imports only the public contracts + services

## Layout
- `packages/core/*`         platform spine (events, audit, entitlements, policy, gdpr, rate-limit)
- `packages/modules/*`      feature modules (billing, flags, webhooks, email, i18n, notifications, etc.)
- `packages/adapters/*`     vendor implementations (starter in-memory + crypto HMAC)
- `apps/demo-node`          runnable demo that exercises the suite end-to-end
