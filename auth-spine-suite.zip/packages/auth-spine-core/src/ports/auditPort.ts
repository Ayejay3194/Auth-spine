export interface AuditEntry {
  id: string;
  at: string;
  actorId?: string;
  action: string;
  targetId?: string;
  metadata?: Record<string, unknown>;
  prevHash?: string;
  hash?: string;
}

export interface AuditPort {
  append(entry: Omit<AuditEntry, "hash">): Promise<AuditEntry>;
  list(filter?: { actorId?: string; targetId?: string; actionPrefix?: string; limit?: number }): Promise<AuditEntry[]>;
}
