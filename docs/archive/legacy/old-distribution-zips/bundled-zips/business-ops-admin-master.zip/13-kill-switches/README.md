# 13-kill-switches

Emergency controls.
