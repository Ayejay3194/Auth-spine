-- Active queries (includes idle in transaction)
create or replace view admin_active_queries as
select
  now() as observed_at,
  pid,
  usename,
  application_name,
  client_addr,
  state,
  now() - query_start as query_age,
  wait_event_type,
  wait_event,
  left(query, 2000) as query
from pg_stat_activity
where pid <> pg_backend_pid()
order by query_age desc nulls last;
