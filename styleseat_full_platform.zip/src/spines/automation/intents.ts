// automation intents.ts
