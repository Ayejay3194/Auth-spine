NETWORK SECURITY

Covers:
- Perimeter defenses (WAF, DDoS, firewalls)
- Internal network segmentation
- VPN / Zero Trust
- DNS & domain security