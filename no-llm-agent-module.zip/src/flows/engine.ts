import { AgentContext } from "../core/types.js";
import { Entity } from "../nlu/entities.js";
import { IntentId } from "../nlu/intents.js";
import { runTool } from "../tools/runner.js";
import { FlowDefinition, FlowEngine, FlowRuntimeDeps, FlowState } from "./types.js";

function firstMissingSlot(def: FlowDefinition, slots: Record<string, string>): string | null {
  for (const s of def.slots) if (s.required && !slots[s.name]) return s.name;
  return null;
}

function fillFromEntities(def: FlowDefinition, slots: Record<string, string>, entities: Entity[]) {
  for (const s of def.slots) {
    if (!slots[s.name] && s.fromEntity) {
      const v = s.fromEntity(entities);
      if (v) slots[s.name] = v;
    }
  }
}

export function createFlowEngine(defs: FlowDefinition[], deps: FlowRuntimeDeps): FlowEngine {
  const map = new Map<IntentId, FlowDefinition>();
  for (const d of defs) map.set(d.intent, d);

  async function advance(ctx: AgentContext, state: FlowState, def: FlowDefinition) {
    const steps = def.steps(state.slots);

    for (let i = state.stepIndex; i < steps.length; i++) {
      const step = steps[i];
      state.stepIndex = i;

      if (step.ask && !state.slots[step.ask.slot]) {
        await deps.audit.write({
          at: deps.clock.now(),
          userId: ctx.userId,
          role: ctx.role,
          type: "slot.asked",
          details: { intent: state.intent, slot: step.ask.slot },
        });
        return {
          state,
          reply: { text: step.ask.prompt, ui: { type: "form", data: { slot: step.ask.slot, hint: step.ask.hint } } },
        };
      }

      if (step.call) {
        const tool = deps.tools.get(step.call.toolId);
        const input = step.call.inputFromSlots(state.slots);
        const res = await runTool({ ctx, tool, input, audit: deps.audit, clock: deps.clock });
        if (!res.ok) {
          state.completed = true;
          await deps.audit.write({
            at: deps.clock.now(),
            userId: ctx.userId,
            role: ctx.role,
            type: "flow.failed",
            details: { intent: state.intent, error: res.error },
          });
          return { state, reply: { text: `That didn’t work: ${res.error?.message ?? "unknown error"}`, done: true } };
        }
      }

      if (step.done) {
        state.completed = true;
        await deps.audit.write({ at: deps.clock.now(), userId: ctx.userId, role: ctx.role, type: "flow.completed", details: { intent: state.intent } });
        return { state, reply: { text: step.done.message, done: true } };
      }
    }

    state.completed = true;
    return { state, reply: { text: "Done.", done: true } };
  }

  async function start(ctx: AgentContext, intent: IntentId, entities: Entity[]) {
    const def = map.get(intent);
    if (!def) return { state: { intent: "unknown", stepIndex: 0, slots: {}, completed: true }, reply: { text: "I can’t help with that yet.", done: true } };

    const slots: Record<string, string> = {};
    fillFromEntities(def, slots, entities);

    // If we already have required slots, it will proceed; otherwise it'll ask.
    return advance(ctx, { intent, stepIndex: 0, slots, completed: false }, def);
  }

  async function cont(ctx: AgentContext, state: FlowState, userText: string, entities: Entity[]) {
    const def = map.get(state.intent);
    if (!def || state.completed) return { state, reply: { text: "Nothing to do.", done: true } };

    const missing = firstMissingSlot(def, state.slots);
    if (missing) {
      state.slots[missing] = userText.trim();
      await deps.audit.write({ at: deps.clock.now(), userId: ctx.userId, role: ctx.role, type: "slot.filled", details: { intent: state.intent, slot: missing } });
    }

    fillFromEntities(def, state.slots, entities);
    return advance(ctx, state, def);
  }

  return { start, continue: cont };
}
