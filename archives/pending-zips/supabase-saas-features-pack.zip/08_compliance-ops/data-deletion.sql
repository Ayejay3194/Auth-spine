-- Deletion/offboarding requests
create table if not exists deletion_requests (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  requested_by uuid not null references auth.users(id),
  scope text not null, -- TENANT | USER
  status text not null default 'PENDING',
  created_at timestamptz default now(),
  executed_at timestamptz
);
