import fs from "node:fs";
import path from "node:path";

export function readJson(p: string) {
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}
export function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}
export function listFiles(dir: string, ext: string) {
  return fs.readdirSync(dir)
    .filter(f => f.toLowerCase().endsWith(ext))
    .map(f => path.join(dir, f));
}
export function readLines(file: string) {
  return fs.readFileSync(file, "utf-8").split(/\r?\n/).filter(Boolean);
}
