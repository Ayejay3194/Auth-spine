export type LatLon = { lat: number; lon: number };

export type GeoAddressParts = {
  houseNumber?: string;
  road?: string;
  neighbourhood?: string;
  suburb?: string;
  city?: string;
  county?: string;
  state?: string;
  postcode?: string;
  country?: string;
  countryCode?: string;
};

export type GeoResult = {
  label: string;              // provider display name / best label
  point: LatLon;              // lat/lon
  bbox?: { south: number; west: number; north: number; east: number };
  parts?: GeoAddressParts;    // structured components when available
  confidence?: number;        // 0..1 if provider supports it (we infer for Nominatim)
  provider: string;           // provider name
  raw?: unknown;              // raw provider payload (optional)
};

export type GeoReceipt = {
  traceId: string;
  at: string;                 // ISO timestamp
  op: "forward" | "reverse";
  cache: { hitL1: boolean; hitL2: boolean; wroteL1: boolean; wroteL2: boolean };
  key: string;                // cache key used
  provider: { name: string; ms: number; status?: number; url?: string };
  policy: { minConfidence: number; negativeCacheTtlMs: number };
  outcome: "ok" | "no_match" | "blocked_low_confidence" | "error";
  notes?: string[];
};

export type ForwardRequest = {
  query: string;
  locale?: string;            // e.g., "en"
  countryCodes?: string[];    // e.g., ["us","ca"]
  limit?: number;             // default 5
};

export type ReverseRequest = {
  point: LatLon;
  locale?: string;
  zoom?: number;              // provider-specific, default sensible
};

export type DigiGeoResponse = {
  best?: GeoResult;
  results: GeoResult[];
  receipt: GeoReceipt;
};

export type CacheValue<T> = { value: T; expiresAt: number };

export interface KeyValueCache {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, ttlMs: number): Promise<void>;
}

export type DigiGeoPolicy = {
  minConfidence: number;
  negativeCacheTtlMs: number;
};

export type DigiGeoConfig = {
  provider: GeoProviderConfig;
  cache: { l1: L1Cache; l2?: KeyValueCache };
  policy: DigiGeoPolicy;
};

export type GeoProviderConfig =
  | { kind: "nominatim"; endpoint: string; userAgent: string; email?: string; referer?: string };

export interface GeoProvider {
  name: string;
  forward(req: ForwardRequest): Promise<{ status: number; url: string; results: GeoResult[] }>;
  reverse(req: ReverseRequest): Promise<{ status: number; url: string; results: GeoResult[] }>;
}

export interface L1Cache {
  get(key: string): string | null;
  set(key: string, value: string, ttlMs: number): void;
}
