import { classify } from "./nlu/classifier.js";
import { route } from "./router/policy.js";
import { getSkill } from "./skills/index.js";
import { MemoryStore } from "./memory/store.js";
import { PhraseBank } from "./renderer/phrasebank.js";
import { Renderer } from "./renderer/render.js";
import { Message, RenderedResponse } from "./types.js";
import { uid } from "./utils/id.js";

export class SolariFaux {
  private memory = new MemoryStore();
  private bank = new PhraseBank();
  private renderer = new Renderer(this.bank);

  constructor(opts?: { jsonlPaths?: string[] }) {
    const paths = opts?.jsonlPaths ?? [];
    if (paths.length) this.bank.loadFromJSONL(paths);
  }

  ingestUser(text: string): Message {
    const msg: Message = { id: uid("u"), role: "user", content: text, ts: Date.now() };
    this.memory.addMessage(msg);
    return msg;
  }

  async respondTo(text: string): Promise<RenderedResponse> {
    const userMsg = this.ingestUser(text);
    const nlu = classify(userMsg.content);
    const r = route(nlu);
    const skill = getSkill(r.skill);

    const ctx = { nlu, memory: this.memory.snapshot(), now: Date.now() };
    const skillResult = await skill.run(ctx);

    const rendered = this.renderer.render({ route: r, nlu, memory: this.memory.snapshot(), skillResult });

    this.memory.addMessage(rendered.message);
    return rendered;
  }
}
