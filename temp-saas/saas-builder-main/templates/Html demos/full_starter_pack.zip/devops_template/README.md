# DevOps Template
Pipelines, docker, and deployment.