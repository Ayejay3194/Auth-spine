SILENCE AS A FEATURE
====================

Rules:
- batch notifications
- suppress redundant confirmations
- prioritize reassurance over alerts
- notify only when action required
