Tenant resolver: src/tenant/tenant.ts (x-tenant-id)
Add tenantId to every table and enforce in all queries.
