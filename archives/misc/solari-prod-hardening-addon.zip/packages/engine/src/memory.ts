/**
 * Simple anti-repetition memory.
 * Tracks recently used nodeIds + phrases.
 */
export class RepetitionMemory {
  private recentIds: string[] = [];
  private recentPhrases: string[] = [];
  constructor(private maxIds = 64, private maxPhrases = 256) {}

  noteId(id: string) {
    this.recentIds.unshift(id);
    this.recentIds = Array.from(new Set(this.recentIds)).slice(0, this.maxIds);
  }
  notePhrase(phrase: string) {
    const p = phrase.trim().toLowerCase();
    if (!p) return;
    this.recentPhrases.unshift(p);
    this.recentPhrases = Array.from(new Set(this.recentPhrases)).slice(0, this.maxPhrases);
  }
  hasId(id: string) { return this.recentIds.includes(id); }
  hasPhrase(phrase: string) { return this.recentPhrases.includes(phrase.trim().toLowerCase()); }
  snapshot() { return { recentIds: [...this.recentIds], recentPhrases: [...this.recentPhrases] }; }
}
