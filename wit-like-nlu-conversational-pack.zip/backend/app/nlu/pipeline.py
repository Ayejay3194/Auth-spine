from .intent import IntentClassifier
from .entities import EntityExtractor

class NLUPipeline:
    def __init__(self):
        self.intent = IntentClassifier()
        self.entities = EntityExtractor()

    def parse(self, text: str) -> dict:
        return {
            "text": text,
            "intents": self.intent.predict(text),
            "entities": self.entities.extract(text),
        }
