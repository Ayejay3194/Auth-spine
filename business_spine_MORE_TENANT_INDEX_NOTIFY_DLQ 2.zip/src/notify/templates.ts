export const templates: Record<string, (vars: any) => { subject?: string; text: string }> = {
  booking_confirm: (v) => ({ subject: "Booking confirmed", text: `Confirmed: ${v.service} at ${v.when}` }),
  booking_reminder: (v) => ({ subject: "Appointment reminder", text: `Reminder: ${v.service} at ${v.when}` }),
  invoice_sent: (v) => ({ subject: "Invoice", text: `Invoice for $${v.amount}` }),
  review_request: (v) => ({ subject: "How did we do?", text: `Leave a review for ${v.service}` }),
};
