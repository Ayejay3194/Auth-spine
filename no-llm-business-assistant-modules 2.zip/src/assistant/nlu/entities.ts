export type Entities = {
  money?: number;
  percent?: number;
  dateISO?: string;
  timeHint?: "morning" | "afternoon" | "evening";
  clientId?: string;
  bookingId?: string;
  invoiceId?: string;
  promoCode?: string;
  service?: string;
  notes?: string;
};

const moneyRe = /\$\s*(\d+(?:\.\d{1,2})?)/;
const pctRe = /(\d{1,3})\s*%/;
const clientIdRe = /\bcl_[a-z0-9_-]+\b/i;
const bookingIdRe = /\bbk_[a-z0-9_-]+\b/i;
const invoiceIdRe = /\binv_[a-z0-9_-]+\b/i;

export function extractEntities(text: string): Entities {
  const t = text.trim();
  const e: Entities = {};

  const m = t.match(moneyRe);
  if (m) e.money = Number(m[1]);

  const p = t.match(pctRe);
  if (p) e.percent = Number(p[1]);

  const cid = t.match(clientIdRe);
  if (cid) e.clientId = cid[0];

  const bid = t.match(bookingIdRe);
  if (bid) e.bookingId = bid[0];

  const iid = t.match(invoiceIdRe);
  if (iid) e.invoiceId = iid[0];

  const code = t.match(/\bpromo[_-]?[a-z0-9]+\b/i);
  if (code) e.promoCode = code[0];

  if (/\bmorning\b/i.test(t)) e.timeHint = "morning";
  if (/\bafternoon\b/i.test(t)) e.timeHint = "afternoon";
  if (/\bevening\b/i.test(t)) e.timeHint = "evening";

  // ISO date passthrough (YYYY-MM-DD)
  const d = t.match(/\b(20\d{2}-\d{2}-\d{2})\b/);
  if (d) e.dateISO = d[1];

  // naive service extraction
  const svc = t.match(/\b(?:book|schedule)\s+([a-z][a-z\s]{2,40})\b/i);
  if (svc) e.service = svc[1].trim();

  return e;
}
