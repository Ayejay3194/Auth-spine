export type ParsedIntent =
  | { kind: "BOOK_REQUEST" }
  | { kind: "BOOK_SAME_AS_LAST_TIME" }
  | { kind: "UNKNOWN" };

export function parseSmsIntent(body: string): ParsedIntent {
  const t = body.trim().toLowerCase();
  if (t.includes("same as last")) return { kind: "BOOK_SAME_AS_LAST_TIME" };
  if (t.includes("book") || t.includes("i want") || t.includes("haircut") || t.includes("thursday")) return { kind: "BOOK_REQUEST" };
  return { kind: "UNKNOWN" };
}
