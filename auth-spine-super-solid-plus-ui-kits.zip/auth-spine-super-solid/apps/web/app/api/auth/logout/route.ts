import { NextRequest, NextResponse } from 'next/server'
import { clearAuthCookie } from '@auth-spine/auth'
import { errorHandler } from '@auth-spine/core'

export async function POST(req: NextRequest) {
  try {
    const res = NextResponse.json({ ok: true })
    clearAuthCookie(res)
    return res
  } catch (e) {
    return errorHandler(e as Error, req)
  }
}
