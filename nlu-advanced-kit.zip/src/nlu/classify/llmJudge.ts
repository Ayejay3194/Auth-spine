import type { NLUModel, NLUResult } from "../types";

/**
 * Optional LLM judge.
 * By default this is a stub so the kit runs without secrets or providers.
 *
 * Wire it by replacing `classifyWithLLM` to call your provider, and keep the return shape.
 */
export async function llmJudge(_model: NLUModel, _text: string): Promise<Pick<NLUResult, "intent" | "entities"> | null> {
  // return null to indicate "not used"
  return null;
}
