OIDC + SAML route stubs are included. Wire to your IdP.
