export default function Page(){return <div style={{padding:24}}>New saas app</div>}
