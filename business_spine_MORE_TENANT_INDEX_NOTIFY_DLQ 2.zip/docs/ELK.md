ES: :9200, Kibana: :5601. Add log shipper later if needed.
