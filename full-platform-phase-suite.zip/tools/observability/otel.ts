export function initTelemetry() {
  // TODO: wire OpenTelemetry NodeSDK + instrumentations (http/fetch/db)
  return { ok: true };
}
