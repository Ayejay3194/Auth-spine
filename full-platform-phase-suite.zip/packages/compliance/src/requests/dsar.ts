import type { ID, ISODateTime } from "@suite/core";

export type DSARType = "export" | "delete" | "rectify" | "access";

export type DSARRequest = {
  id: ID;
  tenantId: ID;
  userId: ID;
  type: DSARType;
  status: "open" | "in_progress" | "fulfilled" | "rejected";
  requestedAt: ISODateTime;
  fulfilledAt?: ISODateTime;
  notes?: string;
};

export interface DSARStore {
  create(req: Omit<DSARRequest,"id">): Promise<DSARRequest>;
  update(id: ID, patch: Partial<DSARRequest>): Promise<DSARRequest>;
  get(id: ID): Promise<DSARRequest | null>;
  list(tenantId: ID, userId?: ID): Promise<DSARRequest[]>;
}

export function requireReauth(lastAuthAtISO: ISODateTime, nowISO: ISODateTime, maxAgeMinutes=10): boolean {
  return (Date.parse(nowISO) - Date.parse(lastAuthAtISO)) > maxAgeMinutes*60*1000;
}
