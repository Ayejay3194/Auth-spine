import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readJson } from "../utils/fs.js";

type Pkg = { scripts?: Record<string, string>; engines?: Record<string, string>; type?: string; dependencies?: Record<string,string>; devDependencies?: Record<string,string>; };

export function auditPackage(root: string): AuditSection {
  const section: AuditSection = { id: "package", title: "Package & Scripts", findings: [] };
  const p = path.join(root, "package.json");

  if (!exists(p)) {
    section.findings.push({
      id: "package.missing",
      title: "package.json missing",
      severity: "ERROR",
      details: "No package.json means no scripts and no reproducible dependency graph.",
      fix: "Create package.json and define scripts for dev/build/start/lint/typecheck.",
      evidence: { packageJsonPath: p },
    });
    return section;
  }

  let pkg: Pkg;
  try { pkg = readJson<Pkg>(p); } catch (e) {
    section.findings.push({
      id: "package.invalid",
      title: "package.json is not valid JSON",
      severity: "ERROR",
      details: "Your package.json failed to parse.",
      fix: "Fix JSON syntax.",
      evidence: { packageJsonPath: p, error: String(e) },
    });
    return section;
  }

  const scripts = pkg.scripts ?? {};
  if (!scripts["build"]) section.findings.push({
    id: "package.scripts.build",
    title: "No build script",
    severity: "ERROR",
    details: "Deployments typically run `npm run build`. Missing build script breaks CI/CD.",
    fix: "Add build script (Next: `next build`, Vite: `vite build`, custom: `tsc -p tsconfig.json`).",
    evidence: { scripts },
  });

  if (!scripts["dev"]) section.findings.push({
    id: "package.scripts.dev",
    title: "No dev script",
    severity: "WARN",
    details: "Local development should be one command.",
    fix: "Add dev script (Next: `next dev`, Vite: `vite`).",
    evidence: { scripts },
  });

  const lockfiles = ["package-lock.json","yarn.lock","pnpm-lock.yaml"];
  const present = lockfiles.filter((f)=> exists(path.join(root,f)));
  if (present.length === 0) section.findings.push({
    id: "package.lockfile.missing",
    title: "No lockfile found",
    severity: "WARN",
    details: "No lockfile means dependency versions drift across machines/CI and you get random breakage.",
    fix: "Commit a lockfile. Use npm/yarn/pnpm consistently.",
    evidence: { checked: lockfiles },
  });

  if (!pkg.engines?.node) section.findings.push({
    id: "package.engines.node",
    title: "No Node engine pinned",
    severity: "INFO",
    details: "Node version mismatches are a top cause of prod-only failures.",
    fix: "Add `engines: { node: '>=18' }` and optionally `.nvmrc`.",
    evidence: { engines: pkg.engines ?? null },
  });

  return section;
}
