import { prisma } from "@/lib/prisma";
import { audit } from "@/lib/audit";
import { requireAdmin } from "../../../_guard";

export async function PUT(req: Request, { params }:{ params:{ id:string } }){
  const g = await requireAdmin();
  if(!g.ok) return new Response("Forbidden", { status: g.status });

  const settings = await req.json();
  const before = await prisma.salonMembership.findUnique({ where:{ id: params.id } });
  const updated = await prisma.salonMembership.update({ where:{ id: params.id }, data:{ settings } });
  await audit({
  actor: { id: g.user!.id, role: g.user!.role },
  action: "SALON_MEMBER_SETTINGS_UPDATED",
  entityType: "SALON_MEMBERSHIP",
  entityId: updated.id,
  before,
  after: updated,
  ip: req.headers.get("x-forwarded-for"),
  userAgent: req.headers.get("user-agent"),
});
return Response.json({ ok:true, settings: updated.settings });
}
