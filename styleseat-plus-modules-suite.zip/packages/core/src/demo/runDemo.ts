import { InMemoryAuditLogger } from "../obs/audit.js";
import { FeatureFlagService } from "../experiments/featureFlags.js";
import { ABTestingService } from "../experiments/abTesting.js";
import { ConsentStore } from "../compliance/consent.js";
import { CampaignService } from "../marketing/campaigns.js";
import { AttributionStore } from "../marketing/attribution.js";
import { segmentAudience } from "../marketing/segments.js";
import { SocialScheduler } from "../social/socialAutomation.js";
import { NotificationCenter } from "../notifications/notifications.js";
import { AutomationService } from "../automation/automation.js";
import { TeamService } from "../team/team.js";
import { exportCSV } from "../analytics/reporting.js";
import { buildDashboard } from "../analytics/kpis.js";

const clock = { now: () => new Date() };
const nowISO = () => clock.now().toISOString();

const audit = new InMemoryAuditLogger();

const flags = new FeatureFlagService([
  { key: "new_checkout", enabled: true, rule: { percentage: 50 }, variants: [{ id: "A", weight: 0.5 }, { id: "B", weight: 0.5 }] }
]);

const ab = new ABTestingService();

const consent = new ConsentStore();
const campaigns = new CampaignService();
const attribution = new AttributionStore();
const social = new SocialScheduler();
const notifications = new NotificationCenter(90);
const automation = new AutomationService();
const team = new TeamService();

const businessId = "biz_1";
const ownerId = "user_owner";
const clientA = "cl_1";
const clientB = "cl_2";

consent.grant(businessId, clientA, "sms_marketing", nowISO());
consent.grant(businessId, clientA, "email_marketing", nowISO());
consent.grant(businessId, clientB, "email_marketing", nowISO());

const tpl = campaigns.createTemplate({ channel: "sms", name: "Winback SMS", body: "Hey {{name}}, we miss you. Rebook and save {{offer}}.", previewText: "We miss you" });
const seg = { id: "seg_1", businessId, name: "Inactive 45d", rules: [{ op: "inactive_days_gte", value: 45, now: nowISO() }] as any };
const cmp = campaigns.createCampaign({ businessId, name: "Winback 45d", channel: "sms", templateId: tpl.id, segmentId: seg.id, enabled: true });

automation.createRule({
  businessId, name: "Inactive triggers winback", trigger: "client.inactive", enabled: true,
  actions: [{ kind: "send_campaign", campaignId: cmp.id }, { kind: "create_notification", userId: ownerId, title: "Win-back campaign triggered" }]
});

const clients = [
  { clientId: clientA, businessId, lastVisitAt: new Date(Date.now()-60*86400000).toISOString(), totalSpend: 1200, tags: ["vip"] },
  { clientId: clientB, businessId, lastVisitAt: new Date(Date.now()-10*86400000).toISOString(), totalSpend: 100 }
];

const audience = segmentAudience(clients as any, seg as any);
console.log("Segment audience:", audience);

const fired = automation.fire(businessId, "client.inactive", { audience }, nowISO());
console.log("Automation fired:", fired.map(f => ({ ruleId: f.ruleId, actions: f.actions.length })));

const messenger = {
  async send(channel: any, toId: any, template: any, vars: any) {
    // consent gate for marketing
    if (channel === "sms") {
      const ok = consent.require(businessId, toId, "sms_marketing");
      if (!ok.ok) return ok as any;
    }
    return { ok: true, data: true } as any;
  }
};

campaigns.runCampaign({ campaignId: cmp.id, audience, at: nowISO(), vars: { name: "friend", offer: "20%" } }, messenger as any).then(r => {
  console.log("Campaign run:", r);
});

// Social scheduling
social.schedulePost({ businessId, platform: "instagram", body: "New slots open this week. Book now.", scheduledAt: new Date(Date.now()+1000).toISOString() });
console.log("Scheduled social posts:", social.listPosts(businessId).length);

// Notifications
notifications.push({ businessId, userId: ownerId, type: "campaign.sent", title: "Winback sent", body: "Sent to inactive clients", createdAt: nowISO() });
console.log("Badge count:", notifications.badgeCount(ownerId, businessId));

// Team / location
const loc = team.createLocation({ businessId, name: "Downtown" });
const stylist = team.addMember({ businessId, locationId: loc.id, name: "Maya", role: "stylist", commissionRate: 0.55 });
console.log("Team members:", team.listMembers(businessId).length);

// Reporting export demo
const reportSrc = {
  async bookings() { return [{ bookingId: "bk_1", clientId: clientA, total: 120, at: nowISO() }]; },
  async payments() { return [{ paymentId: "pay_1", amount: 120, status: "succeeded" }]; },
  async clients() { return clients as any; },
  async campaigns() { return campaigns.listSends(businessId, 50) as any; },
  async payouts() { return [{ payoutId: "po_1", amount: 60, status: "scheduled" }]; }
};

exportCSV(reportSrc as any, "clients", businessId, new Date(Date.now()-30*86400000).toISOString(), nowISO()).then(out => {
  console.log("CSV filename:", out.filename);
  console.log(out.csv.split("\n")[0] + " ...");
});

// Dashboard demo
const kpiSrc = {
  async revenueSeries(biz: string, since: string) { return { key: "revenue", label: "Revenue", unit: "USD", points: [{ at: since, value: 1000 }, { at: nowISO(), value: 1800 }] }; },
  async bookingsSeries(biz: string, since: string) { return { key: "bookings", label: "Bookings", points: [{ at: since, value: 10 }, { at: nowISO(), value: 18 }] }; },
  async cancellationsSeries(biz: string, since: string) { return { key: "cancellations", label: "Cancellations", points: [{ at: since, value: 1 }, { at: nowISO(), value: 2 }] }; },
  async newClientsSeries(biz: string, since: string) { return { key: "new_clients", label: "New Clients", points: [{ at: since, value: 3 }, { at: nowISO(), value: 5 }] }; },
};

buildDashboard(kpiSrc as any, businessId, new Date(Date.now()-30*86400000).toISOString()).then(d => {
  console.log("Dashboard series keys:", d.series.map(s => s.key));
});

console.log("Feature flag new_checkout enabled for clientA:", flags.isEnabled("new_checkout", clientA), "variant:", flags.variant("new_checkout", clientA));
