# runtime/
Schema-locked generation + tool routing.

Run:
```bash
pnpm i
pnpm dev
```

POST:
- http://localhost:7777/generate

Modes:
- `controlled` = schema-locked JSON output (with 1 repair attempt)
- `tools`      = model requests ONE tool call (schema: toolcall), runtime executes it, then model produces final report
