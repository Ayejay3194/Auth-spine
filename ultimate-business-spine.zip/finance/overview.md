FINANCE MODULES
===============

- Ledger (double-entry)
- Invoicing + estimates + receipts
- Expenses + receipts
- Banking sync + reconciliation
- Reporting (P&L, Balance Sheet, Cash Flow)
- Payroll hooks + exports
- Sales tax tracking hooks
- Accountant packet export
