# Security Non-Negotiables (Launch Blockers)

## Authentication & Access
- [ ] HTTPS/TLS for all traffic
- [ ] Passwords >= 12 chars
- [ ] Sessions: secure cookies + timeouts
- [ ] Brute force protection: rate limit + lockouts
- [ ] Password hashing: Argon2/bcrypt/scrypt

## Data Protection
- [ ] Sensitive data encrypted at rest
- [ ] TLS 1.2+ (prefer 1.3)
- [ ] No hardcoded secrets
- [ ] KMS/Vault/Secrets manager
- [ ] Encrypted automated backups + restore tested

## App Security Basics
- [ ] Input validation on all inputs
- [ ] Parameterized queries (no string SQL)
- [ ] XSS protection + CSP
- [ ] CSRF tokens for state changes
- [ ] No stack traces in prod

## Infra Essentials
- [ ] Firewall: only required ports
- [ ] Network segmentation: internal services private
- [ ] Patch management
- [ ] Directory listing disabled
- [ ] No default credentials
- [ ] Least privilege

## Code & Deployment
- [ ] No secrets in Git (scan)
- [ ] Separate dev/staging/prod
- [ ] Debug disabled in prod
- [ ] Remove test endpoints
- [ ] Dependency vuln scan
- [ ] Code review required

## Logging & Monitoring
- [ ] Auth/permission failures logged
- [ ] Monitoring + alerts
- [ ] Incident response plan exists
- [ ] Logs sanitized

## Compliance Basics
- [ ] Privacy policy
- [ ] Terms of service
- [ ] GDPR/CCPA posture if applicable
- [ ] User deletion capability
- [ ] Consent mechanisms

## API Security
- [ ] Auth: OAuth2/JWT/API keys
- [ ] Rate limiting
- [ ] API versioning
- [ ] Input validation

## Critical Headers
- [ ] HSTS
- [ ] nosniff
- [ ] X-Frame-Options
- [ ] CSP

## Database Security
- [ ] DB not public
- [ ] DB creds not in code
- [ ] Encrypted DB connections
- [ ] DB backups

## File Upload Security
- [ ] Type + size validation
- [ ] Malware scanning
- [ ] Store outside web root / no-exec
