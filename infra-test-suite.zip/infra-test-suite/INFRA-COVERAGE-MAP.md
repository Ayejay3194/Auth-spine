# Coverage Map: Your 15 Infrastructure Guideline Areas → Tests

1. Architecture & Design Principles
- `scripts/unit.mjs`: baseline policy sanity + anti-footgun scans
- Add ADR checks in `/docs/adr` (optional)

2. Computing Resources
- IaC scans via `scripts/iac.mjs` (terraform + checkov + tflint)
- Add K8s resource limits policies in `policy/opa`

3. Network Architecture
- IaC static analysis (checkov)
- Add explicit CIDR/subnet assertions via OPA policies

4. Data Storage & Databases
- DR runbooks required (`runbooks/backup-restore.md`)
- Add restore drill in `scripts/drills/restore-drill.sh`

5. Security Infrastructure
- `scripts/security.mjs`: deps vulns, secrets, headers heuristics
- Add WAF/TLS checks via IaC scanners + policies

6. Monitoring & Observability
- `scripts/observability.mjs`: promtool/amtool validation
- Add tracing checks: require trace_id/span_id fields

7. Deployment & CI/CD
- `.github/workflows/infra-tests.yml`
- Extend with SAST + container build scans

8. Disaster Recovery & Business Continuity
- `scripts/disaster-recovery.mjs` requires runbooks + drill hook

9. Performance & Optimization
- Add k6 tests in `/perf` (placeholder)
- Add query plan checks for DB (stack-specific)

10. Cost Management
- `scripts/cost.mjs` tags heuristic + budget docs required

11. Compliance & Governance
- `scripts/compliance.mjs` checks evidence pack presence

12. Service Mesh & API Management
- Add gateway config lint tests (OpenAPI validation, rate-limit policies)

13. Development & Testing Infrastructure
- This repo itself is the “infra test harness”
- Add preview env checks (stack-specific)

14. Documentation & Knowledge Management
- Runbooks + compliance docs enforced by tests

15. Team Structure & Responsibilities
- Add OWNERS/oncall docs checks (optional): `docs/oncall.md`, `CODEOWNERS`
