-- Audit Trail Pattern (trigger-based)
-- Logs before/after row JSONB + actor + ip (pass ip via set_config in your API layer)

create table if not exists public.audit_log (
  id bigserial primary key,
  occurred_at timestamptz not null default now(),
  table_name text not null,
  action text not null, -- INSERT/UPDATE/DELETE
  record_pk text,
  actor_user_id uuid,
  actor_role text,
  actor_ip inet,
  before_row jsonb,
  after_row jsonb
);

create index if not exists audit_log_table_time_idx on public.audit_log(table_name, occurred_at desc);

create or replace function public.audit_trigger()
returns trigger language plpgsql as $$
declare
  v_actor uuid := nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
  v_role  text := nullif(current_setting('request.jwt.claim.role', true), '');
  v_ip    inet := nullif(current_setting('request.ip', true), '')::inet;
  v_pk    text;
begin
  -- best-effort primary key extraction (assumes 'id' exists; customize as needed)
  if (tg_op = 'DELETE') then
    v_pk := coalesce(old.id::text, null);
    insert into public.audit_log(table_name, action, record_pk, actor_user_id, actor_role, actor_ip, before_row)
    values (tg_table_name, tg_op, v_pk, v_actor, v_role, v_ip, to_jsonb(old));
    return old;
  elsif (tg_op = 'UPDATE') then
    v_pk := coalesce(new.id::text, null);
    insert into public.audit_log(table_name, action, record_pk, actor_user_id, actor_role, actor_ip, before_row, after_row)
    values (tg_table_name, tg_op, v_pk, v_actor, v_role, v_ip, to_jsonb(old), to_jsonb(new));
    return new;
  else
    v_pk := coalesce(new.id::text, null);
    insert into public.audit_log(table_name, action, record_pk, actor_user_id, actor_role, actor_ip, after_row)
    values (tg_table_name, tg_op, v_pk, v_actor, v_role, v_ip, to_jsonb(new));
    return new;
  end if;
end;
$$;

-- Example attach:
-- drop trigger if exists trg_audit_example on public.example;
-- create trigger trg_audit_example
-- after insert or update or delete on public.example
-- for each row execute function public.audit_trigger();
