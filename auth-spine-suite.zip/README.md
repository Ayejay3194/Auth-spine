# Auth Spine Suite (TypeScript)

A reusable **Auth Spine** with the missing “senior” pieces:
- AuthContext boundary
- Account state machine
- Step-up auth
- Session revocation reasons
- Auth profiles/capabilities
- Device trust model
- Auth event bus contracts
- Compliance hooks (GDPR export/delete stubs)
- Typed auth error taxonomy

## Run
```bash
corepack enable
corepack prepare pnpm@9.0.0 --activate
pnpm i
pnpm type-check
pnpm demo
```
