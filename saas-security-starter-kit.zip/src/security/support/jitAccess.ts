import { audit } from "../observability/audit";

export type JitGrant = {
  id: string;
  tenantId: string;
  actorId: string;
  approvedBy: string;
  reason: string;
  expiresAt: string;
  scopes: string[];
};

const grants = new Map<string, JitGrant>();

export async function requestJitAccess(input: Omit<JitGrant, "id">) {
  const id = globalThis.crypto?.randomUUID?.() ?? (Date.now()+"_"+Math.random().toString(16).slice(2));
  const g: JitGrant = { id, ...input };
  grants.set(id, g);
  await audit({ event: "support_jit_requested", tenantId: g.tenantId, actorId: g.actorId, meta: g });
  return g;
}

export async function assertJitActive(grantId: string) {
  const g = grants.get(grantId);
  if (!g) throw new Error("JIT_NOT_FOUND");
  if (Date.parse(g.expiresAt) <= Date.now()) throw new Error("JIT_EXPIRED");
  return g;
}

export async function revokeJit(grantId: string, revokedBy: string) {
  const g = grants.get(grantId);
  if (!g) return;
  grants.delete(grantId);
  await audit({ event: "support_jit_revoked", tenantId: g.tenantId, actorId: revokedBy, meta: { grantId } });
}
