export type SsoProvider = "saml" | "ldap";

export type SamlConfig = {
  provider: "saml";
  entityId: string;
  ssoUrl: string;
  x509Cert: string;
  attributeMap: Record<string,string>; // { email: "mail", name: "displayName" }
};

export type LdapConfig = {
  provider: "ldap";
  url: string;
  baseDn: string;
  bindDn: string;
  bindPasswordRef: string; // reference to secret storage
  userFilter: string;      // e.g. "(mail={{email}})"
};

export type SsoConfig = SamlConfig | LdapConfig;

export interface SsoService {
  startLogin(orgId: string): Promise<{ redirectUrl: string }>;
  handleCallback(orgId: string, payload: unknown): Promise<{ userId: string }>;
}
