import type { Tone } from "./tones";

export type TemplateKey =
  | "BOOK_CONFIRM"
  | "ASK_MISSING"
  | "AVAILABILITY"
  | "RESCHEDULE_CONFIRM"
  | "CANCEL_CONFIRM"
  | "PAYMENT_LINK"
  | "REFUND_STATUS"
  | "ERROR_GENERIC";

export type TemplateVars = Record<string, string | number | undefined>;

type TemplateSet = Record<TemplateKey, string[]>;

const friendly: TemplateSet = {
  BOOK_CONFIRM: [
    "Booked. {service} on {date} at {time}.",
    "You’re set for {service} on {date} at {time}.",
    "Done. {service} is scheduled for {date} at {time}."
  ],
  ASK_MISSING: [
    "Quick one: I need {missing} to finish that.",
    "What should I use for {missing}?",
    "To lock this in, tell me {missing}."
  ],
  AVAILABILITY: [
    "Here’s what’s open for {service} {date}: {slots}.",
    "Openings for {service} on {date}: {slots}.",
    "I can do {service} {date}. Pick one: {slots}."
  ],
  RESCHEDULE_CONFIRM: [
    "Moved. New time: {date} at {time}.",
    "Rescheduled to {date} at {time}.",
    "Done. I shifted it to {date} {time}."
  ],
  CANCEL_CONFIRM: [
    "Canceled. You’re all set.",
    "Done, I canceled it.",
    "Canceled. If you want, we can rebook anytime."
  ],
  PAYMENT_LINK: [
    "Here’s your payment link: {url}",
    "Pay here when you’re ready: {url}",
    "Payment link: {url}"
  ],
  REFUND_STATUS: [
    "Refund requested. I’ll update you when it’s processed.",
    "Got it. Refund is in progress.",
    "Refund request submitted."
  ],
  ERROR_GENERIC: [
    "I hit a snag. Try again in a moment.",
    "Something didn’t go through. Try again.",
    "That didn’t work on my end. One more time?"
  ],
};

const templatesByTone: Record<Tone, TemplateSet> = {
  friendly,
  neutral: friendly,
  urgent: {
    ...friendly,
    BOOK_CONFIRM: [
      "Confirmed: {service} on {date} at {time}.",
      "Locked in: {service} {date} {time}.",
      "{service} is confirmed for {date} at {time}."
    ]
  },
  apologetic: {
    ...friendly,
    ERROR_GENERIC: [
      "Sorry. That didn’t go through. Try again.",
      "My bad, I couldn’t complete that. Try again.",
      "Sorry, something failed on my side. One more try."
    ]
  },
  firm: {
    ...friendly,
    REFUND_STATUS: [
      "Refund request submitted. Processing times vary by bank.",
      "Refund request filed. You’ll get a confirmation when processed.",
      "Refund initiated. You’ll see it after processing completes."
    ]
  }
};

export function renderTemplate(tone: Tone, key: TemplateKey, vars: TemplateVars) {
  const set = templatesByTone[tone][key] ?? templatesByTone.friendly[key];
  const t = set[Math.floor(Math.random() * set.length)];
  return t.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? `{${k}}`));
}
