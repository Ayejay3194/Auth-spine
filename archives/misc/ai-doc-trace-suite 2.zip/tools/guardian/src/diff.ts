import type { Manifest, DiffResult, DiffItem } from "./types.js";
function mapByPath(entries: Manifest["entries"]) {
  const m = new Map<string, Manifest["entries"][number]>();
  for (const e of entries) m.set(e.path, e);
  return m;
}
export function diffManifests(before: Manifest, after: Manifest): DiffResult {
  const b = mapByPath(before.entries);
  const a = mapByPath(after.entries);
  const changed: DiffItem[] = [];
  const all = new Set([...b.keys(), ...a.keys()]);
  for (const p of [...all].sort()) {
    const be = b.get(p); const ae = a.get(p);
    if (be && !ae) changed.push({ path: p, status: "deleted", before: be });
    else if (!be && ae) changed.push({ path: p, status: "added", after: ae });
    else if (be && ae && be.sha256 !== ae.sha256) changed.push({ path: p, status: "modified", before: be, after: ae });
  }
  return { createdAt: new Date().toISOString(), changed };
}
