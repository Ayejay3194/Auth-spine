# Incident Response Runbook

## Severity
- SEV0: Full outage / active breach
- SEV1: Major degradation / high-risk vuln
- SEV2: Limited impact
- SEV3: Minor issue

## First 10 Minutes
- Assign IC (incident commander)
- Stabilize: rollback/feature-flag/offline dependency
- Preserve evidence (logs, snapshots)
- Open status page incident (if customer impact)

## Communications
- Internal updates every 15 minutes (SEV0/1)
- Customer updates every 30-60 minutes (SEV0/1)
- Use a single source of truth doc

## Post-Incident
- 5-Whys + timeline
- Action items with owners + deadlines
- Customer-facing postmortem when appropriate
