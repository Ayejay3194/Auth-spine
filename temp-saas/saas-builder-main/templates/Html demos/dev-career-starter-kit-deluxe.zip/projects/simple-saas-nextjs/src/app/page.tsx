import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center gap-6">
      <h1 className="text-3xl font-semibold">Simple SaaS Starter</h1>
      <p className="text-slate-300 max-w-md text-center">
        This is a minimal full-stack starter. Your job is to add auth, projects,
        and a real dashboard.
      </p>
      <div className="flex gap-4">
        <Link
          href="/sign-in"
          className="px-4 py-2 rounded bg-slate-100 text-slate-950 text-sm font-medium"
        >
          Sign in
        </Link>
        <Link
          href="/sign-up"
          className="px-4 py-2 rounded border border-slate-500 text-sm"
        >
          Sign up
        </Link>
      </div>
    </main>
  );
}
