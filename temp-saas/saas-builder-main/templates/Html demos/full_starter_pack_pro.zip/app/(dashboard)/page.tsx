export default function DashboardHome() {
  return (
    <section className="space-y-4">
      <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
      <p className="text-sm text-muted-foreground">
        This is a starter dashboard view. Replace this with your real metrics and widgets.
      </p>
    </section>
  );
}
