# Pre-commit guardrails (Husky)
Hooks:
- lint-staged: prettier + eslint
- typecheck: tsc --noEmit
- secret scan: gitleaks/trufflehog (fast)

Also nice:
- commit-msg: conventional commits
