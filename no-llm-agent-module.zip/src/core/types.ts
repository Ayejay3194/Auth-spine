export type UserId = string;
export type Role = "user" | "admin";

export interface AgentContext {
  userId: UserId;
  role: Role;
  locale?: string;
  timezone?: string;
  ip?: string;
  userAgent?: string;
}

export interface AuditEvent {
  at: Date;
  userId: UserId;
  role: Role;
  type:
    | "intent.detected"
    | "slot.asked"
    | "slot.filled"
    | "tool.called"
    | "tool.result"
    | "tool.error"
    | "flow.completed"
    | "flow.failed";
  details: Record<string, unknown>;
}

export interface AuditLogger { write(ev: AuditEvent): Promise<void>; }
export interface Clock { now(): Date; }

export interface AgentReply {
  text: string;
  ui?: { type: "form" | "choices" | "link"; data: unknown };
  done?: boolean;
}
