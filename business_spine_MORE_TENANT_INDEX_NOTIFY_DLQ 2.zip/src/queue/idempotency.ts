/**
 * Minimal idempotency helper.
 * In production: store in Redis with SETNX + TTL.
 * Here: naive in-memory fallback.
 */
const mem = new Map<string, number>();

export const idempotency = {
  async claim(key: string, ttlSeconds: number) {
    const now = Date.now();
    const exp = mem.get(key);
    if (exp && exp > now) return false;
    mem.set(key, now + ttlSeconds * 1000);
    return true;
  },
};
