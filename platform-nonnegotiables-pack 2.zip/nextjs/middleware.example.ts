import type { NextRequest } from "next/server";
import { withSecurityHeaders } from "./security-headers";

export function middleware(req: NextRequest) {
  return withSecurityHeaders(req);
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
