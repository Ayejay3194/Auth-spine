export type SessionRevocationReason =
  | "USER_LOGOUT"
  | "PASSWORD_CHANGED"
  | "EMAIL_CHANGED"
  | "ADMIN_FORCED"
  | "SUSPICIOUS_ACTIVITY"
  | "EXPIRED";

export interface SessionRecord {
  id: string;
  userId: string;
  deviceId?: string;
  ip?: string;
  userAgent?: string;
  createdAt: string;
  lastSeenAt: string;
  expiresAt?: string;
  revokedAt?: string;
  revokedReason?: SessionRevocationReason;
  revokedBy?: string;
}

export interface SessionStore {
  create(s: Omit<SessionRecord, "createdAt" | "lastSeenAt">): Promise<SessionRecord>;
  byId(id: string): Promise<SessionRecord | null>;
  listByUser(userId: string): Promise<SessionRecord[]>;
  touch(id: string, lastSeenAt: string): Promise<void>;
  revoke(id: string, reason: SessionRecord["revokedReason"], revokedBy?: string, revokedAt?: string): Promise<void>;
  revokeAllForUser(userId: string, reason: SessionRecord["revokedReason"], revokedBy?: string): Promise<number>;
  enforceConcurrency(userId: string, max: number): Promise<void>;
}
