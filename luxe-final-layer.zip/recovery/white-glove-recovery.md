WHITE-GLOVE RECOVERY
====================

Automatic recovery actions:
- goodwill credit issuance
- silent service upgrade
- apology messaging with expiration
- internal log of goodwill spend

Rules:
- capped per user/month
- admin override required for large credits
