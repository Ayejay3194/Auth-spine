# Auditor CLI (v0.3.1)

Runs static checks + optional command execution and **optional local preview + route crawl**.

## Examples
```bash
node dist/cli.js --root ../.. --format md --out ../../audit-report.md
node dist/cli.js --root ../.. --run typecheck --run build --run lint --format md --out ../../audit-report.md
node dist/cli.js --root ../.. --serve auto --crawl --format md --out ../../audit-report.md
```
