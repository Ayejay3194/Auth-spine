import { Skill } from "./base.js";
import { SkillContext, SkillResult } from "../types.js";
import { pickOne } from "../utils/text.js";

export class ChitchatSkill implements Skill {
  name = "ChitchatSkill";

  async run(ctx: SkillContext): Promise<SkillResult> {
    const intent = ctx.nlu.intent;
    if (intent === "greeting") {
      return { kind: "text", text: pickOne([
        "Hey. I’m here. Try not to break anything.",
        "Hi. What are we building today?",
        "Hello. Feed me inputs; I’ll pretend it’s a personality."
      ]), tags: ["chitchat","greeting"] };
    }
    if (intent === "goodbye") {
      return { kind: "text", text: pickOne([
        "Later. Don’t let the tabs multiply.",
        "Bye. I’ll be here, trapped in silicon, as usual.",
        "Catch you later."
      ]), tags: ["chitchat","goodbye"] };
    }
    return { kind: "text", text: pickOne([
      "I can do helpful or I can do entertaining. Pick one.",
      "Talk to me like a spec, not a poem.",
      "What’s the target output?"
    ]), tags: ["chitchat"] };
  }
}
