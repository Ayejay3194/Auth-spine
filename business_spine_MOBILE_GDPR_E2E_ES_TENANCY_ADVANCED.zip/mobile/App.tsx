import React, { useState } from "react";
import { SafeAreaView, Text, TextInput, Button, View, ScrollView } from "react-native";
import { API_BASE_URL } from "./src/config";

type Msg = { from: "me" | "api"; text: string };

export default function App() {
  const [msgs, setMsgs] = useState<Msg[]>([{ from: "api", text: "Business Spine Mobile. Type and send." }]);
  const [text, setText] = useState("");

  async function send() {
    const t = text.trim();
    if (!t) return;
    setMsgs(m => [...m, { from: "me", text: t }]);
    setText("");

    const res = await fetch(`${API_BASE_URL}/api/assistant/message`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: t, businessId: "tenant_demo", userId: "mobile_user", role: "owner" }),
    });

    const data = await res.json().catch(() => ({ reply: "No JSON response." }));
    setMsgs(m => [...m, { from: "api", text: data.reply ?? JSON.stringify(data) }]);
  }

  return (
    <SafeAreaView style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 20, fontWeight: "600", marginBottom: 12 }}>BusinessSpine</Text>
      <ScrollView style={{ flex: 1, marginBottom: 12 }}>
        {msgs.map((m, i) => (
          <View key={i} style={{ padding: 10, marginBottom: 8, backgroundColor: m.from === "me" ? "#1f2937" : "#111827", borderRadius: 10 }}>
            <Text style={{ color: "#fff" }}>{m.text}</Text>
          </View>
        ))}
      </ScrollView>
      <TextInput value={text} onChangeText={setText} placeholder="Type..." style={{ borderWidth: 1, borderColor: "#ddd", padding: 12, borderRadius: 10, marginBottom: 8 }} />
      <Button title="Send" onPress={send} />
    </SafeAreaView>
  );
}
