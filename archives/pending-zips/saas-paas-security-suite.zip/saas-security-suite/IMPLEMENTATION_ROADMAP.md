# Implementation Roadmap (Practical)

## Phase 0 (Week 0-2): Stop-the-bleeding essentials
- Tenant context validation + DB RLS (if multi-tenant)
- Central auth (JWT/OIDC) + RBAC/scopes
- Secrets management + rotation baseline
- Audit logs for auth/admin/data access
- Rate limiting + WAF rules
- Backups + restore test

## Phase 1 (Month 1-2): Operate like an adult
- SLOs/SLIs + alerting, on-call, incident runbooks
- Webhook hardening (sig verify, replay protection, DLQ)
- Data export/import with access logging
- Support JIT access + impersonation w/ consent + logging

## Phase 2 (Quarter 1): Compliance-ready posture
- Change management + CI guardrails
- Vulnerability scanning + patch SLAs
- Formal policies (AC, IR, DR, vendor risk, retention)
- Evidence collection cadence (SOC2-ready)

## Phase 3 (Ongoing): Enterprise features
- SSO (SAML/OIDC), SCIM
- BYOK / customer-managed keys (where needed)
- Dedicated infra options + per-tenant regions
