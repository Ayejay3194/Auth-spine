# EMAIL & NOTIFICATION DISASTERS

## Email Problems

- [ ] Emails going to spam
- [ ] No SPF record
- [ ] No DKIM signing
- [ ] No DMARC policy
- [ ] Shared IP with bad reputation
- [ ] No email authentication
- [ ] Sending rate too high
- [ ] Bounce rate too high
- [ ] Complaint rate too high
- [ ] Sending to invalid addresses
- [ ] No email validation
- [ ] No unsubscribe link
- [ ] Unsubscribe not working
- [ ] Sending to unsubscribed users
- [ ] No email preferences
- [ ] HTML emails not rendering
- [ ] Plain text version missing
- [ ] Email templates broken on mobile
- [ ] Personalization tokens showing raw
- [ ] Wrong email content sent
- [ ] Duplicate emails sent
- [ ] Emails never sent
- [ ] No delivery confirmation
- [ ] No bounce handling
- [ ] Hard bounces not removed from list

## Notification Issues

- [ ] Too many notifications
- [ ] Notification spam
- [ ] Duplicate notifications
- [ ] Notifications for wrong user
- [ ] Critical notifications not sent
- [ ] Notification delays
- [ ] Notifications arrive out of order
- [ ] Cannot disable notifications
- [ ] No notification preferences
- [ ] Notifications not marked as read
- [ ] Old notifications never cleaned
- [ ] Notification badges wrong count
- [ ] Push notifications not working
- [ ] Push notification permissions not requested
- [ ] SMS notifications too expensive
- [ ] SMS encoding issues
- [ ] SMS length issues (split messages)

---
