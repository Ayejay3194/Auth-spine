export type ESConfig = { node: string; apiKey?: string };

export interface ElasticsearchClient {
  index(index: string, id: string, doc: any): Promise<void>;
  bulk(ops: any[]): Promise<void>;
  search(index: string, query: any): Promise<any>;
}

export class StubElasticsearchClient implements ElasticsearchClient {
  async index() {}
  async bulk() {}
  async search() { return { hits: { total: 0, hits: [] } }; }
}
