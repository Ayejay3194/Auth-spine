import { describe, it, expect } from "vitest";
import { resolve } from "../src/resolver.js";
import { composeMarkdown } from "../src/composer.js";
import { RepetitionMemory } from "../src/memory.js";

const nodes = [
  { id:"hd:type:generator", kind:"hd:type", title:"Generator", summary:"Aura: Open + enveloping", tags:["hd"], aliases:[], links:[] },
  { id:"hd:authority:sacral", kind:"hd:authority", title:"Sacral Authority", summary:"Respond from the gut.", tags:["hd"], aliases:["sacral authority"], links:[] },
  { id:"biz:policy:no-show", kind:"biz:policy", title:"No-Show Policy", summary:"Deposits + reminders + fair reschedule windows.", tags:["biz"], aliases:[], links:[] },
] as any[];

describe("golden resolver + composer", () => {
  it("stays deterministic", () => {
    const mem = new RepetitionMemory();
    const r = resolve(nodes, { intents:["hd:type","hd:authority"], text:"generator", preferTags:["hd"] }, { limit: 2, memory: mem });
    const md = composeMarkdown(r.selected, { title:"Test Reading", includeCitations:false, memory: new RepetitionMemory() });
    expect(r.selected.map(n => n.id)).toEqual(["hd:type:generator","hd:authority:sacral"]);
    expect(md).toContain("# Test Reading");
    expect(md).toContain("## Generator");
  });
});
