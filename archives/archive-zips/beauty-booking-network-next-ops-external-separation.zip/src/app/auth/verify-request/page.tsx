import { Container } from "@/components/Container";

export default function VerifyRequest(){
  return (
    <main className="py-14">
      <Container>
        <div className="mx-auto max-w-lg rounded-[28px] border p-8" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
          <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Magic link</div>
          <h1 className="serif mt-2 text-3xl">Check your email.</h1>
          <p className="mt-2 text-sm" style={{color:"var(--muted)"}}>If it’s not there, blame spam filters. They’re needy.</p>
        </div>
      </Container>
    </main>
  );
}
