import { RequestContext } from "../types";

export type ToolBudget = {
  maxToolCalls: number; // per request
  maxTotalMs: number;   // total tool runtime allowed
};

export type ToolCallRecord = {
  name: string;
  startedAt: number;
  endedAt?: number;
};

export class ToolBudgetManager {
  private budget: ToolBudget;
  private start = Date.now();
  private calls: ToolCallRecord[] = [];

  constructor(budget: ToolBudget) {
    this.budget = budget;
  }

  beforeTool(name: string) {
    if (this.calls.length >= this.budget.maxToolCalls) {
      throw new Error(`Tool budget exceeded: maxToolCalls=${this.budget.maxToolCalls}`);
    }
    if ((Date.now() - this.start) > this.budget.maxTotalMs) {
      throw new Error(`Time budget exceeded: maxTotalMs=${this.budget.maxTotalMs}`);
    }
    const rec: ToolCallRecord = { name, startedAt: Date.now() };
    this.calls.push(rec);
    return rec;
  }

  afterTool(rec: ToolCallRecord) {
    rec.endedAt = Date.now();
  }

  snapshot() {
    return {
      budget: this.budget,
      totalMs: Date.now() - this.start,
      calls: this.calls.map(c => ({ ...c, durationMs: (c.endedAt ?? Date.now()) - c.startedAt })),
    };
  }
}

export function attachToolBudget(ctx: RequestContext, budget: ToolBudget) {
  (ctx as any).__toolBudget = new ToolBudgetManager(budget);
  return ctx;
}

export function getToolBudget(ctx: RequestContext): ToolBudgetManager | null {
  return (ctx as any).__toolBudget ?? null;
}
