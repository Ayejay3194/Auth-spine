# Rollback Playbook

## Goal
Rollback in **< 5 minutes**.

## Git
```bash
git fetch --tags
git checkout <KNOWN_GOOD_TAG>
```
Rebuild + redeploy.

## Docker example
```bash
docker tag your-app:latest your-app:bad
docker tag your-app:<KNOWN_GOOD_TAG> your-app:latest
docker compose up -d
```

## Verify
- /health 200
- auth works
- protected endpoints still deny unauthorized users
