# Separation Model (Public vs Studio vs Ops)

## Recommended
- **Public**: `app.domain.com`
  - marketing, discovery, stylist profile pages, booking initiation
- **Studio**: `studio.domain.com` (optional but clean)
  - stylist tools: services, availability, portfolio, client list
- **Ops**: `ops.domain.com`
  - admin tools: payouts, disputes, refunds, support console, analytics, audit

## Hard controls
1. **Host-based routing blocks**
   - Ops endpoints and pages must 404 on public host (edge middleware + server guard)
2. **Separate cookies**
   - Session cookie scope should not be shared across all subdomains unless you know what you’re doing
3. **Separate auth clients**
   - Distinct callback URLs and secrets for ops vs public
4. **DB least privilege**
   - Separate DB users: public cannot read ops-only tables

## Ops surfaces to block on public host
- `/ops/*`
- `/admin/*`
- `/salon-admin/*`
- `/api/ops/*`

## Studio surfaces to optionally isolate
- `/studio/*`
- `/api/studio/*`
