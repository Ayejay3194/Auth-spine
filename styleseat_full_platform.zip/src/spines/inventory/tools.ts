// inventory tools.ts
