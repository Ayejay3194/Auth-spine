CULTURAL SAFEGUARDS
===================

Non-negotiables:
- Do not optimize for volume over human well-being
- Policies are never weaponized
- Staff protection is a system responsibility
- Customers are treated with dignity even when wrong

These principles must be reflected in logic, not slogans.
