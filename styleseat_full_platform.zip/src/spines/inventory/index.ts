// inventory index.ts
