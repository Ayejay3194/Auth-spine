import { beforeAll, afterAll, describe, it, expect } from "vitest";
import request from "supertest";
import { startContainers, stopContainers, Started } from "../helpers/containers";
import "../helpers/env";

let started: Started;
const BASE_URL = process.env.INTEGRATION_BASE_URL ?? "http://localhost:3000";

describe("tenant isolation (template)", () => {
  beforeAll(async () => {
    started = await startContainers();
    process.env.DATABASE_URL = started.postgresUrl;
    process.env.REDIS_URL = started.redisUrl;
    // If using Prisma migrations in tests:
    // await (await import("../helpers/prisma")).prismaMigrate();
  });

  afterAll(async () => {
    await stopContainers(started);
  });

  it("Tenant A cannot read Tenant B record", async () => {
    const res = await request(BASE_URL)
      .get("/api/customers/customerB1")
      .set({ "x-tenant-id": "tenantA", "x-user-id": "userA", "x-role": "owner" });

    expect([401, 403, 404]).toContain(res.status);
  });
});
