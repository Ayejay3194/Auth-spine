MFA Enforcement Checklist

- Required for all roles
- Hardware keys preferred for ADMIN
- Backup codes stored hashed
- MFA enforced on login + sensitive actions
