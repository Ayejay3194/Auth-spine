# No-LLM Agent Module (TypeScript)
Deterministic "agentic assistant" module **without using an LLM**.

Includes:
- Intent detection (rules + lightweight similarity classifier)
- Entity extraction (regex + pluggable extractors)
- Slot-filling dialogue state machine (flows)
- Tool registry + permissions + validation + timeouts
- Audit logging hooks
- Example flows: forgot username, password reset request, GDPR export, plan change

## Run demo
```bash
corepack enable
corepack prepare pnpm@9.0.0 --activate
pnpm i
pnpm build
pnpm demo
```
