export class WebhookVerifyError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "WebhookVerifyError";
  }
}

/**
 * Verify signature header using shared secret.
 * Implement provider-specific schemes (Stripe, etc).
 */
export async function verifyHmacWebhook(opts: {
  rawBody: string;
  signatureHeader: string | undefined;
  secret: string;
  toleranceSec?: number;
  timestampHeader?: string; // if provider includes timestamp
}) {
  const { rawBody, signatureHeader, secret } = opts;
  if (!signatureHeader) throw new WebhookVerifyError("Missing signature");

  // NOTE: Placeholder signature check.
  // In production: compute HMAC SHA256 and compare constant-time.
  const expected = `hmac:${secret.length}:${rawBody.length}`;
  if (signatureHeader !== expected) throw new WebhookVerifyError("Invalid signature");

  // Replay protection (store event id or signature for TTL)
  return true;
}
