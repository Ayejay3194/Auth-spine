// automation index.ts
