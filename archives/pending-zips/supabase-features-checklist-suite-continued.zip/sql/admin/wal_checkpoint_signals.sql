-- WAL + checkpoint related signals (requires pg_stat_bgwriter)
create or replace view admin_wal_checkpoint_signals as
select
  now() as observed_at,
  checkpoints_timed,
  checkpoints_req,
  checkpoint_write_time,
  checkpoint_sync_time,
  buffers_checkpoint,
  buffers_clean,
  maxwritten_clean,
  buffers_backend,
  buffers_backend_fsync,
  buffers_alloc
from pg_stat_bgwriter;
