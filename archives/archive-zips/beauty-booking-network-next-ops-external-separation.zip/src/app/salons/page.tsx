import Link from "next/link";
import { Container } from "@/components/Container";
import { prisma } from "@/lib/prisma";

export default async function Salons(){
  const salons = await prisma.salon.findMany({ orderBy:{ createdAt:"desc" } });
  return (
    <main className="py-10">
      <Container>
        <div>
          <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Salons</div>
          <h1 className="serif mt-2 text-3xl">Organizations, not identities.</h1>
          <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>Salon pages are directories. Stylist pages are the “sites”.</div>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {salons.map(s => (
            <Link key={s.id} href={`/salons/${s.slug}`} className="overflow-hidden rounded-2xl border" style={{borderColor:"var(--border)", background:"var(--panel)"}}>
              <div className="h-36 w-full" style={{backgroundImage:`linear-gradient(to top, color-mix(in srgb, var(--bg) 75%, transparent), transparent), url(${s.coverUrl||""})`, backgroundSize:"cover", backgroundPosition:"center"}}/>
              <div className="p-4">
                <div className="serif text-lg">{s.name}</div>
                <div className="mt-1 text-sm" style={{color:"var(--muted)"}}>{s.area}</div>
                <div className="mt-3 text-xs tracking-[.18em] uppercase" style={{color:"var(--dim)"}}>★ {s.rating.toFixed(1)} · {s.hours}</div>
              </div>
            </Link>
          ))}
        </div>
      </Container>
    </main>
  );
}
