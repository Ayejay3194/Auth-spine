export type ToneCategory =
  | "snark" | "dry" | "corrective" | "amused" | "annoyed"
  | "sharp-care" | "boundary" | "confidence" | "meta" | "clarity";

export type Trigger =
  | "confusion" | "repetition" | "arrogance" | "insecurity" | "vague_question"
  | "overconfidence" | "underconfidence" | "curiosity" | "impatience"
  | "system_error" | "self_doubt" | "misuse" | "manipulation"
  | "analysis" | "scope_creep" | "missing_data" | "contradiction" | "misunderstanding";

export type RiskContext = "none" | "medical" | "legal" | "grief" | "panic" | "trauma";

export interface ToneLine {
  id: string;
  category: ToneCategory;
  trigger: Trigger;
  intensity: 1 | 2 | 3 | 4 | 5;
  text: string;
  notes?: string;
}

export interface ToneState {
  usedIds: Set<string>;
  lastIntensity?: number;
  lastCategory?: ToneCategory;
  sarcasmLock?: boolean;
}

export interface ToneDecisionInput {
  intent: string;
  trigger: Trigger;
  confidence: number;
  risk: RiskContext;
  maxLines?: number;
}

export interface ToneDecisionOutput {
  selected: ToneLine[];
  reason: string;
}
