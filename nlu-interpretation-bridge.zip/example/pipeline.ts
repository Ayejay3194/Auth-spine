
import { resolveSlots } from "../dialogue/slotManager";
import { interpret } from "../interpretation/engine";
import { composeResponse } from "../response/composer";

export function runPipeline(nlu) {
  const slotState = resolveSlots(nlu.intent, nlu.entities);

  if (!slotState.complete) {
    return `I need more information: ${slotState.missing.join(", ")}`;
  }

  const interpretation = interpret(nlu);
  return composeResponse(interpretation);
}
