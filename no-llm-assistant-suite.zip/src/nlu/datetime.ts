import { tokenize } from "./tokenize.js";

export interface ParsedDateTime {
  dateISO?: string;     // YYYY-MM-DD (in user's timezone assumption)
  time24?: string;      // HH:MM
  partOfDay?: "morning" | "afternoon" | "evening" | "night";
  range?: { startISO: string; endISO: string }; // date range inclusive-ish
}

const weekdays = ["sunday","monday","tuesday","wednesday","thursday","friday","saturday"] as const;
type Weekday = typeof weekdays[number];

function pad2(n: number) { return String(n).padStart(2, "0"); }

function nextWeekday(from: Date, target: Weekday): Date {
  const t = weekdays.indexOf(target);
  const d = new Date(from);
  const cur = d.getDay();
  let delta = (t - cur + 7) % 7;
  if (delta === 0) delta = 7;
  d.setDate(d.getDate() + delta);
  return d;
}

function toISODate(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
}

function parseTimeToken(tok: string): string | null {
  // 15:30
  const m1 = tok.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
  if (m1) return `${pad2(Number(m1[1]))}:${m1[2]}`;
  // 3pm / 12am
  const m2 = tok.match(/^([1-9]|1[0-2])(am|pm)$/);
  if (m2) {
    let h = Number(m2[1]);
    const ampm = m2[2];
    if (ampm === "am") { if (h === 12) h = 0; }
    else { if (h !== 12) h += 12; }
    return `${pad2(h)}:00`;
  }
  return null;
}

function parseMonthWord(tok: string): number | null {
  const m = ["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"];
  const i = m.indexOf(tok.slice(0,3));
  return i >= 0 ? i : null;
}

export function parseDateTime(text: string, now: Date): ParsedDateTime {
  const tokens = tokenize(text);
  const out: ParsedDateTime = {};

  // part of day
  if (tokens.includes("morning")) out.partOfDay = "morning";
  if (tokens.includes("afternoon")) out.partOfDay = "afternoon";
  if (tokens.includes("evening")) out.partOfDay = "evening";
  if (tokens.includes("tonight") || tokens.includes("night")) out.partOfDay = out.partOfDay ?? "night";

  // explicit ISO date
  const iso = text.match(/\b(20\d\d)-(\d\d)-(\d\d)\b/);
  if (iso) out.dateISO = iso[0];

  // today/tomorrow
  if (tokens.includes("today")) out.dateISO = toISODate(now);
  if (tokens.includes("tomorrow")) {
    const d = new Date(now); d.setDate(d.getDate()+1);
    out.dateISO = toISODate(d);
  }

  // next weekday
  const nextIdx = tokens.indexOf("next");
  if (nextIdx >= 0 && tokens[nextIdx+1]) {
    const wd = tokens[nextIdx+1] as Weekday;
    if (weekdays.includes(wd)) out.dateISO = toISODate(nextWeekday(now, wd));
  } else {
    for (const wd of weekdays) {
      if (tokens.includes(wd)) {
        // assume upcoming weekday (including next if same-day word used)
        out.dateISO = toISODate(nextWeekday(now, wd));
        break;
      }
    }
  }

  // month day e.g. dec 15
  for (let i=0;i<tokens.length-1;i++) {
    const mo = parseMonthWord(tokens[i]);
    const day = Number(tokens[i+1]);
    if (mo !== null && day >= 1 && day <= 31) {
      const d = new Date(now);
      d.setMonth(mo, day);
      // if already passed this year, bump year
      if (d.getTime() < now.getTime() - 24*3600*1000) d.setFullYear(d.getFullYear()+1);
      out.dateISO = toISODate(d);
      break;
    }
  }

  // time
  for (const t of tokens) {
    const tm = parseTimeToken(t);
    if (tm) { out.time24 = tm; break; }
  }

  // simple ranges: "between dec 1 and dec 5" or "from 2025-12-01 to 2025-12-05"
  const rangeIso = text.match(/\b(20\d\d-\d\d-\d\d)\b.*\b(20\d\d-\d\d-\d\d)\b/);
  if (rangeIso) out.range = { startISO: rangeIso[1], endISO: rangeIso[2] };

  return out;
}
