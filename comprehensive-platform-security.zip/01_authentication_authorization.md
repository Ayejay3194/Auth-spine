AUTHENTICATION & AUTHORIZATION

Covers:
- User authentication (passwords, MFA, SSO, OAuth)
- Session management
- RBAC / ABAC
- Privilege escalation prevention
- Admin authentication separation