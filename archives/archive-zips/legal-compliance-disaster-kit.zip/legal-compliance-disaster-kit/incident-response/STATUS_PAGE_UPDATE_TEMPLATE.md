# Status Page Update (Template)

**Investigating**: We are investigating an issue impacting [service].
**Identified**: Cause identified as [summary].
**Monitoring**: Fix deployed; monitoring.
**Resolved**: Incident resolved. Postmortem: [link/timeframe].
