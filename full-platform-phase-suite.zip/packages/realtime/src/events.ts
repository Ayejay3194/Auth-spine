export type RealtimeEvent =
  | { type: "notification"; userId: string; payload: any }
  | { type: "booking_update"; bookingId: string; payload: any }
  | { type: "support_ticket_update"; ticketId: string; payload: any };

export interface RealtimePublisher {
  publish(ev: RealtimeEvent): Promise<void>;
}
