import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists } from "../utils/fs.js";
export function auditArtifacts(root: string): AuditSection {
  const section: AuditSection = { id:"artifacts", title:"Build Artifacts & Static Assets", findings: [] };
  const candidates = [".next","dist","build","out"];
  const present = candidates.filter(d=>exists(path.join(root,d)));
  if (!present.length) section.findings.push({ id:"artifacts.none", title:"No build output folders found", severity:"INFO",
    details:"In prod this often means CI didn't produce/upload artifacts.", fix:"Run build and ensure deploy serves correct folder.",
    evidence:{checked:candidates}});
  if (!exists(path.join(root,"public"))) section.findings.push({ id:"public.missing", title:"No public/ folder found", severity:"INFO",
    details:"If you reference /asset.png, you typically need public/ (framework-dependent).", fix:"Add public/ or adjust asset pipeline." });
  return section;
}
