#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

BASE_URL="${SMOKE_BASE_URL:-}"
if [ -z "$BASE_URL" ]; then
  log "SMOKE_BASE_URL not set. Skipping."
  exit 0
fi

log "Smoke: GET /health"
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/health" || true)
if [ "$code" != "200" ]; then
  echo "Smoke failed: /health returned $code"
  exit 1
fi

log "Smoke: GET /ready"
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/ready" || true)
if [ "$code" != "200" ]; then
  echo "Smoke failed: /ready returned $code"
  exit 1
fi

log "Smoke tests passed"
