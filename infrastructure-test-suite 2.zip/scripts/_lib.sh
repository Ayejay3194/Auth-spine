#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

log() { printf "\n[%s] %s\n" "$(date +%H:%M:%S)" "$*"; }

docker_run() {
  local image="$1"; shift
  docker run --rm -t -v "$ROOT_DIR:/work" -w /work "$image" "$@"
}
