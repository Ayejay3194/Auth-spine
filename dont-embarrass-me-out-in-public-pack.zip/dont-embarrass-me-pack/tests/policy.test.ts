import { describe, it, expect } from "vitest";
import { buildDefaultPolicy } from "../src/security/policyDefaults";
import { isAllowed, isToolAllowed } from "../src/security/policy";

describe("policy", () => {
  it("fails closed for unknown tool", () => {
    const p = buildDefaultPolicy();
    expect(isToolAllowed(p, "staff", "payments.refund")).toBe(false);
  });

  it("allows owner everywhere", () => {
    const p = buildDefaultPolicy();
    expect(isAllowed(p, "owner", "system", "delete")).toBe(true);
  });

  it("denies readonly invoke", () => {
    const p = buildDefaultPolicy();
    expect(isAllowed(p, "readonly", "chat", "invoke")).toBe(false);
  });
});
