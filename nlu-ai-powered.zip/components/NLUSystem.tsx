"use client";

import React, { useMemo, useState } from "react";
import { Brain, Plus, Trash2, Play, Download, Upload, Sparkles, Settings } from "lucide-react";

type Intent = {
  name: string;
  description: string;
  examples: string[];
};

type Entity = {
  name: string;
  description: string;
  examples: string[];
};

type TestResult = {
  text: string;
  intent: { name: string; confidence: number };
  entities: Array<{ entity: string; value: string; start?: number; end?: number }>;
  reasoning?: string;
};

const defaultIntents: Intent[] = [
  { name: "greeting", description: "User is greeting or saying hello", examples: ["hello", "hi", "hey", "good morning", "howdy"] },
  { name: "weather", description: "User is asking about weather conditions", examples: ["what is the weather", "how is the weather in", "will it rain today", "weather forecast"] },
];

const defaultEntities: Entity[] = [
  { name: "location", description: "A place, city, country, or geographic location", examples: ["new york", "london", "paris", "tokyo", "san francisco"] },
  { name: "date", description: "A specific date or time reference", examples: ["today", "tomorrow", "yesterday", "next week", "monday"] },
];

export default function NLUSystem() {
  const [intents, setIntents] = useState<Intent[]>(defaultIntents);
  const [entities, setEntities] = useState<Entity[]>(defaultEntities);

  const [testInput, setTestInput] = useState("");
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const [newIntentName, setNewIntentName] = useState("");
  const [newEntityName, setNewEntityName] = useState("");

  const [showSettings, setShowSettings] = useState(false);
  const [temperature, setTemperature] = useState(0.3);

  const [showDatasetGen, setShowDatasetGen] = useState(false);
  const [genPrompt, setGenPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const completionStats = useMemo(() => {
    const intentCount = intents.length;
    const entityCount = entities.length;
    const totalExamples = intents.reduce((a, i) => a + i.examples.length, 0);
    return { intentCount, entityCount, totalExamples };
  }, [intents, entities]);

  async function classifyWithLLM(text: string) {
    const res = await fetch("/api/nlu/classify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, intents, entities, temperature }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || "Classification failed");
    return data as { intent: string; confidence: number; entities: any[]; reasoning?: string };
  }

  async function handleTest() {
    if (!testInput.trim() || isProcessing) return;

    setIsProcessing(true);
    try {
      const result = await classifyWithLLM(testInput.trim());
      setTestResult({
        text: testInput.trim(),
        intent: { name: result.intent, confidence: result.confidence },
        entities: Array.isArray(result.entities) ? result.entities : [],
        reasoning: result.reasoning,
      });
    } catch (error: any) {
      setTestResult({
        text: testInput.trim(),
        intent: { name: "error", confidence: 0 },
        entities: [],
        reasoning: error?.message || "Failed to classify.",
      });
    } finally {
      setIsProcessing(false);
    }
  }

  function addIntent() {
    const name = newIntentName.trim();
    if (!name) return;
    setIntents(prev => [...prev, { name, description: "", examples: [] }]);
    setNewIntentName("");
  }

  function addEntity() {
    const name = newEntityName.trim();
    if (!name) return;
    setEntities(prev => [...prev, { name, description: "", examples: [] }]);
    setNewEntityName("");
  }

  function updateIntentDescription(index: number, description: string) {
    setIntents(prev => {
      const next = [...prev];
      next[index] = { ...next[index], description };
      return next;
    });
  }

  function updateEntityDescription(index: number, description: string) {
    setEntities(prev => {
      const next = [...prev];
      next[index] = { ...next[index], description };
      return next;
    });
  }

  function addExample(intentIndex: number, example: string) {
    const ex = example.trim();
    if (!ex) return;
    setIntents(prev => {
      const next = [...prev];
      next[intentIndex] = { ...next[intentIndex], examples: [...next[intentIndex].examples, ex] };
      return next;
    });
  }

  function addEntityExample(entityIndex: number, example: string) {
    const ex = example.trim();
    if (!ex) return;
    setEntities(prev => {
      const next = [...prev];
      next[entityIndex] = { ...next[entityIndex], examples: [...next[entityIndex].examples, ex] };
      return next;
    });
  }

  function removeIntent(index: number) {
    setIntents(prev => prev.filter((_, i) => i !== index));
  }

  function removeEntity(index: number) {
    setEntities(prev => prev.filter((_, i) => i !== index));
  }

  function removeExample(intentIndex: number, exampleIndex: number) {
    setIntents(prev => {
      const next = [...prev];
      next[intentIndex] = {
        ...next[intentIndex],
        examples: next[intentIndex].examples.filter((_, i) => i !== exampleIndex),
      };
      return next;
    });
  }

  function removeEntityExample(entityIndex: number, exampleIndex: number) {
    setEntities(prev => {
      const next = [...prev];
      next[entityIndex] = {
        ...next[entityIndex],
        examples: next[entityIndex].examples.filter((_, i) => i !== exampleIndex),
      };
      return next;
    });
  }

  function exportModel() {
    const model = { intents, entities, settings: { temperature } };
    const blob = new Blob([JSON.stringify(model, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "nlu-model.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  function importModel(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const model = JSON.parse(String(event.target?.result || "{}"));
        if (model.intents) setIntents(model.intents);
        if (model.entities) setEntities(model.entities);
        if (typeof model.settings?.temperature === "number") setTemperature(model.settings.temperature);
      } catch {
        alert("Invalid model file");
      }
    };
    reader.readAsText(file);
  }

  async function generateTrainingData() {
    if (!genPrompt.trim() || isGenerating) return;

    setIsGenerating(true);
    try {
      const res = await fetch("/api/nlu/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: genPrompt.trim(), intents, entities }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Generation failed");

      const jsonl: string = data.jsonl || "";
      const lines = jsonl.split("\n").map((l: string) => l.trim()).filter(Boolean);

      const newIntents = new Map<string, Intent>();
      const newEntities = new Map<string, Entity>();

      for (const line of lines) {
        try {
          const row = JSON.parse(line) as { text?: string; intent?: string; entities?: Array<{ entity?: string; type?: string; value?: string }> };

          if (row.intent) {
            if (!newIntents.has(row.intent)) {
              newIntents.set(row.intent, { name: row.intent, description: `Generated intent for ${row.intent}`, examples: [] });
            }
            if (row.text) newIntents.get(row.intent)!.examples.push(row.text);
          }

          if (Array.isArray(row.entities)) {
            for (const ent of row.entities) {
              const entityName = ent.entity || ent.type;
              const value = ent.value;
              if (!entityName) continue;

              if (!newEntities.has(entityName)) {
                newEntities.set(entityName, { name: entityName, description: `Generated entity: ${entityName}`, examples: [] });
              }
              if (value && !newEntities.get(entityName)!.examples.includes(value)) {
                newEntities.get(entityName)!.examples.push(value);
              }
            }
          }
        } catch {
          // ignore parse errors per-line
        }
      }

      // Merge
      setIntents(prev => {
        const merged = [...prev];
        newIntents.forEach((intent) => {
          const idx = merged.findIndex(i => i.name === intent.name);
          if (idx >= 0) {
            merged[idx] = {
              ...merged[idx],
              examples: Array.from(new Set([...merged[idx].examples, ...intent.examples])),
            };
          } else merged.push(intent);
        });
        return merged;
      });

      setEntities(prev => {
        const merged = [...prev];
        newEntities.forEach((entity) => {
          const idx = merged.findIndex(e => e.name === entity.name);
          if (idx >= 0) {
            merged[idx] = {
              ...merged[idx],
              examples: Array.from(new Set([...merged[idx].examples, ...entity.examples])),
            };
          } else merged.push(entity);
        });
        return merged;
      });

      setGenPrompt("");
      alert(`Generated ${newIntents.size} intents and parsed ${lines.length} JSONL lines.`);
    } catch (err: any) {
      alert(err?.message || "Failed to generate training data");
    } finally {
      setIsGenerating(false);
    }
  }

  function importJSONL(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const raw = String(event.target?.result || "");
        const lines = raw.split("\n").map(l => l.trim()).filter(Boolean);

        const newIntents = new Map<string, Intent>();
        const newEntities = new Map<string, Entity>();

        for (const line of lines) {
          const data = JSON.parse(line);

          if (data.intent) {
            if (!newIntents.has(data.intent)) {
              newIntents.set(data.intent, {
                name: data.intent,
                description: data.intent_description || `Intent for ${data.intent}`,
                examples: [],
              });
            }
            if (data.text) newIntents.get(data.intent)!.examples.push(data.text);
          }

          if (Array.isArray(data.entities)) {
            for (const entity of data.entities) {
              const entityName = entity.entity || entity.type;
              const value = entity.value;
              if (!entityName) continue;

              if (!newEntities.has(entityName)) {
                newEntities.set(entityName, {
                  name: entityName,
                  description: entity.description || `Entity type: ${entityName}`,
                  examples: [],
                });
              }
              if (value && !newEntities.get(entityName)!.examples.includes(value)) {
                newEntities.get(entityName)!.examples.push(value);
              }
            }
          }
        }

        // Merge
        setIntents(prev => {
          const merged = [...prev];
          newIntents.forEach(intent => {
            const idx = merged.findIndex(i => i.name === intent.name);
            if (idx >= 0) {
              merged[idx] = { ...merged[idx], examples: Array.from(new Set([...merged[idx].examples, ...intent.examples])) };
            } else merged.push(intent);
          });
          return merged;
        });

        setEntities(prev => {
          const merged = [...prev];
          newEntities.forEach(entity => {
            const idx = merged.findIndex(e => e.name === entity.name);
            if (idx >= 0) {
              merged[idx] = { ...merged[idx], examples: Array.from(new Set([...merged[idx].examples, ...entity.examples])) };
            } else merged.push(entity);
          });
          return merged;
        });

        alert(`Imported ${newIntents.size} intents and ${newEntities.size} entities from JSONL.`);
      } catch (err) {
        alert('Invalid JSONL file. Expected lines like: {"text":"...","intent":"...","entities":[...]}');
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 p-6">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 rounded-xl bg-white p-6 shadow-lg">
          <div className="mb-4 flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Brain className="h-8 w-8 text-purple-600" />
                <Sparkles className="absolute -right-1 -top-1 h-4 w-4 text-yellow-500" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-800">AI-Powered NLU System</h1>
                <p className="text-sm text-gray-500">Server-side Claude calls via Next.js API routes</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setShowDatasetGen(v => !v)}
                className="flex items-center gap-2 rounded-lg bg-yellow-600 px-4 py-2 text-white hover:bg-yellow-700"
              >
                <Sparkles className="h-4 w-4" />
                Generate Data
              </button>

              <button
                onClick={() => setShowSettings(v => !v)}
                className="flex items-center gap-2 rounded-lg bg-gray-600 px-4 py-2 text-white hover:bg-gray-700"
              >
                <Settings className="h-4 w-4" />
                Settings
              </button>

              <button
                onClick={exportModel}
                className="flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2 text-white hover:bg-green-700"
              >
                <Download className="h-4 w-4" />
                Export
              </button>

              <label className="cursor-pointer rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 flex items-center gap-2">
                <Upload className="h-4 w-4" />
                Import JSON
                <input type="file" accept=".json" onChange={importModel} className="hidden" />
              </label>

              <label className="cursor-pointer rounded-lg bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700 flex items-center gap-2">
                <Upload className="h-4 w-4" />
                Import JSONL
                <input type="file" accept=".jsonl,.txt" onChange={importJSONL} className="hidden" />
              </label>
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-3">
            <StatCard label="Intents" value={completionStats.intentCount} />
            <StatCard label="Entities" value={completionStats.entityCount} />
            <StatCard label="Total Examples" value={completionStats.totalExamples} />
          </div>

          {showSettings && (
            <div className="mt-4 rounded-lg bg-gray-50 p-4">
              <h3 className="mb-3 font-semibold text-gray-700">Model Settings</h3>
              <div className="mb-2 flex items-center gap-4">
                <label className="text-sm text-gray-600">Temperature:</label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="flex-1"
                />
                <span className="w-12 text-sm font-mono text-gray-700">{temperature.toFixed(1)}</span>
              </div>
              <p className="text-xs text-gray-500">Lower = more focused. Higher = more creative.</p>

              <div className="mt-4 rounded-lg border border-blue-200 bg-blue-50 p-3">
                <h4 className="mb-2 text-sm font-semibold text-blue-900">JSONL Format</h4>
                <pre className="overflow-x-auto rounded border border-blue-200 bg-white p-2 text-xs">
{`{"text":"book a flight to NYC","intent":"book_flight","entities":[{"entity":"location","value":"NYC"}]}
{"text":"what's the weather like","intent":"weather","entities":[]}`}
                </pre>
              </div>
            </div>
          )}

          {showDatasetGen && (
            <div className="mt-4 rounded-lg border border-yellow-200 bg-gradient-to-r from-yellow-50 to-orange-50 p-4">
              <div className="mb-2 flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-yellow-600" />
                <h3 className="font-semibold text-gray-700">AI Training Data Generator</h3>
              </div>
              <p className="mb-3 text-sm text-gray-600">
                Describe what kind of training data you need. The server will ask the model for 20 JSONL lines and merge them into your intents/entities.
              </p>

              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  value={genPrompt}
                  onChange={(e) => setGenPrompt(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && !isGenerating && generateTrainingData()}
                  placeholder="e.g. 'restaurant booking chatbot' or 'tech support queries'"
                  className="min-w-[240px] flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                  disabled={isGenerating}
                />
                <button
                  onClick={generateTrainingData}
                  disabled={isGenerating}
                  className={`flex items-center gap-2 rounded-lg px-6 py-2 text-white ${
                    isGenerating ? "cursor-not-allowed bg-gray-400" : "bg-yellow-600 hover:bg-yellow-700"
                  }`}
                >
                  {isGenerating ? (
                    <>
                      <Spinner />
                      Generating
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      Generate
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          <div className="mt-6 rounded-lg border border-purple-200 bg-gradient-to-r from-purple-50 to-blue-50 p-4">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-purple-600" />
              <h2 className="text-lg font-semibold text-gray-700">Test Your AI Model</h2>
            </div>

            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !isProcessing && handleTest()}
                placeholder="Enter text to analyze…"
                className="min-w-[240px] flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
                disabled={isProcessing}
              />
              <button
                onClick={handleTest}
                disabled={isProcessing}
                className={`flex items-center gap-2 rounded-lg px-6 py-2 text-white ${
                  isProcessing ? "cursor-not-allowed bg-gray-400" : "bg-purple-600 hover:bg-purple-700"
                }`}
              >
                {isProcessing ? (
                  <>
                    <Spinner />
                    Processing
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" />
                    Analyze
                  </>
                )}
              </button>
            </div>

            {testResult && (
              <div className="mt-4 rounded-lg border border-purple-200 bg-white p-4">
                <div className="mb-3">
                  <span className="text-sm font-semibold text-gray-600">Intent:</span>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="rounded-full bg-purple-100 px-3 py-1 font-medium text-purple-800">
                      {testResult.intent.name}
                    </span>
                    <span className="text-sm text-gray-500">{Math.round(testResult.intent.confidence * 100)}% confidence</span>
                  </div>
                </div>

                {testResult.entities?.length > 0 && (
                  <div className="mb-3">
                    <span className="text-sm font-semibold text-gray-600">Entities:</span>
                    <div className="mt-1 flex flex-wrap gap-2">
                      {testResult.entities.map((ent, idx) => (
                        <div key={idx} className="rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-800">
                          <span className="font-medium">{ent.entity}:</span> {ent.value}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {testResult.reasoning && (
                  <div className="border-t border-gray-200 pt-3">
                    <span className="text-sm font-semibold text-gray-600">Reasoning:</span>
                    <p className="mt-1 text-sm text-gray-700">{testResult.reasoning}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="rounded-xl bg-white p-6 shadow-lg">
            <h2 className="mb-4 text-xl font-bold text-gray-800">Intents</h2>

            <div className="mb-4 flex gap-2">
              <input
                type="text"
                value={newIntentName}
                onChange={(e) => setNewIntentName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addIntent()}
                placeholder="New intent name…"
                className="flex-1 rounded-lg border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <button onClick={addIntent} className="rounded-lg bg-purple-600 px-4 py-2 text-white hover:bg-purple-700">
                <Plus className="h-5 w-5" />
              </button>
            </div>

            <div className="max-h-[520px] space-y-4 overflow-y-auto pr-1">
              {intents.map((intent, idx) => (
                <IntentEditor
                  key={intent.name + idx}
                  intent={intent}
                  onUpdateDescription={(desc) => updateIntentDescription(idx, desc)}
                  onAddExample={(ex) => addExample(idx, ex)}
                  onRemoveExample={(exIdx) => removeExample(idx, exIdx)}
                  onRemove={() => removeIntent(idx)}
                />
              ))}
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-lg">
            <h2 className="mb-4 text-xl font-bold text-gray-800">Entities</h2>

            <div className="mb-4 flex gap-2">
              <input
                type="text"
                value={newEntityName}
                onChange={(e) => setNewEntityName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addEntity()}
                placeholder="New entity name…"
                className="flex-1 rounded-lg border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button onClick={addEntity} className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">
                <Plus className="h-5 w-5" />
              </button>
            </div>

            <div className="max-h-[520px] space-y-4 overflow-y-auto pr-1">
              {entities.map((entity, idx) => (
                <EntityEditor
                  key={entity.name + idx}
                  entity={entity}
                  onUpdateDescription={(desc) => updateEntityDescription(idx, desc)}
                  onAddExample={(ex) => addEntityExample(idx, ex)}
                  onRemoveExample={(exIdx) => removeEntityExample(idx, exIdx)}
                  onRemove={() => removeEntity(idx)}
                />
              ))}
            </div>
          </div>
        </div>

        <footer className="mt-8 text-center text-xs text-slate-500">
          Pro tip: this is “NLU” for people who want control, not magic. The AI just does the inference.
        </footer>
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg bg-slate-50 p-4">
      <div className="text-2xl font-bold text-slate-800">{value}</div>
      <div className="text-sm text-slate-600">{label}</div>
    </div>
  );
}

function Spinner() {
  return <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />;
}

function IntentEditor({
  intent,
  onUpdateDescription,
  onAddExample,
  onRemoveExample,
  onRemove,
}: {
  intent: Intent;
  onUpdateDescription: (desc: string) => void;
  onAddExample: (ex: string) => void;
  onRemoveExample: (idx: number) => void;
  onRemove: () => void;
}) {
  const [newExample, setNewExample] = useState("");
  const [isEditingDesc, setIsEditingDesc] = useState(false);

  function handleAdd() {
    onAddExample(newExample);
    setNewExample("");
  }

  return (
    <div className="rounded-lg border border-purple-200 bg-purple-50 p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-semibold text-gray-800">{intent.name}</h3>
        <button onClick={onRemove} className="text-red-500 hover:text-red-700">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      <div className="mb-3">
        {isEditingDesc ? (
          <input
            type="text"
            value={intent.description}
            onChange={(e) => onUpdateDescription(e.target.value)}
            onBlur={() => setIsEditingDesc(false)}
            onKeyDown={(e) => e.key === "Enter" && setIsEditingDesc(false)}
            placeholder="Describe what this intent means…"
            className="w-full rounded border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
            autoFocus
          />
        ) : (
          <p
            onClick={() => setIsEditingDesc(true)}
            className="cursor-pointer rounded px-2 py-1 text-sm italic text-gray-600 hover:bg-white"
          >
            {intent.description || "Click to add description…"}
          </p>
        )}
      </div>

      <div className="mb-2 flex gap-2">
        <input
          type="text"
          value={newExample}
          onChange={(e) => setNewExample(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          placeholder="Add training example…"
          className="flex-1 rounded border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
        />
        <button onClick={handleAdd} className="rounded bg-purple-600 px-2 py-1 text-white hover:bg-purple-700">
          <Plus className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-1">
        {intent.examples.map((example, idx) => (
          <div key={example + idx} className="flex items-center justify-between rounded bg-white px-2 py-1 text-sm">
            <span className="text-gray-700">{example}</span>
            <button onClick={() => onRemoveExample(idx)} className="text-red-500 hover:text-red-700">
              <Trash2 className="h-3 w-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function EntityEditor({
  entity,
  onUpdateDescription,
  onAddExample,
  onRemoveExample,
  onRemove,
}: {
  entity: Entity;
  onUpdateDescription: (desc: string) => void;
  onAddExample: (ex: string) => void;
  onRemoveExample: (idx: number) => void;
  onRemove: () => void;
}) {
  const [newExample, setNewExample] = useState("");
  const [isEditingDesc, setIsEditingDesc] = useState(false);

  function handleAdd() {
    onAddExample(newExample);
    setNewExample("");
  }

  return (
    <div className="rounded-lg border border-blue-200 bg-blue-50 p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-semibold text-gray-800">{entity.name}</h3>
        <button onClick={onRemove} className="text-red-500 hover:text-red-700">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      <div className="mb-3">
        {isEditingDesc ? (
          <input
            type="text"
            value={entity.description}
            onChange={(e) => onUpdateDescription(e.target.value)}
            onBlur={() => setIsEditingDesc(false)}
            onKeyDown={(e) => e.key === "Enter" && setIsEditingDesc(false)}
            placeholder="Describe what this entity represents…"
            className="w-full rounded border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            autoFocus
          />
        ) : (
          <p
            onClick={() => setIsEditingDesc(true)}
            className="cursor-pointer rounded px-2 py-1 text-sm italic text-gray-600 hover:bg-white"
          >
            {entity.description || "Click to add description…"}
          </p>
        )}
      </div>

      <div className="mb-2 flex gap-2">
        <input
          type="text"
          value={newExample}
          onChange={(e) => setNewExample(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          placeholder="Add example value…"
          className="flex-1 rounded border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button onClick={handleAdd} className="rounded bg-blue-600 px-2 py-1 text-white hover:bg-blue-700">
          <Plus className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-1">
        {entity.examples.map((example, idx) => (
          <div key={example + idx} className="flex items-center justify-between rounded bg-white px-2 py-1 text-sm">
            <span className="text-gray-700">{example}</span>
            <button onClick={() => onRemoveExample(idx)} className="text-red-500 hover:text-red-700">
              <Trash2 className="h-3 w-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
