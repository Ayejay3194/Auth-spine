import { parseDateTime } from "./datetime.js";

export type EntityType =
  | "email" | "phone" | "bookingId" | "service" | "duration" | "contactMethod"
  | "money" | "promoCode" | "referralCode" | "kpi" | "tag" | "role" | "datetime";

export interface Entity { type: EntityType; value: string; confidence: number; meta?: Record<string, unknown>; }

export class DefaultEntityExtractor {
  extract(text: string, now: Date): Entity[] {
    const out: Entity[] = [];
    const lower = text.toLowerCase();

    const emailRe = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
    for (const m of text.matchAll(emailRe)) out.push({ type: "email", value: m[0], confidence: 0.95 });

    const phoneRe = /\b(\+?1\s*)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g;
    for (const m of text.matchAll(phoneRe)) out.push({ type: "phone", value: m[0], confidence: 0.7 });

    const bkRe = /\b(bk_[a-z0-9]{6,})\b/gi;
    for (const m of lower.matchAll(bkRe)) out.push({ type: "bookingId", value: m[0], confidence: 0.9 });

    const serviceRe = /\b(tarot|astrology|reading|consult|coaching|haircut|braids|lashes)\b/gi;
    for (const m of lower.matchAll(serviceRe)) out.push({ type: "service", value: m[0], confidence: 0.55 });

    const durRe = /\b(15|30|45|60|75|90|120)\s*(min|mins|minutes)\b/gi;
    for (const m of lower.matchAll(durRe)) out.push({ type: "duration", value: m[1], confidence: 0.7, meta: { minutes: Number(m[1]) } });

    const cmRe = /\b(video|phone|chat|in\s*person|in-person)\b/gi;
    for (const m of lower.matchAll(cmRe)) out.push({ type: "contactMethod", value: m[0].includes("in") ? "in_person" : m[0], confidence: 0.6 });

    const moneyRe = /\$\s*(\d+(?:\.\d{1,2})?)/g;
    for (const m of text.matchAll(moneyRe)) out.push({ type: "money", value: m[1], confidence: 0.75, meta: { amount: Number(m[1]) } });

    const promoRe = /\bpromo[_-]?[a-z0-9]{3,}\b/gi;
    for (const m of lower.matchAll(promoRe)) out.push({ type: "promoCode", value: m[0], confidence: 0.6 });

    const refRe = /\bref[_-]?[a-z0-9]{3,}\b/gi;
    for (const m of lower.matchAll(refRe)) out.push({ type: "referralCode", value: m[0], confidence: 0.6 });

    const kpiRe = /\b(revenue|bookings|cancellations|no-show|utilization|new clients|returning)\b/gi;
    for (const m of lower.matchAll(kpiRe)) out.push({ type: "kpi", value: m[0], confidence: 0.55 });

    const tagRe = /\b(vip|blocked|high-no-show|new|returning)\b/gi;
    for (const m of lower.matchAll(tagRe)) out.push({ type: "tag", value: m[0], confidence: 0.55 });

    const roleRe = /\b(owner|staff|assistant|accountant|admin)\b/gi;
    for (const m of lower.matchAll(roleRe)) out.push({ type: "role", value: m[0], confidence: 0.65 });

    const dt = parseDateTime(text, now);
    if (dt.dateISO || dt.time24 || dt.partOfDay) out.push({ type: "datetime", value: "datetime", confidence: 0.5, meta: dt as any });

    return out;
  }
}
