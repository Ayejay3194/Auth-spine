-- Hierarchical Data (Closure Table)
create table if not exists public.nodes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.node_closure (
  ancestor uuid not null references public.nodes(id) on delete cascade,
  descendant uuid not null references public.nodes(id) on delete cascade,
  depth int not null,
  primary key (ancestor, descendant)
);

-- Insert a node as its own ancestor
-- insert into node_closure(ancestor, descendant, depth) values (NEW.id, NEW.id, 0);
