---
name: Bug report
about: Report a bug with reproduction steps
---

## Summary

## Steps to reproduce

## Expected

## Actual

## Logs / screenshots

## Security/Privacy impact (PII? auth? payments?)
