import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, listFiles, safeReadText } from "../utils/fs.js";

export function auditServiceWorker(root: string): AuditSection {
  const section: AuditSection = { id: "serviceWorker", title: "Service Worker Cache Traps", findings: [] };

  const swCandidates = [
    path.join(root, "public", "sw.js"),
    path.join(root, "public", "service-worker.js"),
    path.join(root, "public", "workbox-sw.js"),
  ].filter(exists);

  if (swCandidates.length === 0) {
    section.findings.push({
      id: "sw.none",
      title: "No service worker file detected",
      severity: "INFO",
      details: "No SW means fewer caching landmines. If you expected offline/PWA, then you're missing the SW.",
      fix: "If you want PWA, add a service worker and register it intentionally (not accidentally via templates).",
    });
    return section;
  }

  section.findings.push({
    id: "sw.detected",
    title: "Service worker file detected",
    severity: "WARN",
    details: "Service workers can cache old JS bundles and cause 'fixed in deploy but users still broken' issues.",
    fix: "Ensure assets are fingerprinted (hashed filenames), implement SW update flow, and provide a 'refresh to update' UX.",
    evidence: { files: swCandidates.map((p) => p.replace(root + path.sep, "")) },
  });

  // Try to detect registration code
  const files = listFiles(root, { max: 4000 });
  const jsLike = files.filter((f) => /\.(ts|tsx|js|jsx)$/.test(f));
  const registrations: string[] = [];
  for (const f of jsLike.slice(0, 1200)) {
    const raw = safeReadText(f);
    if (!raw) continue;
    if (raw.includes("navigator.serviceWorker.register")) {
      registrations.push(f.replace(root + path.sep, ""));
      if (registrations.length >= 15) break;
    }
  }

  if (registrations.length === 0) {
    section.findings.push({
      id: "sw.noRegistrationFound",
      title: "SW file exists but registration code not found",
      severity: "INFO",
      details: "You might be relying on framework PWA tooling or the SW is unused. Either way: know what's happening.",
      fix: "Search for service worker registration or confirm your PWA plugin injects it.",
    });
  } else {
    section.findings.push({
      id: "sw.registrationFound",
      title: "Service worker registration code found",
      severity: "WARN",
      details: "If your app has blank screens only for some users, a stale SW cache is a prime suspect.",
      fix: "Add an update strategy: unregister old SW, skipWaiting + clientsClaim carefully, and show an update toast.",
      evidence: { registrations },
    });
  }

  return section;
}
