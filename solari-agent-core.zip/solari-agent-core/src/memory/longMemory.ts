import { MemoryFact } from "../types";

export class LongMemory {
  private facts = new Map<string, MemoryFact>();

  upsert<T>(fact: MemoryFact<T>) {
    this.facts.set(fact.key, fact as MemoryFact);
  }

  get<T>(key: string): MemoryFact<T> | undefined {
    return this.facts.get(key) as MemoryFact<T> | undefined;
  }

  list(): MemoryFact[] {
    return [...this.facts.values()];
  }

  prune(now = new Date()): MemoryFact[] {
    const removed: MemoryFact[] = [];
    for (const [k, v] of this.facts.entries()) {
      const ageDays = (now.getTime() - new Date(v.ts).getTime()) / (1000 * 60 * 60 * 24);
      if (ageDays > v.ttlDays) {
        this.facts.delete(k);
        removed.push(v);
      }
    }
    return removed;
  }
}
