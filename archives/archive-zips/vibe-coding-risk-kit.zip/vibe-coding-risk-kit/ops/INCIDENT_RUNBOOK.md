# Incident Runbook

## Triage
1. Identify blast radius: auth? payments? data exposure? downtime?
2. Stop bleeding:
   - Disable feature flags / endpoints
   - Rotate leaked keys
   - Block abusive IPs (rate limit / WAF)
3. Preserve evidence:
   - Save logs, request IDs, timestamps
   - Snapshot DB if needed

## Common incidents
### Suspected data exposure
- Rotate secrets immediately
- Invalidate sessions
- Audit access logs
- Patch access control bug
- Notify users if required by your jurisdiction/policies

### Chargeback spike
- Tighten deposit/escrow/confirmation rules
- Add delivery proofs (timestamps, receipts, signed URLs)
- Block serial disputers

### Auth brute force
- Increase rate limits
- Add progressive delays / lockouts
- Require captcha after failures

## Postmortem
- Root cause
- Detection gap
- Preventative controls (tests + guardrails)
- Follow-up owners + deadlines
