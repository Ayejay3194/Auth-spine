import type { NextRequest } from 'next/server'
import { NextResponse } from 'next/server'
import { ErrorCode } from '../errors.js'

export interface RateLimitStore {
  incr: (key: string) => Promise<number>
  ttl: (key: string) => Promise<number>
  expire: (key: string, seconds: number) => Promise<void>
}

// Minimal in-memory store for dev/tests.
// Swap with Redis adapter in production.
export function createMemoryStore(): RateLimitStore {
  const counts = new Map<string, { count: number; expiresAt: number }>()
  return {
    async incr(key) {
      const now = Date.now()
      const current = counts.get(key)
      if (!current || current.expiresAt < now) {
        counts.set(key, { count: 1, expiresAt: now + 60_000 })
        return 1
      }
      current.count += 1
      return current.count
    },
    async ttl(key) {
      const now = Date.now()
      const current = counts.get(key)
      if (!current || current.expiresAt < now) return 0
      return Math.ceil((current.expiresAt - now) / 1000)
    },
    async expire(key, seconds) {
      const now = Date.now()
      const current = counts.get(key) || { count: 0, expiresAt: now + seconds * 1000 }
      current.expiresAt = now + seconds * 1000
      counts.set(key, current)
    },
  }
}

export interface RateLimitConfig {
  windowMs: number
  maxRequests: number
  keyPrefix?: string
  store?: RateLimitStore
}

export function rateLimit(config: RateLimitConfig) {
  const store = config.store || createMemoryStore()

  return async (req: NextRequest) => {
    if (process.env.NODE_ENV === 'development') return null

    const ip =
      req.headers.get('x-forwarded-for') ||
      req.headers.get('x-real-ip') ||
      'unknown'

    const key = `${config.keyPrefix || 'ratelimit'}:${ip}`
    const requests = await store.incr(key)

    if (requests === 1) {
      await store.expire(key, Math.ceil(config.windowMs / 1000))
    }

    if (requests > config.maxRequests) {
      const ttl = await store.ttl(key)
      return NextResponse.json(
        {
          error: {
            code: ErrorCode.RATE_LIMIT_EXCEEDED,
            message: 'Too many requests',
            retryAfter: ttl,
          },
        },
        {
          status: 429,
          headers: {
            'Retry-After': ttl.toString(),
            'X-RateLimit-Limit': config.maxRequests.toString(),
            'X-RateLimit-Remaining': '0',
            'X-RateLimit-Reset': (Date.now() + ttl * 1000).toString(),
          },
        }
      )
    }

    return null
  }
}
