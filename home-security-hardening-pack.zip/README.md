# Home Security Hardening Pack (Next.js / Node)
This pack adds the "boring but real" security defaults for your **homepage + public surface area**:
- Strict security headers (CSP/HSTS/etc)
- Production gating for `/swagger`, `/api/openapi.json`, `/api/metrics`
- Minimal `/api/health`
- Basic rate limiting examples for auth + public endpoints
- Test updates so your suite doesn't force insecure prod defaults

## Drop-in files
- `middleware.ts` (headers + route gating)
- `src/lib/security/headers.ts` (CSP + header builder)
- `src/lib/security/env.ts` (safe env helpers)
- `src/lib/security/rateLimit.ts` (simple in-memory limiter + interface)
- `src/pages/api/metrics.ts` (example: gated metrics)
- `src/pages/api/openapi.json.ts` (example: gated OpenAPI)
- `src/pages/api/health.ts` (minimal health)
- `docs/swagger-auth.md` (how to gate swagger properly)
- `tests/playwright/security.e2e.spec.ts` (tests that respect prod gating)

## Quick setup
1) Copy files into your repo (paths match common Next.js layouts; adjust if you use `app/` routes).
2) Set env vars (see `.env.example`).
3) If you host behind a proxy/CDN, ensure `X-Forwarded-Proto` is correct so HTTPS is enforced.
4) Run tests.

## Environment variables
See `.env.example`.

## Notes
- CSP is **strict by default**. If your UI breaks, loosen only the specific directive needed (don’t nuke it with `unsafe-inline` unless you have to).
- In-memory rate limiting is for dev/single instance. For real prod: Redis or your edge provider.
