#!/usr/bin/env node
import { Command } from 'commander'
import prompts from 'prompts'
import chalk from 'chalk'

const program = new Command()

program
  .name('create-auth-spine-app')
  .description('Create a new Auth-Spine application (scaffold)')
  .argument('[project-name]', 'Name of your project')
  .action(async (projectName) => {
    console.log(chalk.blue.bold('\n🚀 Auth-Spine App Generator (scaffold)\n'))
    const answers = await prompts([
      { type: projectName ? null : 'text', name: 'projectName', message: 'Project name?', initial: 'my-app' },
      {
        type: 'select',
        name: 'template',
        message: 'App type?',
        choices: [
          { title: 'SaaS', value: 'saas' },
          { title: 'Internal', value: 'internal' },
          { title: 'API', value: 'api' },
          { title: 'Minimal', value: 'minimal' },
        ],
      },
    ])
    const name = projectName || answers.projectName
    console.log(chalk.green(`\n✅ Would generate: ${name} (${answers.template})\n`))
    console.log(chalk.gray('This package is scaffolded. Wire template copying + prisma generation next.'))
  })

program.parse()
