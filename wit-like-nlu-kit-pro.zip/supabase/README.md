# Optional Supabase bits
If you want multi-tenant storage + RLS for examples/rules, use these as a starting point.

In the Pro-ish kit, we keep it file-based for simplicity. Supabase integration is intentionally optional.
