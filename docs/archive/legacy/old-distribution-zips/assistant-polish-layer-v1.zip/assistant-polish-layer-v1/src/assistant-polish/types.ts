export interface PolishState {
  lastResponseKey?: string;
  lastAssistantText?: string;
  lastAckAt?: number; // epoch ms
}
