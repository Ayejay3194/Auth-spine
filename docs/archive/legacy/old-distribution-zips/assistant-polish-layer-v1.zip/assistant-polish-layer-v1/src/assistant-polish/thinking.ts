export type ThinkingKind = "checking" | "payment" | "conflict";

const PHRASES: Record<ThinkingKind, string[]> = {
  checking: ["Checking that…", "Let me look…", "One moment…"],
  payment: ["Pulling up a payment link…", "Checking payment status…", "One sec…"],
  conflict: ["That slot might be taken…", "Let me find the closest opening…", "Checking alternatives…"],
};

/**
 * Use only when you're truly waiting on a tool call or resolving conflicts.
 * Don't put ellipses on confirmations or policies.
 */
export function thinkingPhrase(kind: ThinkingKind) {
  const pool = PHRASES[kind];
  return pool[Math.floor(Math.random() * pool.length)];
}
