import { test, expect } from "@playwright/test";

test("loads home", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByText("Auth-Spine Solid")).toBeVisible();
});
