-- Optional Supabase schema for Wit-like NLU data.
create table if not exists nlu_intents (
  name text primary key,
  description text,
  created_at timestamptz default now()
);

create table if not exists nlu_entities (
  name text primary key,
  description text,
  created_at timestamptz default now()
);

create table if not exists nlu_examples (
  id uuid primary key default gen_random_uuid(),
  text text not null,
  intent_name text not null references nlu_intents(name) on delete cascade,
  entities jsonb not null default '[]'::jsonb,
  created_at timestamptz default now()
);

create table if not exists nlu_parse_logs (
  id uuid primary key default gen_random_uuid(),
  text text not null,
  result jsonb not null,
  user_id uuid,
  created_at timestamptz default now()
);

create index if not exists nlu_examples_intent_idx on nlu_examples(intent_name);
