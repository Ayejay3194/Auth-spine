import { prisma } from "@/lib/prisma";
import { audit } from "@/lib/audit";
import { requireAdmin } from "../../../_guard";

export async function POST(req:Request, { params }:{ params:{ id:string } }){
  const g = await requireAdmin();
  if(!g.ok) return new Response("Forbidden", { status: g.status });

  const before = await prisma.booking.findUnique({ where:{ id: params.id } });

  const booking = await prisma.booking.update({
    where:{ id: params.id },
    data:{ status:"CONFIRMED", approvedByUserId: g.user!.id }
  });
  await audit({
  actor: { id: g.user!.id, role: g.user!.role },
  action: "BOOKING_APPROVED",
  entityType: "BOOKING",
  entityId: booking.id,
  before,
  after: booking,
  ip: req.headers.get("x-forwarded-for"),
  userAgent: req.headers.get("user-agent"),
});
return Response.json({ ok:true, booking });
}
