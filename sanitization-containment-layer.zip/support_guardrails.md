Prevents support agents from leaking internal notes.
Templates enforced. Copy-paste auto-scrubbing required.