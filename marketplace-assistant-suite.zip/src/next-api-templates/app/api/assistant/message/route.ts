import { NextResponse } from "next/server";
import { buildRuntime } from "@/src/assistant/runtime";
import { makeRealProviders } from "@/src/assistant/providers/real/providers";

// Replace with your audit + persistence
const audit = { async write(_ev: any) {} };
const clock = { now: () => new Date() };

export async function POST(req: Request) {
  const body = await req.json();
  const text = String(body.text ?? "");
  const businessId = String(body.businessId ?? "platform_1");
  const userId = String(body.userId ?? "user_1");
  const role = (body.role ?? "client") as any;
  const timezone = String(body.timezone ?? "America/New_York");
  const locale = String(body.locale ?? "en-US");

  const { assistant } = buildRuntime({ providers: makeRealProviders(null as any, businessId), audit, clock });

  const ctx = { businessId, userId, role, timezone, locale, channel: "web" as const };
  const state = body.state ?? {};
  const out = await assistant.handle(ctx, state, text);

  return NextResponse.json({ reply: out.reply.text, ui: out.reply.ui ?? null, done: out.reply.done ?? true, state: out.state });
}
