import { api } from "@/src/core/api";
export async function GET() {
  return api(async () => {
    const stream = new ReadableStream({
      start(controller) {
        const enc = new TextEncoder();
        controller.enqueue(enc.encode("event: hello\ndata: ok\n\n"));
      },
    });
    return new Response(stream, { headers: { "Content-Type":"text/event-stream","Cache-Control":"no-cache","Connection":"keep-alive" } });
  });
}
