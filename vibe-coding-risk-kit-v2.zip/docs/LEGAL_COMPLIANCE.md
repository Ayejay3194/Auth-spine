# Legal & Compliance Checklist (Engineering-Friendly)

This is not "lawyer cosplay." It's the minimum set of controls to avoid self-inflicted lawsuits and processor shutdowns.

## Privacy (GDPR/CCPA-ish reality)
### Consent & Tracking
- [ ] Cookie consent banner where required (and it actually controls tracking)
- [ ] No analytics/ads pixels fire before consent (where applicable)
- [ ] Opt-out mechanisms work (do-not-sell / limit-use where applicable)
- [ ] Tracking configuration documented (what data, where it goes)

### Data Rights
- [ ] Account deletion works (and removes/anon data per policy)
- [ ] Data export works (self-serve, machine-readable)
- [ ] Retention rules exist + automated deletion after retention
- [ ] No PII in logs/URLs/analytics payloads
- [ ] Breach notification plan exists (owners, timelines, templates)

### Children / Age
- [ ] Age gate if your service requires 18+ (or parental consent path)
- [ ] COPPA considerations if targeting kids (ideally: don't)

## Terms of Service (enforceable, not vibes)
- [ ] Explicit acceptance on signup/checkout (checkbox + record timestamp)
- [ ] Versioned ToS + change notification mechanism
- [ ] Prohibited use / acceptable use policy exists
- [ ] IP ownership: user content, platform content, licenses defined
- [ ] Termination/suspension rules exist (and are applied consistently)
- [ ] Dispute resolution + jurisdiction defined (and not contradictory)

## Compliance (when you promise it, you own it)
- [ ] PCI: never store card data; use processor tokens only
- [ ] Audit logs exist for sensitive actions (immutable/append-only if needed)
- [ ] Incident response plan exists + is testable (tabletop runbook)
- [ ] Vendor/subprocessor list maintained + reviewed
- [ ] Accessibility: core flows tested (WCAG basics, keyboard, contrast)

## Licensing & IP Hygiene
- [ ] Dependency license scan in CI
- [ ] License notices included where required
- [ ] No copyleft surprises in proprietary code (GPL/AGPL check)
- [ ] Fonts/images licensed for commercial use (track proof)
- [ ] Repo has a LICENSE file (and it's not contradictory with deps)

## Engineering Artifacts to Store
- `policy_acceptance` table (userId, policyType, version, acceptedAt, ip)
- `data_retention` doc (data types, retention period, deletion method)
- `subprocessors` list (vendor, purpose, data shared, region)
