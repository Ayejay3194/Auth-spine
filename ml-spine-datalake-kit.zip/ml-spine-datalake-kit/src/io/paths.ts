import path from "node:path";

export type LakeConfig = {
  root: string; // e.g. ./lake
};

export function datasetBase(cfg: LakeConfig, dataset: string, version: string) {
  return path.join(cfg.root, `dataset=${dataset}`, `ver=${version}`);
}

export function partitionDir(cfg: LakeConfig, dataset: string, version: string, partitions: Record<string,string>) {
  const parts = Object.entries(partitions).map(([k,v]) => `${k}=${v}`);
  return path.join(datasetBase(cfg, dataset, version), ...parts);
}

export function manifestDir(cfg: LakeConfig) {
  return path.join(cfg.root, "_manifests");
}

export function registryPath(cfg: LakeConfig) {
  return path.join(cfg.root, "_registry.json");
}
