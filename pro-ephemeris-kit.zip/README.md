# Pro Ephemeris Kit (Unbreakable Source of Truth)

This is the **contract + validation + golden-test harness** for an ephemeris/chart engine.

If your app breaks after a refactor, it's because you let random code define “truth”.
This repo makes **truth boring and immutable**.

## What this gives you

- **ChartDataV1**: the one output format every consumer must accept.
- **AMJCS-1 canonicalization**: stable ordering + numeric normalization.
- **SHA-256 integrity**: detect drift instantly.
- **Golden tests**: compare outputs against locked fixtures in CI.
- **Engine interface**: swap engines without changing consumers (Swiss Ephemeris, your TS engine, etc.)

## Install

```bash
npm i
npm test
```

## Golden workflow (the part that makes it unbreakable)

1. Add a request fixture in `fixtures/requests/*.json`
2. Generate expected outputs:

```bash
npm run golden:run
```

3. Lock them in git.
4. CI runs:

```bash
npm run golden:verify
```

If someone refactors and outputs change, CI fails immediately. No silent drift.

## Where Swiss Ephemeris fits

Replace `MockEngine` with a real adapter:

- `class SwissEphEngine implements EphemerisEngine { ... }`
- Return **Omit<ChartDataV1,"integrity">**.
- Pipeline adds canonical + hash.
- Golden tests compare against Solar Fire exports you captured.

You can keep multiple fixture sets:
- `swisseph/` (truth reference)
- `ts-engine/` (your engine)
- diff them in CI (future step)

## “Source of truth” rules (non-negotiable)

- **Never** change `ChartDataV1` without a version bump.
- **Never** compare raw floats. Compare canonical + sha.
- **Never** accept “close enough” outputs in validation suite. If it differs, it’s a regression until proven otherwise.

## Next upgrades (already scaffolded by the structure)

- Differential runner: SwissEph vs TS engine on the same request set
- House systems + aspects computed (right now aspects are empty)
- More fixtures: DST edges, polar births, historical timezone transitions
