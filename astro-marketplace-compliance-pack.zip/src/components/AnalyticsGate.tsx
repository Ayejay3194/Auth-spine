"use client";
import React from "react";
import { canAnalytics } from "../privacy/consent";
import { dnt } from "../privacy/dnt";

export function AnalyticsGate({ children }: { children: React.ReactNode }) {
  const [ok,setOk]=React.useState(false);
  React.useEffect(()=>{ setOk(canAnalytics() && !dnt()); },[]);
  return ok ? <>{children}</> : null;
}
