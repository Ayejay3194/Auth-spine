import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { validate, schemas } from '@auth-spine/core'
import { AuthError, ErrorCode } from '@auth-spine/core'
import { verifyPassword, generateToken, setAuthCookie } from '@auth-spine/auth'
import { prisma } from '@/lib/prisma'
import { errorHandler } from '@auth-spine/core'

const loginSchema = z.object({
  email: schemas.email,
  password: z.string().min(1),
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const data = validate(loginSchema, body)

    const user = await prisma.user.findUnique({ where: { email: data.email } })
    if (!user) throw new AuthError('Invalid credentials', ErrorCode.AUTH_INVALID_CREDENTIALS)

    const ok = await verifyPassword(data.password, user.password)
    if (!ok) throw new AuthError('Invalid credentials', ErrorCode.AUTH_INVALID_CREDENTIALS)

    const token = await generateToken({ userId: user.id, email: user.email, role: user.role })
    const res = NextResponse.json(
      { user: { id: user.id, email: user.email, name: user.name, role: user.role } },
      { status: 200 }
    )
    setAuthCookie(res, token)
    return res
  } catch (e) {
    return errorHandler(e as Error, req)
  }
}
