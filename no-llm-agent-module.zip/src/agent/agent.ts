import { AgentContext, AgentReply, AuditLogger, Clock } from "../core/types.js";
import { RegexEntityExtractor } from "../nlu/entities.js";
import { IntentDetector } from "../nlu/intents.js";
import { createFlowEngine } from "../flows/engine.js";
import { flowDefs } from "../flows/defs.js";
import { ToolRegistry } from "../tools/types.js";

export interface AgentDeps {
  tools: ToolRegistry;
  audit: AuditLogger;
  clock: Clock;
  intent: IntentDetector;
}

export interface ConversationState {
  flow: { intent: any; stepIndex: number; slots: Record<string, string>; completed: boolean } | null;
}

export function createNoLlmAgent(deps: AgentDeps) {
  const entityExtractor = new RegexEntityExtractor();
  const flowEngine = createFlowEngine(flowDefs, { tools: deps.tools, audit: deps.audit, clock: deps.clock });

  async function handle(ctx: AgentContext, state: ConversationState, userText: string): Promise<{ state: ConversationState; reply: AgentReply }> {
    const entities = entityExtractor.extract(userText);

    if (!state.flow || state.flow.completed) {
      const det = deps.intent.detect(userText);
      await deps.audit.write({ at: deps.clock.now(), userId: ctx.userId, role: ctx.role, type: "intent.detected", details: det as any });

      if (det.intent === "unknown") {
        return { state: { flow: null }, reply: { text: "I can help with: password reset, forgot username, data export, or plan change. Which one?" } };
      }

      const started = await flowEngine.start(ctx, det.intent, entities);
      return { state: { flow: started.state }, reply: started.reply };
    }

    const cont = await flowEngine.continue(ctx, state.flow as any, userText, entities);
    return { state: { flow: cont.state }, reply: cont.reply };
  }

  return { handle };
}
