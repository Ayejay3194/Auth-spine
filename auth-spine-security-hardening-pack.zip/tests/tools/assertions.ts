export function expectForbiddenOrNotFound(status: number) {
  // Some systems use 404 to avoid leaking existence; others use 403 to be explicit.
  if (![401, 403, 404].includes(status)) {
    throw new Error(`Expected 401/403/404, got ${status}`);
  }
}

export function expectNotOk(status: number) {
  if (status >= 200 && status < 300) {
    throw new Error(`Expected non-2xx, got ${status}`);
  }
}

export function maybeSkip(reason: string) {
  // Vitest supports test.skip dynamically by throwing this special error pattern is messy.
  // We'll just return a boolean and callers can early-return.
  // (Yes, humans made testing frameworks like this.)
  console.warn(`SKIP: ${reason}`);
}
