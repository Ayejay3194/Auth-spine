export type AuthErrorCode =
  | "INVALID_CREDENTIALS"
  | "EMAIL_NOT_VERIFIED"
  | "ACCOUNT_LOCKED"
  | "ACCOUNT_SUSPENDED"
  | "ACCOUNT_DEACTIVATED"
  | "SESSION_EXPIRED"
  | "SESSION_REVOKED"
  | "STEP_UP_REQUIRED"
  | "PERMISSION_DENIED"
  | "RATE_LIMITED"
  | "CONFLICT"
  | "VALIDATION";

export class AuthError extends Error {
  readonly code: AuthErrorCode;
  readonly status: number;
  readonly details?: Record<string, unknown>;

  constructor(code: AuthErrorCode, message: string, status = 400, details?: Record<string, unknown>) {
    super(message);
    this.name = "AuthError";
    this.code = code;
    this.status = status;
    this.details = details;
  }
}
