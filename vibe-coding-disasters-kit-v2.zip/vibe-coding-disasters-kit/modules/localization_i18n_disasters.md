# LOCALIZATION & INTERNATIONALIZATION DISASTERS

## Translation Issues

- [ ] Hardcoded English strings
- [ ] Machine translation only
- [ ] Poor translation quality
- [ ] Incomplete translations
- [ ] Missing translations showing keys
- [ ] Placeholder text in production
- [ ] Context lost in translation
- [ ] Gendered language issues
- [ ] Formal vs informal inconsistency
- [ ] Cultural insensitivity
- [ ] Offensive translations
- [ ] Brand name translated
- [ ] Technical terms translated incorrectly
- [ ] String concatenation breaking translations

## Regional Adaptation Failures

- [ ] Wrong date format for region
- [ ] Wrong time format (12h vs 24h)
- [ ] Wrong number format
- [ ] Decimal separator issues (. vs ,)
- [ ] Thousand separator issues
- [ ] Currency symbol wrong
- [ ] Currency placement wrong
- [ ] Address format not matching region
- [ ] Phone number format not matching region
- [ ] Zip/postal code validation wrong
- [ ] Name format assumptions (first/last)
- [ ] No support for single names
- [ ] No support for multiple last names
- [ ] Sort order wrong for language
- [ ] Alphabetical order wrong

---
