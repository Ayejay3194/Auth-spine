import { ToneCategory, ToneDecisionInput, ToneDecisionOutput, ToneLine, ToneState } from "./types";

const HIGH_INTENSITY = 4;

function isHigh(x?: number) {
  return typeof x === "number" && x >= HIGH_INTENSITY;
}

function allowedCategories(input: ToneDecisionInput, state: ToneState): ToneCategory[] {
  if (input.risk !== "none" || state.sarcasmLock) {
    return ["sharp-care", "clarity", "meta", "corrective", "dry", "confidence", "boundary"];
  }
  if (input.confidence < 0.6) {
    return ["sharp-care", "clarity", "meta", "corrective", "dry", "confidence"];
  }
  return ["snark","dry","corrective","amused","annoyed","sharp-care","boundary","confidence","meta","clarity"];
}

function capHighIntensity(lines: ToneLine[], maxHigh = 1): ToneLine[] {
  let highs = 0;
  return lines.filter(l => {
    if (l.intensity >= HIGH_INTENSITY) {
      highs += 1;
      return highs <= maxHigh;
    }
    return true;
  });
}

function avoidRepetition(lines: ToneLine[], state: ToneState): ToneLine[] {
  return lines.filter(l => !state.usedIds.has(l.id));
}

function deescalateIfNeeded(lines: ToneLine[], state: ToneState): ToneLine[] {
  if (isHigh(state.lastIntensity)) {
    return lines.filter(l =>
      l.intensity <= 3 &&
      (l.category === "clarity" || l.category === "sharp-care" || l.category === "dry" || l.category === "meta" || l.category === "corrective" || l.category === "confidence")
    );
  }
  return lines;
}

export function chooseToneLines(pool: ToneLine[], input: ToneDecisionInput, state: ToneState): ToneDecisionOutput {
  const maxLines = input.maxLines ?? 3;

  const allowed = new Set(allowedCategories(input, state));
  let candidates = pool.filter(l => allowed.has(l.category));

  const triggerMatches = candidates.filter(l => l.trigger === input.trigger);
  if (triggerMatches.length) candidates = triggerMatches;

  candidates = avoidRepetition(candidates, state);
  candidates = deescalateIfNeeded(candidates, state);

  candidates.sort((a, b) => {
    const aPenalty = (input.confidence < 0.75 && a.intensity >= 4) ? 10 : 0;
    const bPenalty = (input.confidence < 0.75 && b.intensity >= 4) ? 10 : 0;
    return (aPenalty + a.intensity) - (bPenalty + b.intensity);
  });

  const selected = capHighIntensity(candidates.slice(0, maxLines), 1);

  const reason =
    input.risk !== "none" || state.sarcasmLock
      ? "sarcasm blocked by risk/lock"
      : input.confidence < 0.6
      ? "low confidence: sharp-care/clarity favored"
      : isHigh(state.lastIntensity)
      ? "de-escalation after high intensity"
      : "standard selection";

  return { selected, reason };
}
