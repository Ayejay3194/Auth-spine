Compliance Mapping

SOC2:
- Access controls: auth/
- Logging: logging/
- Change management: ci/

GDPR:
- Data minimization
- Right to deletion
- Auditability
