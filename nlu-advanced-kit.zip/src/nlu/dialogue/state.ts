import type { DialogueState } from "../types";

export function newState(sessionId: string): DialogueState {
  return {
    sessionId,
    slots: {},
    references: {},
    turn: 0,
    updatedAt: new Date().toISOString(),
  };
}

export function bumpTurn(state: DialogueState, userText: string): DialogueState {
  return {
    ...state,
    turn: state.turn + 1,
    lastUserText: userText,
    updatedAt: new Date().toISOString(),
  };
}
