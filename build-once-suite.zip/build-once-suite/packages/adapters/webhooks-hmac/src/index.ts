import crypto from "node:crypto";
import type { WebhookSigner } from "@suite/modules-webhooks";

export class HmacSha256Signer implements WebhookSigner {
  sign(secret: string, body: string, ts: string): string {
    const h = crypto.createHmac("sha256", secret);
    h.update(ts + "." + body);
    return h.digest("hex");
  }
  verify(secret: string, body: string, ts: string, sig: string): boolean {
    const expected = this.sign(secret, body, ts);
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig));
  }
}
