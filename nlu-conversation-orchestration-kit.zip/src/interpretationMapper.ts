import { DeliveryStyle, InterpretationSignals, ToneLevel } from "./types";

// Maps interpretation signals to delivery style knobs.
// Swap these mappings for astrology/HD/your own signals.
export function mapSignalsToStyle(tone: ToneLevel, signals?: InterpretationSignals): DeliveryStyle {
  const s = signals ?? {};

  // Defaults by tone
  const base: DeliveryStyle =
    tone === 0 ? { brevity: "medium", indirectness: "low", warmth: "high", punch: "low" } :
    tone === 1 ? { brevity: "medium", indirectness: "medium", warmth: "medium", punch: "low" } :
    tone === 2 ? { brevity: "short", indirectness: "high", warmth: "low", punch: "medium" } :
                 { brevity: "short", indirectness: "medium", warmth: "low", punch: "high" };

  // Example signal knobs:
  // saturn -> more direct + accountability
  const saturn = s["saturn"] ?? 0;
  if (saturn > 0.5) {
    base.indirectness = "low";
    base.brevity = "short";
  }

  // neptune -> more indirect + poetic fog
  const neptune = s["neptune"] ?? 0;
  if (neptune > 0.5) {
    base.indirectness = "high";
    base.brevity = "medium";
  }

  // mars -> more punch + short
  const mars = s["mars"] ?? 0;
  if (mars > 0.5) {
    base.punch = "high";
    base.brevity = "short";
  }

  // venus -> warmth
  const venus = s["venus"] ?? 0;
  if (venus > 0.5) {
    base.warmth = "high";
  }

  return base;
}
