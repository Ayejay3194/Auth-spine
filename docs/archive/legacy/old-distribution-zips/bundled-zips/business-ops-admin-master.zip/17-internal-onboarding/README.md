# 17-internal-onboarding

How the system works.
