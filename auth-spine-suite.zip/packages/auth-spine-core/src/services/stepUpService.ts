import type { ClockPort } from "../ports/clockPort.js";
import type { AuthContext } from "../model/authContext.js";
import { AuthError } from "../model/errors.js";
import { minutesFromNowIso, isIsoBefore } from "../util/time.js";
import type { EventBus } from "../model/events.js";

export interface StepUpPolicy { windowMinutes: number; }

export class StepUpService {
  constructor(private clock: ClockPort, private bus: EventBus, private policy: StepUpPolicy) {}

  require(ctx: AuthContext, action: string): void {
    if (!ctx.stepUpSatisfiedUntil) throw new AuthError("STEP_UP_REQUIRED", `Step-up required for ${action}`, 401, { action });
    if (isIsoBefore(ctx.stepUpSatisfiedUntil, this.clock.nowIso())) throw new AuthError("STEP_UP_REQUIRED", `Step-up expired for ${action}`, 401, { action });
  }

  async satisfy(ctx: AuthContext): Promise<AuthContext> {
    const until = minutesFromNowIso(this.clock.nowMs(), this.policy.windowMinutes);
    const next: AuthContext = { ...ctx, stepUpSatisfiedUntil: until };
    await this.bus.publish({ type: "auth.stepup.satisfied", userId: ctx.userId, sessionId: ctx.sessionId, until, at: this.clock.nowIso() });
    return next;
  }
}
