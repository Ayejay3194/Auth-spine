import { describe, it, expect } from "vitest";
import { BASE_URL } from "../tools/config";
import { http } from "../tools/http";

/**
 * Input safety tests: XSS/injection payloads should be rejected or sanitized.
 * Customize endpoints to your real write APIs.
 */
describe("security: input safety", () => {
  it("rejects obvious XSS payloads on login fields", async () => {
    const r = await http("POST", `${BASE_URL}/auth/login`, {
      body: { tenantId: "<script>alert(1)</script>", email: "a@example.com", password: "<img src=x onerror=alert(1)>" }
    });

    // Acceptable outcomes:
    // - 400 validation error
    // - 401 unauthorized
    // Not acceptable: 500 crash.
    expect(r.status).toBeLessThan(500);
  });

  it("does not reflect raw HTML in error responses (heuristic)", async () => {
    const r = await http("POST", `${BASE_URL}/auth/login`, {
      body: { tenantId: "<b>t</b>", email: "<svg onload=alert(1)>", password: "x" }
    });
    expect(r.status).toBeLessThan(500);
    // Heuristic: response body should not include the raw payload
    expect(r.text.includes("<svg")).toBe(false);
    expect(r.text.includes("onload=alert")).toBe(false);
  });
});
