/**
 * Edge Function: webhook handler template
 * - Verify signature
 * - Enforce replay protection (delivery_id uniqueness)
 * - Idempotent processing
 */
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import crypto from "node:crypto";

function timingSafeEqual(a: string, b: string) {
  try { return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b)); } catch { return false; }
}

Deno.serve(async (req) => {
  const raw = await req.text();
  const sig = req.headers.get("x-signature") ?? "";
  const secret = Deno.env.get("WEBHOOK_SECRET") ?? "";

  const mac = crypto.createHmac("sha256", secret).update(raw).digest("hex");
  if (!timingSafeEqual(sig, mac)) return new Response("bad signature", { status: 401 });

  const evt = JSON.parse(raw);
  const tenantId = evt.tenant_id;
  const deliveryId = evt.id;

  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

  const { error: replayErr } = await sb.from("webhook_deliveries").insert({
    tenant_id: tenantId, provider: "generic", delivery_id: deliveryId
  });

  if (replayErr) return new Response("replay", { status: 409 });

  // TODO: process event idempotently
  return new Response("ok");
});
