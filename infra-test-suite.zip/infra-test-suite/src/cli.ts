import path from "node:path";
import fs from "node:fs";
import { loadProfile, loadAllowlist } from "./profile.js";
import { CHECKS } from "./checks/index.js";
import type { CheckContext, Finding, Severity } from "./types.js";
import { makeRunId, writeReport, severityGTE } from "./utils/report.js";

function arg(name: string): string | null {
  const idx = process.argv.indexOf(name);
  if (idx === -1) return null;
  return process.argv[idx + 1] ?? null;
}

function usage() {
  console.log(`Usage:
  node dist/cli.js --root <repoRoot> --profile <profilePath> [--out reports]
`);
}

function applyWaivers(findings: Finding[], allowlist: any): Finding[] {
  const waivers = allowlist?.waivers ?? [];
  if (!Array.isArray(waivers) || waivers.length === 0) return findings;

  const now = Date.now();
  const active = waivers.filter((w: any) => {
    const exp = Date.parse(w.expires ?? "");
    return w.id && !Number.isNaN(exp) && exp >= now;
  });

  return findings.filter(f => !active.some((w: any) => w.id === f.id));
}

function totals(findings: Finding[]) {
  const base: Record<Severity, number> = { P0:0, P1:0, P2:0, INFO:0 };
  for (const f of findings) base[f.severity] = (base[f.severity] ?? 0) + 1;
  return base;
}

async function main() {
  const root = arg("--root");
  const profilePath = arg("--profile");
  const outDir = arg("--out") ?? "reports";

  if (!root || !profilePath) { usage(); process.exit(2); }

  const absRoot = path.resolve(root);
  const absProfile = path.resolve(profilePath);
  if (!fs.existsSync(absRoot)) throw new Error(`Root not found: ${absRoot}`);
  if (!fs.existsSync(absProfile)) throw new Error(`Profile not found: ${absProfile}`);

  const profile = loadProfile(absProfile);
  const allowlistPath = path.resolve(path.dirname(absProfile), profile.run.allowlistFile);
  const allowlist = loadAllowlist(allowlistPath);

  const ctx: CheckContext = {
    root: absRoot,
    profilePath: absProfile,
    profile,
    allowlist,
    nowISO: new Date().toISOString()
  };

  const all: Finding[] = [];
  for (const c of CHECKS) {
    const res = await c.run(ctx);
    all.push(...res);
  }

  const waived = applyWaivers(all, allowlist);
  const totalsBySeverity = totals(waived);
  const failOn = profile.run.failOnSeverity as Severity;

  const failed = waived.some(f => severityGTE(f.severity, failOn));

  for (const s of ["P0","P1","P2","INFO"] as Severity[]) {
    if (totalsBySeverity[s] > 0) console.log(`${s}: ${totalsBySeverity[s]}`);
  }
  if (waived.length === 0) console.log("No findings. Suspiciously competent.");

  const report = {
    meta: {
      timestamp: ctx.nowISO,
      root: absRoot,
      profilePath: absProfile,
      tool: "infra-test-suite",
      version: "0.1.0",
      runId: makeRunId()
    },
    summary: { totalsBySeverity, failed, failOnSeverity: failOn },
    findings: waived
  };

  const outPath = writeReport(path.join(absRoot, outDir), report);
  console.log(`Report written: ${outPath}`);

  process.exit(failed ? 1 : 0);
}

main().catch(err => {
  console.error(err);
  process.exit(2);
});
