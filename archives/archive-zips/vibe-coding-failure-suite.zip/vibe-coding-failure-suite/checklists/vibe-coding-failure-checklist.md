# Things That Can Go Wrong With Vibe Coding (Checklist)

_Version 1.0.0 | Generated 2025-12-16T06:03:25.263566Z_

Use this like a preflight: if you can’t check these off, don’t ship. Your future self hates you.

## Security Vulnerabilities

### Authentication & Authorization Disasters  
_Default severity: **critical**_

- [ ] **VCF-0001** No authentication on critical endpoints
- [ ] **VCF-0002** Hardcoded admin credentials in code
- [ ] **VCF-0003** JWT tokens without expiration
- [ ] **VCF-0004** Session tokens stored in localStorage (XSS vulnerable)
- [ ] **VCF-0005** Authorization checks only on frontend
- [ ] **VCF-0006** User can edit their own role/permissions
- [ ] **VCF-0007** Password reset tokens never expire
- [ ] **VCF-0008** No rate limiting on login attempts
- [ ] **VCF-0009** CORS allowing all origins (*)
- [ ] **VCF-0010** No logout or logout doesn't invalidate tokens

### Injection Vulnerabilities  
_Default severity: **critical**_

- [ ] **VCF-0011** SQL injection via string concatenation / raw SQL with user input
- [ ] **VCF-0012** No parameterized queries
- [ ] **VCF-0013** XSS: dangerouslySetInnerHTML with user content
- [ ] **VCF-0014** No input sanitization / output encoding
- [ ] **VCF-0015** Unsafe deserialization
- [ ] **VCF-0016** Path traversal in file paths/uploads
- [ ] **VCF-0017** Header injection

### Data Exposure  
_Default severity: **high**_

- [ ] **VCF-0018** API keys committed to Git / .env in version control
- [ ] **VCF-0019** Verbose stack traces in production
- [ ] **VCF-0020** Debug mode enabled in production
- [ ] **VCF-0021** Source maps exposed in production
- [ ] **VCF-0022** GraphQL introspection enabled in production
- [ ] **VCF-0023** PII in URLs or logs
- [ ] **VCF-0024** Database directly accessible from internet

### File Upload Vulnerabilities  
_Default severity: **high**_

- [ ] **VCF-0025** No file type validation or size limits
- [ ] **VCF-0026** Files saved with original names (no sanitization)
- [ ] **VCF-0027** Uploads stored in web-accessible directory
- [ ] **VCF-0028** Accepting SVG with embedded JavaScript
- [ ] **VCF-0029** No malware/virus scanning
- [ ] **VCF-0030** Zip bombs not prevented

## Database Disasters

### Schema & Design Problems  
_Default severity: **high**_

- [ ] **VCF-0031** No primary keys / foreign keys / constraints
- [ ] **VCF-0032** Money stored as floats (rounding errors)
- [ ] **VCF-0033** Timestamps stored as strings / mixed timezones
- [ ] **VCF-0034** Missing indexes on queried columns
- [ ] **VCF-0035** Over-indexing every column

### Query Problems  
_Default severity: **high**_

- [ ] **VCF-0036** N+1 query problem everywhere
- [ ] **VCF-0037** SELECT * everywhere
- [ ] **VCF-0038** No pagination (loading all records)
- [ ] **VCF-0039** Full table scans on large tables
- [ ] **VCF-0040** LIKE with leading wildcard (%value) on large datasets

### Data Integrity Issues  
_Default severity: **high**_

- [ ] **VCF-0041** No transactions for multi-step operations
- [ ] **VCF-0042** Race conditions / lost updates
- [ ] **VCF-0043** Schema changes in production without testing
- [ ] **VCF-0044** Migrations with no rollback plan
- [ ] **VCF-0045** Backups never tested / no PITR

### Row Level Security (RLS) Issues  
_Default severity: **critical**_

- [ ] **VCF-0046** RLS not enabled
- [ ] **VCF-0047** RLS policies too permissive
- [ ] **VCF-0048** Forgetting policies for new tables
- [ ] **VCF-0049** Using service role in client (bypasses RLS)
- [ ] **VCF-0050** Complex RLS causing slow queries

## API & Backend Disasters

### API Design Problems  
_Default severity: **medium**_

- [ ] **VCF-0051** No API versioning; breaking changes unannounced
- [ ] **VCF-0052** No standard error responses / status codes
- [ ] **VCF-0053** No input validation; trusting client input
- [ ] **VCF-0054** No rate limiting
- [ ] **VCF-0055** No pagination/filtering/sorting on list endpoints
- [ ] **VCF-0056** No request ID for debugging

### Error Handling Problems  
_Default severity: **high**_

- [ ] **VCF-0057** No error handling / empty catch blocks
- [ ] **VCF-0058** Swallowing errors silently / not logging
- [ ] **VCF-0059** Logging sensitive data (tokens/passwords)
- [ ] **VCF-0060** Exposing stack traces to users
- [ ] **VCF-0061** No retry logic / no circuit breaker for external services

### Webhook & Integration Issues  
_Default severity: **high**_

- [ ] **VCF-0062** No webhook signature verification
- [ ] **VCF-0063** No idempotency; processing duplicates
- [ ] **VCF-0064** Webhook timeouts; no retry and replay
- [ ] **VCF-0065** No webhook logging

## Frontend Disasters

### State Management Chaos  
_Default severity: **medium**_

- [ ] **VCF-0066** Global state for everything or no state management
- [ ] **VCF-0067** Not handling loading/error states
- [ ] **VCF-0068** Optimistic updates without rollback
- [ ] **VCF-0069** Client and server state out of sync

### React/Framework Specific Problems  
_Default severity: **medium**_

- [ ] **VCF-0070** Infinite re-render loops / bad useEffect deps
- [ ] **VCF-0071** Using index as key
- [ ] **VCF-0072** Not cleaning up effects / event listeners
- [ ] **VCF-0073** Unnecessary re-renders due to context misuse

### UI/UX Disasters  
_Default severity: **medium**_

- [ ] **VCF-0074** No loading indicators / no feedback
- [ ] **VCF-0075** Not accessible (no keyboard nav/ARIA)
- [ ] **VCF-0076** Not mobile responsive / tiny touch targets
- [ ] **VCF-0077** Layout shifts / janky animations

### Form Problems  
_Default severity: **medium**_

- [ ] **VCF-0078** Only client-side validation
- [ ] **VCF-0079** Submit button enabled during submission (double submit)
- [ ] **VCF-0080** Unclear error messages; errors not near fields
- [ ] **VCF-0081** No confirmation on destructive actions

## Code Quality Disasters

### Architecture & Organization  
_Default severity: **medium**_

- [ ] **VCF-0082** No project structure; everything in one file
- [ ] **VCF-0083** Business logic in UI components
- [ ] **VCF-0084** Copy-pasted code everywhere
- [ ] **VCF-0085** Circular dependencies / tight coupling

### Type Safety Issues  
_Default severity: **medium**_

- [ ] **VCF-0086** TypeScript with any everywhere / @ts-ignore everywhere
- [ ] **VCF-0087** Type assertions without validation
- [ ] **VCF-0088** Strings used where enums/discriminated unions needed

## Testing Disasters

### Testing Gaps  
_Default severity: **high**_

- [ ] **VCF-0089** No tests
- [ ] **VCF-0090** Only happy-path tests
- [ ] **VCF-0091** No integration/E2E tests
- [ ] **VCF-0092** Flaky tests; tests dependent on order

### Testing Problems  
_Default severity: **medium**_

- [ ] **VCF-0093** Not mocking external services appropriately
- [ ] **VCF-0094** Shared test state; no cleanup
- [ ] **VCF-0095** Over-mocking; snapshot tests everywhere

## Deployment & DevOps Disasters

### Build & Deployment Issues  
_Default severity: **high**_

- [ ] **VCF-0096** No CI/CD pipeline
- [ ] **VCF-0097** No staging; testing in production
- [ ] **VCF-0098** No rollback plan
- [ ] **VCF-0099** Deploying breaking changes without warning

### Environment Configuration  
_Default severity: **high**_

- [ ] **VCF-0100** .env in version control / secrets in images
- [ ] **VCF-0101** Wrong environment used accidentally
- [ ] **VCF-0102** Debug/verbose logging in production
- [ ] **VCF-0103** Source maps exposed in production

### Infrastructure Problems  
_Default severity: **high**_

- [ ] **VCF-0104** No monitoring/alerting/logging/metrics
- [ ] **VCF-0105** No health checks / uptime monitoring
- [ ] **VCF-0106** No incident response plan / no postmortems

### Container & Orchestration Issues  
_Default severity: **medium**_

- [ ] **VCF-0107** Running as root in containers
- [ ] **VCF-0108** Using latest tag / not pinning dependencies
- [ ] **VCF-0109** No resource limits / no health checks
- [ ] **VCF-0110** No container scanning

## Version Control & Documentation Disasters

### Git Problems  
_Default severity: **medium**_

- [ ] **VCF-0111** Committing secrets / node_modules / build artifacts
- [ ] **VCF-0112** Committing to main directly; no PRs/reviews
- [ ] **VCF-0113** No .gitignore / wrong .gitignore
- [ ] **VCF-0114** Messy history; force pushing to main

### Branch Management  
_Default severity: **medium**_

- [ ] **VCF-0115** No branch protection rules / bypassing protection
- [ ] **VCF-0116** Long-lived feature branches; stale branches
- [ ] **VCF-0117** No required status checks before merge

### Documentation Disasters  
_Default severity: **medium**_

- [ ] **VCF-0118** No README / setup instructions
- [ ] **VCF-0119** Outdated docs that contradict code
- [ ] **VCF-0120** No troubleshooting guide / runbooks

## Performance, Data/Storage, Dependencies, Business Logic, UX, Observability, Collaboration, Legal

### Performance & Scalability Disasters  
_Default severity: **high**_

- [ ] **VCF-0121** No caching strategy / cache invalidation problems
- [ ] **VCF-0122** Blocking operations on main thread
- [ ] **VCF-0123** No timeouts/retries/backoff
- [ ] **VCF-0124** Thundering herd / cascading failures

### Data & Storage Disasters  
_Default severity: **high**_

- [ ] **VCF-0125** Private files publicly accessible
- [ ] **VCF-0126** No storage monitoring / quotas exceeded
- [ ] **VCF-0127** No file backups / accidental deletions

### Third-Party & Dependency Disasters  
_Default severity: **high**_

- [ ] **VCF-0128** No lockfile; unpinned dependencies
- [ ] **VCF-0129** Using vulnerable/unmaintained packages
- [ ] **VCF-0130** No dependency auditing
- [ ] **VCF-0131** No rate limit handling for external APIs

### Business Logic Disasters  
_Default severity: **high**_

- [ ] **VCF-0132** Timezone/DST bugs; rounding errors with money
- [ ] **VCF-0133** No idempotency; duplicate processing
- [ ] **VCF-0134** Allowing impossible states; no state machine

### Accessibility, Mobile, i18n  
_Default severity: **medium**_

- [ ] **VCF-0135** No semantic HTML / ARIA / keyboard nav
- [ ] **VCF-0136** Not mobile responsive; iOS modal scrolling bugs
- [ ] **VCF-0137** No internationalization; hardcoded strings

### Monitoring & Observability Disasters  
_Default severity: **high**_

- [ ] **VCF-0138** No centralized logging; cannot correlate requests
- [ ] **VCF-0139** No tracing; cannot debug production
- [ ] **VCF-0140** No alerts or noisy alerts with no context

### Communication & Collaboration Disasters  
_Default severity: **medium**_

- [ ] **VCF-0141** No code reviews; rubber-stamp approvals
- [ ] **VCF-0142** No decision logs / meeting notes
- [ ] **VCF-0143** Rushing to production; no process

### Legal & Compliance Disasters  
_Default severity: **high**_

- [ ] **VCF-0144** No privacy policy / collecting data without consent
- [ ] **VCF-0145** No GDPR compliance work
