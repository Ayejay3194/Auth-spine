export type Tone = "direct" | "friendly" | "brief";

export function applyTone(text: string, tone: Tone): string {
  if (tone === "brief") return text.replace(/\s+/g, " ").trim();
  if (tone === "friendly") return soften(text);
  return text;
}

function soften(t: string): string {
  // light touch, not cringe.
  if (/^quick question/i.test(t)) return t;
  return t.replace(/^/,"");
}
