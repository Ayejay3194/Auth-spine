# Backup + Restore Drill

## Frequency
Monthly.

## Steps
1. Take a fresh backup snapshot
2. Restore into a separate environment
3. Run smoke tests: /health, login, create+read a record
4. Verify integrity: row counts, critical tables, indexes
5. Record results (date, duration, success/fail)
