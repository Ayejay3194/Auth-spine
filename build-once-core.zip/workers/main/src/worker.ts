import { createLogger } from "@suite/observability";
import { getPrisma } from "@suite/db";

const log = createLogger();
const prisma = getPrisma();

/**
 * Worker skeleton:
 * Replace with BullMQ Worker consuming Redis queues, or your queue adapter.
 * This exists so you deploy workers separately from API.
 */
async function tick() {
  const pending = await prisma.webhookDelivery.findMany({
    where: { status: "pending", nextAttemptAt: { lte: new Date() } },
    take: 50
  });

  if (pending.length) log.info("worker delivering webhooks", { count: pending.length });

  for (const d of pending) {
    try {
      // TODO: POST to d.endpoint, sign payload, handle response.
      await prisma.webhookDelivery.update({ where: { id: d.id }, data: { status: "success", attempts: d.attempts + 1 } });
    } catch (e: any) {
      const attempts = d.attempts + 1;
      const delay = Math.min(60_000, attempts * 5_000);
      await prisma.webhookDelivery.update({
        where: { id: d.id },
        data: { status: "failed", attempts, lastError: String(e?.message ?? e), nextAttemptAt: new Date(Date.now() + delay) }
      });
    }
  }
}

setInterval(tick, 2000);
log.info("worker up");
