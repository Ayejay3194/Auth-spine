Install k6 and run: BASE_URL=http://localhost:3000 k6 run loadtest/k6_smoke.js
