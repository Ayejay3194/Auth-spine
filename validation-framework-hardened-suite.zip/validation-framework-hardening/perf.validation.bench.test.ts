
/**
 * Performance checks (GATED)
 * Run with: RUN_PERF=1 npm test
 *
 * Not unit tests. Environment-sensitive.
 */
import { performance } from 'node:perf_hooks';

import { ValidationService } from '../../packages/enterprise/validation/service';
import { ReceiptGenerator } from '../../packages/enterprise/validation/receipts';
import { TransactionType } from '../../packages/enterprise/validation/types';

const PERF = process.env.RUN_PERF === '1';
const ttest = PERF ? test : test.skip;

describe('Perf Bench (optional)', () => {
  let validationService: ValidationService;
  let receiptGenerator: ReceiptGenerator;

  beforeEach(() => {
    validationService = new ValidationService();
    receiptGenerator = new ReceiptGenerator();
  });

  ttest('validate single transaction under 75ms (soft)', async () => {
    const tx = { id: 'perf_txn_001', amount: 1000, currency: 'USD', fromAccount: 'acc_001', toAccount: 'acc_002' };
    const t0 = performance.now();
    await validationService.validateFinancialTransaction(tx as any);
    const t1 = performance.now();
    expect(t1 - t0).toBeLessThan(75);
  });

  ttest('generate receipt under 150ms (soft)', async () => {
    const tx = { id: 'perf_txn_002', amount: 1000, currency: 'USD', fromAccount: 'acc_001', toAccount: 'acc_002' };
    const t0 = performance.now();
    await receiptGenerator.generateReceipt(tx.id, TransactionType.PAYMENT, tx as any);
    const t1 = performance.now();
    expect(t1 - t0).toBeLessThan(150);
  });

  ttest('batch: 500 validations under 2.5s (soft)', async () => {
    const txs = Array.from({ length: 500 }, (_, i) => ({
      id: `perf_batch_${i}`,
      amount: 100 + i,
      currency: 'USD',
      fromAccount: `acc_${i}`,
      toAccount: `acc_${i + 1}`,
    }));

    const t0 = performance.now();
    const results = await Promise.all(txs.map(t => validationService.validateFinancialTransaction(t as any)));
    const t1 = performance.now();

    expect(results.length).toBe(500);
    expect(t1 - t0).toBeLessThan(2500);
  });
});
