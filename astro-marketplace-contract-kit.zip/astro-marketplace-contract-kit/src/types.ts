export type ISODate = string; // YYYY-MM-DD
export type ISOTime = string; // HH:mm:ss

export type HouseSystem =
  | 'placidus'
  | 'whole_sign'
  | 'koch'
  | 'equal'
  | 'campanus'
  | 'regiomontanus'
  | 'porphyry';

export type Zodiac = 'tropical' | 'sidereal';

export type PointName =
  | 'Sun'
  | 'Moon'
  | 'Mercury'
  | 'Venus'
  | 'Mars'
  | 'Jupiter'
  | 'Saturn'
  | 'Uranus'
  | 'Neptune'
  | 'Pluto'
  | 'Node'
  | 'Lilith'
  | 'Chiron'
  | 'Fortune'
  | 'Vertex'
  | 'ASC'
  | 'MC'
  | `H${1|2|3|4|5|6|7|8|9|10|11|12}`;

export type Sign =
  | 'Aries'
  | 'Taurus'
  | 'Gemini'
  | 'Cancer'
  | 'Leo'
  | 'Virgo'
  | 'Libra'
  | 'Scorpio'
  | 'Sagittarius'
  | 'Capricorn'
  | 'Aquarius'
  | 'Pisces';

export type RetrogradeFlag = 'R' | '';

export interface Geo {
  lat: number; // decimal degrees, north positive
  lon: number; // decimal degrees, east positive
  label?: string; // optional human label (city)
}

export interface ChartMeta {
  dateOfBirth: ISODate;
  timeOfBirth: ISOTime;
  timezoneOffsetMinutes: number; // e.g. -300 for America/New_York standard
  universalTime: string; // ISO datetime string in UTC
  localSiderealTime: string; // HH:mm:ss
  houseSystem: HouseSystem;
  zodiac: Zodiac;
  location: Geo;
}

export interface PointPosition {
  name: PointName;
  sign: Sign;
  degree: number; // 0..29.999...
  minute: number; // 0..59
  second?: number; // 0..59
  retrograde?: RetrogradeFlag;
}

export interface Aspect {
  a: PointName;
  b: PointName;
  type:
    | 'conjunction'
    | 'opposition'
    | 'trine'
    | 'square'
    | 'sextile'
    | 'quincunx'
    | 'semisextile'
    | 'semisquare'
    | 'sesquisquare'
    | 'quintile'
    | 'biquintile';
  orbDeg: number;
  applying?: boolean;
}

export interface ChartDataV1 {
  schema: 'astro.marketplace.chart.v1';
  engine: {
    name: string;
    version: string;
    ephemeris: string; // e.g. 'swisseph'
  };
  meta: ChartMeta;
  points: PointPosition[];
  aspects?: Aspect[];
  notes?: {
    warnings?: string[];
    source?: string;
  };
}

export interface IntegrityStamp {
  algorithm: 'SHA-256';
  canonical: 'AMJCS-1';
  hashHex: string;
}

export interface SignedChartV1 {
  chart: ChartDataV1;
  integrity: IntegrityStamp;
}
