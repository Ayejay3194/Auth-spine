export type Role = "owner" | "admin" | "manager" | "staff" | "readonly" | "system";

export interface Actor {
  userId: string;
  role: Role;
}

export interface RequestContext {
  requestId: string;
  tenantId: string;
  actor: Actor;
  nowISO: string;
  ip?: string;
  userAgent?: string;
  traceId?: string;
}

export type Result<T> =
  | { ok: true; data: T }
  | { ok: false; error: { code: string; message: string; details?: unknown } };
