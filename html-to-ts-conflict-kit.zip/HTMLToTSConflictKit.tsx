
"use client";
import React, { useState } from "react";
import {
  Search,
  AlertTriangle,
  Code,
  Zap,
  XCircle,
  CheckCircle,
  Copy,
  ChevronDown,
  ChevronRight
} from "lucide-react";

const HTMLToTSConflictKit = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const conflictData: Record<string, any[]> = {
    "JSX vs HTML Syntax Conflicts": [
      {
        id: "jsx-1",
        problem: "class attribute causing errors",
        wrongCode: `<div class="container">Content</div>`,
        rightCode: `<div className="container">Content</div>`,
        explanation: "In JSX, use className instead of class.",
        additionalIssues: [
          "Replace all class= with className=",
          "Check dynamically generated class names"
        ]
      },
      {
        id: "jsx-2",
        problem: "for attribute on labels breaking",
        wrongCode: `<label for="email">Email</label>`,
        rightCode: `<label htmlFor="email">Email</label>`,
        explanation: "JSX uses htmlFor instead of for.",
        additionalIssues: ["Update all label elements"]
      }
    ]
  };

  const copyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({ ...prev, [category]: !prev[category] }));
  };

  const filteredData = searchTerm
    ? Object.fromEntries(
        Object.entries(conflictData).map(([k, v]) => [
          k,
          v.filter(i => i.problem.toLowerCase().includes(searchTerm.toLowerCase()))
        ]).filter(([, v]) => v.length)
      )
    : conflictData;

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-yellow-50 p-6">
      <div className="max-w-5xl mx-auto space-y-4">
        <div className="bg-white border-4 border-red-500 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center gap-3 mb-4">
            <AlertTriangle className="w-8 h-8 text-red-600" />
            <h1 className="text-3xl font-bold">HTML → TypeScript Conflict Resolver</h1>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search conflicts..."
              className="w-full pl-12 pr-4 py-3 border-2 rounded-lg"
            />
          </div>
        </div>

        {Object.entries(filteredData).map(([category, items]) => (
          <div key={category} className="bg-white rounded-xl border">
            <button
              onClick={() => toggleCategory(category)}
              className="w-full flex justify-between px-6 py-4 bg-red-100"
            >
              <span className="flex items-center gap-2">
                <Code className="w-5 h-5" /> {category}
              </span>
              {expandedCategories[category] ? <ChevronDown /> : <ChevronRight />}
            </button>

            {expandedCategories[category] && (
              <div className="p-6 space-y-6">
                {items.map(item => (
                  <div key={item.id} className="border-l-4 border-red-500 pl-4">
                    <h3 className="font-bold mb-2 flex gap-2 items-center">
                      <AlertTriangle className="w-4 h-4" />
                      {item.problem}
                    </h3>

                    <div className="bg-red-50 p-3 rounded mb-3">
                      <pre className="bg-slate-900 text-slate-100 p-3 rounded">
                        <code>{item.wrongCode}</code>
                      </pre>
                    </div>

                    <div className="bg-green-50 p-3 rounded mb-3 relative">
                      <button
                        onClick={() => copyCode(item.rightCode, item.id)}
                        className="absolute top-2 right-2"
                      >
                        {copiedId === item.id ? <CheckCircle /> : <Copy />}
                      </button>
                      <pre className="bg-slate-900 text-slate-100 p-3 rounded pr-10">
                        <code>{item.rightCode}</code>
                      </pre>
                    </div>

                    <p className="text-sm text-slate-700">{item.explanation}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default HTMLToTSConflictKit;
