import Docs from "@/components/docs/AuthSpineSuperSolid";
export default function Page() { return <Docs />; }
