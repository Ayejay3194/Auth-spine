export default function AdminHome() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Admin</h1>
      <p className="text-sm text-slate-300">
        This area is for admins only. Next tasks:
      </p>
      <ul className="list-disc pl-5 text-sm text-slate-300 space-y-1">
        <li>Add a guard that only allows users with role="admin".</li>
        <li>List users and subscriptions.</li>
        <li>Add simple system health info.</li>
      </ul>
    </div>
  );
}
