import { prisma } from '../../../lib/db';

type Props = {
  params: { slug: string };
};

export default async function BlogPostPage({ params }: Props) {
  const post = await prisma.post.findUnique({
    where: { slug: params.slug },
  });

  if (!post) {
    return (
      <main className="max-w-2xl mx-auto py-12">
        <p className="text-sm text-slate-400">Post not found.</p>
      </main>
    );
  }

  return (
    <main className="max-w-2xl mx-auto py-12 space-y-4">
      <h1 className="text-3xl font-semibold">{post.title}</h1>
      <p className="whitespace-pre-wrap text-sm text-slate-200">{post.content}</p>
    </main>
  );
}
