# PR Checklist (Required)

## Security
- [ ] No secrets in code, commits, logs, or responses
- [ ] AuthZ checks enforced server-side (not just UI)
- [ ] Sensitive endpoints require auth + role checks
- [ ] Input validation at boundary (API/Edge/DB) with clear errors
- [ ] Rate limiting applied where abuse is plausible
- [ ] File uploads validated (type, size, name) and stored safely

## Data
- [ ] Migrations included and tested (with rollback plan)
- [ ] Indexes reviewed for new queries
- [ ] Multi-step writes are transactional
- [ ] Audit logging for sensitive actions

## Reliability
- [ ] Timeouts and retries for network calls
- [ ] Idempotency for payments/webhooks/jobs
- [ ] Observability: logs + metrics + trace context (request_id)

## UX
- [ ] Loading + error states exist
- [ ] Forms validate and prevent double-submit
- [ ] Accessibility basics: labels, keyboard nav, contrast

## Shipping
- [ ] Tests added/updated
- [ ] Docs updated (README, env vars, runbook)
