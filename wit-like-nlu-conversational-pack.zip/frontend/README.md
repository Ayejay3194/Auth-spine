# Frontend (optional)

This pack is backend-first. To make it feel like a chat:
- Keep a `session_id` in localStorage
- POST every user message to `/v1/message`
- Render `response.text`
