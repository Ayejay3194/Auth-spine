# Auth-Spine Security Hardening Test Pack

This pack adds **real security tests** (negative-path, authz, tenant isolation, token/session, and abuse checks)
for your Auth-Spine API. It's designed to drop into your repo and run with **Vitest**.

## Where to put this
Copy `tests/security` and `tests/tools` into your repo.

Recommended layout:
- `tests/tools/*` (shared helpers)
- `tests/security/*.test.ts` (security suites)

## Environment variables
Set these for CI/local:

- `BASE_URL` (default: http://localhost:3000)
- `TEST_TENANT_A_ID`, `TEST_TENANT_B_ID`
- `TEST_USER_A_EMAIL`, `TEST_USER_B_EMAIL`
- `TEST_USER_PASSWORD` (optional; if your login requires password)
- `TEST_ADMIN_EMAIL` (optional; if you have an admin)
- `TEST_ADMIN_PASSWORD` (optional)
- `RATE_LIMIT_EXPECT_429` (optional; set to "1" if your env enforces 429s)

## Notes
- These tests are written to be **strict** about cross-tenant access:
  - If a cross-tenant read returns **200**, you have an IDOR problem.
  - Acceptable outcomes are usually **403** or **404** (depending on how you hide existence).
- Some tests are designed to **skip** if your API doesn't expose the endpoint. Skips are better than fake passing.

## Run
```bash
pnpm vitest run
# or
npm run test
```
