LUXE RESPONSE TEMPLATES
======================

Opening:
"Thanks for flagging this — I’m looking into it now and will walk you through what I see."

Mid-resolution:
"Here’s what I’m seeing on our end. Let me know if this matches your experience."

Resolution:
"Based on this, here’s what we can do immediately."

Close:
"I’ve taken care of this for you. If anything feels off, you can reply directly here."
