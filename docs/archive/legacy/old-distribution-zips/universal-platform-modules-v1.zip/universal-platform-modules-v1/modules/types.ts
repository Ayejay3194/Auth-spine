export type TierId = "free" | "solo" | "grow" | "salon" | "enterprise";
export type VerticalId =
  | "beauty_wellness"
  | "fitness"
  | "professional_services"
  | "education"
  | "home_services"
  | "health_therapy";

export type ModuleId =
  // kernel
  | "identity_auth"
  | "workspace_tenancy"
  | "billing_ledger"
  | "notification_hub"
  | "files_media"
  // booking
  | "service_catalog"
  | "availability_scheduler"
  | "booking_core"
  | "intake_forms"
  | "calendar_sync"
  // payments/POS
  | "payments_core"
  | "payouts_settlement"
  | "pos_checkout"
  | "subscriptions_packages"
  // CRM/experience
  | "client_profiles"
  | "portfolio_history"
  | "messaging_dm"
  | "client_portal"
  // marketing
  | "campaigns"
  | "review_engine"
  | "referrals"
  | "social_publishing"
  // intelligence/ops
  | "pricing_engine"
  | "no_show_prediction"
  | "ops_analytics"
  | "inventory_costing"
  | "forecasting"
  // team
  | "staff_scheduling"
  | "compensation_commissions"
  | "training_certifications"
  | "internal_comms"
  // network effects
  | "shared_client_identity"
  | "bundle_marketplace"
  | "pro_directory"
  // assistant layer
  | "assistant_nlu"
  | "assistant_automation"
  | "assistant_copy_polish";

export interface ModuleSpec {
  id: ModuleId;
  name: string;
  description: string;
  dependsOn?: ModuleId[];
  optionalWith?: ModuleId[];
  tierMinimum?: TierId;
  verticals?: VerticalId[] | "all";
  tags?: string[];
  events?: string[];
  apis?: string[];
}

export interface EnablementInput {
  tier: TierId;
  vertical: VerticalId;
  flags?: Record<string, boolean>;
  deny?: ModuleId[];
}

export interface EnablementResult {
  enabled: ModuleId[];
  disabled: { id: ModuleId; reason: string }[];
  graph: { id: ModuleId; dependsOn: ModuleId[] }[];
}
