# Apply order (so you don’t faceplant)
1) Create tenants + memberships tables (`02_multi-tenant/migrations/0001_tenants.sql`)
2) Add tenant context function + RLS example (`02_multi-tenant/migrations/0002_rls_tenant_context.sql`)
3) Add advanced patterns as needed (`03_advanced-db-patterns/*`)
4) Add Realtime tables (`04_realtime/*`) + enable Realtime on the right tables
5) Add API keys + webhook replay tables (`06_api-integrations/*`)
6) Add billing/subscriptions tables (`07_billing/*`)
7) Add export/deletion jobs (`08_compliance-ops/*`)
8) Implement tenant resolution + set `app.tenant_id` on DB session in your server code.
