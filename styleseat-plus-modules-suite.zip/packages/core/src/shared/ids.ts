export function cuid(prefix: string = ""): string {
  // simple deterministic-ish ID generator for demos; replace with your real ID generator
  const rand = Math.random().toString(36).slice(2, 10);
  const t = Date.now().toString(36);
  return prefix ? `${prefix}_${t}_${rand}` : `${t}_${rand}`;
}
