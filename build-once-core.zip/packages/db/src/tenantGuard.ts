import type { PrismaClient } from "@prisma/client";

/**
 * Hard rule: every query must be tenant-scoped.
 * These helpers force tenantId into where clauses for common patterns.
 */
export function tenantWhere<T extends Record<string, any>>(tenantId: string, where: T): T & { tenantId: string } {
  return { ...where, tenantId };
}

export async function assertTenantMembership(prisma: PrismaClient, tenantId: string, userId: string) {
  const user = await prisma.user.findFirst({ where: { id: userId, tenantId } });
  if (!user) throw Object.assign(new Error("Not in tenant"), { code: "TENANT_FORBIDDEN" });
  return user;
}
