import type { ID } from "../shared/types.js";

export type FlagRule = { percentage?: number; allowUsers?: ID[]; denyUsers?: ID[] };
export type FeatureFlag = { key: string; enabled: boolean; rule?: FlagRule; variants?: Array<{ id: string; weight: number }> };

export class FeatureFlagService {
  constructor(private flags: FeatureFlag[]) {}

  isEnabled(key: string, userId: ID): boolean {
    const f = this.flags.find(x => x.key === key);
    if (!f) return false;
    if (!f.enabled) return false;
    const rule = f.rule;
    if (!rule) return true;
    if (rule.denyUsers?.includes(userId)) return false;
    if (rule.allowUsers?.includes(userId)) return true;
    if (typeof rule.percentage === "number") return this.bucket(userId, key) < rule.percentage;
    return true;
  }

  variant(key: string, userId: ID): string | null {
    const f = this.flags.find(x => x.key === key);
    if (!f?.variants?.length) return null;
    const r = this.bucket(userId, key) / 100;
    let acc = 0;
    for (const v of f.variants) {
      acc += v.weight;
      if (r <= acc) return v.id;
    }
    return f.variants[0].id;
  }

  private bucket(userId: ID, salt: string): number {
    // stable hash bucket 0..99
    const s = `${userId}:${salt}`;
    let h = 0;
    for (let i=0;i<s.length;i++) h = (h*31 + s.charCodeAt(i)) >>> 0;
    return h % 100;
  }
}
