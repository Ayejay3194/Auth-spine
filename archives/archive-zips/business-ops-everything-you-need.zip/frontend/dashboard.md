Ops + finance dashboard layout.
