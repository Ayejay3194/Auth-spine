import type { NLUModel, DialogueState, NLUResult } from "../types";

/**
 * Small behavior rules to avoid "robot interrogation".
 */
export function shouldClarify(model: NLUModel, state: DialogueState, nlu: NLUResult): boolean {
  // If user just greeted, don't interrogate.
  if (nlu.intent.name === "greeting") return false;

  // If we have no active intent and classifier is unknown, ask what they mean.
  const minAct = model.settings?.minConfidenceToAct ?? 0.55;
  if (nlu.intent.name === "unknown" || nlu.intent.confidence < minAct) return true;

  // If active intent exists and has required slots missing, clarify.
  return true;
}
