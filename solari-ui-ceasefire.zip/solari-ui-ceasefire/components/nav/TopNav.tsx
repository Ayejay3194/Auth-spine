"use client";
import Link from "next/link";
import { useUI } from "@/components/ui/UIContext";

export function TopNav() {
  const { theme, setTheme } = useUI();
  return (
    <header className="sticky top-0 bg-panel/80 backdrop-blur border-b border-white/10">
      <div className="flex items-center justify-between px-4 py-3 max-w-6xl mx-auto">
        <Link href="/" className="font-black tracking-widest text-gold">SOLARI</Link>
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="text-xs border border-white/10 rounded-full px-3 py-1"
        >
          Theme: {theme}
        </button>
      </div>
    </header>
  );
}
