import { describe, test, expect, vi } from "vitest";
import { startSpineServer, stopSpineServer } from "../helpers/testServer";

describe("API Server E2E", () => {
  test("health + core endpoints respond", async () => {
    // E2E should use real time because it interacts with actual server timeouts.
    vi.useRealTimers();

    const { spine, baseUrl } = await startSpineServer({ tenantId: "api-test-tenant" });

    try {
      // Health
      const healthRes = await fetch(`${baseUrl}/health`);
      expect(healthRes.ok).toBe(true);
      const health = await healthRes.json();
      expect(health).toHaveProperty("status");

      const ctx = {
        actor: { userId: "test-user", role: "admin" },
        tenantId: "api-test-tenant",
        nowISO: new Date("2024-01-15T12:00:00.000Z").toISOString()
      };

      // Chat
      const chatRes = await fetch(`${baseUrl}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "book appointment for Alex tomorrow at 2pm", context: ctx })
      });
      expect(chatRes.ok).toBe(true);
      const chat = await chatRes.json();
      expect(chat).toHaveProperty("steps");

      // Intent
      const intentRes = await fetch(`${baseUrl}/api/intent`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: "find client Alex", context: ctx })
      });
      expect(intentRes.ok).toBe(true);
      const intent = await intentRes.json();
      expect(intent).toHaveProperty("intents");

      // Suggestions
      const suggRes = await fetch(`${baseUrl}/api/suggestions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context: { ...ctx, bookings: [], clients: [], practitioner: { id: "test-practitioner" } }
        })
      });
      expect(suggRes.ok).toBe(true);
      const suggestions = await suggRes.json();
      expect(suggestions).toHaveProperty("suggestions");

      // System info
      const infoRes = await fetch(`${baseUrl}/api/system/info`);
      expect(infoRes.ok).toBe(true);
      const info = await infoRes.json();
      expect(info).toHaveProperty("spines");
    } finally {
      await stopSpineServer(spine);
    }
  });
});