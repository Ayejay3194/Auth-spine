-- Soft delete pattern
alter table workspaces add column if not exists deleted_at timestamptz;

create or replace view workspaces_active as
select * from workspaces where deleted_at is null;

-- In RLS policies, include `deleted_at is null` for normal users.
