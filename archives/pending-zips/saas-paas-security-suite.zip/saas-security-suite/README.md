# SaaS/PaaS Security Suite (Zip Pack)

If you're building anything multi-tenant, subscription-based, and internet-facing, this is your checklist turned into something you can actually use.

## What's inside
- `SECURITY_CHECKLIST.md` master checklist
- `controls_catalog.json` structured controls starter
- `IMPLEMENTATION_ROADMAP.md` phased plan
- `templates/` policies + runbooks + evidence tracker

## How to use
1. Start with `IMPLEMENTATION_ROADMAP.md`
2. Convert your must-haves into `controls_catalog.json` and assign owners
3. Use templates to standardize evidence and ops
