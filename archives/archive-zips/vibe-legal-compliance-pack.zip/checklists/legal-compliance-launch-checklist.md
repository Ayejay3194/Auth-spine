# Legal/Compliance Launch Checklist

## Must-have docs (public)
- Terms of Service
- Privacy Policy
- Cookie Policy + preferences UI
- Acceptable Use Policy
- Accessibility Statement

## Must-have product features
- consent recording + versioning
- DSAR: export + delete + access + correction
- retention + deletion jobs (including storage + search + backups expiration)
- vendor/subprocessor inventory
- incident response plan + breach templates

## Must-have operational guardrails
- PII redaction in logs
- analytics consent gate
- admin access logging + MFA
- documented support access policy (JIT, time-boxed)

## High-risk “nope” list
- store card numbers
- log tokens
- ship without deletion/export
- copy ToS from random sites
