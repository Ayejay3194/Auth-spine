# Search, Filtering, Import/Export Checklist

## Search
- [ ] Pagination on all lists
- [ ] Server-side filtering/sorting for large datasets
- [ ] Case-insensitive search where expected
- [ ] Fuzzy matching strategy documented (or explicitly not supported)
- [ ] Search index freshness monitored (no stale results)

## Import
- [ ] Validate schema before import
- [ ] Transactional or chunked with rollback plan
- [ ] Error report with row numbers
- [ ] Dedup strategy (unique keys)

## Export
- [ ] Avoid exporting sensitive data by default
- [ ] Export links are signed + expire
- [ ] Export files deleted after TTL
- [ ] Large exports handled async with progress
