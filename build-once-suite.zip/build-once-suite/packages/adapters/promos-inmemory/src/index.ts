import type { PromoCode, PromoStore } from "@suite/modules-promos";

export class InMemoryPromoStore implements PromoStore {
  private promos = new Map<string, PromoCode>();
  private redemptions = new Map<string, number>();
  private userRedemptions = new Map<string, number>();

  seed(p: PromoCode) { this.promos.set(p.code, p); }

  async get(code: string) { return this.promos.get(code) ?? null; }
  async countRedemptions(code: string) { return this.redemptions.get(code) ?? 0; }
  async countUserRedemptions(userId: string, code: string) { return this.userRedemptions.get(`${userId}:${code}`) ?? 0; }

  redeem(userId: string, code: string) {
    this.redemptions.set(code, (this.redemptions.get(code) ?? 0) + 1);
    this.userRedemptions.set(`${userId}:${code}`, (this.userRedemptions.get(`${userId}:${code}`) ?? 0) + 1);
  }
}
