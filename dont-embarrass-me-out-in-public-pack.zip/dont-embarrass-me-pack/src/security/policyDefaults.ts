import type { Policy } from "./policy";

export function buildDefaultPolicy(): Policy {
  return {
    rules: [
      { role: "admin", resource: "*", actions: ["read", "create", "update", "invoke", "export"] },
      { role: "manager", resource: "bookings", actions: ["read", "create", "update"] },
      { role: "manager", resource: "crm", actions: ["read", "update"] },
      { role: "staff", resource: "bookings", actions: ["read", "create"] },
      { role: "staff", resource: "crm", actions: ["read"] },
      { role: "readonly", resource: "*", actions: ["read"] },
      { role: "system", resource: "*", actions: ["read", "create", "update", "invoke", "export", "admin"] },
    ],
    toolAllowlist: {
      admin: ["booking.create", "booking.cancel", "crm.findClient", "payments.createInvoice", "analytics.weekSummary"],
      manager: ["booking.create", "booking.cancel", "crm.findClient"],
      staff: ["booking.create", "crm.findClient"],
      readonly: [],
      system: ["*"] as any
    }
  };
}
