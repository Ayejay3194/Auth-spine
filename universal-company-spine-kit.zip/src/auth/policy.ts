import type { Decision, Receipt, Severity, TenantId, UserId } from "../types.js";
import { stableId } from "../utils/stable_id.js";

export type AuthPolicyConfig = {
  maxFailedLoginsPerHour: number;
  lockoutSeconds: number;
};

export const DEFAULT_AUTH_POLICY: AuthPolicyConfig = {
  maxFailedLoginsPerHour: 10,
  lockoutSeconds: 30 * 60
};

export function authDecision(params: {
  tsISO: string;
  tenantId?: TenantId;
  subjectUserId?: UserId;
  receipts: Receipt[];
  config?: AuthPolicyConfig;
}): Decision {
  const cfg = params.config ?? DEFAULT_AUTH_POLICY;

  // Example receipt reasons:
  // - FAILED_LOGIN_BURST
  // - PASSWORD_RESET_REQUESTED
  // - SUSPECTED_BRUTE_FORCE
  const byCode = new Map<string, Receipt[]>();
  for (const r of params.receipts) {
    byCode.set(r.reasonCode, [...(byCode.get(r.reasonCode) ?? []), r]);
  }

  const failed = (byCode.get("FAILED_LOGIN_BURST") ?? []).reduce((s, r) => s + (r.weight ?? 1) * (r.confidence ?? 1), 0);

  let action = "allow";
  let severity: Severity = "low";
  let ttlSeconds: number | undefined;

  if (failed >= cfg.maxFailedLoginsPerHour) {
    action = "temp_lock";
    severity = "high";
    ttlSeconds = cfg.lockoutSeconds;
  }

  return {
    id: stableId(`authDecision:${params.subjectUserId ?? "none"}:${params.tsISO}:${action}`),
    tsISO: params.tsISO,
    tenantId: params.tenantId,
    subjectUserId: params.subjectUserId,
    action,
    severity,
    receipts: Array.from(byCode.entries()).map(([reasonCode, arr]) => ({ reasonCode, receiptIds: arr.map(x => x.id) })),
    ttlSeconds,
    notes: `failedScore=${failed.toFixed(2)}`
  };
}
