# Launch Gate (SaaS/PaaS)

## Must-have before any public beta
- Tenant context: required, validated, cannot be spoofed
- DB access: always scoped by tenantId
- OLA (object-level auth): enforced in service layer
- Rate limiting: per tenant + per user
- Webhooks: signature verification + replay protection
- Logging: auth attempts, permission denials, boundary violations
- Secrets: scanned in CI, rotated

## Before first enterprise customer
- SSO (SAML/OIDC) + SCIM
- Per-tenant encryption keys / BYOK option
- Data residency selectable per tenant
- Tamper-evident audit logs + export
- Dedicated infra option (single-tenant)
