Bank sync and reconciliation logic.
