import type { EnablementInput, EnablementResult, ModuleId, ModuleSpec, TierId } from "./types";
import { MODULE_REGISTRY } from "./registry";

const TIER_ORDER: TierId[] = ["free", "solo", "grow", "salon", "enterprise"];
function tierGte(a: TierId, b: TierId) {
  return TIER_ORDER.indexOf(a) >= TIER_ORDER.indexOf(b);
}

export function computeEnablement(input: EnablementInput): EnablementResult {
  const deny = new Set<ModuleId>(input.deny ?? []);
  const disabled: { id: ModuleId; reason: string }[] = [];

  const base = MODULE_REGISTRY.filter((m) => {
    const min = m.tierMinimum ?? "free";
    if (!tierGte(input.tier, min)) {
      disabled.push({ id: m.id, reason: `requires tier >= ${min}` });
      return false;
    }
    const verts = m.verticals ?? "all";
    if (verts !== "all" && !verts.includes(input.vertical)) {
      disabled.push({ id: m.id, reason: `not available for vertical ${input.vertical}` });
      return false;
    }
    if (deny.has(m.id)) {
      disabled.push({ id: m.id, reason: "disabled by deny-list" });
      return false;
    }
    if (input.flags && input.flags[`disable:${m.id}`] === true) {
      disabled.push({ id: m.id, reason: "disabled by flag" });
      return false;
    }
    return true;
  });

  const enabled = new Set<ModuleId>();
  const byId = new Map<ModuleId, ModuleSpec>(base.map((m) => [m.id, m]));

  function enable(id: ModuleId, stack: ModuleId[] = []) {
    if (enabled.has(id)) return;
    const m = byId.get(id);
    if (!m) {
      disabled.push({ id, reason: "missing from registry or filtered out by tier/vertical" });
      return;
    }
    if (stack.includes(id)) {
      disabled.push({ id, reason: `circular dependency: ${[...stack, id].join(" -> ")}` });
      return;
    }
    const deps = (m.dependsOn ?? []) as ModuleId[];
    for (const d of deps) enable(d, [...stack, id]);
    enabled.add(id);
  }

  for (const m of base) enable(m.id);

  return {
    enabled: Array.from(enabled),
    disabled,
    graph: Array.from(enabled).map((id) => ({ id, dependsOn: (byId.get(id)?.dependsOn ?? []) as ModuleId[] })),
  };
}
