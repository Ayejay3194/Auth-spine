export type AccountState =
  | "PENDING_VERIFICATION"
  | "ACTIVE"
  | "LOCKED"
  | "SUSPENDED"
  | "DEACTIVATED"
  | "SOFT_DELETED"
  | "HARD_DELETED";

export type AccountTransition =
  | { type: "VERIFY_EMAIL" }
  | { type: "LOCK"; reason: string }
  | { type: "UNLOCK" }
  | { type: "SUSPEND"; reason: string }
  | { type: "UNSUSPEND" }
  | { type: "DEACTIVATE"; reason?: string }
  | { type: "REACTIVATE" }
  | { type: "SOFT_DELETE"; reason?: string }
  | { type: "HARD_DELETE"; reason?: string };

export function canTransition(from: AccountState, t: AccountTransition): boolean {
  switch (from) {
    case "PENDING_VERIFICATION":
      return t.type === "VERIFY_EMAIL" || t.type === "SOFT_DELETE" || t.type === "HARD_DELETE";
    case "ACTIVE":
      return ["LOCK", "SUSPEND", "DEACTIVATE", "SOFT_DELETE", "HARD_DELETE"].includes(t.type);
    case "LOCKED":
      return ["UNLOCK", "HARD_DELETE"].includes(t.type);
    case "SUSPENDED":
      return ["UNSUSPEND", "HARD_DELETE"].includes(t.type);
    case "DEACTIVATED":
      return ["REACTIVATE", "HARD_DELETE"].includes(t.type);
    case "SOFT_DELETED":
      return ["HARD_DELETE"].includes(t.type);
    case "HARD_DELETED":
      return false;
  }
}

export function applyTransition(from: AccountState, t: AccountTransition): AccountState {
  if (!canTransition(from, t)) return from;
  switch (t.type) {
    case "VERIFY_EMAIL": return "ACTIVE";
    case "LOCK": return "LOCKED";
    case "UNLOCK": return "ACTIVE";
    case "SUSPEND": return "SUSPENDED";
    case "UNSUSPEND": return "ACTIVE";
    case "DEACTIVATE": return "DEACTIVATED";
    case "REACTIVATE": return "ACTIVE";
    case "SOFT_DELETE": return "SOFT_DELETED";
    case "HARD_DELETE": return "HARD_DELETED";
  }
}
