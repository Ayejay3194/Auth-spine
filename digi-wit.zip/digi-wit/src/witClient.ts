import type { WitResponse } from "./types.js";

export type WitClientOptions = {
  accessToken: string;
  apiVersion?: string; // default: 20240531 (safe-ish)
  baseUrl?: string; // default: https://api.wit.ai
};

export class WitClient {
  private accessToken: string;
  private apiVersion: string;
  private baseUrl: string;

  constructor(opts: WitClientOptions) {
    if (!opts.accessToken) throw new Error("WitClient requires accessToken");
    this.accessToken = opts.accessToken;
    this.apiVersion = opts.apiVersion ?? "20240531";
    this.baseUrl = opts.baseUrl ?? "https://api.wit.ai";
  }

  async message(text: string, locale?: string): Promise<WitResponse> {
    const url = new URL(this.baseUrl + "/message");
    url.searchParams.set("q", text);
    if (locale) url.searchParams.set("locale", locale);

    const res = await fetch(url.toString(), {
      method: "GET",
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        "wit-version": this.apiVersion,
      },
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`Wit.ai error ${res.status}: ${body}`);
    }

    const data = (await res.json()) as WitResponse;
    return data;
  }

  getVersion(): string {
    return this.apiVersion;
  }
}
