"use client";
import { usePathname } from "next/navigation";

export function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const isMap = path === "/map";

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4">
      <section>{children}</section>
      <aside className="hidden lg:block">
        {isMap ? <Feed /> : <MiniMap />}
      </aside>
    </div>
  );
}

function MiniMap() {
  return <div className="border border-white/10 rounded-xl p-4">Mini‑map (rail)</div>;
}
function Feed() {
  return <div className="border border-white/10 rounded-xl p-4">Feed (rail)</div>;
}
