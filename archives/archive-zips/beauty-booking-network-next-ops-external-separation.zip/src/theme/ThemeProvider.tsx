"use client";
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
type ThemeMode = "light" | "dark" | "system";
type ThemeCtx = { mode: ThemeMode; resolved: "light" | "dark"; setMode: (m: ThemeMode) => void };
const Ctx = createContext<ThemeCtx | null>(null);
const KEY = "bb_theme_mode";
function resolve(mode: ThemeMode): "light" | "dark" {
  if (mode !== "system") return mode;
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>(() => (typeof window === "undefined" ? "system" : ((localStorage.getItem(KEY) as ThemeMode) || "system")));
  const [resolved, setResolved] = useState<"light" | "dark">("light");
  useEffect(() => {
    const next = resolve(mode);
    setResolved(next);
    document.documentElement.dataset.theme = next;
    localStorage.setItem(KEY, mode);
  }, [mode]);
  useEffect(() => {
    if (mode !== "system") return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => setResolved(resolve("system"));
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, [mode]);
  const api = useMemo(() => ({ mode, resolved, setMode }), [mode, resolved]);
  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}
export function useTheme(){ const v = useContext(Ctx); if(!v) throw new Error("useTheme must be used inside ThemeProvider"); return v; }
