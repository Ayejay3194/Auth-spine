
alter table profiles enable row level security;
alter table bookings enable row level security;
alter table salon_memberships enable row level security;

-- Clients & stylists see only their own profile
create policy "self profile"
on profiles for select
using (auth.uid() = id);

-- Stylists see their bookings
create policy "stylist bookings"
on bookings for select
using (auth.uid() = stylist_id);

-- Clients see their bookings
create policy "client bookings"
on bookings for select
using (auth.uid() = client_id);

-- Salon managers see bookings for their salon
create policy "salon manager bookings"
on bookings for select
using (
  exists (
    select 1 from salon_memberships sm
    where sm.user_id = auth.uid()
    and sm.salon_id = bookings.salon_id
    and sm.role in ('MANAGER','OWNER')
  )
);
