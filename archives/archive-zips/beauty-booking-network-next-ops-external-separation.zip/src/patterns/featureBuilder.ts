import { prisma } from "@/lib/prisma";

export async function computeClientFeatures(userId: string) {
  const now = new Date();
  const since90 = new Date(now); since90.setDate(since90.getDate() - 90);
  const since365 = new Date(now); since365.setDate(since365.getDate() - 365);

  const bookings90 = await prisma.booking.count({ where:{ clientUserId: userId, createdAt:{ gte: since90 } } });
  const cancels90 = await prisma.booking.count({ where:{ clientUserId: userId, status:"CANCELED", createdAt:{ gte: since90 } } });
  const noShows365 = await prisma.booking.count({ where:{ clientUserId: userId, status:"NO_SHOW", createdAt:{ gte: since365 } } });

  return { bookings_90d: bookings90, cancels_90d: cancels90, no_shows_365d: noShows365 };
}

export async function computeStylistFeatures(stylistId: string) {
  const now = new Date();
  const since30 = new Date(now); since30.setDate(since30.getDate() - 30);

  const created30 = await prisma.booking.count({ where:{ stylistId, createdAt:{ gte: since30 } } });
  const canceled30 = await prisma.booking.count({ where:{ stylistId, status:"CANCELED", createdAt:{ gte: since30 } } });
  const confirmed30 = await prisma.booking.count({ where:{ stylistId, status:"CONFIRMED", createdAt:{ gte: since30 } } });
  const avgTicket = await prisma.booking.aggregate({ where:{ stylistId, status:{ in:["CONFIRMED","COMPLETED"] }, createdAt:{ gte: since30 } }, _avg:{ priceCentsFinal:true } });

  return { bookings_30d: created30, cancels_30d: canceled30, confirmed_30d: confirmed30, avg_ticket_cents_30d: Math.round(avgTicket._avg.priceCentsFinal ?? 0) };
}
