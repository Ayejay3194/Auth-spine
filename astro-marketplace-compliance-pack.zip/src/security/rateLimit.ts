type Bucket = { count: number; resetAt: number };
const mem = new Map<string, Bucket>();

export function rateLimit(key: string, windowMs: number, max: number) {
  const now = Date.now();
  const b = mem.get(key);
  if (!b || now > b.resetAt) { mem.set(key, { count: 1, resetAt: now + windowMs }); return { ok: true, remaining: max-1, resetAt: now+windowMs }; }
  if (b.count >= max) return { ok: false, remaining: 0, resetAt: b.resetAt };
  b.count += 1; mem.set(key, b);
  return { ok: true, remaining: max-b.count, resetAt: b.resetAt };
}
