import fs from "node:fs";
import path from "node:path";
import { execSync } from "node:child_process";

const DATABASE_URL = process.env.DATABASE_URL;
if(!DATABASE_URL){
  console.error("Missing DATABASE_URL in env");
  process.exit(1);
}

const BACKUP_DIR = path.join(process.cwd(), "backups");
fs.mkdirSync(BACKUP_DIR, { recursive: true });
const ts = new Date().toISOString().replace(/[:.]/g, "-");
const filename = `backup-${ts}.sql`;
const outPath = path.join(BACKUP_DIR, filename);

const u = new URL(DATABASE_URL);
const host = u.hostname;
const port = u.port || "5432";
const user = decodeURIComponent(u.username);
const pass = decodeURIComponent(u.password);
const db = u.pathname.replace(/^\//, "");

console.log("📦 Creating backup:", filename);
execSync(
  `PGPASSWORD="${pass}" pg_dump -h ${host} -p ${port} -U ${user} -d ${db} -f "${outPath}"`,
  { stdio: "inherit" }
);
execSync(`gzip "${outPath}"`, { stdio: "inherit" });
console.log("✅ Backup created:", filename + ".gz");

// prune > 7 days
const sevenDaysAgo = Date.now() - 7*24*60*60*1000;
for(const file of fs.readdirSync(BACKUP_DIR)){
  const fp = path.join(BACKUP_DIR, file);
  const st = fs.statSync(fp);
  if(st.mtimeMs < sevenDaysAgo){
    fs.unlinkSync(fp);
    console.log("🗑️ Deleted old backup:", file);
  }
}
