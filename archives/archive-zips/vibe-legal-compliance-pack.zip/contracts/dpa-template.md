# Data Processing Addendum (DPA) (Template)

This DPA is between:
- **Customer**: {{CUSTOMER_NAME}} (“Controller”)
- **Provider**: {{COMPANY_NAME}} (“Processor”)

## 1. Processing details
- Subject matter: platform hosting + booking operations
- Duration: term of agreement
- Nature/purpose: provide Service; support; security
- Data subjects: customers’ users
- Categories of data: account, booking, usage, messages (as configured)

## 2. Processor obligations
- process only on documented instructions
- confidentiality
- security measures (Appendix A)
- assist with DSAR requests
- breach notification within {{BREACH_NOTIFY_WINDOW}}
- subprocessors list + notice

## 3. Subprocessors
See `contracts/subprocessors-template.md`

## 4. International transfers
Use SCCs where required (Appendix B).

## 5. Deletion/return
Upon termination: return/export data and delete within {{DELETION_WINDOW}}, subject to legal retention.

## Appendix A: Security measures
Reference security baseline: {{SECURITY_BASELINE_LINK}}.
