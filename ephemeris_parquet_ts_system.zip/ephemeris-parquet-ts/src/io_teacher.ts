import { parse } from "csv-parse/sync";
import type { BodyName, SampleRow } from "./types.js";

const BODIES: BodyName[] = ["sun","mercury","venus","earth","moon","mars","jupiter","saturn","uranus","neptune","pluto"];

export function loadTeacherCsv(csvText: string): SampleRow[] {
  const rows = parse(csvText, { columns: true, skip_empty_lines: true });
  const out: SampleRow[] = [];
  for (const r of rows) {
    const jd = Number((r as any).jd ?? (r as any).JD ?? (r as any).julian_day);
    if (!Number.isFinite(jd)) throw new Error("Teacher CSV must have 'jd' column");
    const states: any = {};
    for (const b of BODIES) {
      const px = Number((r as any)[`${b}_x`]);
      const py = Number((r as any)[`${b}_y`]);
      const pz = Number((r as any)[`${b}_z`]);
      const vx = Number((r as any)[`${b}_vx`]);
      const vy = Number((r as any)[`${b}_vy`]);
      const vz = Number((r as any)[`${b}_vz`]);
      if (![px,py,pz,vx,vy,vz].every(Number.isFinite)) {
        throw new Error(`Missing/invalid columns for body=${b} at jd=${jd}`);
      }
      states[b] = { r: [px,py,pz], v: [vx,vy,vz] };
    }
    out.push({ jd, states });
  }
  return out;
}
