export type ID = string;

export type Money = { amount: number; currency: "USD" | "EUR" | "GBP" | string };

export type ISODateTime = string; // ISO 8601

export type Result<T> = { ok: true; data: T } | { ok: false; error: { code: string; message: string; details?: any } };

export type Page<T> = { items: T[]; nextCursor?: string | null };

export interface Clock { now(): Date; }

export function nowISO(clock: Clock): ISODateTime { return clock.now().toISOString(); }
