# 4-Week Home Training Plan (No Gym, Minimal Gear)

## Rules
- Warmup 5–8 min (walk in place, arm circles, hip hinges, bodyweight squats).
- Stop 2 reps before failure. Form > ego.
- If a move hurts (sharp pain), swap it. If you’re just tired, congratulations, you’re alive.

## Weekly Schedule (repeat for 4 weeks)
**Day 1: Full Body A**
- Squat pattern: Goblet squat or bodyweight squat — 3x8–12
- Push: Push-ups (incline if needed) — 3x6–12
- Pull: One-arm row (backpack/dumbbell) — 3x8–12/side
- Hinge: Romanian deadlift (backpack/dumbbells) — 3x8–12
- Core: Dead bug — 3x8/side

**Day 2: Cardio + Mobility (25–40 min)**
- Brisk walk / bike / stairs
- Mobility: hips, thoracic spine, calves (10 min)

**Day 3: Full Body B**
- Split squat or reverse lunge — 3x8–12/side
- Overhead press (bands/dumbbells) — 3x8–12
- Pull: Band pull-aparts or towel rows — 3x12–20
- Glute bridge/hip thrust — 3x10–15
- Core: Side plank — 3x20–45s/side

**Day 4: Optional Conditioning (15–25 min)**
Choose one:
- Intervals: 30s hard / 90s easy x 8–10
- Circuit x 4 rounds: squats 12, push-ups 8, rows 10, plank 30s

**Days 5–7: Rest / light activity**
- Walks + stretch. Your body is not a disposable robot.

## Progression (how you get better)
- Week 1: find your working weights/variations.
- Week 2: add 1–2 reps per set.
- Week 3: add a set to the first 2 lifts (4 sets).
- Week 4: keep sets, push reps near top range OR slightly increase load.

## Equipment Substitutes
- Dumbbells: backpack filled with books.
- Bands: cheap loop bands.
- Bench: sturdy chair/sofa edge.
