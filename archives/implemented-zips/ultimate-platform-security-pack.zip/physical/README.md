PHYSICAL SECURITY DOMAIN

This folder contains:
- Policies
- Checklists
- Implementation notes
- Audit artifacts

Nothing here is optional for high-trust systems.
