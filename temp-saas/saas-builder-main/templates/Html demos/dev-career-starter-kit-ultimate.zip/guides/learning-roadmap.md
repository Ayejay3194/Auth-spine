# Learning Roadmap – Ultimate Track

## Phase 1 – Foundations (1–2 weeks)
- JS/TS basics, React components, Next.js App Router
- HTML/CSS layout, Tailwind utility mindset

## Phase 2 – Full Stack Feature (2–4 weeks)
- Prisma schema + migrations
- CRUD feature: Projects (already scaffolded)
- Add one more entity on your own

## Phase 3 – Auth & Sessions (2–3 weeks)
- Understand: sessions vs tokens, protected routes
- Implement real auth using an auth library (NextAuth/Lucia) into the stubbed routes

## Phase 4 – Billing & Plans (2–3 weeks)
- Integrate Stripe with the billing scaffolding
- Add free vs paid features

## Phase 5 – Admin & Operations (ongoing)
- Add admin views, logs, metrics
- Improve DX, tests, observability
