import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readText } from "../utils/fs.js";

function parseDotEnv(content: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const m = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!m) continue;
    let v = m[2] ?? "";
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    out[m[1]] = v;
  }
  return out;
}

export function auditEnv(root: string): AuditSection {
  const section: AuditSection = { id: "env", title: "Environment Variables", findings: [] };

  const envFiles = [".env", ".env.local", ".env.production", ".env.production.local"];
  const found = envFiles.filter((f) => exists(path.join(root, f)));

  if (found.length === 0) {
    section.findings.push({
      id: "env.none",
      title: "No .env files found",
      severity: "INFO",
      details: "Not always a problem, but missing env vars are a top cause of prod-only breakage (DB/auth/APIs).",
      fix: "If your app needs env vars, document them in `.env.example` and set them in deployment.",
      evidence: { checked: envFiles },
    });
    return section;
  }

  const allVars: Record<string, string> = {};
  for (const f of found) {
    Object.assign(allVars, parseDotEnv(readText(path.join(root, f))));
  }

  const emptyOrPlaceholder = Object.entries(allVars)
    .filter(([k, v]) => v === "" || /changeme|replace_me|todo/i.test(v))
    .map(([k]) => k);

  if (emptyOrPlaceholder.length) {
    section.findings.push({
      id: "env.placeholders",
      title: "Empty/placeholder env vars detected",
      severity: "WARN",
      details: "These frequently slip into production and cause runtime failures (auth/payments/db).",
      fix: "Keep placeholders only in `.env.example`. Real envs must set real values.",
      evidence: { vars: emptyOrPlaceholder },
    });
  }

  const keys = Object.keys(allVars);
  const hasNextPublic = keys.some((k) => k.startsWith("NEXT_PUBLIC_"));
  const hasVite = keys.some((k) => k.startsWith("VITE_"));

  if (!hasNextPublic && !hasVite) {
    section.findings.push({
      id: "env.publicPrefixes",
      title: "No client-exposed env prefixes detected",
      severity: "INFO",
      details: "If you expect env vars in the browser, frameworks require prefixes (Next: NEXT_PUBLIC_, Vite: VITE_).",
      fix: "Use correct prefixes for browser-exposed vars. Keep secrets server-only.",
      evidence: { example: ["NEXT_PUBLIC_API_BASE", "VITE_API_BASE"] },
    });
  }

  return section;
}
