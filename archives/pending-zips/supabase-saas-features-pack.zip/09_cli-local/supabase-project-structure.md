# Supabase CLI project structure
- supabase/config.toml
- supabase/migrations/*.sql
- supabase/functions/*

Use:
- `supabase init`
- copy migrations from this pack into `supabase/migrations`
- `supabase start`
- `supabase db reset`
