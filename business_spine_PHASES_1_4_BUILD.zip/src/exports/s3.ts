import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

export function s3Client() {
  const region = process.env.AWS_REGION ?? "us-east-1";
  return new S3Client({ region });
}

export async function putExportObject(key: string, body: Uint8Array, contentType = "text/csv") {
  const bucket = process.env.EXPORTS_S3_BUCKET;
  if (!bucket) throw new Error("EXPORTS_S3_BUCKET not set");
  const s3 = s3Client();
  await s3.send(new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: body,
    ContentType: contentType,
  }));

  // Public URL strategy: either explicit CDN/base URL, or default S3 virtual-hosted style
  const base = process.env.EXPORTS_PUBLIC_BASE_URL;
  if (base) return base.replace(/\/$/, "") + "/" + key;
  const region = process.env.AWS_REGION ?? "us-east-1";
  return `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
}
