import crypto from "crypto";

/**
 * Verify webhook signature (HMAC).
 * Provider-dependent: adapt header names and payload handling.
 */
export function verifyHmacSignature(rawBody: string, signature: string, secret: string) {
  const mac = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(mac));
  } catch {
    return false;
  }
}
