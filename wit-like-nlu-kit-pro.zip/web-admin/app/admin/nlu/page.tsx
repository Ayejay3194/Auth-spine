"use client";
import React, { useEffect, useMemo, useState } from "react";

const API = process.env.NEXT_PUBLIC_NLU_API || "http://localhost:8000";

type Intent = { name: string; confidence: number };
type Entity = { entity: string; role?: string | null; value: string; start: number; end: number; confidence: number; meta?: any };
type ModelInfo = { id: string; created_at: string; active: boolean; stats: any; notes?: string | null };

export default function Page() {
  const [tab, setTab] = useState<"parse"|"examples"|"entities"|"models">("parse");

  // parse
  const [text, setText] = useState("Book Amy for balayage tomorrow at 2pm");
  const [parseOut, setParseOut] = useState<any>(null);

  // examples
  const [examples, setExamples] = useState<any[]>([]);
  const [exText, setExText] = useState("");
  const [exIntents, setExIntents] = useState("booking.create");
  const [exEntities, setExEntities] = useState("service:primary:balayage, person:provider:Amy");

  // entities rules
  const [rules, setRules] = useState<any>(null);

  // models
  const [models, setModels] = useState<ModelInfo[]>([]);
  const [trainNotes, setTrainNotes] = useState("baseline");

  async function api(path: string, opts?: RequestInit) {
    const res = await fetch(`${API}${path}`, { ...opts, headers: { "Content-Type": "application/json", ...(opts?.headers||{}) } });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  }

  async function doParse() {
    const out = await api("/parse", { method:"POST", body: JSON.stringify({ text, top_k_intents: 3, entity_threshold: 0.78 }) });
    setParseOut(out);
  }

  async function loadExamples() {
    const out = await api("/examples?limit=500");
    setExamples(out.items || []);
  }

  function parseEntityCsv(s: string) {
    // format: entity:role:value, entity:role:value
    const parts = s.split(",").map(x => x.trim()).filter(Boolean);
    const ents = parts.map(p => {
      const [entity, role, ...rest] = p.split(":");
      const value = rest.join(":").trim();
      const idx = exText.indexOf(value);
      const start = idx >= 0 ? idx : 0;
      const end = idx >= 0 ? idx + value.length : Math.min(1, exText.length);
      return { entity: entity.trim(), role: role?.trim() || null, value, start, end };
    });
    return ents;
  }

  async function addExample() {
    const intents = exIntents.split(",").map(x => x.trim()).filter(Boolean).map(name => ({ name, confidence: 1.0 }));
    const entities = exEntities.trim() ? parseEntityCsv(exEntities) : [];
    await api("/examples", { method:"POST", body: JSON.stringify([{ text: exText, intents, entities }]) });
    setExText("");
    await loadExamples();
  }

  async function loadRules() {
    const out = await api("/entity-rules");
    setRules(out);
  }

  async function saveRules() {
    await api("/entity-rules", { method:"POST", body: JSON.stringify(rules) });
    alert("Saved entity rules (train to apply to a new model version).");
  }

  async function loadModels() {
    const out = await api("/models");
    setModels(out.items || []);
  }

  async function train() {
    const out = await api("/train", { method:"POST", body: JSON.stringify({ notes: trainNotes, min_examples: 5 }) });
    alert(`Trained model ${out.model_id}`);
    await loadModels();
  }

  async function activate(id: string) {
    await api(`/models/${id}/activate`, { method:"POST", body: JSON.stringify({}) });
    await loadModels();
  }

  useEffect(() => {
    loadExamples().catch(()=>{});
    loadRules().catch(()=>{});
    loadModels().catch(()=>{});
  }, []);

  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: 24 }}>
      <h1 style={{ margin: 0, fontSize: 28 }}>NLU Admin</h1>
      <p style={{ opacity: 0.8, marginTop: 8 }}>A tiny Wit-ish loop. Label some examples, train versions, parse text.</p>

      <div style={{ display:"flex", gap: 8, margin: "16px 0" }}>
        {(["parse","examples","entities","models"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            style={{
              padding:"10px 12px",
              borderRadius: 10,
              border: "1px solid #223055",
              background: tab===t ? "#1b2a50" : "transparent",
              color:"#e6edf3",
              cursor:"pointer"
            }}>
            {t.toUpperCase()}
          </button>
        ))}
      </div>

      {tab==="parse" && (
        <div style={{ background:"#0f1933", border:"1px solid #223055", borderRadius: 14, padding: 16 }}>
          <h2 style={{ marginTop: 0 }}>Parse</h2>
          <textarea value={text} onChange={e=>setText(e.target.value)} rows={3}
            style={{ width:"100%", padding: 12, borderRadius: 10, border:"1px solid #223055", background:"#0b1220", color:"#e6edf3" }} />
          <div style={{ display:"flex", gap: 10, marginTop: 10 }}>
            <button onClick={doParse} style={{ padding:"10px 12px", borderRadius:10, border:"1px solid #2f4a8a", background:"#193a7a", color:"#fff" }}>
              Parse
            </button>
          </div>

          {parseOut && (
            <pre style={{ marginTop: 12, padding: 12, background:"#0b1220", border:"1px solid #223055", borderRadius: 10, overflow:"auto" }}>
{JSON.stringify(parseOut, null, 2)}
            </pre>
          )}
        </div>
      )}

      {tab==="examples" && (
        <div style={{ background:"#0f1933", border:"1px solid #223055", borderRadius: 14, padding: 16 }}>
          <h2 style={{ marginTop: 0 }}>Examples</h2>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap: 10 }}>
            <div>
              <label>Text</label>
              <input value={exText} onChange={e=>setExText(e.target.value)}
                style={{ width:"100%", padding: 10, borderRadius: 10, border:"1px solid #223055", background:"#0b1220", color:"#e6edf3" }} />
            </div>
            <div>
              <label>Intents (comma)</label>
              <input value={exIntents} onChange={e=>setExIntents(e.target.value)}
                style={{ width:"100%", padding: 10, borderRadius: 10, border:"1px solid #223055", background:"#0b1220", color:"#e6edf3" }} />
            </div>
            <div style={{ gridColumn:"1 / -1" }}>
              <label>Entities (csv: entity:role:value)</label>
              <input value={exEntities} onChange={e=>setExEntities(e.target.value)}
                style={{ width:"100%", padding: 10, borderRadius: 10, border:"1px solid #223055", background:"#0b1220", color:"#e6edf3" }} />
              <div style={{ opacity: 0.75, marginTop: 6, fontSize: 12 }}>
                Example: <code>service:primary:balayage, person:provider:Amy</code>
              </div>
            </div>
          </div>
          <div style={{ display:"flex", gap: 10, marginTop: 10 }}>
            <button onClick={addExample} style={{ padding:"10px 12px", borderRadius:10, border:"1px solid #2f4a8a", background:"#193a7a", color:"#fff" }}>
              Add Example
            </button>
            <button onClick={loadExamples} style={{ padding:"10px 12px", borderRadius:10, border:"1px solid #223055", background:"transparent", color:"#e6edf3" }}>
              Refresh
            </button>
          </div>

          <div style={{ marginTop: 12, maxHeight: 420, overflow:"auto" }}>
            {examples.map((ex, i) => (
              <pre key={i} style={{ padding: 12, background:"#0b1220", border:"1px solid #223055", borderRadius: 10, overflow:"auto" }}>
{JSON.stringify(ex, null, 2)}
              </pre>
            ))}
          </div>
        </div>
      )}

      {tab==="entities" && (
        <div style={{ background:"#0f1933", border:"1px solid #223055", borderRadius: 14, padding: 16 }}>
          <h2 style={{ marginTop: 0 }}>Entity rules (synonyms, roles, regex)</h2>
          <p style={{ opacity: 0.8 }}>Edit rules, save, then train a new model version to apply.</p>
          <button onClick={loadRules} style={{ padding:"10px 12px", borderRadius:10, border:"1px solid #223055", background:"transparent", color:"#e6edf3" }}>
            Reload
          </button>
          <button onClick={saveRules} style={{ marginLeft: 10, padding:"10px 12px", borderRadius:10, border:"1px solid #2f4a8a", background:"#193a7a", color:"#fff" }}>
            Save Rules
          </button>
          {rules && (
            <textarea value={JSON.stringify(rules, null, 2)} onChange={e=>setRules(JSON.parse(e.target.value))}
              rows={18}
              style={{ marginTop: 10, width:"100%", padding: 12, borderRadius: 10, border:"1px solid #223055", background:"#0b1220", color:"#e6edf3", fontFamily:"ui-monospace, SFMono-Regular" }} />
          )}
        </div>
      )}

      {tab==="models" && (
        <div style={{ background:"#0f1933", border:"1px solid #223055", borderRadius: 14, padding: 16 }}>
          <h2 style={{ marginTop: 0 }}>Models</h2>
          <div style={{ display:"flex", gap: 10, alignItems:"center" }}>
            <input value={trainNotes} onChange={e=>setTrainNotes(e.target.value)}
              placeholder="training notes"
              style={{ flex: 1, padding: 10, borderRadius: 10, border:"1px solid #223055", background:"#0b1220", color:"#e6edf3" }} />
            <button onClick={train} style={{ padding:"10px 12px", borderRadius:10, border:"1px solid #2f4a8a", background:"#193a7a", color:"#fff" }}>
              Train New Version
            </button>
            <button onClick={loadModels} style={{ padding:"10px 12px", borderRadius:10, border:"1px solid #223055", background:"transparent", color:"#e6edf3" }}>
              Refresh
            </button>
          </div>

          <div style={{ marginTop: 12, display:"grid", gap: 10 }}>
            {models.map(m => (
              <div key={m.id} style={{ padding: 12, borderRadius: 12, border:"1px solid #223055", background:"#0b1220" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div>
                    <div style={{ fontWeight: 700 }}>{m.id} {m.active ? " (active)" : ""}</div>
                    <div style={{ opacity: 0.75, fontSize: 12 }}>{m.created_at} {m.notes ? `• ${m.notes}` : ""}</div>
                  </div>
                  {!m.active && (
                    <button onClick={()=>activate(m.id)} style={{ padding:"8px 10px", borderRadius:10, border:"1px solid #2f4a8a", background:"#193a7a", color:"#fff" }}>
                      Activate
                    </button>
                  )}
                </div>
                <pre style={{ marginTop: 10, padding: 10, background:"#071022", border:"1px solid #223055", borderRadius: 10, overflow:"auto" }}>
{JSON.stringify(m.stats, null, 2)}
                </pre>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ marginTop: 18, opacity: 0.7, fontSize: 12 }}>
        API: <code>{API}</code>
      </div>
    </div>
  );
}
