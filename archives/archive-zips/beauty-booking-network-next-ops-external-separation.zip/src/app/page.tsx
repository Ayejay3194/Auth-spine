import Link from "next/link";
import { Container } from "@/components/Container";
import { prisma } from "@/lib/prisma";
import { StylistCard } from "@/components/StylistCard";

export default async function Home(){
  const stylists = await prisma.stylistProfile.findMany({ where:{ isActive:true }, orderBy:{ createdAt:"desc" }, take: 6 });
  return (
    <main className="py-10">
      <Container>
        <div className="overflow-hidden rounded-[28px] border p-10" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
          <div className="max-w-2xl">
            <div className="text-xs tracking-[.28em] uppercase" style={{color:"var(--dim)"}}>Portfolio-first bookings</div>
            <h1 className="serif mt-4 text-4xl leading-tight">Stylists get their own “website”.<br/>Bookings live behind it.</h1>
            <p className="mt-4 text-sm" style={{color:"var(--muted)"}}>Clients follow people. Salons become the org layer. You keep the network.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/discover" className="rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>Discover stylists</Link>
              <Link href="/salons" className="rounded-2xl border px-5 py-3 text-sm font-semibold" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>Browse salons</Link>
            </div>
          </div>
        </div>

        <div className="mt-10 flex items-end justify-between gap-4">
          <div>
            <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Featured</div>
            <h2 className="serif mt-2 text-2xl">Pick a portfolio</h2>
          </div>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-2">
          {stylists.map(s => <StylistCard key={s.id} slug={s.slug} displayName={s.displayName} title={s.title} heroUrl={s.heroUrl} />)}
        </div>
      </Container>
    </main>
  );
}
