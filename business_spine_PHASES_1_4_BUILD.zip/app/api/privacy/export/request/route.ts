import { z } from "zod";
import { api } from "@/src/core/api";
import { prisma } from "@/lib/prisma";
import { getTenant } from "@/src/tenant/tenant";
import { reportQueue } from "@/src/queue/queues";
import { getActor } from "@/src/core/auth";

const Q = z.object({ userId: z.string().optional() });

export async function POST(req: Request) {
  return api(async () => {
    const actor = getActor(req);
    const { tenantId } = getTenant(req);
    const body = Q.parse(await req.json());
    const userId = body.userId ?? actor.userId;

    const dsr = await prisma.dataSubjectRequest.create({ data: { tenantId, userId, type: "export", status: "queued" } });
    await reportQueue.add("dsr_export", { dsrId: dsr.id, tenantId, userId }, { attempts: 5, backoff: { type: "exponential", delay: 2000 } });
    return { requestId: dsr.id, status: dsr.status };
  });
}
