from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class Intent(BaseModel):
    name: str
    confidence: float = 1.0

class EntitySpan(BaseModel):
    entity: str
    role: Optional[str] = None
    value: str
    start: int
    end: int
    confidence: float = 1.0
    meta: Dict[str, Any] = Field(default_factory=dict)

class Example(BaseModel):
    text: str
    intents: List[Intent] = Field(default_factory=list)
    entities: List[EntitySpan] = Field(default_factory=list)

class ParseRequest(BaseModel):
    text: str
    top_k_intents: int = 3
    entity_threshold: float = 0.75

class ParseResponse(BaseModel):
    text: str
    intents: List[Intent]
    entities: List[EntitySpan]
    model_id: str

class TrainRequest(BaseModel):
    min_intent_conf: float = 0.0
    min_examples: int = 10
    notes: Optional[str] = None

class ModelInfo(BaseModel):
    id: str
    created_at: str
    active: bool
    stats: Dict[str, Any]
    notes: Optional[str] = None
