export type EntitlementValue = boolean | number | string;
export type Entitlements = Record<string, EntitlementValue>;

export type Plan = {
  id: string;
  name: string;
  priceCentsMonthly: number;
  entitlements: Entitlements;
};

export type Subscription = {
  userId: string;
  planId: string;
  status: "free" | "trialing" | "active" | "past_due" | "canceled";
};

export interface EntitlementsService {
  planForUser(userId: string): Promise<Plan>;
  subscriptionForUser(userId: string): Promise<Subscription>;
  can(userId: string, key: string, amount?: number): Promise<boolean>;
  get(userId: string, key: string): Promise<EntitlementValue | undefined>;
}

export class InMemoryEntitlements implements EntitlementsService {
  constructor(
    private plans: Plan[],
    private subs: Map<string, Subscription>
  ) {}

  async planForUser(userId: string): Promise<Plan> {
    const sub = this.subs.get(userId);
    const planId = sub?.planId ?? "free";
    return this.plans.find(p => p.id === planId) ?? this.plans[0];
  }

  async subscriptionForUser(userId: string): Promise<Subscription> {
    return this.subs.get(userId) ?? { userId, planId: "free", status: "free" };
  }

  async get(userId: string, key: string) {
    const plan = await this.planForUser(userId);
    return plan.entitlements[key];
  }

  async can(userId: string, key: string, amount: number = 1): Promise<boolean> {
    const v = await this.get(userId, key);
    if (typeof v === "boolean") return v;
    if (typeof v === "number") return v >= amount;
    if (typeof v === "string") return v.length > 0;
    return false;
  }
}
