# Supabase SaaS/PaaS Features Pack (Advanced)
You dropped a giant checklist. Humans love checklists because they’re terrified of missing things. Fair.

This pack turns that checklist into:
- **Supabase capability map** (what Supabase covers vs what you must build)
- **Implementation templates** for the high-risk pieces:
  - Multi-tenant isolation (tenant_id + RLS + tenant context)
  - Admin/support tooling separation patterns
  - Soft delete + audit trail + versioning + hierarchies
  - Realtime chat/presence + notifications tables
  - Storage security + media pipeline hooks (edge functions triggers)
  - API keys + scopes + per-tenant rate limits + quotas
  - Webhook verification + idempotency for billing/integrations
  - Data export/import + deletion/offboarding
  - Observability + runbooks (SEV1 cross-tenant, webhook forgery)

## What Supabase covers well
- Auth, sessions, OAuth, email magic links, MFA (feature availability varies by project config)
- Postgres + RLS (your best friend)
- Storage + signed URLs + policies
- Realtime channels / Postgres changes
- Edge Functions (serverless handlers)
- Logs/metrics (baseline), backups (plan-dependent)

## What you still build
- Tenant resolution (domain/subdomain mapping)
- Plan gating + billing logic
- Moderation logic, fraud rules, dispute flows
- Advanced analytics + ML pipelines (unless you use external tooling)
- Enterprise features like SAML/SCIM (depends; often add-ons or external IdP)

## Folder map
- `01_capability-map/` what’s native vs custom
- `02_multi-tenant/` schemas + RLS + tenant context + custom domains
- `03_advanced-db-patterns/` soft delete, audit, versioning, trees, events
- `04_realtime/` chat, presence, notifications patterns
- `05_storage-media/` secure storage + processing pipelines
- `06_api-integrations/` API keys, scopes, webhooks, rate limits
- `07_billing/` webhook verify + idempotency + plan gating
- `08_compliance-ops/` support JIT, impersonation, audit retention, data exports/deletes
- `09_cli-local/` supabase local dev wiring and migrations structure
