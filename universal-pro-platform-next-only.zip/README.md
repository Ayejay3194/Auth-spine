# Universal Professional Platform (Next.js only, TS modules)

This is the V1 booking wedge **plus** the universal multi-vertical platform architecture,
as **Next-only** modules with in-memory repos (so tools stop hallucinating structure).

## What’s in here
- Service-agnostic booking core + locking + conflict prevention
- Universal clients (cross-vertical trust transfer)
- Professionals + service catalog (location_type + metadata)
- Vertical config system (add a vertical via JSON config file)
- SMS conversation engine (detect vertical + 1 intake question + book slots)
- Orchestration event bus (booking.created -> reminders stub)
- Referral + bundle skeleton modules

## Run
```bash
npm i
npm run dev
```

## Endpoints
- POST /api/sms/inbound  (Twilio webhook: From, To, Body)
- GET  /api/verticals
- POST /api/professional/onboard
- POST /api/service
- GET  /api/service?professionalId=...
- POST /api/booking
- GET  /api/booking?id=...

State is in-memory by design. Swap repos to Postgres/Redis when you’re ready.
