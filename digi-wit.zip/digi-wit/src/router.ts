import { z } from "zod";
import type { IntentMap, ParseRequest, ParseResult, ReceiptSink } from "./types.js";
import { WitClient } from "./witClient.js";
import { buildBaseReceipt, payloadHash } from "./receipts.js";

/**
 * DigiWitRouter:
 * - calls Wit.ai
 * - chooses top intent
 * - normalizes entities into a flat payload (best-effort)
 * - validates payload against Zod schema
 * - enforces confidence floor
 * - emits receipt for every request
 */
export class DigiWitRouter {
  private wit: WitClient;
  private confidenceFloor: number;
  private intents: IntentMap;
  private receiptSink?: ReceiptSink;

  constructor(opts: {
    accessToken: string;
    apiVersion?: string;
    confidenceFloor?: number;
    intents: IntentMap;
    receiptSink?: ReceiptSink;
  }) {
    this.wit = new WitClient({ accessToken: opts.accessToken, apiVersion: opts.apiVersion });
    this.confidenceFloor = opts.confidenceFloor ?? 0.85;
    this.intents = opts.intents;
    this.receiptSink = opts.receiptSink;
  }

  async parseAndValidate(req: ParseRequest): Promise<ParseResult> {
    const receipt = buildBaseReceipt({ text: req.text, userId: req.userId, requestId: req.requestId });

    try {
      const res = await this.wit.message(req.text, req.locale);
      const top = res.intents?.[0];

      receipt.wit.apiVersion = this.wit.getVersion();
      receipt.wit.intent = top?.name;
      receipt.wit.confidence = top?.confidence;

      if (!top) {
        receipt.result = { accepted: false, reason: "no_intent" };
        await this.emit(receipt);
        return { ok: false, reason: "No intent recognized." };
      }

      if (top.confidence < this.confidenceFloor) {
        receipt.result = { accepted: false, reason: "low_confidence" };
        await this.emit(receipt);
        return { ok: false, reason: "Low confidence parse.", intent: top.name, confidence: top.confidence };
      }

      const spec = this.intents[top.name];
      if (!spec) {
        receipt.result = { accepted: false, reason: "unknown_intent" };
        await this.emit(receipt);
        return { ok: false, reason: "Intent not supported.", intent: top.name, confidence: top.confidence };
      }

      // Normalization strategy:
      // Wit entities arrive as arrays; we pick the highest-confidence item for each entity key.
      const rawPayload: Record<string, unknown> = {};
      for (const [k, arr] of Object.entries(res.entities ?? {})) {
        const best = [...arr].sort((a, b) => (b.confidence ?? 0) - (a.confidence ?? 0))[0];
        rawPayload[k] = best?.value ?? null;
      }

      // Allow a mapper override pattern in the future.
      // For now, support common aliasing:
      const payload = this.aliasCommon(rawPayload);

      const parsed = spec.schema.safeParse(payload);
      if (!parsed.success) {
        receipt.result = {
          accepted: false,
          reason: "schema_reject",
          schema: spec.name,
        };
        await this.emit(receipt);
        return { ok: false, reason: "Schema validation failed.", intent: top.name, confidence: top.confidence };
      }

      receipt.result = {
        accepted: true,
        schema: spec.name,
        payloadSha256: payloadHash(parsed.data),
      };
      await this.emit(receipt);

      return { ok: true, intent: spec.name, confidence: top.confidence, payload: parsed.data };
    } catch (err: any) {
      receipt.result = { accepted: false, reason: "exception" };
      await this.emit(receipt);
      return { ok: false, reason: "Wit.ai request failed." };
    }
  }

  private aliasCommon(payload: Record<string, unknown>): Record<string, unknown> {
    // Example: Wit might return "chart_id" but our schema expects "chartId"
    const out: Record<string, unknown> = { ...payload };

    const aliasPairs: Array<[string, string]> = [
      ["chart_id", "chartId"],
      ["chart", "chartId"],
      ["range", "range"],
      ["start_date", "startDate"],
      ["end_date", "endDate"],
      ["chart_type", "chartType"],
      ["datetime_utc", "dateTimeUtc"],
      ["house_system", "houseSystem"],
    ];

    for (const [from, to] of aliasPairs) {
      if (out[to] === undefined && out[from] !== undefined) out[to] = out[from];
    }

    // Flatten nested objects if Wit returns structures
    // (you can tighten this per your entity config).
    return out;
  }

  private async emit(receipt: any) {
    if (!this.receiptSink) return;
    try {
      await this.receiptSink(receipt);
    } catch {
      // receipts should never break product flows
    }
  }
}
