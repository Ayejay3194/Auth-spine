import { tokenize } from "./tokenize.js";

export interface ParsedDateTime {
  dateISO?: string; // YYYY-MM-DD
  time24?: string;  // HH:MM
  partOfDay?: "morning" | "afternoon" | "evening" | "night";
}

const weekdays = ["sunday","monday","tuesday","wednesday","thursday","friday","saturday"] as const;
type Weekday = typeof weekdays[number];
function pad2(n: number) { return String(n).padStart(2, "0"); }
function isoDate(d: Date) { return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`; }
function nextWeekday(from: Date, target: Weekday): Date {
  const t = weekdays.indexOf(target);
  const d = new Date(from);
  const cur = d.getDay();
  let delta = (t - cur + 7) % 7;
  if (delta === 0) delta = 7;
  d.setDate(d.getDate() + delta);
  return d;
}
function parseTime(tok: string): string | null {
  const m1 = tok.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
  if (m1) return `${pad2(Number(m1[1]))}:${m1[2]}`;
  const m2 = tok.match(/^([1-9]|1[0-2])(am|pm)$/);
  if (m2) {
    let h = Number(m2[1]); const ap = m2[2];
    if (ap === "am") { if (h === 12) h = 0; } else { if (h !== 12) h += 12; }
    return `${pad2(h)}:00`;
  }
  return null;
}

export function parseDateTime(text: string, now: Date): ParsedDateTime {
  const tokens = tokenize(text);
  const out: ParsedDateTime = {};

  if (tokens.includes("morning")) out.partOfDay = "morning";
  if (tokens.includes("afternoon")) out.partOfDay = "afternoon";
  if (tokens.includes("evening")) out.partOfDay = "evening";
  if (tokens.includes("tonight") || tokens.includes("night")) out.partOfDay = out.partOfDay ?? "night";

  const iso = text.match(/\b(20\d\d)-(\d\d)-(\d\d)\b/);
  if (iso) out.dateISO = iso[0];

  if (tokens.includes("today")) out.dateISO = isoDate(now);
  if (tokens.includes("tomorrow")) { const d = new Date(now); d.setDate(d.getDate()+1); out.dateISO = isoDate(d); }

  const nextIdx = tokens.indexOf("next");
  if (nextIdx >= 0 && tokens[nextIdx+1]) {
    const wd = tokens[nextIdx+1] as Weekday;
    if ((weekdays as any).includes(wd)) out.dateISO = isoDate(nextWeekday(now, wd));
  } else {
    for (const wd of weekdays) { if (tokens.includes(wd)) { out.dateISO = isoDate(nextWeekday(now, wd)); break; } }
  }

  for (const t of tokens) { const tm = parseTime(t); if (tm) { out.time24 = tm; break; } }

  return out;
}
