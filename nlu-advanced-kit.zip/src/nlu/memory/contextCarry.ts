import type { DialogueState, EntitySpan } from "../types";

/**
 * Resolve conversational references like "there", "that", "same place", "tomorrow".
 */
export function carryContext(state: DialogueState, text: string, entities: EntitySpan[]): EntitySpan[] {
  const lower = text.toLowerCase();

  const out = [...entities];

  const mentionsThere = /\bthere\b|\bsame place\b|\bthat city\b/.test(lower);
  if (mentionsThere && state.references.lastLocation) {
    // only add if no location already present
    if (!out.some(e => e.entity === "location")) {
      out.push({
        entity: "location",
        value: state.references.lastLocation,
        start: 0,
        end: 0,
        normalized: state.references.lastLocation,
        source: "memory",
      });
    }
  }

  const mentionsThatDay = /\bthat day\b|\bsame day\b/.test(lower);
  if (mentionsThatDay && state.references.lastDate) {
    if (!out.some(e => e.entity === "date")) {
      out.push({
        entity: "date",
        value: state.references.lastDate,
        start: 0,
        end: 0,
        normalized: state.references.lastDate,
        source: "memory",
      });
    }
  }

  return out;
}
