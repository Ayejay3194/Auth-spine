import type { NextApiRequest, NextApiResponse } from "next";

// Minimal health. No versions. No dependency dump. No "here's my DB hostname".
export default function handler(_req: NextApiRequest, res: NextApiResponse) {
  res.status(200).json({ ok: true });
}
