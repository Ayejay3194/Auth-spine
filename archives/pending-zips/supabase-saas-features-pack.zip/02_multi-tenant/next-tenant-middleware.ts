/**
 * Next.js middleware idea:
 * - Derive tenant from host
 * - Block ops routes from public host (and vice versa)
 * - Attach tenant to headers for server handlers
 */
import { NextRequest, NextResponse } from "next/server";

const OPS_HOST = process.env.OPS_HOST;
const APP_HOST = process.env.APP_HOST;

export function middleware(req: NextRequest) {
  const host = req.headers.get("host") ?? "";

  const isOpsPath = req.nextUrl.pathname.startsWith("/ops") || req.nextUrl.pathname.startsWith("/admin");
  const isOpsHost = OPS_HOST && host === OPS_HOST;

  if (isOpsPath && !isOpsHost) return NextResponse.redirect(new URL("/", req.url));
  if (!isOpsPath && isOpsHost) return NextResponse.redirect(new URL("/ops", req.url));

  // Tenant resolution usually hits your server/edge function, then sets headers.
  return NextResponse.next();
}
