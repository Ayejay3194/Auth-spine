import random
import yaml
from pathlib import Path

TEMPLATES_PATH = Path(__file__).resolve().parent / "templates.yaml"

class NLGRenderer:
    def __init__(self):
        self.templates = yaml.safe_load(TEMPLATES_PATH.read_text(encoding="utf-8"))

    def render(self, dm_out: dict) -> dict:
        action = dm_out["next_action"]
        state = dm_out["state"]
        t = action.get("type")

        if t == "ask":
            return {"text": self._pick("ask.slot").format(question=action.get("question")), "suggestions": []}

        if t == "respond":
            tpl = action.get("template", "fallback")
            params = action.get("params") or {}
            if "suggestions" in params and isinstance(params["suggestions"], list):
                params["suggestions"] = ", ".join(params["suggestions"])
            return {"text": self._pick(tpl).format(**params), "suggestions": []}

        if t == "execute":
            intent = action.get("intent") or state.get("active_intent") or "unknown"
            slots = state.get("slots") or {}
            summary = self._summary(intent, slots)
            key = f"execute.{intent}"
            if key in self.templates:
                return {"text": self._pick(key).format(summary=summary), "suggestions": []}
            return {"text": summary, "suggestions": []}

        return {"text": "...", "suggestions": []}

    def _pick(self, key: str) -> str:
        return random.choice(self.templates.get(key) or ["..."])

    def _summary(self, intent: str, slots: dict) -> str:
        if intent == "book_appointment":
            service = slots.get("service","service")
            date = slots.get("date","a day")
            time = slots.get("time",{})
            if isinstance(time, dict):
                t = f"{time.get('hour','?')}:{time.get('minute',0):02d}{time.get('ampm','')}"
            else:
                t = str(time)
            stylist = slots.get("stylist")
            return f"Booked a {service} on {date} at {t}" + (f" with {stylist}." if stylist else ".")
        if intent == "price_quote":
            return f"Price for {slots.get('service','that')} is $X (wire your real pricing table)."
        if intent == "hours":
            return "Hours: 9am–6pm (wire your real hours store)."
        return f"Done: {intent} with {slots}."
