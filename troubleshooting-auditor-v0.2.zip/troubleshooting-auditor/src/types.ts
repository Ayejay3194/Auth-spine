export type Severity = "INFO" | "WARN" | "ERROR";

export type Finding = {
  id: string;
  title: string;
  severity: Severity;
  details: string;
  evidence?: Record<string, unknown>;
  fix?: string;
};

export type AuditSection = {
  id: string;
  title: string;
  findings: Finding[];
};

export type AuditReport = {
  meta: {
    tool: string;
    version: string;
    timestamp: string;
    root: string;
    node: string;
    platform: string;
  };
  sections: AuditSection[];
  summary: {
    errors: number;
    warns: number;
    infos: number;
  };
};
