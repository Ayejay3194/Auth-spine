import type { TenantContext } from "../shared/types.js";

/**
 * Tenant extraction order:
 * 1) Header: X-Tenant-Id
 * 2) Subdomain: {tenant}.yourapp.com
 * 3) Path: /t/{tenant}/...
 */
export function resolveTenant(input: { headers?: Record<string,string>; host?: string; path?: string }): TenantContext {
  const h = input.headers ?? {};
  const fromHeader = h["x-tenant-id"] || h["X-Tenant-Id"];
  if (fromHeader) return { tenantId: fromHeader };

  const host = (input.host ?? "").split(":")[0];
  const parts = host.split(".");
  if (parts.length >= 3) {
    const sub = parts[0];
    if (sub && sub !== "www" && sub !== "app") return { tenantId: sub };
  }

  const p = input.path ?? "";
  const m = p.match(/^\/t\/([^\/]+)\//);
  if (m) return { tenantId: m[1] };

  return { tenantId: "default" };
}
