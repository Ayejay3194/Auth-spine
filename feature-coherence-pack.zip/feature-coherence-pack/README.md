# Feature Coherence Pack (Drop-in)

This pack gives you a simple nervous system so features actually connect instead of becoming feature soup.

## What's inside

- `schemas/feature-contract.schema.json` — JSON Schema for feature contracts
- `registry/feature-registry.template.json` — a registry template (single source of truth)
- `templates/feature-scorecard.template.json` — ship/no-ship gate
- `features/*/contract.json` — example feature contracts
- `ts/*` — minimal TypeScript types + a tiny checker

## The rules (use these to block PRs)

1) Every feature must have a `contract.json` that validates against the schema.  
2) Features communicate through events, not direct imports/calls.  
3) Redux/global state keys must have a single owner.  
4) Feature must be disable-able (feature flag + kill switch).  
5) Feature must connect via:
   - shared events OR
   - shared primitives with at least one other feature.

## Quick adoption

1) Copy this folder into your repo (e.g. `packages/feature-coherence/`).  
2) Put each feature contract at `features/<feature_name>/contract.json`.  
3) Add a CI step to validate JSON + run the checker.

## Suggested CI steps

- Validate JSON schema (Ajv or similar)
- Run coherence check:
  - compile TS or run with ts-node in CI
  - fail build on errors, warn on isolated features

## Recommended event naming

`domain.entity.action` or `domain.feature.action`

Examples:
- `tasks.task.created`
- `calendar.availability.computed`
- `cache.indexdb.cleared`

## Shared primitives (keep this small)

- User
- Task
- Event
- TimeRange
- Status
- Permission
- Source
- Confidence
