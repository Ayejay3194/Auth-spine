import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerPaymentsTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "payments.create_invoice",
    title: "Create invoice",
    description: "Creates an invoice for a client.",
    inputSchema: { type: "object", properties: { clientId: { type: "string" }, amount: { type: "number" } }, required: ["clientId", "amount"] },
    async run(ctx, input) {
      const data = await p.payments.createInvoice({ clientId: input.clientId, amount: input.amount });
      return { ok: true, data };
    }
  });

  reg.register({
    id: "payments.refund",
    title: "Refund invoice",
    description: "Marks an invoice refunded (or triggers gateway refund in real provider).",
    inputSchema: { type: "object", properties: { invoiceId: { type: "string" } }, required: ["invoiceId"] },
    async run(ctx, input) {
      const data = await p.payments.refund({ invoiceId: input.invoiceId });
      return { ok: true, data };
    }
  });
}
