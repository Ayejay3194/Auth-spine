# NLU System (Rule/Keyword-Based)

A tiny, dependency-light **NLU editor + tester**:
- Manage **intents** with example phrases
- Manage **entities** with dictionary values
- Run **intent classification** + **entity extraction**
- **Import/Export** model JSON
- Auto-saves to **localStorage** so you don’t lose work

## Next.js App Router usage
This zip includes:
- `components/NLUSystem.tsx`
- `lib/nlu.ts`, `lib/types.ts`, `lib/storage.ts`
- `app/nlu/page.tsx`

Drop these into an existing Next.js + Tailwind project.

## Model format
```json
{
  "version": 1,
  "intents": [{ "name": "greeting", "examples": ["hi", "hello"] }],
  "entities": [{ "name": "location", "values": ["new york", "london"] }]
}
```

## What it is (and isn't)
- Intent classification is scored matching (token overlap + phrase bonuses).
- Entity extraction is dictionary phrase matching with overlap resolution (longest wins).
- Not ML. Not embeddings. Not magic. Just fast and predictable.
