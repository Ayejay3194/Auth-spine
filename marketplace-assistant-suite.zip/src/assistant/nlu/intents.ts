export type IntentId =
  | "unknown"
  // single-business core
  | "payments.create_invoice" | "analytics.kpi" | "ops.list_tasks" | "admin.show_audit"
  | "marketing.create_promo" | "payments.refund" | "gdpr.export_request"
  // marketplace
  | "market.search_providers" | "market.search_slots"
  | "market.booking.hold" | "market.booking.confirm" | "market.booking.cancel"
  | "market.payments.create_intent" | "market.payout.schedule" | "market.refund.issue"
  | "market.message.send" | "market.review.submit" | "market.dispute.open" | "market.dispute.resolve";

export type IntentExample = { intent: IntentId; utterance: string };
export type IntentRule = { intent: IntentId; any: string[]; all: string[] };

function tokenize(s: string) { return s.toLowerCase().replace(/[^a-z0-9\s$%_.-]/g, " ").split(/\s+/).filter(Boolean); }
function jaccard(a: string[], b: string[]) {
  const A = new Set(a), B = new Set(b);
  const inter = new Set([...A].filter(x => B.has(x)));
  const union = new Set([...A, ...B]);
  return union.size ? inter.size / union.size : 0;
}

export class IntentDetector {
  constructor(private rules: IntentRule[], private examples: IntentExample[], private opts: { minScore: number }) {}
  detect(text: string): { intent: IntentId; score: number; why: string } {
    const toks = tokenize(text);
    for (const r of this.rules) {
      const anyHit = r.any.length ? r.any.some(k => toks.includes(k)) : true;
      const allHit = r.all.every(k => toks.includes(k));
      if (anyHit && allHit) return { intent: r.intent, score: 0.95, why: "rule" };
    }
    let best: { intent: IntentId; score: number } = { intent: "unknown", score: 0 };
    for (const ex of this.examples) {
      const s = jaccard(toks, tokenize(ex.utterance));
      if (s > best.score) best = { intent: ex.intent, score: s };
    }
    if (best.score >= this.opts.minScore) return { intent: best.intent, score: best.score, why: "similarity" };
    return { intent: "unknown", score: best.score, why: "none" };
  }
}
