import fs from "node:fs/promises";
import path from "node:path";
import { LakeConfig, manifestDir } from "../io/paths.js";
import { sha256File } from "../io/hash.js";

export type PartitionRef = {
  path: string;   // relative to lake root
  sha256: string;
  rows?: number;
};

export type Manifest = {
  manifestVersion: "1";
  kind: "dataset_write" | "training_compile" | "metrics_write";
  dataset: string;
  datasetVersion: string;
  schemaVersion: string;
  partitions: PartitionRef[];
  createdAtISO: string;
  generator: string;
  notes?: string;
};

export async function writeManifest(
  cfg: LakeConfig,
  m: Omit<Manifest, "createdAtISO" | "manifestVersion">
): Promise<string> {
  const dir = manifestDir(cfg);
  await fs.mkdir(dir, { recursive: true });
  const createdAtISO = new Date().toISOString();
  const id = `${m.kind}-${m.dataset}-${m.datasetVersion}-${createdAtISO}`.replaceAll(":", "-");
  const file = path.join(dir, `${id}.json`);
  const full: Manifest = { manifestVersion: "1", createdAtISO, ...m };
  await fs.writeFile(file, JSON.stringify(full, null, 2));
  return file;
}

export async function manifestForSingleFile(
  cfg: LakeConfig,
  kind: Manifest["kind"],
  dataset: string,
  datasetVersion: string,
  schemaVersion: string,
  absoluteFilePath: string,
  generator: string,
  rows?: number
) {
  const rel = path.relative(cfg.root, absoluteFilePath);
  return writeManifest(cfg, {
    kind,
    dataset,
    datasetVersion,
    schemaVersion,
    partitions: [{ path: rel, sha256: await sha256File(absoluteFilePath), rows }],
    generator
  });
}
