export const SENSITIVE_KEYS = new Set([
  "ssn","taxId","dob","dateOfBirth","address","phone",
  "salary","salaryCents","payRateCents",
  "bankAccount","routingNumber","accountNumber",
  "notes","internalNotes","audit","auditLog",
  "password","hash","token","apiKey","secret"
]);

export function stripSensitiveKeys(obj: any): any {
  if (!obj || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(stripSensitiveKeys);
  const out: any = {};
  for (const [k,v] of Object.entries(obj)) {
    if (SENSITIVE_KEYS.has(k)) continue;
    out[k] = stripSensitiveKeys(v);
  }
  return out;
}

export function deepRedact(obj: any): any {
  if (typeof obj === "string") {
    return obj
      .replace(/\b\d{3}-\d{2}-\d{4}\b/g, "[REDACTED_SSN]")
      .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[REDACTED_EMAIL]");
  }
  if (Array.isArray(obj)) return obj.map(deepRedact);
  if (obj && typeof obj === "object") {
    const out: any = {};
    for (const [k,v] of Object.entries(obj)) out[k] = deepRedact(v);
    return out;
  }
  return obj;
}

export function sanitizeExternalPayload<T>(payload: any): T {
  return deepRedact(stripSensitiveKeys(payload)) as T;
}
