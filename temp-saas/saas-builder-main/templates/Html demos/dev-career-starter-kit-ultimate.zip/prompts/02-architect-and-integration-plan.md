# Prompt: Monorepo Architect & Integration Plan
[...user fills manifest and goals, assistant designs final monorepo + plan...]
