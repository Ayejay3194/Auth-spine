import fs from "node:fs/promises";
import { Float64Vector, Int32Vector, Utf8Vector, Table as ArrowTable } from "apache-arrow";
import { assertResidualRow } from "../core/validate.js";
import { WarehouseConfig, partFile } from "../core/paths.js";
import { writeArrowTableToParquet } from "../core/parquetArrowHybrid.js";
import { makeMeta } from "../core/versioning.js";
import { ResidualSchema } from "../core/schema.js";

export type IngestArgs = {
  cfg: WarehouseConfig;
  dayISO: string;     // YYYY-MM-DD
  inputJsonl: string; // path
  part?: number;
};

export async function ingestResiduals(args: IngestArgs): Promise<string> {
  const part = args.part ?? 1;
  const raw = await fs.readFile(args.inputJsonl, "utf8");
  const lines = raw.split("\n").map((s) => s.trim()).filter(Boolean);

  const ts: string[] = [];
  const body: string[] = [];
  const dx: number[] = [];
  const dy: number[] = [];
  const mv: number[] = [];

  for (const line of lines) {
    const obj = JSON.parse(line);
    assertResidualRow(obj);
    ts.push(obj.ts);
    body.push(obj.body);
    dx.push(obj.dx_arcsec);
    dy.push(obj.dy_arcsec);
    mv.push(obj.model_version | 0);
  }

  const table = ArrowTable.new({
    ts: Utf8Vector.from(ts),
    body: Utf8Vector.from(body),
    dx_arcsec: Float64Vector.from(dx),
    dy_arcsec: Float64Vector.from(dy),
    model_version: Int32Vector.from(mv),
  });

  const out = partFile(args.cfg, args.dayISO, part);
  const meta = makeMeta({
    dataset: args.cfg.dataset,
    datasetVersion: args.cfg.datasetVersion,
    schemaVersion: ResidualSchema.schemaVersion,
  });

  await writeArrowTableToParquet(out, table, {
    compression: "zstd",
    metadata: { ...meta, schemaName: ResidualSchema.schemaName },
  });

  return out;
}
