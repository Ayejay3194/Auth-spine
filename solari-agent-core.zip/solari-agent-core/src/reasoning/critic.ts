import { Plan } from "../types";
import { validatePlan } from "../governance/policy";

export function critiquePlan(plan: Plan): { ok: true } | { ok: false; issues: string[] } {
  const v = validatePlan(plan);
  if (v.ok) return { ok: true };
  return { ok: false, issues: v.errors };
}
