/**
 * Normalize numbers for hashing so tiny float noise doesn’t brick your goldens.
 *
 * Policy:
 * - angles + coords: fixed 10 decimals
 * - decimal hours: fixed 10 decimals
 */
export function normalizeNumber(n: number, decimals = 10): string {
  if (!Number.isFinite(n)) return String(n);
  return n.toFixed(decimals);
}

export function walkAndNormalizeNumbers(value: unknown): unknown {
  if (value === null) return null;
  if (Array.isArray(value)) return value.map(walkAndNormalizeNumbers);
  if (typeof value === "object") {
    const obj = value as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj)) {
      out[k] = walkAndNormalizeNumbers(v);
    }
    return out;
  }
  if (typeof value === "number") return normalizeNumber(value);
  return value;
}
