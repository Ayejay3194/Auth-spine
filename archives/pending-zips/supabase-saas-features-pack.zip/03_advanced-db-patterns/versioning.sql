-- Versioning pattern (history table)
create table if not exists workspace_versions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  tenant_id uuid not null,
  version int not null,
  data jsonb not null,
  created_at timestamptz default now()
);

-- App writes a new version row on update.
-- Can enforce monotonic version with unique(workspace_id, version).
