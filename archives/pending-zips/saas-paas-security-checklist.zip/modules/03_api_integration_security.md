API & INTEGRATION SECURITY

AuthN/AuthZ
- OAuth2/OIDC
- API keys per tenant + rotation
- JWT signature verification + expiry
- Scope-based permissions
- Service accounts / M2M auth
- Read-only vs read-write keys
- Webhook auth + signature verification
- IP allowlists (optional)
- Auth logging

Rate Limiting
- Global + per-tenant + per-user limits
- Per-endpoint limits
- Burst handling
- Standard headers + 429 responses
- Distributed rate limiting
- Abuse detection
- GraphQL depth + complexity limits
- Batch/concurrent request limits

Webhooks
- HMAC verification
- Retries with backoff
- Delivery confirmation + idempotency
- Timeouts
- Failure notifications
- Endpoint validation
- Replay prevention
- Secret rotation
- Delivery status tracking
- Dead-letter queue

Third-Party Integrations
- OAuth scope minimization
- Permissions review
- Token storage security
- Rate limit handling
- Monitoring + error handling
- Marketplace security + approval workflows
- Sandbox/testing environment
- Versioning + deprecation

API Docs
- Access control
- No sensitive endpoints in public docs
- Sanitized examples
- Sandbox mode
- Security guidance embedded
- Deprecation + changelog hygiene
