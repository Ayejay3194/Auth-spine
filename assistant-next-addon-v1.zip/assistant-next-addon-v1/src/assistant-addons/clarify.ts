import type { Intent } from "./types";

const SLOT_QUESTIONS: Record<string, string[]> = {
  service: ["What service do you want?", "Which service should I book?"],
  date: ["What day works?", "What date should I use?"],
  time: ["What time?", "What time works best?"],
  booking_ref: ["What’s the booking code (ex: BK1234)?", "Send your booking reference (BK####)."],
};

const INTENT_ORDER: Record<string, string[]> = {
  book_service: ["service", "date", "time"],
  check_availability: ["service", "date"],
  reschedule_booking: ["date", "time"],
  cancel_booking: ["booking_ref"],
  pricing_quote: ["service"],
  service_info: ["service"],
};

export function clarifyQuestion(intent: Intent, missing: string[]) {
  // Ask 1 question that covers the highest information gain slot(s).
  const order = INTENT_ORDER[intent] ?? missing;
  const top = order.find((s) => missing.includes(s)) ?? missing[0];

  const pool = SLOT_QUESTIONS[top] ?? [`Tell me ${top}.`];
  return pool[Math.floor(Math.random() * pool.length)];
}

export function disambiguateQuestion(options: Array<{ intent: Intent; confidence: number }>) {
  const top2 = options.slice(0, 2);
  const label = (i: Intent) => {
    switch (i) {
      case "book_service": return "book something";
      case "check_availability": return "check availability";
      case "reschedule_booking": return "reschedule";
      case "cancel_booking": return "cancel";
      case "pricing_quote": return "get pricing";
      case "service_info": return "ask about a service";
      case "contact_support": return "get support";
      default: return String(i);
    }
  };

  return `Quick check: do you want to ${label(top2[0].intent)} or ${label(top2[1]?.intent ?? "something else")}?`;
}
