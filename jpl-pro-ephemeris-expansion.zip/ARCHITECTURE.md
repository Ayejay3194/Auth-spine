
# System Architecture

## Source of Truth
- JPL SPK kernels (DE440/DE441)
- Canonical JSON output
- Versioned time + EOP models

## Anti-Breakage Strategy
- Golden vectors
- Horizons comparison
- Deterministic math only
- CI regression gates

## Refactor Rule
If numbers change, the version must change.
Silent drift is considered a bug.
