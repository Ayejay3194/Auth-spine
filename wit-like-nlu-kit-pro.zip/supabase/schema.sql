-- Optional tables (starter)
create table if not exists nlu_examples (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  tenant_id uuid not null,
  text text not null,
  intents jsonb not null default '[]'::jsonb,
  entities jsonb not null default '[]'::jsonb
);

create table if not exists nlu_entity_rules (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  tenant_id uuid not null,
  rules jsonb not null
);
