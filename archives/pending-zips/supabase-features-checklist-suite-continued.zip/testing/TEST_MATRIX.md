# Test Matrix (Supabase Continued Pack)

## Database
- RLS policy tests (positive + negative)
- Trigger tests (audit rows created, hashes chained)
- Migration forward + rollback
- Query plan snapshots for top endpoints

## Auth
- Session invalidation on password reset
- Force logout (single session + global)
- Suspicious login rules (simulated)

## Storage
- Signed upload path enforcement
- Bucket policy regression tests
- Lifecycle purge job dry-run + real-run

## Realtime
- Connect/reconnect
- Message dedupe
- Ack/retry
- Presence accuracy under multi-tab

## Edge Functions
- Middleware order
- Rate limit behavior
- Input validation
- Error mapping + logging

## CI Hooks
- Lint/typecheck
- Unit tests
- Migration dry-run
- RLS smoke tests against local Supabase

