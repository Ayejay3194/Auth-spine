import { NextRequest, NextResponse } from 'next/server'
import { getTokenFromRequest, verifyToken } from '@auth-spine/auth'

const PROTECTED_PREFIXES = ['/dashboard', '/admin']

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  const needsAuth = PROTECTED_PREFIXES.some((p) => pathname.startsWith(p))
  if (!needsAuth) return NextResponse.next()

  const token = getTokenFromRequest(req)
  if (!token) {
    const url = req.nextUrl.clone()
    url.pathname = '/login'
    url.searchParams.set('next', pathname)
    return NextResponse.redirect(url)
  }

  try {
    const payload = await verifyToken(token)
    // Admin gate
    if (pathname.startsWith('/admin') && (payload.role || '').toUpperCase() !== 'ADMIN') {
      const url = req.nextUrl.clone()
      url.pathname = '/dashboard'
      return NextResponse.redirect(url)
    }
    return NextResponse.next()
  } catch {
    const url = req.nextUrl.clone()
    url.pathname = '/login'
    url.searchParams.set('next', pathname)
    return NextResponse.redirect(url)
  }
}

export const config = {
  matcher: ['/dashboard/:path*', '/admin/:path*'],
}
