/**
 * End-of-turn restraint: don't tack on extra questions when the job is done.
 * This trims trailing filler like "Anything else I can help with?"
 */
const FILLER_PATTERNS: RegExp[] = [
  /anything else\s*(i can|i could)?\s*help( you)?\s*with\??$/i,
  /is there anything else\??$/i,
  /let me know if you need anything else\.?$/i,
];

export function finalizeReply(text: string) {
  let out = text.trim();
  for (const r of FILLER_PATTERNS) out = out.replace(r, "").trim();
  // tidy punctuation if we removed the end
  out = out.replace(/\s+([?.!])/g, "$1").trim();
  return out;
}
