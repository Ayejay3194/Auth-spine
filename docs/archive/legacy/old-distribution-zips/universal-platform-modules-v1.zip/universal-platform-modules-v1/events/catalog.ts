import catalogJson from "./catalog.json";
export type EventName = (typeof catalogJson)[number]["name"];
export const EVENT_CATALOG = catalogJson as { name: string; module: string; description: string }[];
