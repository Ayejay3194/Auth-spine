# 08-vendors-subscriptions

Recurring spend and contracts.
