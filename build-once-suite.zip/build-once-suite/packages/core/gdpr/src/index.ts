import type { AuditStore } from "@suite/core-audit";

export type Consent = { analytics: boolean; emailTracking: boolean; updatedAt: string };

export interface GdprService {
  setConsent(userId: string, consent: Omit<Consent, "updatedAt">): Promise<Consent>;
  getConsent(userId: string): Promise<Consent | null>;

  requestExport(userId: string): Promise<{ jobId: string }>;
  requestDelete(userId: string, mode: "deactivate" | "delete"): Promise<{ jobId: string }>;
}

export class InMemoryGdpr implements GdprService {
  private consent = new Map<string, Consent>();
  private jobs = new Map<string, { type: "export" | "delete"; userId: string; mode?: string; ts: string }>();

  constructor(private audit: AuditStore) {}

  async setConsent(userId: string, c: Omit<Consent, "updatedAt">): Promise<Consent> {
    const full: Consent = { ...c, updatedAt: new Date().toISOString() };
    this.consent.set(userId, full);
    await this.audit.append({ actor: { actorType: "user", userId }, action: "gdpr.consent.updated", targetType: "user", targetId: userId, metadata: full });
    return full;
  }

  async getConsent(userId: string): Promise<Consent | null> {
    return this.consent.get(userId) ?? null;
  }

  async requestExport(userId: string) {
    const jobId = `exp_${Math.random().toString(16).slice(2)}`;
    this.jobs.set(jobId, { type: "export", userId, ts: new Date().toISOString() });
    await this.audit.append({ actor: { actorType: "user", userId }, action: "gdpr.export.requested", targetType: "user", targetId: userId });
    return { jobId };
  }

  async requestDelete(userId: string, mode: "deactivate" | "delete") {
    const jobId = `del_${Math.random().toString(16).slice(2)}`;
    this.jobs.set(jobId, { type: "delete", userId, mode, ts: new Date().toISOString() });
    await this.audit.append({ actor: { actorType: "user", userId }, action: "gdpr.delete.requested", targetType: "user", targetId: userId, metadata: { mode } });
    return { jobId };
  }
}
