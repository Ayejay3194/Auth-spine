import { describe, it, expect } from 'vitest';

describe('sanity check', () => {
  it('1 + 1 = 2', () => {
    expect(1 + 1).toBe(2);
  });
});
