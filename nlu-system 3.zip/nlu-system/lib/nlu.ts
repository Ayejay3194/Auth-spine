import type { NLUModel, IntentResult, ExtractedEntity, NLUResult } from "./types";

function normalize(text: string) {
  return text
    .toLowerCase()
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[^a-z0-9\s'_-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokens(text: string) {
  const t = normalize(text);
  return t ? t.split(" ") : [];
}

function unique<T>(arr: T[]) {
  return Array.from(new Set(arr));
}

/**
 * Scoring:
 * - token overlap: +1 per shared token
 * - contiguous phrase match: +6
 * - exact match: +12
 * - prefix match: +4
 */
export function classifyIntent(text: string, model: NLUModel): IntentResult {
  const lower = normalize(text);
  const textTokens = tokens(lower);

  let best: IntentResult | null = null;

  for (const intent of model.intents) {
    let score = 0;

    for (const ex of intent.examples) {
      const exNorm = normalize(ex);
      const exTokens = tokens(exNorm);

      for (const w of unique(exTokens)) {
        if (textTokens.includes(w)) score += 1;
      }

      if (exNorm && lower.includes(exNorm)) score += 6;
      if (exNorm && lower === exNorm) score += 12;
      if (exNorm && (lower.startsWith(exNorm) || exNorm.startsWith(lower))) score += 4;
    }

    if (!best || score > best.score) best = { name: intent.name, confidence: 0, score };
  }

  if (!best || best.score <= 0) return { name: "unknown", confidence: 0, score: 0 };

  const confidence = Math.max(0.35, Math.min(0.97, 0.35 + Math.log1p(best.score) / 4));
  return { ...best, confidence };
}

/**
 * Dictionary entity extraction:
 * - finds all occurrences
 * - rejects inside-word matches
 * - resolves overlaps by preferring longer matches
 */
export function extractEntities(text: string, model: NLUModel): ExtractedEntity[] {
  const raw = text;
  const lower = raw.toLowerCase();

  const matches: ExtractedEntity[] = [];

  for (const entity of model.entities) {
    for (const value of entity.values) {
      const v = value.trim();
      if (!v) continue;
      const vLower = v.toLowerCase();

      let idx = 0;
      while (idx < lower.length) {
        const found = lower.indexOf(vLower, idx);
        if (found === -1) break;

        const before = found - 1;
        const after = found + vLower.length;
        const okBefore = before < 0 || /[^a-z0-9]/i.test(lower[before]);
        const okAfter = after >= lower.length || /[^a-z0-9]/i.test(lower[after]);

        if (okBefore && okAfter) {
          matches.push({ entity: entity.name, value: v, start: found, end: found + vLower.length });
        }

        idx = found + Math.max(1, vLower.length);
      }
    }
  }

  matches.sort((a, b) => (a.start - b.start) || ((b.end - b.start) - (a.end - a.start)));

  const kept: ExtractedEntity[] = [];
  for (const m of matches) {
    const overlaps = kept.some(k => !(m.end <= k.start || m.start >= k.end));
    if (!overlaps) kept.push(m);
  }

  kept.sort((a, b) => a.start - b.start);
  return kept;
}

export function analyze(text: string, model: NLUModel): NLUResult {
  return { text, intent: classifyIntent(text, model), entities: extractEntities(text, model) };
}
