import { getAllUsers } from '../../../lib/db';

export const dynamic = 'force-dynamic';

export default async function AdminUsersPage() {
  const users = await getAllUsers();

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Users</h1>
      <table className="w-full text-sm border border-slate-800">
        <thead className="bg-slate-900">
          <tr>
            <th className="text-left p-2 border-b border-slate-800">Email</th>
            <th className="text-left p-2 border-b border-slate-800">Role</th>
            <th className="text-left p-2 border-b border-slate-800">Created</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id} className="border-b border-slate-800">
              <td className="p-2">{user.email}</td>
              <td className="p-2">{user.role}</td>
              <td className="p-2 text-slate-400">
                {new Date(user.createdAt).toLocaleDateString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
