# Quick Start

```bash
npm install
cp apps/web/.env.example apps/web/.env
npm run env:check
npm run dev
```

Default pages:
- /docs
- /ui-toolkit
- /html-to-ts
- /health
- /api/health
