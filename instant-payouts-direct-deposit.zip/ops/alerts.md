ALERTS
======
Trigger alerts on:
- payout failures
- reversals
- velocity spikes
- eligibility violations
