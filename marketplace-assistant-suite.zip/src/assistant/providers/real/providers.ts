import type { Providers } from "../types.js";

export function makeRealProviders(_db: any, _platformOrBusinessId: string): Providers {
  throw new Error("Implement real providers: DB search index, holds, escrow ledger, payouts, messaging, reviews, disputes.");
}
