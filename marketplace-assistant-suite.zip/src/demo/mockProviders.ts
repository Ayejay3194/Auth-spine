import type { Providers, Invoice, Promo, KPI, Task, ProviderSearchResult, Slot, BookingHold, Booking, PaymentIntent, Payout, Message, Review, Dispute } from "../assistant/providers/types.js";

let invoices: Invoice[] = [];
let promos: Promo[] = [];
let tasks: Task[] = [{ taskId: "t1", title: "Confirm tomorrow clients", status: "open" }];
let disputes: Dispute[] = [];
let holds: BookingHold[] = [];
let bookings: Booking[] = [];

const providerIndex: ProviderSearchResult[] = [
  { providerId: "prov_1", displayName: "Maya Styles", rating: 4.9, distanceMi: 2.1, priceFrom: 90 },
  { providerId: "prov_2", displayName: "Kira Beauty", rating: 4.7, distanceMi: 4.8, priceFrom: 75 },
];

const slots: Slot[] = [
  { slotId: "slot_1", providerId: "prov_1", startISO: new Date(Date.now()+86400000).toISOString(), durationMin: 60, price: 120, serviceName: "braids" },
  { slotId: "slot_2", providerId: "prov_1", startISO: new Date(Date.now()+2*86400000).toISOString(), durationMin: 60, price: 100, serviceName: "twists" },
];

export function makeMockProviders(): Providers {
  return {
    payments: {
      async createInvoice(input) {
        const inv: Invoice = { invoiceId: `inv_${invoices.length+1}`, clientId: input.clientId, amount: input.amount, status: "sent" };
        invoices.push(inv);
        return inv;
      },
      async refund(input) {
        const inv = invoices.find(i => i.invoiceId === input.invoiceId) ?? { invoiceId: input.invoiceId, clientId: "cl_1", amount: 0, status: "sent" as const };
        inv.status = "refunded";
        return inv;
      }
    },
    marketing: {
      async createPromo(input) {
        const p: Promo = { code: input.code, percentOff: input.percentOff, active: true };
        promos.push(p);
        return p;
      }
    },
    analytics: {
      async kpis() {
        const revenue = invoices.filter(i => i.status !== "refunded").reduce((a,b)=>a+b.amount,0);
        const k: KPI[] = [{ key: "revenue", value: revenue, unit: "USD" }, { key: "invoices", value: invoices.length }];
        return k;
      }
    },
    ops: { async listTasks() { return tasks; } },
    admin: {
      async showAudit() { return []; },
      async gdprExport(input) { return { url: `https://example.com/gdpr/${input.userId}.zip` }; }
    },

    marketDiscovery: {
      async searchProviders(input) { return providerIndex.filter(p => true); },
      async providerProfile(input) { return null; },
      async searchSlots(input) { return slots.filter(s => s.providerId === input.providerId); }
    },
    marketBooking: {
      async createHold(input) {
        const slot = slots.find(s => s.providerId === input.providerId) ?? slots[0];
        const hold: BookingHold = { holdId: `hold_${holds.length+1}`, slotId: slot.slotId, providerId: input.providerId, clientId: input.clientId, expiresAtISO: new Date(Date.now()+10*60*1000).toISOString() };
        holds.push(hold); return hold;
      },
      async confirmBooking(input) {
        const h = holds.find(x => x.holdId === input.holdId) ?? holds[0];
        const bk: Booking = { bookingId: `bk_${bookings.length+1}`, slotId: h.slotId, providerId: h.providerId, clientId: h.clientId, status: "confirmed" };
        bookings.push(bk); return bk;
      },
      async cancelBooking(input) {
        const bk = bookings.find(b => b.bookingId === input.bookingId) ?? { bookingId: input.bookingId, slotId: "slot_1", providerId: "prov_1", clientId: "cl_1", status: "canceled" as const };
        bk.status = "canceled"; return bk;
      }
    },
    marketPayments: {
      async createPaymentIntent(input) {
        const pi: PaymentIntent = { paymentIntentId: `pi_${input.holdId}`, amount: input.amount, fee: Math.round(input.amount*0.12*100)/100, currency: "USD", status: "requires_payment" };
        return pi;
      },
      async schedulePayout(input) {
        const po: Payout = { payoutId: `po_${input.providerId}`, providerId: input.providerId, amount: input.amount, releaseAtISO: input.releaseAtISO, status: "scheduled" };
        return po;
      },
      async issueRefund(input) { return { ok: true as const }; }
    },
    marketMessaging: {
      async sendMessage(input) {
        const msg: Message = { messageId: `msg_${Date.now()}`, bookingId: input.bookingId, fromId: input.fromId, text: input.text, atISO: new Date().toISOString() };
        return msg;
      }
    },
    marketReputation: {
      async submitReview(input) {
        const r: Review = { reviewId: `rev_${Date.now()}`, bookingId: input.bookingId, providerId: "prov_1", rating: input.rating, text: input.text, atISO: new Date().toISOString() };
        return r;
      }
    },
    marketDisputes: {
      async openDispute(input) {
        const d: Dispute = { disputeId: `disp_${disputes.length+1}`, bookingId: input.bookingId, status: "open", reason: input.reason };
        disputes.push(d); return d;
      },
      async resolveDispute(input) {
        const d = disputes.find(x => x.disputeId === input.disputeId) ?? { disputeId: input.disputeId, bookingId: "bk_1", status: "open" as const, reason: "unknown" };
        d.status = "resolved";
        d.outcome = input.outcome;
        d.refundAmount = input.refundAmount;
        return d;
      }
    }
  };
}
