TICKET LIFECYCLE
================

States:
- opened
- awaiting_customer
- awaiting_provider
- internal_review
- resolved
- closed

Rules:
- One active owner at all times
- No ticket can be closed without resolution reason
- Silent auto-closure disabled for disputes
