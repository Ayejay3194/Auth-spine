export type TokenBucketConfig = {
  capacity: number;
  refillPerSecond: number;
};

export interface RateLimitStore {
  get(key: string): Promise<{ tokens: number; lastRefillMs: number } | null>;
  set(key: string, value: { tokens: number; lastRefillMs: number }, ttlSeconds: number): Promise<void>;
}

export class InMemoryRateLimitStore implements RateLimitStore {
  private m = new Map<string, { v: { tokens: number; lastRefillMs: number }; exp: number }>();

  async get(key: string) {
    const it = this.m.get(key);
    if (!it) return null;
    if (it.exp <= Date.now()) { this.m.delete(key); return null; }
    return it.v;
  }

  async set(key: string, value: { tokens: number; lastRefillMs: number }, ttlSeconds: number) {
    this.m.set(key, { v: value, exp: Date.now() + ttlSeconds*1000 });
  }
}

export async function takeToken(
  store: RateLimitStore,
  key: string,
  cfg: TokenBucketConfig,
  ttlSeconds = 3600
): Promise<{ allowed: boolean; remaining: number }> {
  const now = Date.now();
  const cur = await store.get(key);
  let tokens = cur?.tokens ?? cfg.capacity;
  let last = cur?.lastRefillMs ?? now;

  const elapsed = Math.max(0, (now - last)/1000);
  tokens = Math.min(cfg.capacity, tokens + elapsed * cfg.refillPerSecond);
  last = now;

  if (tokens < 1) {
    await store.set(key, { tokens, lastRefillMs: last }, ttlSeconds);
    return { allowed: false, remaining: Math.floor(tokens) };
  }

  tokens -= 1;
  await store.set(key, { tokens, lastRefillMs: last }, ttlSeconds);
  return { allowed: true, remaining: Math.floor(tokens) };
}
