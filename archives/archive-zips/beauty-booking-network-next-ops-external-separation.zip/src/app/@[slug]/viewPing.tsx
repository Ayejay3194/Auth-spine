"use client";
import { useEffect } from "react";

export function ViewPing({ entityType, entityId }:{ entityType:"STYLIST"|"SALON"; entityId:string }){
  useEffect(()=>{
    fetch("/api/events", {
      method:"POST",
      headers:{ "content-type":"application/json" },
      body: JSON.stringify({ entityType, entityId, name:"PROFILE_VIEW" }),
      keepalive: true,
    }).catch(()=>{});
  },[entityType, entityId]);

  return null;
}
