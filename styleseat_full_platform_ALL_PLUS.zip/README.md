# StyleSeat-Level Platform


## PLUS Pack
- Waitlist + matching + gapfill slots
- Staff + commissions (rules + ledger)
- Loyalty points + tiers
- Referrals + gift cards
- MessageLog queue + basic delivery worker stubs
- Dash pages under /dashboard
