export async function getConversation(_db: any, _businessId: string, _userId: string) {
  // Implement with your DB (Prisma/Drizzle/etc)
  return { id: "conv_1", stateJson: {} };
}
export async function setConversationState(_db: any, _id: string, _stateJson: any) {
  // Implement with your DB
}
