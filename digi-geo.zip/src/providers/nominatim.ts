import type { ForwardRequest, ReverseRequest, GeoProvider, GeoResult, GeoProviderConfig } from "../types.js";
import { inferConfidenceFromRank } from "../util.js";

type NominatimSearchItem = {
  display_name: string;
  lat: string;
  lon: string;
  boundingbox?: [string, string, string, string]; // south, north, west, east
  importance?: number;
  rank_search?: number;
  address?: Record<string, string>;
};

type NominatimReverse = NominatimSearchItem & {
  address?: Record<string, string>;
};

function bboxFromNominatim(b?: [string, string, string, string]) {
  if (!b) return undefined;
  const south = Number(b[0]);
  const north = Number(b[1]);
  const west = Number(b[2]);
  const east = Number(b[3]);
  if ([south, north, west, east].some(n => Number.isNaN(n))) return undefined;
  return { south, west, north, east };
}

function partsFromAddress(address?: Record<string, string>) {
  if (!address) return undefined;
  return {
    houseNumber: address.house_number,
    road: address.road,
    neighbourhood: address.neighbourhood,
    suburb: address.suburb,
    city: address.city || address.town || address.village,
    county: address.county,
    state: address.state,
    postcode: address.postcode,
    country: address.country,
    countryCode: address.country_code?.toUpperCase(),
  };
}

export function createNominatimProvider(cfg: Extract<GeoProviderConfig, { kind: "nominatim" }>): GeoProvider {
  const endpoint = cfg.endpoint.replace(/\/$/, "");
  const headers: Record<string, string> = {
    "User-Agent": cfg.userAgent,
    "Accept": "application/json",
  };
  if (cfg.referer) headers["Referer"] = cfg.referer;

  async function forward(req: ForwardRequest) {
    const url = new URL(endpoint + "/search");
    url.searchParams.set("format", "jsonv2");
    url.searchParams.set("q", req.query);
    url.searchParams.set("addressdetails", "1");
    url.searchParams.set("limit", String(req.limit ?? 5));
    if (req.locale) url.searchParams.set("accept-language", req.locale);
    if (req.countryCodes?.length) url.searchParams.set("countrycodes", req.countryCodes.join(","));
    if (cfg.email) url.searchParams.set("email", cfg.email);

    const r = await fetch(url.toString(), { headers });
    const status = r.status;
    const data = (await r.json()) as NominatimSearchItem[];

    const results: GeoResult[] = (data ?? []).map((it) => ({
      label: it.display_name,
      point: { lat: Number(it.lat), lon: Number(it.lon) },
      bbox: bboxFromNominatim(it.boundingbox),
      parts: partsFromAddress(it.address),
      confidence: inferConfidenceFromRank(it.rank_search, it.importance),
      provider: "nominatim",
      raw: it,
    })).filter(x => !Number.isNaN(x.point.lat) && !Number.isNaN(x.point.lon));

    return { status, url: url.toString(), results };
  }

  async function reverse(req: ReverseRequest) {
    const url = new URL(endpoint + "/reverse");
    url.searchParams.set("format", "jsonv2");
    url.searchParams.set("lat", String(req.point.lat));
    url.searchParams.set("lon", String(req.point.lon));
    url.searchParams.set("addressdetails", "1");
    if (req.locale) url.searchParams.set("accept-language", req.locale);
    if (cfg.email) url.searchParams.set("email", cfg.email);

    const r = await fetch(url.toString(), { headers });
    const status = r.status;
    const data = (await r.json()) as NominatimReverse;

    const results: GeoResult[] = data?.display_name ? [{
      label: data.display_name,
      point: { lat: Number(data.lat), lon: Number(data.lon) },
      bbox: bboxFromNominatim(data.boundingbox),
      parts: partsFromAddress(data.address),
      confidence: inferConfidenceFromRank(data.rank_search, data.importance),
      provider: "nominatim",
      raw: data,
    }] : [];

    return { status, url: url.toString(), results };
  }

  return { name: "nominatim", forward, reverse };
}
