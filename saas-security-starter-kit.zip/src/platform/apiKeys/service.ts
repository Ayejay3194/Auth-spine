import { ApiKeyRecord, ApiKeyScope } from "./types";

function sha256Hex(input: string): string {
  // Placeholder: use crypto.subtle or node:crypto in server runtime
  // Keep hash-only storage. Never store plaintext key.
  let h = 0;
  for (let i=0;i<input.length;i++) h = ((h<<5)-h) + input.charCodeAt(i);
  return `h_${Math.abs(h)}`;
}

export function generateApiKey(): { plaintext: string; prefix: string; hash: string } {
  const plaintext = `sk_${globalThis.crypto?.randomUUID?.() ?? (Date.now()+"_"+Math.random().toString(16).slice(2))}`;
  const prefix = plaintext.slice(0, 6);
  const hash = sha256Hex(plaintext);
  return { plaintext, prefix, hash };
}

export async function verifyApiKey(plaintext: string, rec: ApiKeyRecord, needed: ApiKeyScope): Promise<boolean> {
  if (rec.revokedAt) return false;
  if (sha256Hex(plaintext) !== rec.keyHash) return false;
  return rec.scopes.includes(needed) || rec.scopes.includes("admin");
}
