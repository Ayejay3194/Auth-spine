-- Shared-db tenant isolation with RLS using request-scoped settings

-- Helper: require tenant setting exists
create or replace function app.current_tenant_id()
returns uuid
language sql stable
as $$
  select nullif(current_setting('app.tenant_id', true), '')::uuid
$$;

-- Example app table
create table if not exists workspaces (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  name text not null,
  created_at timestamptz default now()
);

alter table workspaces enable row level security;

create policy "tenant_select" on workspaces
for select using (tenant_id = app.current_tenant_id());

create policy "tenant_insert" on workspaces
for insert with check (tenant_id = app.current_tenant_id());

create policy "tenant_update" on workspaces
for update using (tenant_id = app.current_tenant_id())
with check (tenant_id = app.current_tenant_id());

create policy "tenant_delete" on workspaces
for delete using (tenant_id = app.current_tenant_id());
