from __future__ import annotations
import os
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple
import joblib
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

@dataclass
class NLUModel:
    pipeline: Pipeline
    labels: List[str]

def train_intent_model(examples: List[Dict[str, Any]]) -> NLUModel:
    X = [ex["text"] for ex in examples]
    y = [ex["intent"] for ex in examples]
    labels = sorted(list(set(y)))

    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1,2), min_df=1, max_features=50000)),
        ("clf", LogisticRegression(max_iter=2000, n_jobs=1))
    ])
    pipe.fit(X, y)
    return NLUModel(pipeline=pipe, labels=labels)

def save_model(model: NLUModel, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    joblib.dump({"pipeline": model.pipeline, "labels": model.labels}, path)

def load_model(path: str) -> NLUModel | None:
    if not os.path.exists(path):
        return None
    obj = joblib.load(path)
    return NLUModel(pipeline=obj["pipeline"], labels=obj["labels"])

def predict_intents(model: NLUModel, text: str, top_k: int = 5) -> List[Tuple[str, float]]:
    proba = model.pipeline.predict_proba([text])[0]
    classes = list(model.pipeline.classes_)
    scored = sorted(zip(classes, proba), key=lambda x: x[1], reverse=True)
    return scored[:top_k]
