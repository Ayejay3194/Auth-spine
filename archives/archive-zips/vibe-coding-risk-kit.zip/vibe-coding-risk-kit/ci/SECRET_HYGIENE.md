# Secret Hygiene (do this before you cry)

## Required
- .env is in .gitignore
- No tokens printed in logs
- Rotate secrets after leaks (immediately)

## Recommended tooling
- Pre-commit secret scan (gitleaks or similar)
- CI secret scan on PRs

## Fast local checks
- grep for common patterns:
  - "sk_" (payment keys)
  - "service_role"
  - "SUPABASE_SERVICE_ROLE_KEY"
  - "PRIVATE_KEY"
