\
import http from 'k6/http';
import { check, sleep } from 'k6';

const base = __ENV.TARGET_BASE_URL || 'http://localhost:3000';

export const options = {
  scenarios: {
    login_abuse: {
      executor: 'constant-arrival-rate',
      rate: 50,
      timeUnit: '1s',
      duration: '30s',
      preAllocatedVUs: 50,
      maxVUs: 200,
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.05'],
    http_req_duration: ['p(95)<1200'],
  },
};

export default function () {
  const payload = JSON.stringify({ email: 'test@example.com', password: 'WrongPassword!!' });
  const res = http.post(`${base}/api/auth/login`, payload, { headers: { 'Content-Type': 'application/json' } });
  check(res, {
    'not 200': (r) => r.status !== 200,
    'auth response ok': (r) => [401, 403, 429].includes(r.status),
  });
  sleep(0.1);
}
