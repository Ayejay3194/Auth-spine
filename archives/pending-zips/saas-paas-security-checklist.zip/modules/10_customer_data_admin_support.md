CUSTOMER DATA + ADMIN/SUPPORT ACCESS

Data Classification
- Public/Internal/Confidential/Restricted
- Tagging + handling rules per class

Customer Data Protection
- AES-256 at rest + TLS in transit
- Field-level encryption + BYOK (enterprise)
- Masking in lower environments
- JIT support access + audit trails
- Customer consent for access (where feasible)

Admin Console Security
- Admin RBAC + MFA enforced
- IP allowlists (optional)
- Dual control for sensitive actions
- Break-glass procedures
- Privileged access management

Impersonation/Debugging
- Logged + time-limited
- Customer notification/consent options
- Read-only impersonation mode
- Debug tooling access controls
