export type GoldenVector = {
  name: string;
  input: any;
  expected: any;
};

/**
 * Store your "source of truth" vectors here.
 * Example: ephemeris outputs, intent detection outputs, receipt hashes, etc.
 * The key is: deterministic input -> deterministic expected output.
 */
export const GOLDEN_VECTORS: GoldenVector[] = [
  {
    name: "example-intent-booking",
    input: { text: "book appointment for Alex tomorrow at 2pm" },
    expected: { topIntent: "booking.create", minConfidence: 0.5 }
  }
];
