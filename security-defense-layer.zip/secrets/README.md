Secrets Management Rules

- No secrets in code or repos
- Use KMS / Vault / Secrets Manager
- Rotate secrets every 90 days
- Separate secrets per environment
