ICS export endpoint added. Google sync is integration work (OIDC + Calendar API).
