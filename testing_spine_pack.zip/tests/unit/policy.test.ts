import { describe, it, expect } from "vitest";

type Policy = { allow: Record<string, string[]> };

function canExecute(policy: Policy, role: string, toolId: string) {
  return (policy.allow[role] ?? []).includes(toolId);
}

describe("policy allowlist", () => {
  it("denies missing tools", () => {
    const p: Policy = { allow: { staff: ["booking.list"] } };
    expect(canExecute(p, "staff", "payments.refund")).toBe(false);
  });

  it("allows listed tools", () => {
    const p: Policy = { allow: { owner: ["payments.refund"] } };
    expect(canExecute(p, "owner", "payments.refund")).toBe(true);
  });
});
