import { Shell } from "@/components/layout/Shell";

export default function Home() {
  return (
    <Shell>
      <div className="border border-white/10 rounded-xl p-6">
        <h1 className="text-3xl font-black">UI Ceasefire Build</h1>
        <p className="text-white/70 mt-2">
          One UI store. Route decides layout. CSS decides mobile vs desktop.
        </p>
      </div>
    </Shell>
  );
}
