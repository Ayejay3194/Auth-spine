Three-tier error handling:
1. Internal (full truth)
2. Ops-facing (redacted)
3. Public-facing (safe, calm, non-specific)
