import { z } from "zod";
import { api } from "@/src/core/api";
import { prisma } from "@/lib/prisma";
import { getTenant } from "@/src/tenant/tenant";
import { getActor } from "@/src/core/auth";
import { assertRole } from "@/src/core/policy";

const Q = z.object({ status: z.string().optional(), limit: z.number().int().min(1).max(200).default(50) });
export async function POST(req: Request) {
  return api(async () => {
    const actor = getActor(req);
    assertRole(actor.role, ["owner","admin","staff"]);
    const { tenantId } = getTenant(req);
    const body = Q.parse(await req.json());
    const rows = await prisma.supportTicket.findMany({ where: { tenantId, ...(body.status ? { status: body.status } : {}) }, orderBy: { createdAt: "desc" }, take: body.limit });
    return { tickets: rows };
  });
}
