export type PlanKey = "free" | "solo" | "pro" | "studio";

export type Entitlements = {
  seats: number;
  maxLocations: number;
  features: Record<string, boolean>;
  quotas: Record<string, number>; // e.g. "api_calls_per_day"
};

export const PLAN_ENTITLEMENTS: Record<PlanKey, Entitlements> = {
  free:   { seats: 1, maxLocations: 1, features: { sms:false, marketing:false }, quotas: { api_calls_per_day: 500 } },
  solo:   { seats: 1, maxLocations: 1, features: { sms:true,  marketing:true  }, quotas: { api_calls_per_day: 5000 } },
  pro:    { seats: 5, maxLocations: 3, features: { sms:true,  marketing:true, ab_testing:true }, quotas: { api_calls_per_day: 20000 } },
  studio: { seats: 25, maxLocations: 25, features:{ sms:true, marketing:true, ab_testing:true, sso:true }, quotas: { api_calls_per_day: 100000 } },
};

export function entitlementsForPlan(planKey: string) {
  return PLAN_ENTITLEMENTS[(planKey as PlanKey) ?? "free"] ?? PLAN_ENTITLEMENTS.free;
}

export function hasFeature(ent: Entitlements, featureKey: string) {
  return !!ent.features[featureKey];
}
