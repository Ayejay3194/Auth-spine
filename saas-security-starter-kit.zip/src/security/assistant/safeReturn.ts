import { sanitizeExternalPayload } from "./sanitize";
import { audit } from "../observability/audit";
import { TenantContext } from "../../platform/tenant/types";

/**
 * Use at the FINAL boundary for any external assistant/tool output.
 * Never return raw DB objects externally.
 */
export async function safeReturn<T>(ctx: TenantContext, event: string, payload: any): Promise<T> {
  const sanitized = sanitizeExternalPayload<T>(payload);
  await audit({ event: "external_output_sanitized", tenantId: ctx.tenantId, actorId: ctx.userId, requestId: ctx.requestId, meta: { sourceEvent: event } });
  return sanitized;
}
