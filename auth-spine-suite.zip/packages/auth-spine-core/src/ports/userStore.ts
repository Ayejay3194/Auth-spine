import type { AccountState } from "../model/accountState.js";

export interface UserRecord {
  id: string;
  email: string;
  username?: string;
  passwordHash: string;
  emailVerified: boolean;
  state: AccountState;
  createdAt: string;
  updatedAt: string;
}

export interface UserStore {
  create(u: Omit<UserRecord, "createdAt" | "updatedAt">): Promise<UserRecord>;
  byEmail(email: string): Promise<UserRecord | null>;
  byId(id: string): Promise<UserRecord | null>;
  update(id: string, patch: Partial<UserRecord>): Promise<UserRecord>;
}
