ADMIN CONTROLS
==============

Admins can:
- Require manager approval
- Set verification windows
- Lock records
- Override with justification
- View mismatch reports
