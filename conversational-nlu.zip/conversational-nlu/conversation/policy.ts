// Policy layer: decides what to do with validated NLU + current state.
// Replace with your real rules/guardrails.

export function policyDecide(validated, state) {
  return {
    action: validated.intent ?? "fallback",
    state: {
      ...(state ?? {}),
      activeIntent: validated.intent ?? "fallback",
      confidence: validated.confidence ?? 0,
      lastUserMessage: state?.lastUserMessage ?? ""
    }
  };
}
