export type ConversationState = {
  sessionId: string;
  activeIntent: string | null;
  slots: Record<string, any>;
  confidence: number;
  turn: number;
  lastUserMessage: string;
};
