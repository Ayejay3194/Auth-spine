import { prisma } from "@/lib/prisma";

const SLOT_MIN = 30;

function startOfDayUTC(d: Date) {
  const x = new Date(d);
  x.setUTCHours(0,0,0,0);
  return x;
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const stylistId = searchParams.get("stylistId");
  const serviceId = searchParams.get("serviceId");
  const dateStr = searchParams.get("date"); // YYYY-MM-DD

  if (!stylistId || !serviceId || !dateStr) return new Response("Missing params", { status: 400 });

  const day = new Date(dateStr + "T00:00:00Z");
  const dow = day.getUTCDay();
  const dayStart = startOfDayUTC(day);
  const dayEnd = new Date(dayStart);
  dayEnd.setUTCDate(dayEnd.getUTCDate() + 1);

  const service = await prisma.serviceTemplate.findUnique({ where: { id: serviceId } });
  if (!service) return new Response("Invalid service", { status: 400 });

  const rules = await prisma.availabilityRule.findMany({
    where: { ownerType: "STYLIST", stylistId, dow },
    orderBy: { startMin: "asc" },
  });

  const taken = await prisma.booking.findMany({
    where: {
      stylistId,
      startAt: { gte: dayStart, lt: dayEnd },
      status: { in: ["REQUESTED","PENDING_APPROVAL","CONFIRMED"] },
    },
    select: { startAt: true },
  });

  const takenSet = new Set(taken.map(b => b.startAt.toISOString()));
  const slots: string[] = [];

  for (const r of rules) {
    for (let m = r.startMin; m + service.durationMin <= r.endMin; m += SLOT_MIN) {
      const slot = new Date(dayStart);
      slot.setUTCMinutes(m);
      const iso = slot.toISOString();
      if (!takenSet.has(iso)) slots.push(iso);
    }
  }

  return Response.json({ slots: Array.from(new Set(slots)).sort() });
}
