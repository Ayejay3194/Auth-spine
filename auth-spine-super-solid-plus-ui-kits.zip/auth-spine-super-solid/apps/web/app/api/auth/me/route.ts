import { NextRequest, NextResponse } from 'next/server'
import { withAuth } from '@auth-spine/auth'
import { prisma } from '@/lib/prisma'
import { errorHandler } from '@auth-spine/core'

export const GET = async (req: NextRequest) => {
  try {
    const handler = withAuth(async (_req, { user }) => {
      const dbUser = await prisma.user.findUnique({
        where: { id: user.userId },
        select: { id: true, email: true, name: true, role: true, createdAt: true },
      })
      return NextResponse.json({ user: dbUser })
    })
    return await handler(req)
  } catch (e) {
    return errorHandler(e as Error, req)
  }
}
