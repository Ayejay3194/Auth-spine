
export function resolveSlots(intent: string, entities: Record<string, any>) {
  const requiredSlots: Record<string, string[]> = {
    ask_transit_meaning: ["planet", "house", "timeframe"],
  };

  const missing = (requiredSlots[intent] || []).filter(
    slot => !entities[slot]
  );

  return {
    complete: missing.length === 0,
    missing,
  };
}
