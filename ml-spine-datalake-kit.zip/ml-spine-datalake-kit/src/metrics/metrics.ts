import path from "node:path";
import fs from "node:fs/promises";
import { Table as ArrowTable, Float64Vector, Int32Vector, Utf8Vector } from "apache-arrow";
import { LakeConfig, datasetBase } from "../io/paths.js";
import { readParquetToArrowTable, writeArrowTableToParquet } from "../io/parquetArrow.js";
import { registerDataset } from "../registry/registry.js";
import { manifestForSingleFile } from "../registry/manifest.js";

export type HistogramSpec = {
  col: string;
  bins: number;
  min?: number;
  max?: number;
};

export type MetricsArgs = {
  cfg: LakeConfig;
  input: { dataset: string; version: string; file: string };
  output: { dataset: string; version: string; schemaVersion: string };
  histograms: HistogramSpec[];
  generator: string;
};

function computeHistogram(values: number[], bins: number, min: number, max: number) {
  const counts = new Array(bins).fill(0);
  const width = (max - min) / bins;
  for (const v of values) {
    if (!Number.isFinite(v)) continue;
    if (v < min || v > max) continue;
    const idx = Math.min(bins - 1, Math.max(0, Math.floor((v - min) / width)));
    counts[idx]++;
  }
  const edges = new Array(bins + 1);
  for (let i = 0; i <= bins; i++) edges[i] = min + i * width;
  return { counts, edges };
}

export async function writeMetrics(args: MetricsArgs): Promise<{ outFile: string; manifest: string }> {
  const t = await readParquetToArrowTable(args.input.file);

  const rows: { metric: string; bin: number; edge_lo: number; edge_hi: number; count: number }[] = [];

  for (const spec of args.histograms) {
    const v = t.getChild(spec.col);
    if (!v) throw new Error(`Missing column for histogram: ${spec.col}`);

    const arr: number[] = [];
    for (let i = 0; i < t.numRows; i++) arr.push(Number(v.get(i)));
    const finite = arr.filter(Number.isFinite);
    const min = spec.min ?? Math.min(...finite);
    const max = spec.max ?? Math.max(...finite);

    const { counts, edges } = computeHistogram(arr, spec.bins, min, max);
    for (let i = 0; i < counts.length; i++) {
      rows.push({
        metric: `hist:${spec.col}`,
        bin: i,
        edge_lo: edges[i],
        edge_hi: edges[i + 1],
        count: counts[i],
      });
    }
  }

  const outTable = ArrowTable.new({
    metric: Utf8Vector.from(rows.map(r => r.metric)),
    bin: Int32Vector.from(rows.map(r => r.bin)),
    edge_lo: Float64Vector.from(rows.map(r => r.edge_lo)),
    edge_hi: Float64Vector.from(rows.map(r => r.edge_hi)),
    count: Int32Vector.from(rows.map(r => r.count)),
  });

  const outDir = datasetBase(args.cfg, args.output.dataset, args.output.version);
  await fs.mkdir(outDir, { recursive: true });
  const outFile = path.join(outDir, "metrics.parquet");

  await writeArrowTableToParquet(outFile, outTable, {
    compression: "zstd",
    metadata: {
      dataset: args.output.dataset,
      version: args.output.version,
      schemaVersion: args.output.schemaVersion,
      source: `${args.input.dataset}@${args.input.version}`,
    }
  });

  await registerDataset(args.cfg, {
    dataset: args.output.dataset,
    version: args.output.version,
    schemaVersion: args.output.schemaVersion,
    description: "Metrics outputs",
    tags: ["metrics"]
  });

  const manifest = await manifestForSingleFile(
    args.cfg,
    "metrics_write",
    args.output.dataset,
    args.output.version,
    args.output.schemaVersion,
    outFile,
    args.generator,
    outTable.numRows
  );

  return { outFile, manifest };
}
