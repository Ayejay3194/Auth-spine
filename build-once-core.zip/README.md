Build-Once Core (DB + Sessions + Workers + Stripe + Observability)
=================================================================

This is the missing "actually-done" layer:
1) **Database schema + migrations** (Prisma)
2) **Tenant-enforced access helpers**
3) **Auth sessions** (DB session + optional Redis cache adapter)
4) **Stripe billing + webhooks** (subscriptions + entitlements)
5) **Queue workers** (BullMQ pattern) + retries + DLQ concepts
6) **Observability** (structured logging + OpenTelemetry hooks)
7) **Backup automation stubs** (cron-friendly scripts + restore verification)
8) **E2E hooks** (Playwright wiring placeholders)

Quick start (local):
- docker compose up -d
- npm i
- npm run db:push
- npm run dev
- npm run worker

Endpoints:
- GET /health
- POST /tenants (dev only)
- POST /auth/login (demo)
- GET /auth/sessions
- POST /billing/stripe/webhook (raw body)

Notes:
- This is framework-agnostic by design, but includes a Fastify API app to run it.
- Replace demo auth with your real auth provider as needed. Session layer stays.

