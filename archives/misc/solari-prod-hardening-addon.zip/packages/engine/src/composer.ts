import type { Node, Provenance } from "@solari/schema";
import { RepetitionMemory } from "./memory.js";

export type ComposeOptions = {
  title: string;
  includeCitations?: boolean;
  memory?: RepetitionMemory;
};

function cite(p?: Provenance) {
  if (!p) return "";
  const bits = [p.author, p.title, p.edition, p.pageRange].filter(Boolean);
  if (!bits.length) return "";
  return `\n\n_Citation: ${bits.join(" | ")}_`;
}

export function composeMarkdown(nodes: Node[], opt: ComposeOptions) {
  const mem = opt.memory;
  const lines: string[] = [`# ${opt.title}`, ""];

  for (const n of nodes) {
    // Anti-repetition: skip if we already used this exact title recently
    if (mem?.hasPhrase(n.title)) continue;

    lines.push(`## ${n.title}`);
    if (n.summary) lines.push(n.summary, "");
    if (n.body) lines.push(n.body, "");
    if (opt.includeCitations) lines.push(cite(n.provenance));
    lines.push("");

    mem?.notePhrase(n.title);
  }

  return lines.join("\n");
}
