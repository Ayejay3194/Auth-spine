export default function BillingPage(){return <div>Billing placeholder</div>;}
