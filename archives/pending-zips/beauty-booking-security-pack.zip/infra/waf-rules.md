# WAF Rule Starter Set

- Block common scanners (bad UA patterns)
- Rate-limit:
  - /auth/* (login, reset)
  - /api/bookings (create)
- Geo/IP rules for ops:
  - allowlist office/VPN IPs (optional)
- Block:
  - requests with suspicious traversal patterns ../
  - oversized bodies on JSON endpoints
- Bot protection for public search + signup
