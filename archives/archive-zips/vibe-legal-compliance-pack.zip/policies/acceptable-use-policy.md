# Acceptable Use Policy (AUP)

You may not use the Service to:
- violate laws or regulations
- infringe IP, privacy, or other rights
- harass, threaten, or discriminate
- distribute malware, phishing, or spam
- scrape data or attempt unauthorized access
- interfere with service operation (DDoS, abuse, automation without permission)
- upload illegal or non-consensual content

We may remove content or suspend accounts for violations.
Contact: {{CONTACT_EMAIL}}
