INTERNAL COMMUNICATIONS
=======================

Purpose:
- Keep team aligned
- Avoid rumor loops
- Reduce anxiety during change

Rules:
- One update channel
- Clear cadence
- Plain language
