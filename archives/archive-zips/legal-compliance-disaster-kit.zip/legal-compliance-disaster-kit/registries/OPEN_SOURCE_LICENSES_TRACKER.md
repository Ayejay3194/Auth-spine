# Open Source Licenses Tracker

Generate an SBOM in CI (CycloneDX/SPDX). Track license risk here.

| Package | Version | License | Risk | Notes |
|---|---|---|---|---|
| | | | | |
