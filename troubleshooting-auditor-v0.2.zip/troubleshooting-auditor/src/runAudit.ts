import path from "node:path";
import type { AuditReport, AuditSection } from "./types.js";
import { auditTsconfig } from "./auditors/tsconfig.js";
import { auditPackage } from "./auditors/package.js";
import { auditEnv } from "./auditors/env.js";
import { auditFramework } from "./auditors/framework.js";
import { auditArtifacts } from "./auditors/artifacts.js";
import { auditRewrites } from "./auditors/rewrites.js";
import { auditServiceWorker } from "./auditors/serviceWorker.js";
import { auditRoutes } from "./auditors/routes.js";
import { auditCommands, type RunCommand } from "./auditors/commands.js";
import { auditEndpoints } from "./auditors/endpoints.js";

export async function runAudit(args: { root: string; run: RunCommand[]; endpoints: string[] }): Promise<AuditReport> {
  const root = path.resolve(args.root);
  const sections: AuditSection[] = [];

  sections.push(auditTsconfig(root));
  sections.push(auditPackage(root));
  sections.push(auditEnv(root));
  sections.push(auditFramework(root));
  sections.push(auditArtifacts(root));
  sections.push(auditRoutes(root));
  sections.push(auditRewrites(root));
  sections.push(auditServiceWorker(root));

  if (args.run.length) sections.push(await auditCommands(root, args.run));
  if (args.endpoints.length) sections.push(await auditEndpoints(args.endpoints));

  const summary = { errors: 0, warns: 0, infos: 0 };
  for (const s of sections) for (const f of s.findings) {
    if (f.severity === "ERROR") summary.errors++;
    else if (f.severity === "WARN") summary.warns++;
    else summary.infos++;
  }

  return {
    meta: {
      tool: "troubleshooting-auditor",
      version: "0.2.0",
      timestamp: new Date().toISOString(),
      root,
      node: process.version,
      platform: `${process.platform} ${process.arch}`,
    },
    sections,
    summary,
  };
}
