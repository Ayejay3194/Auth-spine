import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerMarketPaymentsTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "market.payments.create_intent",
    title: "Create payment intent",
    description: "Creates a payment intent for a held booking.",
    inputSchema: { type: "object", properties: { holdId: { type: "string" }, amount: { type: "number" } }, required: ["holdId","amount"] },
    async run(ctx, input) { return { ok: true, data: await p.marketPayments.createPaymentIntent(input) }; }
  });

  reg.register({
    id: "market.payout.schedule",
    title: "Schedule payout",
    description: "Schedules provider payout (escrow release).",
    inputSchema: { type: "object", properties: { providerId: { type: "string" }, amount: { type: "number" }, releaseAtISO: { type: "string" } }, required: ["providerId","amount","releaseAtISO"] },
    async run(ctx, input) { return { ok: true, data: await p.marketPayments.schedulePayout(input) }; }
  });

  reg.register({
    id: "market.refund.issue",
    title: "Issue refund",
    description: "Issues a refund for a booking (marketplace).",
    inputSchema: { type: "object", properties: { bookingId: { type: "string" }, amount: { type: "number" }, reason: { type: "string" } }, required: ["bookingId","amount","reason"] },
    async run(ctx, input) { return { ok: true, data: await p.marketPayments.issueRefund(input) }; }
  });
}
