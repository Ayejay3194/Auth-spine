CONCIERGE MODE
==============

Applies to:
- VIP customers
- top providers
- enterprise accounts

Effects:
- priority routing
- human review before automation
- direct escalation
- fewer automated messages
