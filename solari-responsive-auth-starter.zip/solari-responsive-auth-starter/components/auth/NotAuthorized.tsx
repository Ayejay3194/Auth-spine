"use client";
import Link from "next/link";
import { useAuth } from "./AuthContext";

export function NotAuthorized({ neededRole }: { neededRole: string }) {
  const { user, setRoles } = useAuth();
  return (
    <div className="glass rounded-xl2 p-6 max-w-xl">
      <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Authorization</div>
      <h2 className="mt-2 text-3xl font-black">Not authorized</h2>
      <p className="mt-2 text-white/70">
        Need role <span className="text-gold font-bold">{neededRole}</span>. Current roles:{" "}
        <span className="font-semibold">{user?.roles.join(", ")}</span>
      </p>
      <div className="mt-5 flex flex-wrap gap-3">
        <button className="btn btn-primary" onClick={() => setRoles(["user", neededRole])}>Grant role (demo)</button>
        <Link className="btn" href="/">Home</Link>
      </div>
    </div>
  );
}
