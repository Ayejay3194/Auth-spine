# Access Control Policy (SaaS)
- MFA required for ops/admin
- Least privilege + segregation of duties
- Quarterly access reviews
- JIT access for support
- Break-glass procedure documented + logged
