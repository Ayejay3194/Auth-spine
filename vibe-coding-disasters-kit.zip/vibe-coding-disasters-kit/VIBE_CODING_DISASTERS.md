# COMPLETE “THINGS THAT CAN GO WRONG WITH VIBE CODING” LIST

This is a structured, ship-ready risk register for “vibe coding” (fast prototyping without guardrails).
Use it as: preflight checks, PR review rubric, security gates, and “don’t embarrass yourself in prod” enforcement.

> Source: user-provided checklist (may be truncated at the end).

---

## SECURITY VULNERABILITIES

### Authentication & Authorization Disasters
- [ ] No authentication on critical endpoints
- [ ] Hardcoded admin credentials in code
- [ ] JWT tokens without expiration
- [ ] No token refresh mechanism
- [ ] Session tokens stored in localStorage (XSS vulnerable)
- [ ] Weak password requirements (no minimum length)
- [ ] No password hashing (storing plain text passwords)
- [ ] Using weak hashing algorithms (MD5, SHA1)
- [ ] No rate limiting on login attempts
- [ ] Missing CSRF protection
- [ ] No email verification on signup
- [ ] Authorization checks only on frontend
- [ ] User can edit their own role/permissions
- [ ] Missing authentication on API endpoints
- [ ] Anyone can access other users’ data
- [ ] No session timeout
- [ ] Forgot password without token expiration
- [ ] Password reset tokens never expire
- [ ] Using GET requests for sensitive operations
- [ ] No account lockout after failed attempts
- [ ] Predictable session IDs
- [ ] Session fixation vulnerabilities
- [ ] No logout functionality
- [ ] Logout doesn’t invalidate tokens
- [ ] Auth state only checked once on page load

### Injection Vulnerabilities
- [ ] SQL injection everywhere (string concatenation in queries)
- [ ] No parameterized queries
- [ ] Raw SQL with user input
- [ ] XSS attacks (no output encoding)
- [ ] Dangerously setting innerHTML with user content
- [ ] No input sanitization
- [ ] Command injection in system calls
- [ ] LDAP injection
- [ ] XML injection
- [ ] NoSQL injection
- [ ] GraphQL injection
- [ ] Template injection
- [ ] Server-side template injection (SSTI)
- [ ] Code injection in eval()
- [ ] Using eval() with user input
- [ ] Unsafe deserialization
- [ ] Path traversal vulnerabilities
- [ ] File inclusion vulnerabilities
- [ ] Header injection

### Data Exposure
- [ ] API returns all user data including passwords
- [ ] Exposing internal IDs that reveal system info
- [ ] Verbose error messages with stack traces in production
- [ ] Database credentials in frontend code
- [ ] API keys committed to Git
- [ ] .env files in version control
- [ ] Secrets in Docker images
- [ ] Debug mode enabled in production
- [ ] Source maps exposed in production
- [ ] Directory listing enabled
- [ ] Backup files accessible (.bak, .old)
- [ ] Git folder exposed (.git directory accessible)
- [ ] Internal API documentation publicly accessible
- [ ] GraphQL introspection enabled in production
- [ ] Database directly accessible from internet
- [ ] Admin panel at /admin with no protection
- [ ] Exposing user email addresses publicly
- [ ] PII in URLs or logs
- [ ] Sensitive data in query parameters
- [ ] Logging passwords or tokens
- [ ] Exposing server/framework version in headers
- [ ] CORS allowing all origins (*)
- [ ] No encryption for sensitive data
- [ ] Storing credit cards directly

### Access Control Issues
- [ ] Horizontal privilege escalation (access other users’ data by changing ID)
- [ ] Vertical privilege escalation (regular user accessing admin features)
- [ ] Insecure direct object references (IDOR)
- [ ] Missing authorization checks
- [ ] Only client-side authorization
- [ ] Can access resources by guessing IDs
- [ ] Sequential/predictable IDs
- [ ] No ownership verification
- [ ] Mass assignment vulnerabilities
- [ ] User can modify any field in update requests
- [ ] No role-based access control
- [ ] Everyone is admin by default
- [ ] Admin functionality accessible to all
- [ ] API endpoints with no access control
- [ ] File uploads accessible by direct URL
- [ ] Private files in public folder

### File Upload Vulnerabilities
- [ ] No file type validation
- [ ] Accepting any file extension
- [ ] No file size limits
- [ ] Files saved with original names
- [ ] Uploaded files executed by server
- [ ] PHP/executable files can be uploaded
- [ ] No virus scanning
- [ ] Files stored in web-accessible directory
- [ ] No filename sanitization
- [ ] Path traversal in file uploads
- [ ] Zip bombs
- [ ] XXE attacks via XML uploads
- [ ] Image processing vulnerabilities
- [ ] No content-type validation
- [ ] Accepting SVG with embedded JavaScript

---

## DATABASE DISASTERS

### Schema & Design Problems
- [ ] No database schema at all
- [ ] Using wrong data types (storing dates as strings)
- [ ] No primary keys
- [ ] No foreign key constraints
- [ ] Missing indexes on queried columns
- [ ] Index on every column (over-indexing)
- [ ] Denormalization without reason
- [ ] Extreme normalization causing joins on joins
- [ ] No NOT NULL constraints where needed
- [ ] No UNIQUE constraints where needed
- [ ] No default values
- [ ] Timestamps stored as strings
- [ ] Boolean values as strings (“true”/“false”)
- [ ] Money stored as floats (rounding errors)
- [ ] Using VARCHAR(255) for everything
- [ ] No constraints on important fields
- [ ] Missing CASCADE rules
- [ ] Circular foreign key dependencies
- [ ] Polymorphic associations without type safety

### Query Problems
- [ ] N+1 query problem everywhere
- [ ] SELECT * in all queries
- [ ] No pagination (loading all records)
- [ ] Missing WHERE clauses
- [ ] Using OR instead of IN for multiple values
- [ ] Subqueries instead of JOINs
- [ ] Inefficient JOINs
- [ ] No query optimization
- [ ] LIKE queries without indexes
- [ ] Leading wildcard searches (%value)
- [ ] No query result caching
- [ ] Queries in loops
- [ ] Full table scans on large tables
- [ ] No use of LIMIT
- [ ] Fetching data not used in application
- [ ] Using COUNT(*) on large tables
- [ ] No aggregate function optimization
- [ ] Sorting in application instead of database

### Data Integrity Issues
- [ ] No data validation
- [ ] Duplicate data everywhere
- [ ] Orphaned records (referential integrity violations)
- [ ] Inconsistent data formats
- [ ] Mixed timezones
- [ ] No audit trail
- [ ] Soft deletes breaking foreign keys
- [ ] No transactions for multi-step operations
- [ ] Race conditions in updates
- [ ] Lost updates problem
- [ ] Dirty reads
- [ ] No locking strategy
- [ ] Deadlocks
- [ ] Stale data being used
- [ ] No data migration strategy
- [ ] Schema changes in production without testing
- [ ] Data loss during migrations
- [ ] No rollback plan for migrations

### Connection & Performance Issues
- [ ] No connection pooling
- [ ] Opening new connection for each query
- [ ] Connection leaks
- [ ] Not closing connections
- [ ] Max connections reached constantly
- [ ] No query timeout
- [ ] Long-running queries blocking others
- [ ] Table locks during peak hours
- [ ] No read replicas for heavy read workload
- [ ] Single point of failure
- [ ] No database backup
- [ ] Backups never tested
- [ ] No point-in-time recovery
- [ ] Database on same server as application
- [ ] Insufficient database resources
- [ ] No monitoring of database performance
- [ ] Ignoring slow query logs

### Row Level Security (RLS) Issues
- [ ] RLS not enabled at all
- [ ] RLS policies too permissive
- [ ] Forgetting to add policies for new tables
- [ ] Bypassing RLS with service role in client
- [ ] Testing with service role (not catching RLS issues)
- [ ] RLS policies with performance problems
- [ ] Complex RLS causing slow queries
- [ ] RLS not covering all CRUD operations
- [ ] Missing policies for edge cases
- [ ] RLS only on some tables in multi-table queries

---

## LEGAL & COMPLIANCE DISASTERS

### Privacy Violations
- [ ] No privacy policy
- [ ] Collecting data without consent
- [ ] No GDPR compliance
