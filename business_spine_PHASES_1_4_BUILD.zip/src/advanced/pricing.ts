export type PricingRule =
  | { kind: "off_peak"; percent: number; dayOfWeek: number[]; startHour: number; endHour: number }
  | { kind: "last_minute"; percent: number; withinHours: number }
  | { kind: "vip_discount"; percent: number; tier: "VIP" | "VVIP" };

export function applyPricing(baseCents: number, rules: PricingRule[], ctx: { now: Date; hoursUntil?: number; tier?: string }) {
  let price = baseCents;
  for (const r of rules) {
    if (r.kind === "off_peak") {
      const dow = ctx.now.getDay();
      const h = ctx.now.getHours();
      if (r.dayOfWeek.includes(dow) && h >= r.startHour && h < r.endHour) price = Math.floor(price * (1 - r.percent / 100));
    }
    if (r.kind === "last_minute" && (ctx.hoursUntil ?? 999) <= r.withinHours) price = Math.floor(price * (1 - r.percent / 100));
    if (r.kind === "vip_discount" && ctx.tier === r.tier) price = Math.floor(price * (1 - r.percent / 100));
  }
  return Math.max(0, price);
}
