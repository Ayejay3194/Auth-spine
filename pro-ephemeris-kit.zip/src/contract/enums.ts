import { z } from "zod";

export const HouseSystem = z.enum([
  "placidus",
  "whole_sign",
  "koch",
  "equal_house",
  "campanus",
  "regiomontanus",
  "porphyry",
]);

export const Zodiac = z.enum(["tropical", "sidereal"]);

export const BodyId = z.enum([
  "Sun","Moon","Mercury","Venus","Mars","Jupiter","Saturn","Uranus","Neptune","Pluto",
  "MeanNode","TrueNode",
  "Chiron","LilithMean","LilithTrue","Fortune","Vertex",
]);

export const AspectId = z.enum([
  "conjunction","opposition","trine","square","sextile",
  "quincunx","semisextile","semisquare","sesquiquadrate",
]);

export type HouseSystem = z.infer<typeof HouseSystem>;
export type Zodiac = z.infer<typeof Zodiac>;
export type BodyId = z.infer<typeof BodyId>;
export type AspectId = z.infer<typeof AspectId>;
