import fs from "node:fs";
import path from "node:path";
import { MockEngine } from "../engine/mock-engine.js";
import type { ChartRequest } from "../engine/engine.js";
import { computeNatalWithIntegrity } from "../pipeline/build.js";
import { exportAMT1 } from "../export/text.js";

export function readJson(p: string) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

export function writeFile(p: string, s: string) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, s, "utf8");
}

export async function runOne(reqPath: string) {
  const req = readJson(reqPath) as ChartRequest;
  const engine = new MockEngine();
  const chart = await computeNatalWithIntegrity(engine, req);
  const text = exportAMT1(chart);
  return { chart, text };
}
