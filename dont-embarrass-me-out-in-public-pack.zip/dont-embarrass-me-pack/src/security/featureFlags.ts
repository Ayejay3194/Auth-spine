import { safeJsonParse } from "../utils/safeJson";

type FlagKey =
  | "CHAT_ENABLED"
  | "TOOL_EXECUTION_ENABLED"
  | "EXPORTS_ENABLED"
  | "PAYMENTS_ENABLED"
  | string;

type FlagMap = Record<string, boolean>;

const defaults: FlagMap = (() => {
  const parsed = safeJsonParse(process.env.FEATURE_FLAG_DEFAULTS || "{}");
  return parsed.ok && parsed.data && typeof parsed.data === "object" ? (parsed.data as FlagMap) : {};
})();

const tenantOverrides = new Map<string, FlagMap>();

export const featureFlags = {
  setTenantFlags(tenantId: string, flags: FlagMap) {
    tenantOverrides.set(tenantId, { ...flags });
  },

  isEnabled(flag: FlagKey, tenantId?: string): boolean {
    const tid = tenantId || "public";
    const overrides = tenantOverrides.get(tid);
    if (overrides && typeof overrides[flag] === "boolean") return overrides[flag];
    if (typeof defaults[flag] === "boolean") return defaults[flag];
    return false; // FAIL CLOSED: unknown flags default off
  }
};
