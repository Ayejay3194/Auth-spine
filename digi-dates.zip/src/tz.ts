import { ValidationError } from "./errors.js";

export function assertIanaTimeZone(tz: string): void {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz }).format(0);
  } catch {
    throw new ValidationError(`Invalid IANA time zone: ${tz}`);
  }
}

export type FormatInTimeZoneOptions = {
  locale?: string;
  withSeconds?: boolean;
};

export function formatInTimeZone(
  d: Date,
  tz: string,
  opts: FormatInTimeZoneOptions = {}
): string {
  assertIanaTimeZone(tz);

  const locale = opts.locale ?? "en-US";
  const withSeconds = opts.withSeconds ?? true;

  const fmt = new Intl.DateTimeFormat(locale, {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: withSeconds ? "2-digit" : undefined,
    hour12: false,
    timeZoneName: "short",
  });

  return fmt.format(d);
}

export function toEpochMs(d: Date): number {
  return d.getTime();
}

export function fromEpochMs(ms: number): Date {
  if (!Number.isFinite(ms)) throw new ValidationError("epoch ms must be finite");
  return new Date(ms);
}
