import Link from "next/link";
import { Container } from "@/components/Container";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";

export default async function OpsHome(){
  const session = await auth();
  const user = session?.user?.email ? await prisma.user.findUnique({ where:{ email: session.user.email } }) : null;
  await requireRole(user, ["OWNER","MANAGER","ADMIN"]);

  return (
    <main className="py-10">
      <Container>
        <div className="rounded-[28px] border p-8" style={{borderColor:"var(--border)", background:"var(--panel)", boxShadow:"var(--shadow)"}}>
          <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Ops</div>
          <h1 className="serif mt-2 text-3xl">Operations Console</h1>
          <p className="mt-2 text-sm" style={{color:"var(--muted)"}}>
            Internal-only. If this is visible on your public host, your separation is broken.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            <Link href="/salon-admin/luxe-salon" className="rounded-2xl px-5 py-3 text-sm font-semibold" style={{background:"var(--accent)", color:"var(--accentText)"}}>Salon Admin</Link>
            <Link href="/admin/patterns" className="rounded-2xl border px-5 py-3 text-sm font-semibold" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>Patterns</Link>
            <Link href="/ops/audit" className="rounded-2xl border px-5 py-3 text-sm font-semibold" style={{borderColor:"var(--border)", background:"var(--panel2)"}}>Audit</Link>
          </div>
        </div>
      </Container>
    </main>
  );
}
