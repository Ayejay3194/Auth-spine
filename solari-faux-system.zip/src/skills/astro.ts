import { Skill } from "./base.js";
import { SkillContext, SkillResult } from "../types.js";

export class AstroInterpreterSkill implements Skill {
  name = "AstroInterpreterSkill";

  async run(ctx: SkillContext): Promise<SkillResult> {
    // Deterministic interpretation: map placements/keywords to themed outputs.
    const placements = ctx.nlu.entities.filter(e => e.kind === "placement").map(e => (e as any).value as string);
    const q = ctx.nlu.intent;

    if (placements.length === 0) {
      return {
        kind: "clarify",
        question: "Tell me the placement you want interpreted (example: “Moon in Scorpio”, “Leo rising”).",
        options: ["Moon in Scorpio", "Leo rising", "Venus in Pisces"],
        tags: ["astrology","clarify"],
      };
    }

    const lines: string[] = [];
    for (const p of placements) {
      lines.push(...interpretPlacement(p));
    }

    // Keep it readable
    const text = lines.slice(0, 8).join("\n");
    return { kind: "text", text, tags: ["astrology","interpretation"] };
  }
}

function interpretPlacement(p: string): string[] {
  const s = p.toLowerCase();
  if (s.includes("moon in scorpio")) {
    return [
      "Moon in Scorpio: emotional x-ray vision. You feel everything, then you pretend you don’t.",
      "Trust is earned in blood, not vibes. Once you’re in, you’re in. Once you’re out, you’re a ghost story.",
      "Shadow move: control through silence. Growth move: say the scary thing out loud before it becomes a test."
    ];
  }
  if (s.includes("sun in pisces")) {
    return [
      "Sun in Pisces: porous boundaries, huge imagination, psychic-level patterning.",
      "Shadow move: self-sacrifice that quietly turns into resentment. Growth move: choose, don’t dissolve.",
    ];
  }
  if (s.includes("leo rising")) {
    return [
      "Leo rising: main-character delivery. Even when you’re low-key, your presence isn’t.",
      "You’re here to be seen, not to shrink yourself into ‘easy to manage.’"
    ];
  }
  if (s.includes("venus in pisces")) {
    return [
      "Venus in Pisces: romantic idealist. You love the soul, not the resume.",
      "Shadow move: ‘I can heal them’ dating. Growth move: love with standards, not just empathy."
    ];
  }
  // default fallback
  return [
    `${p}: I can interpret this, but give me more context (house, aspects, or what you’re trying to understand).`,
  ];
}
