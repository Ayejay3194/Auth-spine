import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { z } from "zod";

const Body = z.object({
  displayName: z.string().min(1),
  title: z.string().optional().nullable(),
  bio: z.string().optional().nullable(),
  heroUrl: z.string().optional().nullable(),
  avatarUrl: z.string().optional().nullable(),
  instagram: z.string().optional().nullable(),
});

async function getStylistBySession() {
  const session = await auth();
  if(!session?.user?.email) return null;
  const user = await prisma.user.findUnique({ where:{ email: session.user.email }, include:{ stylistProfile:true } });
  return user?.stylistProfile ?? null;
}

export async function GET(){
  const stylist = await getStylistBySession();
  if(!stylist) return new Response("Unauthorized", { status: 401 });
  const socials: any = stylist.socials || {};
  return Response.json({
    profile: {
      displayName: stylist.displayName,
      title: stylist.title,
      bio: stylist.bio,
      heroUrl: stylist.heroUrl,
      avatarUrl: stylist.avatarUrl,
      instagram: socials.instagram || "",
    }
  });
}

export async function PUT(req: Request){
  const stylist = await getStylistBySession();
  if(!stylist) return new Response("Unauthorized", { status: 401 });

  const data = Body.parse(await req.json());
  const socials = { ...(stylist.socials as any || {}), instagram: data.instagram || "" };

  const updated = await prisma.stylistProfile.update({
    where:{ id: stylist.id },
    data: {
      displayName: data.displayName,
      title: data.title ?? null,
      bio: data.bio ?? null,
      heroUrl: data.heroUrl ?? null,
      avatarUrl: data.avatarUrl ?? null,
      socials,
    }
  });

  return Response.json({ ok:true, profile: updated });
}
