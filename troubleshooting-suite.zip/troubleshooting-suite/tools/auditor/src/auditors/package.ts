import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readJson } from "../utils/fs.js";
type Pkg = { scripts?: Record<string,string>; engines?: Record<string,string>; };
export function auditPackage(root: string): AuditSection {
  const section: AuditSection = { id:"package", title:"Package & Scripts", findings: [] };
  const p = path.join(root,"package.json");
  if (!exists(p)) { section.findings.push({ id:"package.missing", title:"package.json missing", severity:"ERROR",
    details:"No scripts and no dependency graph.", fix:"Add package.json with build/dev/start or preview.", evidence:{packageJsonPath:p}}); return section; }
  let pkg: Pkg;
  try { pkg = readJson<Pkg>(p); } catch (e) { section.findings.push({ id:"package.invalid", title:"package.json invalid JSON", severity:"ERROR",
    details:"package.json failed to parse.", fix:"Fix JSON syntax.", evidence:{packageJsonPath:p, error:String(e)}}); return section; }
  const scripts = pkg.scripts ?? {};
  if (!scripts.build) section.findings.push({ id:"package.build", title:"No build script", severity:"ERROR",
    details:"CI/deploy usually runs npm run build.", fix:"Add build script.", evidence:{scripts} });
  if (!scripts.dev) section.findings.push({ id:"package.dev", title:"No dev script", severity:"WARN",
    details:"Local dev should be one command.", fix:"Add dev script.", evidence:{scripts} });
  if (!scripts.start && !scripts.preview) section.findings.push({ id:"package.startPreview", title:"No start/preview script", severity:"INFO",
    details:"Prod-parity testing is easier with start/preview.", fix:"Add start (SSR) or preview (static).", evidence:{scripts} });
  if (!pkg.engines?.node) section.findings.push({ id:"package.nodeEngine", title:"No Node engine pinned", severity:"INFO",
    details:"Node mismatches cause prod-only failures.", fix:"Add engines.node and/or .nvmrc.", evidence:{engines: pkg.engines ?? null} });
  return section;
}
