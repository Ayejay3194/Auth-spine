# Auth-Spine Test Pack

You dropped a pile of Playwright + Vitest tests and utilities in one chat message (because humans love suffering),
so here's a clean, runnable layout.

## What's included

- **Playwright E2E**: homepage/dashboard/swagger/metrics + responsive checks
- **Vitest API**: health/metrics/openapi/providers + basic auth flows
- **Vitest smoke**: tenant creation + login + sessions scoping (IDOR starter)
- **Test utils**: Prisma mock, factories, DB helpers, perf helpers, env helpers

## Install

```bash
npm i
npx playwright install --with-deps
```

## Run Vitest

```bash
BASE_URL=http://localhost:3000 npm run test:unit
```

## Run Playwright

```bash
BASE_URL=http://localhost:3000 npm run test:e2e
```

## Notes

- Some endpoints in these tests are *project-specific* (e.g. `/tenants` dev endpoint, `/auth/login` vs `/api/auth/login`).
  Adjust paths to match your app.
- Import-path tests using `@/src/...` assume you have TS path aliases configured.
