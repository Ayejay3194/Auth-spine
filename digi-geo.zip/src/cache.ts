import type { L1Cache } from "./types.js";

type Entry = { v: string; exp: number };

export class InMemoryCache implements L1Cache {
  private maxEntries: number;
  private defaultTtlMs: number;
  private map = new Map<string, Entry>();

  constructor(opts?: { maxEntries?: number; defaultTtlMs?: number }) {
    this.maxEntries = opts?.maxEntries ?? 5000;
    this.defaultTtlMs = opts?.defaultTtlMs ?? 1000 * 60 * 60 * 24 * 7;
  }

  get(key: string): string | null {
    const e = this.map.get(key);
    if (!e) return null;
    if (Date.now() > e.exp) {
      this.map.delete(key);
      return null;
    }
    return e.v;
  }

  set(key: string, value: string, ttlMs?: number): void {
    const ttl = ttlMs ?? this.defaultTtlMs;
    if (this.map.size >= this.maxEntries) this.evict();
    this.map.set(key, { v: value, exp: Date.now() + ttl });
  }

  private evict() {
    // naive eviction: delete oldest expiring entry
    let oldestKey: string | null = null;
    let oldestExp = Infinity;
    for (const [k, e] of this.map.entries()) {
      if (e.exp < oldestExp) {
        oldestExp = e.exp;
        oldestKey = k;
      }
    }
    if (oldestKey) this.map.delete(oldestKey);
    else this.map.clear();
  }
}
