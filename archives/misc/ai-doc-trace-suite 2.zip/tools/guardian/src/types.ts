export type Policy = {
  version: number;
  requireChangelog: boolean;
  changelogPath: string;
  protected: string[];
  allowedTouch: string[];
  denyDelete: string[];
  denyRename: string[];
  maxFilesChanged: number;
  requireSynopsis: boolean;
  synopsisOutput: string;
};

export type ManifestEntry = { path: string; sha256: string; bytes: number; mtimeMs: number; };
export type Manifest = { createdAt: string; root: string; entries: ManifestEntry[]; };

export type DiffItem = {
  path: string;
  status: "added" | "modified" | "deleted";
  before?: ManifestEntry;
  after?: ManifestEntry;
};

export type DiffResult = { createdAt: string; changed: DiffItem[]; };
