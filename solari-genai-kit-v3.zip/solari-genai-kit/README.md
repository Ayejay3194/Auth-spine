# Solari GenAI Kit (self-hosted, controlled generation) — v3

Now includes **edge-case eval pack**, **failure classification**, and a simple **confidence scoring** hook.

Generated: 2026-02-26T00:54:41.965361Z

## Folders
- `training/` : JSONL conversion + validation + stats + dedupe + split (including group split) + Axolotl configs
- `serve/`    : vLLM OpenAI-compatible server (Docker) + optional auth proxy
- `runtime/`  : schema-locked generation + tool router (TypeScript) + confidence scoring
- `rag/`      : Postgres+pgvector compose + ingest/retrieval contracts
- `evals/`    : golden tests + **edge-case tests** + results.json with failure taxonomy

## Run order
1) `serve/`
2) `runtime/`
3) `evals/` (golden + edge-case)
