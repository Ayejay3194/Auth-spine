// staff entities.ts
