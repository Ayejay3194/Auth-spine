import type { DialogueState, NLUModel } from "../types";
import { defaultModel } from "./defaultModel";
import { importModel as importModelRaw, exportModel as exportModelRaw } from "./versioning";
import { withDefaults } from "./schema";

const MODEL_KEY = "nlu:model";
const STATE_KEY_PREFIX = "nlu:state:";

function hasLocalStorage(): boolean {
  try { return typeof window !== "undefined" && !!window.localStorage; } catch { return false; }
}

export function loadModel(): NLUModel {
  if (!hasLocalStorage()) return withDefaults(defaultModel);
  const raw = window.localStorage.getItem(MODEL_KEY);
  if (!raw) return withDefaults(defaultModel);
  const res = importModelRaw(raw);
  return res.ok ? res.model : withDefaults(defaultModel);
}

export function saveModel(model: NLUModel): void {
  if (!hasLocalStorage()) return;
  window.localStorage.setItem(MODEL_KEY, exportModelRaw(model));
}

export function exportModel(model: NLUModel): string {
  return exportModelRaw(model);
}

export function importModel(jsonText: string): { ok: true; model: NLUModel } | { ok: false; error: string } {
  return importModelRaw(jsonText);
}

export function loadState(sessionId: string): DialogueState | null {
  if (!hasLocalStorage()) return null;
  const raw = window.localStorage.getItem(STATE_KEY_PREFIX + sessionId);
  if (!raw) return null;
  try { return JSON.parse(raw) as DialogueState; } catch { return null; }
}

export function saveState(state: DialogueState): void {
  if (!hasLocalStorage()) return;
  window.localStorage.setItem(STATE_KEY_PREFIX + state.sessionId, JSON.stringify(state));
}

export function clearState(sessionId: string): void {
  if (!hasLocalStorage()) return;
  window.localStorage.removeItem(STATE_KEY_PREFIX + sessionId);
}
