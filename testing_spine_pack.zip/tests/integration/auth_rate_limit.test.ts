import { describe, it, expect } from "vitest";
import request from "supertest";
import "../helpers/env";

const BASE_URL = process.env.INTEGRATION_BASE_URL ?? "http://localhost:3000";

describe("auth rate limiting (template)", () => {
  it("eventually returns 429 after many failures", async () => {
    for (let i = 0; i < 12; i++) {
      await request(BASE_URL).post("/api/auth/login").send({ email: "x@x.com", password: "wrongwrong" });
    }
    const last = await request(BASE_URL).post("/api/auth/login").send({ email: "x@x.com", password: "wrongwrong" });
    expect([200, 401, 429]).toContain(last.status);
  });
});
