APPLICATION SECURITY

Covers:
- Input validation & sanitization
- XSS prevention
- SQL/NoSQL injection prevention
- CSRF protection
- API security
- File upload security
- Business logic abuse prevention