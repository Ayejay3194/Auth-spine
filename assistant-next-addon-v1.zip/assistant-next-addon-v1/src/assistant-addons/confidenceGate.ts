import type { ConversationState, GateDecision, NluResult, Intent } from "./types";

export interface GateConfig {
  low: number;      // below -> disambiguate/clarify
  medium: number;   // between -> disambiguate
}

const DEFAULTS: GateConfig = { low: 0.55, medium: 0.75 };

const REQUIRED_SLOTS: Record<string, string[]> = {
  book_service: ["service", "date", "time"],
  check_availability: ["service", "date"],
  reschedule_booking: ["date", "time"],
  cancel_booking: ["booking_ref"],
  pricing_quote: ["service"],
  service_info: ["service"],
};

export function missingSlots(intent: Intent, entities: Record<string, any>): string[] {
  const req = REQUIRED_SLOTS[intent] ?? [];
  return req.filter((k) => !entities?.[k]);
}

export function gate(nlu: NluResult, state: ConversationState, cfg: GateConfig = DEFAULTS): GateDecision {
  // Missing slots beats confidence. If you don't have the info, you don't have the info.
  const missing = missingSlots(nlu.intent, nlu.entities ?? {});
  if (missing.length) {
    state.pendingSlots = missing;
    return { type: "clarify", missing };
  }

  // Confidence gating for intent
  const c = nlu.confidence ?? 0;

  // If model already provides alternatives, use them
  const opts = (nlu.alternatives ?? [])
    .filter((o) => o.intent !== nlu.intent)
    .slice(0, 2);

  if (c < cfg.low) {
    // low confidence: offer two likely options if available, else ask what they mean
    if (opts.length) return { type: "disambiguate", options: [{ intent: nlu.intent, confidence: c }, ...opts] };
    return { type: "disambiguate", options: guessOptions(nlu.intent, c) };
  }

  if (c < cfg.medium) {
    if (opts.length) return { type: "disambiguate", options: [{ intent: nlu.intent, confidence: c }, ...opts] };
  }

  return { type: "act" };
}

function guessOptions(primary: Intent, conf: number) {
  // pragmatic guesses: booking-ish intents often collide
  const pairs: Record<string, Intent[]> = {
    book_service: ["check_availability", "reschedule_booking"],
    check_availability: ["book_service", "service_info"],
    reschedule_booking: ["cancel_booking", "confirm_details"],
    cancel_booking: ["reschedule_booking", "confirm_details"],
    pricing_quote: ["service_info", "book_service"],
    unknown: ["help", "contact_support"],
  };

  const alts = pairs[primary] ?? ["help", "contact_support"];
  return [{ intent: primary, confidence: conf }, { intent: alts[0], confidence: 0.5 }, { intent: alts[1], confidence: 0.45 }];
}
