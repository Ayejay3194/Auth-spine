import { NextResponse } from "next/server";
import { z } from "zod";

const Req = z.object({
  text: z.string().min(1),
  intents: z.array(z.object({
    name: z.string(),
    description: z.string().optional().default(""),
    examples: z.array(z.string()).default([]),
  })),
  entities: z.array(z.object({
    name: z.string(),
    description: z.string().optional().default(""),
    examples: z.array(z.string()).default([]),
  })),
  temperature: z.number().min(0).max(1).optional().default(0.3),
});

function buildSystemPrompt(intents:any[], entities:any[]) {
  return `You are an expert NLU system.

Available intents:
${intents.map(i => `- ${i.name}: ${i.description} Examples: ${i.examples.join(", ")}`).join("\n")}

Available entities:
${entities.map(e => `- ${e.name}: ${e.description} Examples: ${e.examples.join(", ")}`).join("\n")}

Return ONLY strict JSON:
{
  "intent":"intent_name",
  "confidence":0.95,
  "entities":[{"entity":"entity_name","value":"extracted_value","start":0,"end":5}],
  "reasoning":"brief"
}`;
}

export async function POST(req: Request) {
  const traceId = crypto.randomUUID();
  try {
    const body = Req.parse(await req.json());
    const system = buildSystemPrompt(body.intents, body.entities);

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY ?? "",
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 500,
        temperature: body.temperature,
        system,
        messages: [{ role: "user", content: `Analyze: "${body.text}"` }]
      })
    });

    if (!r.ok) {
      return NextResponse.json({ traceId, error: await r.text() }, { status: 500 });
    }

    const data = await r.json();
    const text = data?.content?.[0]?.text ?? "";
    const clean = String(text).replace(/```json\s*|\s*```/g, "").trim();

    let parsed;
    try {
      parsed = JSON.parse(clean);
    } catch {
      parsed = { intent: "unknown", confidence: 0, entities: [], reasoning: "Invalid JSON from model" };
    }

    return NextResponse.json({ traceId, input: body.text, ...parsed });
  } catch (e:any) {
    return NextResponse.json({ traceId, error: e.message }, { status: 400 });
  }
}
