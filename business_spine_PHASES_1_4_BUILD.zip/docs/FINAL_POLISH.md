# Final Polish Pack

## 1) CSRF enforced automatically (cookie-session only)
Middleware now enforces CSRF for state-changing requests when:
- Authorization Bearer token is NOT used, and
- session cookie IS used

Flow:
- GET /api/csrf -> sets csrf cookie + returns token
- Send x-csrf-token header with POST/PUT/PATCH/DELETE calls

## 2) Webhook signature verification helper
- src/webhooks/verify.ts provides timing-safe verification for receivers.

## 3) Report exports can upload to S3
Worker will upload exports to S3 if:
- EXPORTS_S3_BUCKET is set

Optional:
- EXPORTS_PUBLIC_BASE_URL for CDN URL.

Otherwise it falls back to /public/exports.
