import type { AgentContext, ToolResult } from "../core/types.js";

export type PolicyConfig = {
  allow: Record<string, string[]>; // role -> allowed tool ids
  rate: { windowSeconds: number; max: number };
  confirmIntents: string[]; // intents requiring confirm gate
  confirmPhrase?: string; // default "YES"
};

export interface RateStore {
  incr(key: string, windowSeconds: number): Promise<number>;
}

export class InMemoryRateStore implements RateStore {
  private m = new Map<string, { count: number; resetAt: number }>();

  async incr(key: string, windowSeconds: number): Promise<number> {
    const now = Date.now();
    const cur = this.m.get(key);
    if (!cur || cur.resetAt <= now) {
      this.m.set(key, { count: 1, resetAt: now + windowSeconds * 1000 });
      return 1;
    }
    cur.count += 1;
    return cur.count;
  }
}

export class PolicyEngine {
  constructor(private rateStore: RateStore, private cfg: PolicyConfig) {}

  async checkRate(ctx: AgentContext): Promise<ToolResult> {
    const key = `rate:${ctx.businessId}:${ctx.userId}`;
    const n = await this.rateStore.incr(key, this.cfg.rate.windowSeconds);
    if (n > this.cfg.rate.max) {
      return { ok: false, error: { code: "RATE_LIMIT", message: "Slow down. Rate limit hit." } };
    }
    return { ok: true, data: {} };
  }

  canUseTool(ctx: AgentContext, toolId: string): boolean {
    const allow = this.cfg.allow[ctx.role] ?? [];
    return allow.includes(toolId);
  }

  needsConfirm(intentId: string): boolean {
    return this.cfg.confirmIntents.includes(intentId);
  }

  confirmPhrase(): string {
    return this.cfg.confirmPhrase ?? "YES";
  }
}
