import { spawn } from "node:child_process";
export type ExecResult = { code: number | null; stdout: string; stderr: string; };
export function execCmd(cmd: string, args: string[], opts: { cwd: string; timeoutMs?: number }): Promise<ExecResult> {
  const timeoutMs = opts.timeoutMs ?? 180_000;
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { cwd: opts.cwd, shell: process.platform === "win32", env: process.env });
    let stdout = "", stderr = "";
    child.stdout.on("data", d => stdout += d.toString());
    child.stderr.on("data", d => stderr += d.toString());
    const timer = setTimeout(() => { child.kill("SIGKILL"); resolve({ code: -1, stdout, stderr: stderr + `\n[TIMEOUT ${timeoutMs}ms]` }); }, timeoutMs);
    child.on("close", code => { clearTimeout(timer); resolve({ code, stdout, stderr }); });
  });
}
