import parquet from "parquetjs-lite";
import { dirname, join } from "node:path";
import { mkdir } from "node:fs/promises";
import type { SegmentCoeffs, BodyName } from "./types.js";

function fixed(prefix: string, order: number) {
  const out: any = {};
  for (let i = 0; i <= order; i++) out[`${prefix}${i}`] = { type: "DOUBLE" };
  return out;
}

export function makeSegmentSchema(order: number) {
  return new parquet.ParquetSchema({
    body: { type: "UTF8" },
    span: { type: "UTF8" },
    segStartJd: { type: "DOUBLE" },
    segEndJd: { type: "DOUBLE" },
    order: { type: "INT32" },
    ...fixed("px_", order),
    ...fixed("py_", order),
    ...fixed("pz_", order),
    ...fixed("vx_", order),
    ...fixed("vy_", order),
    ...fixed("vz_", order),
  });
}

export function storePath(outDir: string, body: string, span: string) {
  return join(outDir, `body=${body}`, `span=${span}`, "segments.parquet");
}

export async function writeSegmentsParquet(path: string, segments: SegmentCoeffs[], order: number) {
  await mkdir(dirname(path), { recursive: true });
  const schema = makeSegmentSchema(order);
  const writer = await parquet.ParquetWriter.openFile(schema, path);

  for (const s of segments) {
    const row: any = {
      body: s.body,
      span: s.span,
      segStartJd: s.segStartJd,
      segEndJd: s.segEndJd,
      order: s.order,
    };
    const axes: Array<[string, number[]]> = [
      ["px_", s.px], ["py_", s.py], ["pz_", s.pz],
      ["vx_", s.vx], ["vy_", s.vy], ["vz_", s.vz],
    ];
    for (const [pref, arr] of axes) {
      if (arr.length !== order + 1) throw new Error(`Coeff length mismatch for ${pref}`);
      for (let i = 0; i <= order; i++) row[`${pref}${i}`] = arr[i];
    }
    await writer.appendRow(row);
  }
  await writer.close();
}

export async function readSegmentsParquet(path: string, order: number): Promise<SegmentCoeffs[]> {
  const reader = await parquet.ParquetReader.openFile(path);
  const cursor = reader.getCursor();
  const out: SegmentCoeffs[] = [];
  let row: any;
  while ((row = await cursor.next())) {
    const body = row.body as BodyName;
    const span = row.span as string;
    const segStartJd = Number(row.segStartJd);
    const segEndJd = Number(row.segEndJd);
    const ord = Number(row.order);

    const getArr = (pref: string) => {
      const arr = new Array(order + 1);
      for (let i = 0; i <= order; i++) arr[i] = Number(row[`${pref}${i}`]);
      return arr;
    };

    out.push({
      body,
      span,
      segStartJd,
      segEndJd,
      order: ord,
      px: getArr("px_"),
      py: getArr("py_"),
      pz: getArr("pz_"),
      vx: getArr("vx_"),
      vy: getArr("vy_"),
      vz: getArr("vz_"),
    });
  }
  await reader.close();
  return out;
}
