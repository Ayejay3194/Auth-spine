# App Conversion Guide

Detailed explanation of each phase.

(…full document…)