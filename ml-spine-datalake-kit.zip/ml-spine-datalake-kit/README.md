# ml-spine-datalake-kit

A pragmatic “Parquet lake + manifests + registry + training compiler + metrics writer” kit for an ML spine.

This is **not** a full Delta Lake implementation. It gives you the useful 80%:
- immutable Parquet partitions
- manifests per write
- a tiny dataset registry for discovery/versioning
- deterministic “compile training set” step
- metrics written back to Parquet for audits

## Run demos
```bash
npm i
npm run dev:registry
npm run dev:compile
npm run dev:metrics
```

## Core idea
**Parquet is your truth. Manifests are your receipts. Registry is your index.**
