import { Span, Tracer } from "../core/types.js";

export class SimpleTracer implements Tracer {
  start(name: string, meta?: Record<string, unknown>): Span {
    return { name, start: Date.now(), meta };
  }
  end(span: Span, meta?: Record<string, unknown>): void {
    span.end = Date.now();
    span.meta = { ...(span.meta ?? {}), ...(meta ?? {}), durationMs: (span.end - span.start) };
    // eslint-disable-next-line no-console
    console.log(`[TRACE] ${span.name} ${span.meta?.durationMs}ms`);
  }
}
