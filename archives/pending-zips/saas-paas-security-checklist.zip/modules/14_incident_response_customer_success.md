INCIDENT RESPONSE + CUSTOMER SUCCESS

Customer Communication
- Affected customer identification
- Multi-channel notifications
- Status page updates
- Remediation communications + credits policy

Breach Response
- Evidence preservation + forensics
- Regulatory timelines (GDPR 72h if applicable)
- PR + legal coordination
- Post-incident improvements

Customer Success Security
- Secure onboarding/migration
- Training portal access control
- Health monitoring privacy
