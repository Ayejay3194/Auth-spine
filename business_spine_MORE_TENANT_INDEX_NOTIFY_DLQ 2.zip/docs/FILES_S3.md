POST /api/files/presign -> presigned S3 upload URL. Env: UPLOADS_S3_BUCKET, AWS_REGION, AWS creds.
