// simple local smoke check (expects dev server running)
const url = process.env.HEALTH_URL || "http://localhost:3000/api/health";
const res = await fetch(url);
const json = await res.json();
console.log(res.status, JSON.stringify(json, null, 2));
process.exit(res.ok ? 0 : 1);
