import { Matrix } from "ml-matrix";

export function chebBasis(order: number, x: number): number[] {
  const out = new Array(order + 1);
  out[0] = 1;
  if (order >= 1) out[1] = x;
  for (let k = 2; k <= order; k++) out[k] = 2 * x * out[k - 1] - out[k - 2];
  return out;
}

export function mapJdToChebX(jd: number, startJd: number, endJd: number): number {
  const mid = (startJd + endJd) / 2;
  const half = (endJd - startJd) / 2;
  return half === 0 ? 0 : (jd - mid) / half;
}

export function evalCheb(coeffs: number[], x: number): number {
  const n = coeffs.length - 1;
  if (n < 0) return 0;
  let b1 = 0, b2 = 0;
  for (let k = n; k >= 1; k--) {
    const b0 = 2 * x * b1 - b2 + coeffs[k];
    b2 = b1;
    b1 = b0;
  }
  return x * b1 - b2 + coeffs[0];
}

export function fitChebLeastSquares(
  jds: number[],
  ys: number[],
  startJd: number,
  endJd: number,
  order: number
): number[] {
  const m = jds.length;
  const n = order + 1;
  const A = Matrix.zeros(m, n);
  for (let i = 0; i < m; i++) {
    const x = mapJdToChebX(jds[i], startJd, endJd);
    const basis = chebBasis(order, x);
    for (let k = 0; k < n; k++) A.set(i, k, basis[k]);
  }
  const y = Matrix.columnVector(ys);
  const qr = A.qr();
  const c = qr.solve(y);
  return c.to1DArray();
}
