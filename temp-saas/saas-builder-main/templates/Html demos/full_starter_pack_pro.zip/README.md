# Full Stack SaaS Starter (Pro Template)

This is a generic, production-minded starter kit:
- Next.js (App Router)
- TypeScript
- Tailwind CSS + basic Radix-ready theming
- Prisma + PostgreSQL
- Auth-ready data model
- Dashboard + admin shell
- Dark/light mode
- Placeholder billing & workspace structure

## Quickstart

1. Install dependencies:

   ```bash
   pnpm install
   # or npm install / yarn
   ```

2. Copy `.env.example` to `.env` and fill in values.

3. Run Prisma migrations:

   ```bash
   npx prisma migrate dev
   ```

4. Start dev server:

   ```bash
   pnpm dev
   ```

Then start replacing placeholders with your real logic and UI.
