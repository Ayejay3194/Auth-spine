import type { ChartContract } from "./types.js";
import { sortPointsInPlace } from "./order.js";
import { walkAndNormalizeNumbers } from "./normalize.js";
import { stableStringify } from "./stableStringify.js";
import { sha256Hex } from "./hash.js";

export const CANONICALIZATION_LABEL = "json-stable-stringify + normalized decimals + sorted points";

/**
 * Produces a deterministic string for hashing.
 * This does NOT mutate the original object.
 */
export function canonicalizeForHash(chart: ChartContract): string {
  const clone: ChartContract = structuredClone(chart);
  // Ensure points ordering is stable
  sortPointsInPlace(clone);
  // Do not include integrity block itself in the hashed material
  delete (clone as any).integrity;
  // Normalize numbers into fixed strings for stable serialization
  const normalized = walkAndNormalizeNumbers(clone);
  return stableStringify(normalized);
}

export function computeIntegrity(chart: ChartContract): { hash_sha256: string; canonicalization: string } {
  const canonical = canonicalizeForHash(chart);
  return {
    canonicalization: CANONICALIZATION_LABEL,
    hash_sha256: sha256Hex(canonical)
  };
}

export function attachIntegrity(chart: ChartContract): ChartContract {
  const out: ChartContract = structuredClone(chart);
  out.integrity = computeIntegrity(out);
  return out;
}

export function toCanonicalJSON(chart: ChartContract): string {
  const withIntegrity = attachIntegrity(chart);
  // NOTE: This is a canonical JSON string for storage / diffing.
  // It uses the same pipeline as hashing to prevent mismatch.
  return canonicalizeForHash(withIntegrity);
}
