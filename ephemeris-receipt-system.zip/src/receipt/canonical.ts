import canonicalize from "canonicalize";
import { createHash } from "node:crypto";

/** Stable JSON canonicalization (key ordering etc.). */
export function canonicalJson(obj: unknown): string {
  const s = canonicalize(obj);
  if (typeof s !== "string") throw new Error("Failed to canonicalize JSON");
  return s;
}

export function sha256Hex(input: string | Buffer): string {
  return createHash("sha256").update(input).digest("hex");
}
