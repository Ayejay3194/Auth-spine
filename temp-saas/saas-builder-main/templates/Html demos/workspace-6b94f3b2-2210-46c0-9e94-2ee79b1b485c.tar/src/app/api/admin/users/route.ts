import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/permissions'

// GET /api/admin/users - Get all users
export async function GET(request: NextRequest) {
  const handler = requireAdmin(async (req: Request) => {
    try {
      const users = await db.user.findMany({
        include: {
          _count: {
            select: {
              workspaces: true
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        }
      })

      return NextResponse.json({
        success: true,
        data: users
      })
    } catch (error) {
      console.error('Failed to fetch users:', error)
      return NextResponse.json(
        { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch users' } },
        { status: 500 }
      )
    }
  })

  return handler(request, { user: { isAdmin: true } })
}