ENTERPRISE FEATURES

SSO
- SAML + OIDC
- IdP metadata + cert rotation
- SCIM provisioning
- Role/group mapping

Audit Logging
- Tamper-evident logs
- 7+ year retention options
- SIEM export + streaming

Dedicated Infrastructure
- Single-tenant deploy option
- Dedicated DB/compute/network
- Private connectivity (VPN/Private endpoints)
