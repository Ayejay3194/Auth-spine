import { describe, it, expect } from "vitest";
import { BASE_URL } from "../tools/config";

describe("security: headers & info leakage", () => {
  it("does not leak framework versions in headers (best-effort)", async () => {
    const res = await fetch(`${BASE_URL}/health`);
    // Not all platforms allow full control, but these are common leaks.
    const poweredBy = res.headers.get("x-powered-by") || "";
    expect(poweredBy.toLowerCase()).not.toContain("express");
    expect(poweredBy.toLowerCase()).not.toContain("next");
  });

  it("CORS is not wildcard with credentials (best-effort)", async () => {
    const res = await fetch(`${BASE_URL}/health`, {
      method: "GET",
      headers: { Origin: "https://evil.example" }
    });
    const acao = res.headers.get("access-control-allow-origin");
    const acc = res.headers.get("access-control-allow-credentials");
    if (acc === "true") {
      // If you allow credentials, you must not use wildcard origin.
      expect(acao).not.toBe("*");
    } else {
      expect(true).toBe(true);
    }
  });
});
