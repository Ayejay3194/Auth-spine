import { AgentContext } from "../core/types.js";

export type ToolId =
  | "auth.send_forgot_username"
  | "auth.send_password_reset"
  | "gdpr.queue_export"
  | "billing.change_plan";

export interface ToolResult<T = unknown> { ok: boolean; data?: T; error?: { code: string; message: string }; }

export interface Tool<TInput, TOutput> {
  id: ToolId;
  description: string;
  allowed: (ctx: AgentContext) => boolean;
  validate: (input: TInput) => void;
  run: (ctx: AgentContext, input: TInput) => Promise<ToolResult<TOutput>>;
  timeoutMs?: number;
}

export interface ToolRegistry { get(id: ToolId): Tool<any, any>; }
