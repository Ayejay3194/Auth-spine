# Policy Snapshotting

Versioned permission graphs.