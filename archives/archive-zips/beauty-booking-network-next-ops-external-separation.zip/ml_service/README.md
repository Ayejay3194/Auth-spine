# ML Service (scikit-learn)

Optional sidecar that trains and serves simple models (v1).
It reads features from the same database as the Next app.

## Run locally
```bash
cd ml_service
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload --port 8001
```

Env:
- DATABASE_URL (same as Next app)
- MODEL_DIR=./models

## Endpoints
- POST /train/no_show
- POST /score/no_show  { "clientUserId": "..." }
