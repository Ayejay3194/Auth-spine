# COMPLETE “THINGS THAT CAN GO WRONG WITH VIBE CODING” LIST

This is a structured, ship-ready risk register for “vibe coding” (fast prototyping without guardrails).
Use it as: preflight checks, PR review rubric, security gates, and “don’t embarrass yourself in prod” enforcement.

> Source: user-provided checklist (may be truncated at the end).

---

## SECURITY VULNERABILITIES

### Authentication & Authorization Disasters
- [ ] No authentication on critical endpoints
- [ ] Hardcoded admin credentials in code
- [ ] JWT tokens without expiration
- [ ] No token refresh mechanism
- [ ] Session tokens stored in localStorage (XSS vulnerable)
- [ ] Weak password requirements (no minimum length)
- [ ] No password hashing (storing plain text passwords)
- [ ] Using weak hashing algorithms (MD5, SHA1)
- [ ] No rate limiting on login attempts
- [ ] Missing CSRF protection
- [ ] No email verification on signup
- [ ] Authorization checks only on frontend
- [ ] User can edit their own role/permissions
- [ ] Missing authentication on API endpoints
- [ ] Anyone can access other users’ data
- [ ] No session timeout
- [ ] Forgot password without token expiration
- [ ] Password reset tokens never expire
- [ ] Using GET requests for sensitive operations
- [ ] No account lockout after failed attempts
- [ ] Predictable session IDs
- [ ] Session fixation vulnerabilities
- [ ] No logout functionality
- [ ] Logout doesn’t invalidate tokens
- [ ] Auth state only checked once on page load

### Injection Vulnerabilities
- [ ] SQL injection everywhere (string concatenation in queries)
- [ ] No parameterized queries
- [ ] Raw SQL with user input
- [ ] XSS attacks (no output encoding)
- [ ] Dangerously setting innerHTML with user content
- [ ] No input sanitization
- [ ] Command injection in system calls
- [ ] LDAP injection
- [ ] XML injection
- [ ] NoSQL injection
- [ ] GraphQL injection
- [ ] Template injection
- [ ] Server-side template injection (SSTI)
- [ ] Code injection in eval()
- [ ] Using eval() with user input
- [ ] Unsafe deserialization
- [ ] Path traversal vulnerabilities
- [ ] File inclusion vulnerabilities
- [ ] Header injection

### Data Exposure
- [ ] API returns all user data including passwords
- [ ] Exposing internal IDs that reveal system info
- [ ] Verbose error messages with stack traces in production
- [ ] Database credentials in frontend code
- [ ] API keys committed to Git
- [ ] .env files in version control
- [ ] Secrets in Docker images
- [ ] Debug mode enabled in production
- [ ] Source maps exposed in production
- [ ] Directory listing enabled
- [ ] Backup files accessible (.bak, .old)
- [ ] Git folder exposed (.git directory accessible)
- [ ] Internal API documentation publicly accessible
- [ ] GraphQL introspection enabled in production
- [ ] Database directly accessible from internet
- [ ] Admin panel at /admin with no protection
- [ ] Exposing user email addresses publicly
- [ ] PII in URLs or logs
- [ ] Sensitive data in query parameters
- [ ] Logging passwords or tokens
- [ ] Exposing server/framework version in headers
- [ ] CORS allowing all origins (*)
- [ ] No encryption for sensitive data
- [ ] Storing credit cards directly

### Access Control Issues
- [ ] Horizontal privilege escalation (access other users’ data by changing ID)
- [ ] Vertical privilege escalation (regular user accessing admin features)
- [ ] Insecure direct object references (IDOR)
- [ ] Missing authorization checks
- [ ] Only client-side authorization
- [ ] Can access resources by guessing IDs
- [ ] Sequential/predictable IDs
- [ ] No ownership verification
- [ ] Mass assignment vulnerabilities
- [ ] User can modify any field in update requests
- [ ] No role-based access control
- [ ] Everyone is admin by default
- [ ] Admin functionality accessible to all
- [ ] API endpoints with no access control
- [ ] File uploads accessible by direct URL
- [ ] Private files in public folder

### File Upload Vulnerabilities
- [ ] No file type validation
- [ ] Accepting any file extension
- [ ] No file size limits
- [ ] Files saved with original names
- [ ] Uploaded files executed by server
- [ ] PHP/executable files can be uploaded
- [ ] No virus scanning
- [ ] Files stored in web-accessible directory
- [ ] No filename sanitization
- [ ] Path traversal in file uploads
- [ ] Zip bombs
- [ ] XXE attacks via XML uploads
- [ ] Image processing vulnerabilities
- [ ] No content-type validation
- [ ] Accepting SVG with embedded JavaScript

---

## DATABASE DISASTERS

### Schema & Design Problems
- [ ] No database schema at all
- [ ] Using wrong data types (storing dates as strings)
- [ ] No primary keys
- [ ] No foreign key constraints
- [ ] Missing indexes on queried columns
- [ ] Index on every column (over-indexing)
- [ ] Denormalization without reason
- [ ] Extreme normalization causing joins on joins
- [ ] No NOT NULL constraints where needed
- [ ] No UNIQUE constraints where needed
- [ ] No default values
- [ ] Timestamps stored as strings
- [ ] Boolean values as strings (“true”/“false”)
- [ ] Money stored as floats (rounding errors)
- [ ] Using VARCHAR(255) for everything
- [ ] No constraints on important fields
- [ ] Missing CASCADE rules
- [ ] Circular foreign key dependencies
- [ ] Polymorphic associations without type safety

### Query Problems
- [ ] N+1 query problem everywhere
- [ ] SELECT * in all queries
- [ ] No pagination (loading all records)
- [ ] Missing WHERE clauses
- [ ] Using OR instead of IN for multiple values
- [ ] Subqueries instead of JOINs
- [ ] Inefficient JOINs
- [ ] No query optimization
- [ ] LIKE queries without indexes
- [ ] Leading wildcard searches (%value)
- [ ] No query result caching
- [ ] Queries in loops
- [ ] Full table scans on large tables
- [ ] No use of LIMIT
- [ ] Fetching data not used in application
- [ ] Using COUNT(*) on large tables
- [ ] No aggregate function optimization
- [ ] Sorting in application instead of database

### Data Integrity Issues
- [ ] No data validation
- [ ] Duplicate data everywhere
- [ ] Orphaned records (referential integrity violations)
- [ ] Inconsistent data formats
- [ ] Mixed timezones
- [ ] No audit trail
- [ ] Soft deletes breaking foreign keys
- [ ] No transactions for multi-step operations
- [ ] Race conditions in updates
- [ ] Lost updates problem
- [ ] Dirty reads
- [ ] No locking strategy
- [ ] Deadlocks
- [ ] Stale data being used
- [ ] No data migration strategy
- [ ] Schema changes in production without testing
- [ ] Data loss during migrations
- [ ] No rollback plan for migrations

### Connection & Performance Issues
- [ ] No connection pooling
- [ ] Opening new connection for each query
- [ ] Connection leaks
- [ ] Not closing connections
- [ ] Max connections reached constantly
- [ ] No query timeout
- [ ] Long-running queries blocking others
- [ ] Table locks during peak hours
- [ ] No read replicas for heavy read workload
- [ ] Single point of failure
- [ ] No database backup
- [ ] Backups never tested
- [ ] No point-in-time recovery
- [ ] Database on same server as application
- [ ] Insufficient database resources
- [ ] No monitoring of database performance
- [ ] Ignoring slow query logs

### Row Level Security (RLS) Issues
- [ ] RLS not enabled at all
- [ ] RLS policies too permissive
- [ ] Forgetting to add policies for new tables
- [ ] Bypassing RLS with service role in client
- [ ] Testing with service role (not catching RLS issues)
- [ ] RLS policies with performance problems
- [ ] Complex RLS causing slow queries
- [ ] RLS not covering all CRUD operations
- [ ] Missing policies for edge cases
- [ ] RLS only on some tables in multi-table queries

---

## LEGAL & COMPLIANCE DISASTERS

### Privacy Violations
- [ ] No privacy policy
- [ ] Collecting data without consent
- [ ] No GDPR compliance

# LEGAL & COMPLIANCE DISASTERS (CONTINUED)

## Privacy Violations (Continued)

- [ ] No cookie consent banner
- [ ] Tracking users without permission
- [ ] Sharing user data without consent
- [ ] No data processing agreements
- [ ] Not honoring “Do Not Track”
- [ ] No way to delete account
- [ ] No way to export user data
- [ ] Not deleting data after retention period
- [ ] Keeping data longer than needed
- [ ] No data anonymization
- [ ] PII in logs
- [ ] PII in URLs
- [ ] PII in analytics
- [ ] Sending PII to third parties
- [ ] No data breach notification plan
- [ ] Not reporting breaches within required time
- [ ] No Data Protection Officer (when required)
- [ ] Children’s data without parental consent (COPPA)
- [ ] No age verification
- [ ] Violating CCPA/CPRA requirements
- [ ] No opt-out mechanism for data sale
- [ ] Not respecting user data rights
- [ ] No record of processing activities (ROPA)

## Terms of Service Issues

- [ ] No terms of service
- [ ] Copied ToS from another site
- [ ] ToS not enforceable
- [ ] No acceptance mechanism
- [ ] Changes to ToS without notification
- [ ] Unclear liability limitations
- [ ] No dispute resolution clause
- [ ] Wrong jurisdiction specified
- [ ] Contradictory terms
- [ ] Unreasonable terms
- [ ] No intellectual property rights defined
- [ ] No user content ownership clarity
- [ ] No prohibited use policy
- [ ] No acceptable use policy
- [ ] No service termination terms

## Compliance Violations

- [ ] Not PCI DSS compliant (if handling cards)
- [ ] Storing credit card data improperly
- [ ] Not HIPAA compliant (if healthcare)
- [ ] PHI not properly encrypted
- [ ] Not SOC 2 compliant (when promised)
- [ ] No audit logs for compliance
- [ ] Not meeting contractual SLAs
- [ ] Violating industry regulations
- [ ] No compliance documentation
- [ ] No security policies
- [ ] No incident response plan (when required)
- [ ] Not meeting data residency requirements
- [ ] Using non-compliant subprocessors
- [ ] No vendor management program
- [ ] No business associate agreements (BAA)
- [ ] Accessibility violations (ADA, Section 508)

## Licensing Issues

- [ ] Using GPL code in proprietary software
- [ ] Not including required license notices
- [ ] Violating open source licenses
- [ ] Using pirated software
- [ ] No software license tracking
- [ ] Using libraries beyond license terms
- [ ] Not attributing third-party code
- [ ] Closed-source code using copy-left licenses
- [ ] No license file in repository
- [ ] Conflicting licenses in dependencies
- [ ] Using commercial fonts without license
- [ ] Using stock photos without license
- [ ] Copyright violations in content

---

# FINANCIAL & BUSINESS DISASTERS

## Payment Processing Issues

- [ ] Not using payment processor (rolling own)
- [ ] Storing credit card numbers
- [ ] Not validating payment amounts
- [ ] Race conditions in payment processing
- [ ] Duplicate charges
- [ ] Failed refunds
- [ ] No payment reconciliation
- [ ] Lost transaction records
- [ ] Currency conversion errors
- [ ] Rounding errors in billing
- [ ] Subscription charges when canceled
- [ ] Not handling failed payments
- [ ] No retry logic for payments
- [ ] No payment confirmation emails
- [ ] No receipt generation
- [ ] Tax calculation errors
- [ ] Not collecting required tax info
- [ ] Chargeback rate too high
- [ ] No fraud detection
- [ ] Accepting stolen cards

## Billing & Subscription Disasters

- [ ] No subscription management
- [ ] Cannot upgrade/downgrade plans
- [ ] Billing on wrong schedule
- [ ] Prorating calculations wrong
- [ ] Double billing users
- [ ] Not billing users (revenue loss)
- [ ] Trial period not enforced
- [ ] Grace period not working
- [ ] Dunning management missing
- [ ] No failed payment recovery
- [ ] Subscription state inconsistent
- [ ] Access not revoked when payment fails
- [ ] Cannot cancel subscription
- [ ] Cancellation not processed
- [ ] No invoice generation
- [ ] Invoice calculations wrong
- [ ] Missing billing notifications
- [ ] Discount codes not working
- [ ] Coupon abuse possible
- [ ] Referral fraud possible

## Cost Management Failures

- [ ] No cost monitoring
- [ ] Cloud costs out of control
- [ ] Storage costs exploding
- [ ] API costs unexpected
- [ ] Egress bandwidth charges surprise
- [ ] No budget alerts
- [ ] Unused resources running
- [ ] Over-provisioned resources
- [ ] Not using reserved instances
- [ ] Paying for unused licenses
- [ ] No cost allocation
- [ ] Cannot track cost per customer
- [ ] No cost optimization
- [ ] Inefficient resource usage
- [ ] Development resources too expensive

---

# EDGE CASES & RARE FAILURES

## Boundary Conditions

- [ ] Empty arrays/lists not handled
- [ ] Single item lists breaking
- [ ] Maximum length strings breaking
- [ ] Empty strings causing errors
- [ ] Null vs undefined confusion
- [ ] Zero values treated as null
- [ ] Negative numbers not considered
- [ ] Very large numbers breaking
- [ ] Very small decimals (precision loss)
- [ ] Special characters breaking
- [ ] Unicode characters breaking
- [ ] Emoji breaking system
- [ ] Right-to-left text breaking layout
- [ ] Long words breaking layout
- [ ] No content state not handled

## Date/Time Disasters

- [ ] Timezone bugs everywhere
- [ ] Hardcoded timezone assumptions
- [ ] Daylight Saving Time bugs
- [ ] Leap year not handled
- [ ] Leap second issues
- [ ] Date parsing errors
- [ ] ISO 8601 format issues
- [ ] Date format ambiguity (MM/DD vs DD/MM)
- [ ] Wrong date calculations
- [ ] Time travel bugs (comparing across zones)
- [ ] Unix timestamp overflow (Y2038 problem)
- [ ] Storing dates as strings
- [ ] Not using UTC internally
- [ ] Business day calculations wrong
- [ ] Holiday detection wrong
- [ ] Month boundaries bugs
- [ ] Year boundaries bugs
- [ ] Century bugs

## Concurrency Issues

- [ ] Race conditions
- [ ] Deadlocks
- [ ] Livelocks
- [ ] Thread starvation
- [ ] Resource contention
- [ ] Lost updates
- [ ] Dirty reads
- [ ] Non-repeatable reads
- [ ] Phantom reads
- [ ] Write-write conflicts
- [ ] Read-write conflicts
- [ ] Incorrect isolation level
- [ ] No pessimistic locking
- [ ] No optimistic locking
- [ ] Lock timeouts
- [ ] Database locks not released
- [ ] Table-level locks causing issues
- [ ] Concurrent modification exceptions
- [ ] Atomic operations not atomic
- [ ] Critical sections not protected

## Network & External Dependencies

- [ ] Assuming network is reliable
- [ ] No timeout handling
- [ ] Services calling each other in circle
- [ ] Cascading failures
- [ ] Service mesh issues
- [ ] DNS failures not handled
- [ ] SSL certificate expiration
- [ ] Certificate validation disabled
- [ ] Man-in-the-middle vulnerability
- [ ] Third-party API down breaks everything
- [ ] External service slow makes app slow
- [ ] No circuit breaker
- [ ] Retry storms
- [ ] Thundering herd on startup
- [ ] Services cannot start without dependencies
- [ ] Startup order dependencies

---

# OPERATIONAL DISASTERS

## Maintenance Problems

- [ ] No maintenance window
- [ ] Maintenance during peak hours
- [ ] No maintenance notifications
- [ ] Surprise downtime
- [ ] Extended unplanned outages
- [ ] Cannot perform maintenance without downtime
- [ ] Schema changes causing downtime
- [ ] Deployments causing downtime
- [ ] Database migrations taking too long
- [ ] Migration rollback not tested
- [ ] Breaking changes in migrations
- [ ] Data corruption during migration
- [ ] No rollback capability

## Backup Disasters

- [ ] No backups at all
- [ ] Backups never tested
- [ ] Backups corrupted
- [ ] Backups in same location as primary
- [ ] Backups not encrypted
- [ ] Backup retention too short
- [ ] No point-in-time recovery
- [ ] Restore process unknown
- [ ] Restore takes too long (RTO)
- [ ] Too much data loss on restore (RPO)
- [ ] Backup process breaking production
- [ ] Backups consuming too many resources
- [ ] No backup monitoring
- [ ] Backup failures ignored
- [ ] Cannot restore specific records
- [ ] Backups too large to download

## Disaster Recovery Failures

- [ ] No disaster recovery plan
- [ ] DR plan never tested
- [ ] DR plan outdated
- [ ] Single region deployment
- [ ] No geographic redundancy
- [ ] DNS single point of failure
- [ ] Database single point of failure
- [ ] No failover mechanism
- [ ] Failover process manual and slow
- [ ] Failover never tested
- [ ] Data loss during failover
- [ ] Cannot fail back
- [ ] No runbooks for incidents
- [ ] Incident response chaotic
- [ ] No communication plan during outage
- [ ] Team doesn’t know DR procedures

## Capacity Issues

- [ ] No capacity planning
- [ ] Running out of resources
- [ ] Cannot scale fast enough
- [ ] Hitting infrastructure limits
- [ ] Database connections exhausted
- [ ] File descriptors exhausted
- [ ] Memory exhausted
- [ ] CPU at 100%
- [ ] Disk full
- [ ] Network bandwidth maxed
- [ ] Rate limits from providers hit
- [ ] API quotas exceeded
- [ ] Database storage full
- [ ] Log storage full
- [ ] Backup storage full
- [ ] No auto-scaling
- [ ] Auto-scaling too slow
- [ ] Auto-scaling too aggressive

---

# EMAIL & NOTIFICATION DISASTERS

## Email Problems

- [ ] Emails going to spam
- [ ] No SPF record
- [ ] No DKIM signing
- [ ] No DMARC policy
- [ ] Shared IP with bad reputation
- [ ] No email authentication
- [ ] Sending rate too high
- [ ] Bounce rate too high
- [ ] Complaint rate too high
- [ ] Sending to invalid addresses
- [ ] No email validation
- [ ] No unsubscribe link
- [ ] Unsubscribe not working
- [ ] Sending to unsubscribed users
- [ ] No email preferences
- [ ] HTML emails not rendering
- [ ] Plain text version missing
- [ ] Email templates broken on mobile
- [ ] Personalization tokens showing raw
- [ ] Wrong email content sent
- [ ] Duplicate emails sent
- [ ] Emails never sent
- [ ] No delivery confirmation
- [ ] No bounce handling
- [ ] Hard bounces not removed from list

## Notification Issues

- [ ] Too many notifications
- [ ] Notification spam
- [ ] Duplicate notifications
- [ ] Notifications for wrong user
- [ ] Critical notifications not sent
- [ ] Notification delays
- [ ] Notifications arrive out of order
- [ ] Cannot disable notifications
- [ ] No notification preferences
- [ ] Notifications not marked as read
- [ ] Old notifications never cleaned
- [ ] Notification badges wrong count
- [ ] Push notifications not working
- [ ] Push notification permissions not requested
- [ ] SMS notifications too expensive
- [ ] SMS encoding issues
- [ ] SMS length issues (split messages)

---

# SEARCH & FILTERING DISASTERS

## Search Problems

- [ ] No search functionality
- [ ] Search too slow
- [ ] Search not finding results
- [ ] Search finding irrelevant results
- [ ] No fuzzy matching
- [ ] Typos breaking search
- [ ] Search case-sensitive
- [ ] No partial matching
- [ ] Search accent-sensitive
- [ ] No search suggestions
- [ ] No search highlighting
- [ ] Search pagination broken
- [ ] Search sorting wrong
- [ ] Search relevance poor
- [ ] No faceted search
- [ ] Cannot filter search results
- [ ] Search index not updated
- [ ] Stale search results
- [ ] Search index corruption

## Filtering & Sorting Issues

- [ ] No filtering options
- [ ] Filters not working
- [ ] Filters conflicting with each other
- [ ] Cannot clear filters
- [ ] Filter state not preserved
- [ ] Sorting not working
- [ ] Sort order inconsistent
- [ ] No multi-column sorting
- [ ] Default sort order confusing
- [ ] Filter/sort performance terrible
- [ ] Client-side filtering of large datasets
- [ ] Not using database for filtering
- [ ] Filter values not validated

---

# IMPORT/EXPORT DISASTERS

## Data Import Problems

- [ ] No import validation
- [ ] Accepting malformed data
- [ ] Import creating duplicates
- [ ] Import failing silently
- [ ] No import error reporting
- [ ] Cannot rollback failed import
- [ ] Import locking database
- [ ] Import taking too long
- [ ] No progress indicator for import
- [ ] Large imports timing out
- [ ] Memory issues with large imports
- [ ] Import not transactional
- [ ] Partial imports on failure
- [ ] Cannot resume failed imports
- [ ] Import encoding issues
- [ ] Special characters breaking import
- [ ] Date format issues in import
- [ ] No import templates
- [ ] No sample import files

## Data Export Problems

- [ ] No export functionality
- [ ] Export timing out
- [ ] Export failing for large datasets
- [ ] Export incomplete data
- [ ] Export wrong format
- [ ] Encoding issues in exports
- [ ] Special characters breaking export
- [ ] Date format inconsistent in exports
- [ ] No column headers in exports
- [ ] Cannot choose export columns
- [ ] Export missing related data
- [ ] Export contains sensitive data
- [ ] No export encryption
- [ ] Export files not deleted after download
- [ ] Export links accessible by others

---

# MIGRATION DISASTERS

## Data Migration Issues

- [ ] No migration plan
- [ ] Migration not tested
- [ ] Data loss during migration
- [ ] Data corruption during migration
- [ ] Incomplete migration
- [ ] Migration takes too long
- [ ] Cannot rollback migration
- [ ] Migration breaking application
- [ ] No downtime window
- [ ] Migration during business hours
- [ ] Old and new systems out of sync
- [ ] Data inconsistency after migration
- [ ] Foreign keys broken
- [ ] Relationships lost
- [ ] File references broken
- [ ] IDs changed causing issues
- [ ] No data validation post-migration

## Platform Migration Problems

- [ ] Vendor lock-in preventing migration
- [ ] Cannot export data from old system
- [ ] APIs incompatible between systems
- [ ] Feature parity issues
- [ ] Performance worse after migration
- [ ] Cost higher after migration
- [ ] Users cannot adapt to new system
- [ ] Training not provided
- [ ] No parallel running period
- [ ] Big bang migration failure
- [ ] No gradual rollout
- [ ] Cannot switch back to old system

---

# CONFIGURATION & SETTINGS DISASTERS

## Configuration Problems

- [ ] No configuration management
- [ ] Configuration in multiple places
- [ ] Inconsistent configuration
- [ ] Configuration only in code (requires deployment to change)
- [ ] No configuration validation
- [ ] Wrong configuration in environment
- [ ] Configuration drift between environments
- [ ] No configuration versioning
- [ ] Configuration changes require restart
- [ ] Cannot change config without downtime
- [ ] No configuration backup
- [ ] Lost configuration after deployment
- [ ] Feature flags not working
- [ ] Feature flags stuck on/off
- [ ] No gradual rollout capability
- [ ] A/B testing not possible

## Settings Management Issues

- [ ] User settings not saved
- [ ] Settings not persisted
- [ ] Settings reset unexpectedly
- [ ] No default settings
- [ ] Bad default settings
- [ ] Cannot reset to defaults
- [ ] Settings across devices not synced
- [ ] Settings validation missing
- [ ] Invalid settings crashing app
- [ ] Too many settings (overwhelming)
- [ ] Settings buried in UI
- [ ] No search in settings
- [ ] Settings changes require app reload

---

# MULTI-TENANCY DISASTERS

## Tenant Isolation Failures

- [ ] No tenant isolation
- [ ] Data bleeding between tenants
- [ ] One tenant seeing another’s data
- [ ] Tenant ID not checked
- [ ] Hardcoded tenant ID
- [ ] Tenant context lost
- [ ] Query forgetting tenant filter
- [ ] Admin can’t access all tenants
- [ ] Cross-tenant queries too easy
- [ ] No audit of cross-tenant access
- [ ] Shared resources causing interference
- [ ] One tenant affecting another’s performance
- [ ] Resource quotas not enforced per tenant
- [ ] Tenant deletion not complete
- [ ] Orphaned data after tenant deletion

## Multi-Tenant Specific Issues

- [ ] Cannot provision new tenants
- [ ] Tenant provisioning too slow
- [ ] Tenant onboarding broken
- [ ] Cannot customize per tenant
- [ ] Tenant branding not working
- [ ] Tenant-specific features broken
- [ ] Cannot manage tenant settings
- [ ] Tenant billing issues
- [ ] Cannot track usage per tenant
- [ ] Tenant suspension not working
- [ ] Reactivation not working
- [ ] Data export per tenant broken
- [ ] Tenant analytics broken

---

# WEBSOCKET & REALTIME DISASTERS

## WebSocket Problems

- [ ] WebSocket connections dropping
- [ ] No reconnection logic
- [ ] Reconnection storms
- [ ] Connection leak
- [ ] Too many open connections
- [ ] Message ordering issues
- [ ] Lost messages
- [ ] Duplicate messages
- [ ] Message delivery not guaranteed
- [ ] No message acknowledgment
- [ ] Heartbeat/ping-pong missing
- [ ] No connection timeout
- [ ] Zombie connections
- [ ] Broadcasting to wrong clients
- [ ] Broadcasting too frequently
- [ ] Message payload too large
- [ ] No message queuing
- [ ] Backpressure not handled
- [ ] WebSocket endpoints not secured
- [ ] Authentication on initial connection only

## Realtime Sync Issues

- [ ] Clients out of sync
- [ ] Conflict resolution missing
- [ ] Last write wins (data loss)
- [ ] Optimistic updates failing
- [ ] Rollback not working
- [ ] Version vectors wrong
- [ ] Merge conflicts
- [ ] Split brain scenarios
- [ ] Data inconsistency across clients
- [ ] Presence status wrong
- [ ] Typing indicators not clearing
- [ ] Live cursors desynchronized
- [ ] Collaborative editing conflicts

---

# ANALYTICS & TRACKING DISASTERS

## Analytics Problems

- [ ] No analytics at all
- [ ] Tracking wrong events
- [ ] Events not firing
- [ ] Duplicate event tracking
- [ ] Analytics blocking page load
- [ ] Analytics JavaScript errors
- [ ] PII in analytics data
- [ ] Analytics not anonymized
- [ ] Cookie consent not respected
- [ ] Analytics data inconsistent
- [ ] Cannot track conversions
- [ ] Funnel analysis broken
- [ ] Attribution data wrong
- [ ] UTM parameters lost
- [ ] Cross-domain tracking broken
- [ ] Bot traffic skewing data
- [ ] Sampling rate too high (missing data)
- [ ] Historical data inconsistent
- [ ] Cannot export analytics data

## Metrics & KPI Issues

- [ ] No metrics defined
- [ ] Wrong metrics tracked
- [ ] Metrics not actionable
- [ ] Vanity metrics only
- [ ] No baseline for metrics
- [ ] Cannot trend metrics over time
- [ ] Metrics calculation wrong
- [ ] Metrics delayed
- [ ] Real-time metrics not real-time
- [ ] Dashboard showing wrong data
- [ ] Metrics not aligned with goals
- [ ] No alerts on metric thresholds

---

# LOCALIZATION & INTERNATIONALIZATION DISASTERS

## Translation Issues

- [ ] Hardcoded English strings
- [ ] Machine translation only
- [ ] Poor translation quality
- [ ] Incomplete translations
- [ ] Missing translations showing keys
- [ ] Placeholder text in production
- [ ] Context lost in translation
- [ ] Gendered language issues
- [ ] Formal vs informal inconsistency
- [ ] Cultural insensitivity
- [ ] Offensive translations
- [ ] Brand name translated
- [ ] Technical terms translated incorrectly
- [ ] String concatenation breaking translations

## Regional Adaptation Failures

- [ ] Wrong date format for region
- [ ] Wrong time format (12h vs 24h)
- [ ] Wrong number format
- [ ] Decimal separator issues (. vs ,)
- [ ] Thousand separator issues
- [ ] Currency symbol wrong
- [ ] Currency placement wrong
- [ ] Address format not matching region
- [ ] Phone number format not matching region
- [ ] Zip/postal code validation wrong
- [ ] Name format assumptions (first/last)
- [ ] No support for single names
- [ ] No support for multiple last names
- [ ] Sort order wrong for language
- [ ] Alphabetical order wrong

---

# MOBILE-SPECIFIC DISASTERS

## Mobile App Issues

- [ ] App crashes frequently
- [ ] Memory leaks on mobile
- [ ] Battery drain excessive
- [ ] Data usage excessive
- [ ] Offline mode not working
- [ ] Poor network handling
- [ ] Not caching data
- [ ] Images not optimized for mobile
- [ ] Videos auto-playing on cellular
- [ ] Background sync draining battery
- [ ] Location tracking always on
- [ ] Push notifications too frequent
- [ ] Deep links not working
- [ ] Universal links broken
- [ ] App store description outdated
- [ ] Screenshots outdated
- [ ] No app rating prompts
- [ ] Negative reviews not addressed

## Platform-Specific Problems

- [ ] iOS and Android inconsistent
- [ ] Platform-specific bugs
- [ ] Not using native UI patterns
- [ ] Android back button broken
- [ ] iOS swipe gestures broken
- [ ] Safe area not respected
- [ ] Notch issues on iPhone
- [ ] Keyboard covering inputs
- [ ] Status bar issues
- [ ] Navigation bar issues
- [ ] Split screen not supported
- [ ] iPad layout broken
- [ ] Tablet UI not optimized
- [ ] Rotation issues
- [ ] Dark mode not implemented
- [ ] Dark mode broken

---

# QUEUE & BACKGROUND JOB DISASTERS

## Job Queue Problems

- [ ] No job queue system
- [ ] Jobs executing synchronously
- [ ] Jobs blocking main thread
- [ ] Jobs never completing
- [ ] Jobs timing out
- [ ] Jobs failing silently
- [ ] No job retry logic
- [ ] Infinite retry loops
- [ ] Jobs processed out of order
- [ ] Job priority not working
- [ ] Dead letter queue missing
- [ ] Cannot inspect failed jobs
- [ ] Cannot requeue jobs
- [ ] Job status not tracked
- [ ] Jobs piling up
- [ ] Queue backlog growing
- [ ] Workers overwhelmed
- [ ] Not enough workers
- [ ] Too many workers (resource waste)

## Background Processing Issues

- [ ] Long-running jobs blocking queue
- [ ] Memory leaks in background jobs
- [ ] Jobs not idempotent
- [ ] Duplicate job execution
- [ ] Jobs interfering with each other
- [ ] Shared state in jobs
- [ ] Jobs modifying same data
- [ ] Race conditions in jobs
- [ ] Jobs with side effects on retry
- [ ] External API calls in jobs without timeout
- [ ] Jobs failing on transient errors
- [ ] No circuit breaker for jobs
- [ ] Jobs scheduling more jobs (job explosion)

---

# CRON & SCHEDULED TASK DISASTERS

## Scheduling Problems

- [ ] Cron jobs not running
- [ ] Cron running on multiple servers
- [ ] Duplicate cron execution
- [ ] No distributed locking
- [ ] Cron overlapping with previous run
- [ ] Long-running cron blocking next execution
- [ ] Cron timezone issues
- [ ] DST causing double/missed execution
- [ ] Cron schedule incorrect
- [ ] No cron monitoring
- [ ] Cron failures not alerted
- [ ] Cannot manually trigger cron
- [ ] Cron logs not accessible
- [ ] No cron execution history
- [ ] Cron consuming too many resources
