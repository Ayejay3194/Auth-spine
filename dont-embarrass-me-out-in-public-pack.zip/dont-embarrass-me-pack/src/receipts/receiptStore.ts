import type { Receipt } from "./receipt";

export interface ReceiptStore {
  append(r: Receipt): Promise<void>;
  latest(tenantId: string): Promise<Receipt | null>;
  get(id: string): Promise<Receipt | null>;
  list(tenantId: string, limit: number): Promise<Receipt[]>;
}

export class MemoryReceiptStore implements ReceiptStore {
  private byId = new Map<string, Receipt>();
  private byTenant = new Map<string, Receipt[]>();

  async append(r: Receipt) {
    this.byId.set(r.id, r);
    const arr = this.byTenant.get(r.tenantId) || [];
    arr.push(r);
    this.byTenant.set(r.tenantId, arr);
  }

  async latest(tenantId: string) {
    const arr = this.byTenant.get(tenantId) || [];
    return arr.length ? arr[arr.length - 1] : null;
  }

  async get(id: string) {
    return this.byId.get(id) || null;
  }

  async list(tenantId: string, limit: number) {
    const arr = this.byTenant.get(tenantId) || [];
    return arr.slice(Math.max(0, arr.length - limit));
  }
}
