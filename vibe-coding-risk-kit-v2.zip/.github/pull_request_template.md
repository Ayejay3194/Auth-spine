## What changed
- 

## Risk / Blast radius
- 

## Checklist (don’t lie)
- [ ] AuthZ enforced server-side (no frontend-only gates)
- [ ] No secrets added (scanned)
- [ ] Tests added/updated
- [ ] Logging avoids PII/tokens
- [ ] Migration plan documented (if schema changes)
- [ ] Rollback plan exists

## Screenshots (if UI)
- 
