
# SaaS/PaaS Launch Gate (Prioritized)

## Blockers (must-have)
- Tenant context validation on every request
- Object-level authorization checks
- Hard tenant isolation (DB schema/db + app guards)
- Rate limiting per tenant/user
- Secrets management + rotation
- Webhook signature verification
- Logging (auth, permission denials, tenant boundary violations)
- Backup + restore drills
- Production debug off + no test endpoints
- Support access: JIT + audited

## Strongly recommended before first enterprise customer
- SSO (SAML/OIDC) + SCIM
- BYOK / per-tenant key isolation
- Data residency options
- Tamper-proof audit logs
- Dedicated infra option (single tenant)
