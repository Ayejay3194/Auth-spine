# Vendor Security Checklist

- [ ] Data processing agreement (DPA)
- [ ] Breach notification SLA
- [ ] SOC2/ISO evidence (if available)
- [ ] Least scope OAuth permissions
- [ ] Webhook signatures
- [ ] Key rotation process
- [ ] Offboarding/export + deletion path
