import type { AgentContext, AssistantState, Reply, AuditLogger, Clock } from "../core/types.js";
import { IntentDetector } from "../nlu/intents.js";
import { extractEntities } from "../nlu/entities.js";
import { ToolRegistry, runTool } from "../tools/registry.js";
import { PolicyEngine } from "../policy/policy.js";
import type { Flow } from "../flows/flowTypes.js";
import { SimpleTracer } from "../obs/tracer.js";

export function createAssistant(opts: {
  tools: ToolRegistry;
  policy: PolicyEngine;
  audit: AuditLogger;
  clock: Clock;
  detector: IntentDetector;
  flows: Flow[];
  tracer?: SimpleTracer;
}) {
  const tracer = opts.tracer ?? new SimpleTracer();
  const flowIndex = new Map(opts.flows.map(f => [f.id, f]));

  async function handle(ctx: AgentContext, state: AssistantState, text: string): Promise<{ state: AssistantState; reply: Reply }> {
    const span = tracer.start("assistant.handle", { textLen: text.length });

    const rate = await opts.policy.checkRate(ctx);
    if (!rate.ok) return { state, reply: { text: rate.error.message, done: true } };

    // continue flow
    if (state.activeFlow) {
      const flow = flowIndex.get(state.activeFlow.id) ?? flowIndex.get("confirm");
      const out = await flow.handle({ ctx, text, state, tools: opts.tools });
      tracer.end(span, { path: "flow", flowId: state.activeFlow.id });
      return out;
    }

    const det = opts.detector.detect(text);
    const entities = extractEntities(text);

    const toolId = INTENT_TO_TOOL[det.intent] ?? null;
    if (!toolId) return { state, reply: { text: "Didn’t catch that. Try: 'search providers', 'hold booking', 'create invoice'.", done: true } };

    if (!opts.policy.canUseTool(ctx, toolId)) return { state, reply: { text: "Permission denied.", done: true } };

    const tool = opts.tools.get(toolId);
    if (!tool) return { state, reply: { text: "Tool missing.", done: true } };

    const input = buildInput(toolId, ctx, text, entities);
    const missing = requiredMissing(toolId, input);

    if (missing.length) {
      return {
        state: { ...state, activeFlow: { id: "slotFill", step: "collect", slots: { toolId, input, missing }, requiresConfirm: opts.policy.needsConfirm(det.intent) } },
        reply: { text: `Need: ${missing.join(", ")}`, ui: { type: "form", title: "Missing info", fields: missing.map(k => ({ key: k, label: k, type: k.includes("amount") ? "number" : "text" })) }, done: false }
      };
    }

    if (opts.policy.needsConfirm(det.intent)) {
      return {
        state: { ...state, activeFlow: { id: "confirm", step: "confirm", slots: {}, requiresConfirm: true, confirmPhrase: opts.policy.confirmPhrase(), pendingAction: { toolId, input } } },
        reply: { text: `Type **${opts.policy.confirmPhrase()}** to confirm.`, done: false }
      };
    }

    const res = await runTool({ tool, ctx, input, audit: opts.audit });
    tracer.end(span, { intent: det.intent, toolId });

    return res.ok ? { state, reply: formatReply(toolId, res.data) } : { state, reply: { text: `Failed: ${res.error.message}`, done: true } };
  }

  return { handle, tracer };
}

const INTENT_TO_TOOL: Record<string, string> = {
  // core
  "payments.create_invoice": "payments.create_invoice",
  "payments.refund": "payments.refund",
  "marketing.create_promo": "marketing.create_promo",
  "analytics.kpi": "analytics.kpi",
  "ops.list_tasks": "ops.list_tasks",
  "admin.show_audit": "admin.show_audit",
  "gdpr.export_request": "gdpr.export_request",
  // marketplace
  "market.search_providers": "market.search_providers",
  "market.search_slots": "market.search_slots",
  "market.booking.hold": "market.booking.hold",
  "market.booking.confirm": "market.booking.confirm",
  "market.booking.cancel": "market.booking.cancel",
  "market.payments.create_intent": "market.payments.create_intent",
  "market.payout.schedule": "market.payout.schedule",
  "market.refund.issue": "market.refund.issue",
  "market.message.send": "market.message.send",
  "market.review.submit": "market.review.submit",
  "market.dispute.open": "market.dispute.open",
  "market.dispute.resolve": "market.dispute.resolve",
};

function buildInput(toolId: string, ctx: AgentContext, text: string, e: any) {
  switch (toolId) {
    case "payments.create_invoice": return { clientId: e.clientId, amount: e.money };
    case "payments.refund": return { invoiceId: e.invoiceId };
    case "marketing.create_promo": return { code: e.promoCode, percentOff: e.percent };
    case "analytics.kpi": return {};
    case "ops.list_tasks": return {};
    case "admin.show_audit": return { limit: 50 };
    case "gdpr.export_request": return { userId: ctx.userId };

    case "market.search_providers": return { service: e.service ?? text, location: e.location ?? "near me" };
    case "market.search_slots": return { providerId: e.providerId, dateISO: e.dateISO, durationMin: 60 };
    case "market.booking.hold": return { providerId: e.providerId, clientId: e.clientId, service: e.service, dateISO: e.dateISO, timeHint: e.timeHint };
    case "market.booking.confirm": return { holdId: e.holdId, paymentIntentId: "pi_mock" };
    case "market.booking.cancel": return { bookingId: e.bookingId, reason: "client_request" };

    case "market.payments.create_intent": return { holdId: e.holdId, amount: e.money };
    case "market.payout.schedule": return { providerId: e.providerId, amount: e.money, releaseAtISO: new Date(Date.now()+7*86400000).toISOString() };
    case "market.refund.issue": return { bookingId: e.bookingId, amount: e.money, reason: "policy" };

    case "market.message.send": return { bookingId: e.bookingId, text };
    case "market.review.submit": return { bookingId: e.bookingId, rating: 5, text };
    case "market.dispute.open": return { bookingId: e.bookingId, reason: text };
    case "market.dispute.resolve": return { disputeId: e.disputeId, outcome: "refund", refundAmount: e.money ?? 0 };

    default: return {};
  }
}

function requiredMissing(toolId: string, input: any): string[] {
  const req: Record<string, string[]> = {
    "payments.create_invoice": ["clientId", "amount"],
    "payments.refund": ["invoiceId"],
    "marketing.create_promo": ["code", "percentOff"],
    "market.search_slots": ["providerId"],
    "market.booking.hold": ["providerId", "clientId"],
    "market.booking.confirm": ["holdId"],
    "market.booking.cancel": ["bookingId"],
    "market.payments.create_intent": ["holdId", "amount"],
    "market.payout.schedule": ["providerId", "amount"],
    "market.refund.issue": ["bookingId", "amount"],
    "market.message.send": ["bookingId"],
    "market.review.submit": ["bookingId"],
    "market.dispute.open": ["bookingId"],
    "market.dispute.resolve": ["disputeId"],
  };
  const keys = req[toolId] ?? [];
  return keys.filter(k => input[k] === undefined || input[k] === null || input[k] === "");
}

function formatReply(toolId: string, data: any): Reply {
  if (toolId === "analytics.kpi") return { text: "KPIs:", ui: { type: "table", title: "KPIs", columns: ["key","value","unit"], rows: data }, done: true };
  if (toolId === "ops.list_tasks") return { text: "Tasks:", ui: { type: "table", title: "Tasks", columns: ["taskId","title","status"], rows: data }, done: true };
  if (toolId.startsWith("market.search")) return { text: "Results:", ui: { type: "table", title: toolId, columns: Object.keys((data?.[0] ?? {})), rows: data }, done: true };
  return { text: "Done.", done: true };
}
