// ai_insights flows.ts
