import { TenantContext } from "../tenant/types";

/**
 * Enforce data residency by routing to region-specific resources.
 * Implement as:
 * - per-region DB clusters
 * - per-region object storage
 * - per-region queues
 */
export function assertRegionAllowed(ctx: TenantContext, resourceRegion: string) {
  if (ctx.region && ctx.region !== resourceRegion) {
    throw new Error("DATA_RESIDENCY_VIOLATION");
  }
}
