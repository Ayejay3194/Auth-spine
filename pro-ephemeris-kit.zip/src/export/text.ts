import type { ChartDataV1 } from "../contract/schema.js";
import { TEXT_EXPORT_VERSION } from "../contract/version.js";

function fmtDeg(x: number) {
  // degree minute apostrophe like 9°51’
  const deg = Math.floor(x);
  const min = Math.round((x - deg) * 60);
  const mm = String(min).padStart(2, "0");
  return `${deg}°${mm}’`;
}

export function exportAMT1(chart: ChartDataV1): string {
  const lines: string[] = [];
  lines.push(`# ${TEXT_EXPORT_VERSION}`);
  lines.push(`Date of Birth: ${chart.input.dobUtc} (UTC)`);
  lines.push(`House system: ${chart.houseSystem}`);
  lines.push(`Latitude, Longitude: ${chart.input.geo.lat.toFixed(4)}, ${chart.input.geo.lon.toFixed(4)} (${chart.input.geo.tz})`);
  lines.push("");

  // bodies
  for (const b of [...chart.bodies].sort((a,b)=>a.id.localeCompare(b.id))) {
    lines.push(`${b.id},${b.sign},${fmtDeg(b.degInSign)}${b.retrograde ? ",R" : ""}`);
  }
  lines.push("");

  const asc = chart.angles.find(a => a.id === "ASC");
  const mc  = chart.angles.find(a => a.id === "MC");
  if (asc) lines.push(`ASC,${asc.sign},${fmtDeg(asc.degInSign)}`);
  if (mc)  lines.push(`MC,${mc.sign},${fmtDeg(mc.degInSign)}`);
  for (const h of [...chart.houses].sort((a,b)=>a.house-b.house)) {
    lines.push(`H${h.house},${h.sign},${fmtDeg(h.degInSign)}`);
  }

  lines.push("");
  lines.push(`Integrity (sha256): ${chart.integrity.sha256}`);
  return lines.join("\n") + "\n";
}
