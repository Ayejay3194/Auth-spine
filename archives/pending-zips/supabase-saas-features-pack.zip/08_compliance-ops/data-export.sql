-- Export jobs (async)
create table if not exists export_jobs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  requested_by uuid not null references auth.users(id),
  status text not null default 'PENDING',
  format text not null default 'JSON',
  output_path text,
  created_at timestamptz default now(),
  completed_at timestamptz
);

-- Edge Function/worker picks up jobs and writes to Storage (signed URL for download).
