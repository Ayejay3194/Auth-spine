import fs from "node:fs/promises";
import path from "node:path";
import initWasm, {
  readParquet,
  writeParquet,
  WriterPropertiesBuilder,
  Compression,
} from "parquet-wasm";
import { tableFromIPC, tableToIPC, Table as ArrowTable } from "apache-arrow";

/**
 * parquet-wasm requires a one-time init per process.
 */
let WASM_READY = false;
export async function initParquetArrow(): Promise<void> {
  if (!WASM_READY) {
    await initWasm();
    WASM_READY = true;
  }
}

export type ParquetWriteOptions = {
  compression?: "snappy" | "zstd" | "gzip" | "uncompressed";
  metadata?: Record<string, string>;
};

function toCompression(c?: ParquetWriteOptions["compression"]) {
  switch (c) {
    case "zstd":
      return Compression.ZSTD;
    case "gzip":
      return Compression.GZIP;
    case "uncompressed":
      return Compression.UNCOMPRESSED;
    case "snappy":
    default:
      return Compression.SNAPPY;
  }
}

/**
 * Write an Arrow Table to a .parquet file.
 */
export async function writeArrowTableToParquet(
  filePath: string,
  table: ArrowTable,
  opts: ParquetWriteOptions = {}
): Promise<void> {
  await initParquetArrow();

  // parquet-wasm bridges via Arrow IPC bytes
  const ipc = tableToIPC(table, "stream"); // Uint8Array
  const props = new WriterPropertiesBuilder()
    .setCompression(toCompression(opts.compression))
    .build();

  const parquetBytes = writeParquet(ipc, props);

  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, parquetBytes);

  // Keep metadata explicit + easy to inspect
  if (opts.metadata && Object.keys(opts.metadata).length) {
    await fs.writeFile(filePath + ".meta.json", JSON.stringify(opts.metadata, null, 2));
  }
}

/**
 * Read a .parquet file into an Arrow Table (JS memory).
 */
export async function readParquetToArrowTable(filePath: string): Promise<ArrowTable> {
  await initParquetArrow();
  const parquetBytes = await fs.readFile(filePath);
  const wasmTable = readParquet(parquetBytes);

  // Convert WASM table → Arrow IPC → Arrow JS Table
  const ipc = wasmTable.intoIPCStream();
  return tableFromIPC(ipc);
}
