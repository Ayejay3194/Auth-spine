/**
 * Naive feature coherence checker (no deps).
 * Rules:
 * 1) Every feature must either listen to an event, emit an event, or share primitives with >=1 other feature.
 * 2) Feature IDs must be unique.
 * 3) No two features can claim ownership of the same redux_global key.
 */

import path from "node:path";
import { loadAllContracts } from "./registry-loader";

type Issue = { level: "error" | "warn"; feature?: string; message: string };

export function runCheck(contractsRoot: string): Issue[] {
  const contracts = loadAllContracts(contractsRoot);

  const issues: Issue[] = [];
  const ids = new Set<string>();
  const reduxOwners = new Map<string, string>(); // key -> featureId

  for (const c of contracts) {
    if (ids.has(c.id)) issues.push({ level: "error", feature: c.id, message: "Duplicate feature id." });
    ids.add(c.id);

    for (const st of c.state_touches) {
      if (st.layer === "redux_global" && st.keys) {
        for (const key of st.keys) {
          const existing = reduxOwners.get(key);
          if (existing && existing !== c.id) {
            issues.push({
              level: "error",
              feature: c.id,
              message: `Redux key ownership conflict: "${key}" already owned by "${existing}".`,
            });
          } else {
            reduxOwners.set(key, c.id);
          }
        }
      }
    }
  }

  // connectivity check
  const allEmits = new Map<string, string[]>(); // event -> [featureIds]
  const allListens = new Map<string, string[]>();

  for (const c of contracts) {
    for (const e of c.events.emits) {
      const arr = allEmits.get(e.name) ?? [];
      arr.push(c.id);
      allEmits.set(e.name, arr);
    }
    for (const l of c.events.listens) {
      const arr = allListens.get(l.event_name) ?? [];
      arr.push(c.id);
      allListens.set(l.event_name, arr);
    }
  }

  for (const c of contracts) {
    const emitsAny = c.events.emits.length > 0;
    const listensAny = c.events.listens.length > 0;

    // "connected" if it participates in any shared event pair or shares primitives with another feature
    let connected = false;

    // event pair: emits event that someone listens to OR listens to event that someone emits
    for (const e of c.events.emits) {
      if ((allListens.get(e.name) ?? []).some(fid => fid !== c.id)) connected = true;
    }
    for (const l of c.events.listens) {
      if ((allEmits.get(l.event_name) ?? []).some(fid => fid !== c.id)) connected = true;
    }

    // primitive sharing
    if (!connected && c.primitives_used && c.primitives_used.length) {
      const other = contracts.filter(o => o.id !== c.id);
      for (const o of other) {
        const shared =
          (o.primitives_used ?? []).some(p => c.primitives_used!.includes(p));
        if (shared) { connected = true; break; }
      }
    }

    if (!connected) {
      issues.push({
        level: "warn",
        feature: c.id,
        message: "Feature appears isolated: no shared events or primitives with other features.",
      });
    }

    if (!emitsAny && !listensAny) {
      issues.push({
        level: "warn",
        feature: c.id,
        message: "Feature neither emits nor listens to events. Consider adding events for integration.",
      });
    }
  }

  return issues;
}

// If run directly (node ts compiled), default to checking ../features
if (process.argv[1] && process.argv[1].includes("coherence-check")) {
  const root = process.argv[2] ?? path.resolve(process.cwd(), "../features");
  const issues = runCheck(root);
  const hasError = issues.some(i => i.level === "error");
  for (const i of issues) {
    const tag = i.level.toUpperCase();
    console.log(`[${tag}] ${i.feature ? i.feature + ": " : ""}${i.message}`);
  }
  process.exit(hasError ? 1 : 0);
}
