FINANCIAL + LEGAL

Financial Security
- Revenue recognition controls
- Billing access control + audit trails
- Reconciliation + fraud detection
- ACH/wire controls (if used)

Legal/Regulatory
- ToS versioning + acceptance tracking
- DPA management + subprocessors
- Privacy policy + cookie consent
- Legal holds + eDiscovery procedures
- Legal request logging + transparency practices
