# Vibe Coding Manual – Extended Edition

This manual teaches a multi-model, TypeScript-first workflow:

- Ideate in GPT (product, flows, **formulas**, and **pre-code zips**).
- Bundle the "thinking session" into a structured zip-like plan.
- Feed that into GLM / chat.z.ai to index, classify, and refine structure.
- Use Claude/code models inside Windsurf or Cursor to implement and refactor.
- Build with React, Next.js, Tailwind, DaisyUI/MUI/shadcn/ui, lucide-react, and React Context.
- Use **TypeScript everywhere** to prevent whole categories of errors.

Start with `manual/00-overview.md` then follow the steps.
