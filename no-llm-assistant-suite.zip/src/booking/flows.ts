import { FlowDefinition } from "../flows/types.js";
import { Entity } from "../nlu/entities.js";

function getDT(entities: Entity[]) {
  return entities.find((e) => e.type === "datetime")?.meta as any | undefined;
}

export function bookingFlows(): FlowDefinition[] {
  return [
    {
      intent: "booking.create",
      slots: [
        { name: "service", required: true, fromEntity: (e) => e.find(x => x.type === "service")?.value ?? null },
        { name: "duration", required: true, fromEntity: (e) => String((e.find(x => x.type === "duration")?.meta as any)?.minutes ?? "") || null },
        { name: "contactMethod", required: true, fromEntity: (e) => e.find(x => x.type === "contactMethod")?.value ?? null },
        { name: "dateISO", required: false, fromEntity: (e) => (getDT(e)?.dateISO ?? null) },
        { name: "partOfDay", required: false, fromEntity: (e) => (getDT(e)?.partOfDay ?? null) },
        { name: "slotChoice", required: true },
        { name: "confirm", required: true },
      ],
      steps: (s) => [
        { ask: { slot: "service", prompt: "What are we booking? (tarot | astrology | consult)", hint: "tarot" } },
        { ask: { slot: "duration", prompt: "How long? (15/30/45/60/90 minutes)", hint: "60" } },
        { ask: { slot: "contactMethod", prompt: "How do you want it? (video | phone | chat)", hint: "video" } },
        { call: { toolId: "availability.findSlots", inputFromSlots: (x) => ({ service: x.service, dateISO: x.dateISO, partOfDay: x.partOfDay, durationMin: Number(x.duration), contactMethod: x.contactMethod }) } },
        { ask: { slot: "slotChoice", prompt: "Pick a slot number from the list I showed.", hint: "1" } },
        { ask: { slot: "confirm", prompt: "Type YES to confirm booking.", hint: "YES" } },
        { call: { toolId: "booking.create", commitIntent: "booking.create", confirmSlot: "confirm", inputFromSlots: (x) => ({ slotChoice: x.slotChoice, service: x.service, contactMethod: x.contactMethod, notes: x.notes ?? "" }) } },
        { done: { message: "Booked. You’re all set." } },
      ],
    },
    {
      intent: "booking.reschedule",
      slots: [
        { name: "bookingId", required: true, fromEntity: (e) => e.find(x => x.type === "bookingId")?.value ?? null },
        { name: "duration", required: true, fromEntity: (e) => String((e.find(x => x.type === "duration")?.meta as any)?.minutes ?? "") || null },
        { name: "dateISO", required: false, fromEntity: (e) => (getDT(e)?.dateISO ?? null) },
        { name: "partOfDay", required: false, fromEntity: (e) => (getDT(e)?.partOfDay ?? null) },
        { name: "slotChoice", required: true },
        { name: "confirm", required: true },
      ],
      steps: (s) => [
        { ask: { slot: "bookingId", prompt: "What booking are we rescheduling? (example: bk_ab12cd)", hint: "bk_..." } },
        { ask: { slot: "duration", prompt: "Same duration as before? (minutes)", hint: "60" } },
        { call: { toolId: "availability.findSlots", inputFromSlots: (x) => ({ service: "existing", dateISO: x.dateISO, partOfDay: x.partOfDay, durationMin: Number(x.duration) }) } },
        { ask: { slot: "slotChoice", prompt: "Pick a new slot number.", hint: "2" } },
        { ask: { slot: "confirm", prompt: "Type YES to confirm reschedule.", hint: "YES" } },
        { call: { toolId: "booking.reschedule", commitIntent: "booking.reschedule", confirmSlot: "confirm", inputFromSlots: (x) => ({ bookingId: x.bookingId, slotChoice: x.slotChoice }) } },
        { done: { message: "Rescheduled." } },
      ],
    },
    {
      intent: "booking.cancel",
      slots: [
        { name: "bookingId", required: true, fromEntity: (e) => e.find(x => x.type === "bookingId")?.value ?? null },
        { name: "reason", required: false },
        { name: "confirm", required: true },
      ],
      steps: (s) => [
        { ask: { slot: "bookingId", prompt: "What booking are we canceling? (example: bk_ab12cd)", hint: "bk_..." } },
        { ask: { slot: "reason", prompt: "Reason? (optional)", hint: "schedule conflict" } },
        { ask: { slot: "confirm", prompt: "Type YES to confirm cancellation.", hint: "YES" } },
        { call: { toolId: "booking.cancel", commitIntent: "booking.cancel", confirmSlot: "confirm", inputFromSlots: (x) => ({ bookingId: x.bookingId, reason: x.reason ?? "" }) } },
        { done: { message: "Canceled." } },
      ],
    },
    {
      intent: "booking.list",
      slots: [],
      steps: () => [
        { call: { toolId: "booking.list", inputFromSlots: () => ({}) } },
        { done: { message: "Those are your upcoming bookings." } },
      ],
    },
  ];
}
