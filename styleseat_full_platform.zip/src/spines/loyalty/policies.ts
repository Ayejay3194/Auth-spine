// loyalty policies.ts
