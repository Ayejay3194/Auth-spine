# Vendor Intake Questionnaire (Quick)

- What data do they receive?
- Do they sign a DPA?
- Where is data stored (regions)?
- Encryption at rest/in transit?
- Access controls and audit logs?
- Subprocessors?
- Breach notification timeline?
- SOC2/ISO reports available?
- Data deletion process and timeline?
