ANOMALY DETECTION
================

Detect:
- spikes in refunds
- payout velocity changes
- booking conflicts
- dispute clustering
- silent churn

Actions:
- alert ops
- flag dashboards
- require review
