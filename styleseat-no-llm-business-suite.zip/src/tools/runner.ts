import { AgentContext, AuditLogger, Clock, Tracer } from "../core/types.js";
import { PolicyEngine } from "../policy/types.js";
import { Tool, ToolResult } from "./types.js";

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  let to: any;
  const t = new Promise<T>((_, rej) => { to = setTimeout(() => rej(new Error("TIMEOUT")), ms); });
  return Promise.race([p.finally(() => clearTimeout(to)), t]);
}

export async function runTool<TI, TO>(opts: {
  ctx: AgentContext;
  tool: Tool<TI, TO>;
  input: TI;
  audit: AuditLogger;
  clock: Clock;
  tracer: Tracer;
  policy: PolicyEngine;
}): Promise<ToolResult<TO>> {
  const { ctx, tool, input, audit, clock, tracer, policy } = opts;

  const pol = await policy.checkTool(ctx, tool.id);
  if (!pol.ok) {
    await audit.write({ at: clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "policy.blocked", details: { toolId: tool.id, code: pol.code } });
    return { ok: false, error: { code: pol.code ?? "POLICY", message: pol.message ?? "Blocked" } };
  }

  await audit.write({ at: clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "tool.called", details: { toolId: tool.id, input } });

  const max = (tool.retries ?? 0) + 1;
  for (let attempt = 1; attempt <= max; attempt++) {
    const span = tracer.start("tool.run", { toolId: tool.id, attempt });
    try {
      tool.validate(input);
      const res = await (tool.timeoutMs ? withTimeout(tool.run(ctx, input), tool.timeoutMs) : tool.run(ctx, input));
      tracer.end(span, { ok: res.ok });
      await audit.write({ at: clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: res.ok ? "tool.result" : "tool.error", details: { toolId: tool.id, ok: res.ok, error: res.error } });
      return res;
    } catch (e: any) {
      tracer.end(span, { ok: false });
      const err = { code: e?.message === "TIMEOUT" ? "TIMEOUT" : "ERROR", message: String(e?.message ?? e) };
      await audit.write({ at: clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "tool.error", details: { toolId: tool.id, attempt, error: err } });
      if (attempt == max) return { ok: false, error: err };
    }
  }
  return { ok: false, error: { code: "ERROR", message: "Unknown error" } };
}
