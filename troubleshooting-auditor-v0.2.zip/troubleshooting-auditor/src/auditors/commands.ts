import type { AuditSection } from "../types.js";
import { execCmd } from "../utils/exec.js";

export type RunCommand = "typecheck" | "build" | "lint";

const MAP: Record<RunCommand, { cmd: string; args: string[]; title: string }> = {
  typecheck: { cmd: "npx", args: ["tsc", "--noEmit"], title: "TypeScript typecheck (tsc --noEmit)" },
  build: { cmd: "npm", args: ["run", "build"], title: "Build (npm run build)" },
  lint: { cmd: "npm", args: ["run", "lint"], title: "Lint (npm run lint)" },
};

export async function auditCommands(root: string, run: RunCommand[]): Promise<AuditSection> {
  const section: AuditSection = { id: "commands", title: "Command Execution (Optional)", findings: [] };
  if (run.length === 0) return section;

  for (const r of run) {
    const spec = MAP[r];
    const res = await execCmd(spec.cmd, spec.args, { cwd: root, timeoutMs: 240_000 });

    if (res.code !== 0) {
      section.findings.push({
        id: `cmd.${r}.fail`,
        title: `${spec.title} failed`,
        severity: "ERROR",
        details: "Command failed. The captured output usually tells you exactly what broke.",
        fix: "Fix the first error in output. If this only fails in CI/prod, compare Node version and env vars.",
        evidence: {
          command: [spec.cmd, ...spec.args].join(" "),
          code: res.code,
          stdoutTail: res.stdout.slice(-4000),
          stderrTail: res.stderr.slice(-4000),
        },
      });
    } else {
      section.findings.push({
        id: `cmd.${r}.ok`,
        title: `${spec.title} passed`,
        severity: "INFO",
        details: "Command completed successfully.",
        evidence: { command: [spec.cmd, ...spec.args].join(" "), stdoutTail: res.stdout.slice(-2000) },
      });
    }
  }

  return section;
}
