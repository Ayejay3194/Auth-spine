export default function DashboardHome() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <p className="text-sm text-slate-300">
        From here you can navigate to projects, billing, and admin (if allowed).
      </p>
    </div>
  );
}
