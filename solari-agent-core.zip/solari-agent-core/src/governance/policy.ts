import { Plan, PlanStep } from "../types";

export function validatePlan(plan: Plan): { ok: true } | { ok: false; errors: string[] } {
  const errors: string[] = [];
  if (!plan.steps.length) errors.push("Plan has no steps.");
  for (const s of plan.steps) {
    if (!s.id) errors.push("Step missing id.");
    if (!s.title) errors.push(`Step ${s.id} missing title.`);
    if (!s.successCriteria?.length) errors.push(`Step ${s.id} missing success criteria.`);
    if (s.action === "tool" && !s.toolName) errors.push(`Step ${s.id} action=tool but toolName missing.`);
  }
  return errors.length ? { ok: false, errors } : { ok: true };
}

export function requireAuditForStep(step: PlanStep) {
  // marker for integrators: enforce in executor
  return step.action === "tool" || step.action === "write_file";
}
