# Legal + Compliance Pack (SaaS/Marketplace/Booking)

This is a **starter pack**: templates + implementation checklists to avoid the most common **legal/compliance faceplants**:
- no ToS / unenforceable ToS
- missing consent + DSAR flows (export/delete)
- missing DPA/subprocessors
- no incident/breach plan
- PII leaking into logs/analytics

> Not legal advice. It's a structured starting point so you can hand it to counsel and ship sane defaults.

## What’s inside
- `policies/` — ToS, Privacy, Cookie Policy, AUP, Accessibility Statement, Retention Schedule
- `contracts/` — DPA template, Subprocessor list template, Security Addendum, SLA notes
- `ops/` — incident response plan, breach runbook + customer templates, ROPA template
- `product/` — consent banner spec, DSAR API checklist, analytics redaction rules
- `checklists/` — launch readiness checklists, vendor intake questionnaire, OSS license hygiene

## How to use
1. Replace ALL `{PLACEHOLDER}` fields.
2. Decide your **roles** (Controller vs Processor) and regions (US, EU, CA).
3. Wire the DSAR endpoints and retention jobs before you scale.
4. Get counsel to bless final text if you’re selling to real businesses.

## Minimum implementation targets
- Consent: cookie banner + preferences + proof log
- DSAR: export + delete + correction + access
- Retention: automated deletes for cancelled accounts + stale logs
- Vendor: subprocessors list + DPAs + access controls
- Security: incident response playbook + breach notification workflow

Generated: 2025-12-16
