import { section, ok, fail, run, readJson, exists, findFiles, readText } from "./_util.mjs";

async function optional(cmd, args, name){
  section(name);
  const code = await run(cmd, args);
  if(code===127 || code===9009){
    console.log(`⚠️  ${cmd} not found. Skipping ${name}. Install it to enforce this check.`);
    return 0;
  }
  if(code!==0) fail(`${name} failed`);
  else ok(`${name} passed`);
  return code;
}

section("Dependency vulnerability scan");
if(exists("./package.json")){
  await optional("npm", ["audit", "--audit-level=high"], "npm audit (high)");
}
await optional("osv-scanner", ["--recursive", "."], "OSV dependency scan");
await optional("trivy", ["fs", "--security-checks", "vuln,secret,config", "."], "Trivy fs scan (vuln/secret/config)");

section("Secret leak heuristics (cheap but catches the usual crimes)");
const bad = [];
const files = findFiles(".", [".env",".ts",".js",".mjs",".json",".yml",".yaml"]);
const secretRe = /(api[_-]?key|secret|private[_-]?key|password|passwd|token)\s*[:=]\s*["']?[A-Za-z0-9_\-\/\+=]{12,}/i;

for(const f of files){
  if(f.includes("node_modules") || f.includes(".git") || f.includes("dist")) continue;
  const t = readText(f);
  if(secretRe.test(t) && !f.endsWith(".schema.json")){
    bad.push(f);
  }
}
if(bad.length){
  console.log("Potential secrets found in:");
  for(const f of bad.slice(0,40)) console.log(`- ${f}`);
  fail("Secret leak heuristic triggered. Rotate keys and move secrets to a manager.");
} else {
  ok("No obvious hardcoded secrets detected (heuristic scan)");
}

section("HTTP security headers checks (for Next/Express configs)");
const cfg = readJson("./infra.config.json");
const required = (cfg.policy?.required_security_headers ?? []).map(s=>String(s).toLowerCase());
const headerFiles = findFiles("./apps", [".ts",".js",".mjs"]);
let missing = [];
for(const f of headerFiles){
  const lower = readText(f).toLowerCase();
  const hasAny = required.some(h=>lower.includes(h));
  if(required.length && !hasAny) missing.push(f);
}
if(missing.length){
  console.log("Apps that might be missing security headers (heuristic):");
  for(const f of missing.slice(0,30)) console.log(`- ${f}`);
  console.log("If you use a central middleware, ignore this. Otherwise fix it.");
} else {
  ok("Security headers heuristics look okay");
}
