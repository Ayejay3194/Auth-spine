-- Approximate bloat indicators (heuristic)
-- Note: Exact bloat calculation is complex; treat this as a signal, not truth.
create or replace view admin_table_bloat_signals as
select
  n.nspname as schema_name,
  c.relname as table_name,
  pg_total_relation_size(c.oid) as total_bytes,
  pg_relation_size(c.oid) as heap_bytes,
  pg_total_relation_size(c.oid) - pg_relation_size(c.oid) as other_bytes,
  s.n_live_tup,
  s.n_dead_tup,
  case when (s.n_live_tup + s.n_dead_tup) = 0 then 0
       else round(100.0 * s.n_dead_tup / (s.n_live_tup + s.n_dead_tup), 2)
  end as dead_tuple_pct
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
left join pg_stat_user_tables s on s.relid = c.oid
where c.relkind = 'r'
order by dead_tuple_pct desc nulls last, total_bytes desc;
