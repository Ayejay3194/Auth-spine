import { test, expect } from "@playwright/test";

const BASE_URL = process.env.BASE_URL || "http://localhost:3000";
const IS_PROD = process.env.NODE_ENV === "production";

test.describe("Public surface hardening", () => {
  test("home loads and does not leak internals", async ({ page }) => {
    const r = await page.goto(BASE_URL);
    expect(r?.status()).toBeLessThan(500);

    // Basic header sanity
    const headers = r?.headers() || {};
    expect(headers["x-content-type-options"]).toBeTruthy();
    expect(headers["content-security-policy"]).toBeTruthy();
  });

  test("health is minimal", async ({ request }) => {
    const r = await request.get(`${BASE_URL}/api/health`);
    expect(r.status()).toBe(200);
    const json = await r.json();
    expect(json.ok).toBe(true);
    expect(Object.keys(json).length).toBe(1);
  });

  test("swagger/openapi are gated in prod", async ({ page, request }) => {
    const openapi = await request.get(`${BASE_URL}/api/openapi.json`);
    if (IS_PROD) {
      expect(openapi.status()).toBe(404);
    } else {
      expect([200, 404]).toContain(openapi.status());
    }

    const swagger = await page.goto(`${BASE_URL}/swagger`);
    if (IS_PROD) {
      expect(swagger?.status()).toBe(404);
    } else {
      expect(swagger?.status()).toBeLessThan(500);
    }
  });

  test("metrics are never public", async ({ request }) => {
    const r = await request.get(`${BASE_URL}/api/metrics`);
    // Without auth/IP allowlist, should be 404.
    expect([404, 200]).toContain(r.status());
    if (r.status() === 200) {
      const text = await r.text();
      expect(text).toContain("# HELP");
    }
  });
});
