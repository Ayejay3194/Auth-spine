# Infrastructure Test Suite

This suite is split into three layers:

## 1. Unit
Pure logic tests. No IO. Fast.

## 2. Integration
Real services: database, auth, queues, storage.

## 3. System
Deployed environment validation: security, DR, observability.

Run order:
1. unit
2. integration
3. system
