import Link from "next/link";
export function StylistCard({slug, displayName, title, heroUrl}:{slug:string; displayName:string; title?:string|null; heroUrl?:string|null;}){
  return (
    <Link href={`/@${slug}`} className="group overflow-hidden rounded-2xl border" style={{borderColor:"var(--border)", background:"var(--panel)"}}>
      <div className="h-40 w-full" style={{backgroundImage:`linear-gradient(to top, color-mix(in srgb, var(--bg) 75%, transparent), transparent), url(${heroUrl||""})`, backgroundSize:"cover", backgroundPosition:"center"}}/>
      <div className="p-4">
        <div className="serif text-lg">{displayName}</div>
        <div className="mt-1 text-sm" style={{color:"var(--muted)"}}>{title || "Stylist"}</div>
        <div className="mt-3 inline-flex items-center rounded-full border px-3 py-2 text-xs tracking-[.18em] uppercase" style={{borderColor:"var(--border)", background:"var(--panel2)", color:"var(--dim)"}}>
          View portfolio →
        </div>
      </div>
    </Link>
  );
}
