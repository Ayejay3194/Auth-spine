import { NextRequest, NextResponse } from "next/server";
import { securityHeaders } from "./src/security/headers";
import { rateLimit } from "./src/security/rateLimit";
import { requestId } from "./src/lib/request";

export function middleware(req: NextRequest) {
  const res = NextResponse.next();
  res.headers.set("x-request-id", requestId(req.headers.get("x-request-id")));

  for (const [k, v] of Object.entries(securityHeaders)) res.headers.set(k, v);

  const limit = Number(process.env.REQUEST_BODY_LIMIT || 1048576);
  const len = Number(req.headers.get("content-length") || 0);
  if (len && len > limit) return NextResponse.json({ error: "Payload too large" }, { status: 413 });

  if (req.nextUrl.pathname.startsWith("/api/")) {
    const ip = req.headers.get("x-forwarded-for") || "unknown";
    const rl = rateLimit(`${ip}:${req.nextUrl.pathname}`, 60_000, 120);
    res.headers.set("x-ratelimit-remaining", String(rl.remaining));
    if (!rl.ok) return NextResponse.json({ error: "Rate limit exceeded" }, { status: 429 });
  }
  return res;
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
