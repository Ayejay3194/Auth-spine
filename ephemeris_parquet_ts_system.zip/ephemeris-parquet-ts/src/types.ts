export type Vec3 = [number, number, number];

export type BodyName =
  | "sun" | "mercury" | "venus" | "earth" | "moon"
  | "mars" | "jupiter" | "saturn" | "uranus" | "neptune" | "pluto";

export interface State {
  r: Vec3; // AU
  v: Vec3; // AU/day
}

export interface SampleRow {
  jd: number;
  states: Record<BodyName, State>;
}

export interface SegmentCoeffs {
  body: BodyName;
  span: string;
  segStartJd: number;
  segEndJd: number;
  order: number; // N, coeffs length = N+1
  px: number[]; py: number[]; pz: number[];
  vx: number[]; vy: number[]; vz: number[];
}
