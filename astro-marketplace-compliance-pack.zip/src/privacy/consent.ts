export type Consent = { v:"v1"; necessary:true; functional:boolean; analytics:boolean; marketing:boolean; dismissed:boolean };
const KEY="consent:v1";
export function getConsent(): Consent {
  if (typeof window==="undefined") return { v:"v1", necessary:true, functional:true, analytics:false, marketing:false, dismissed:false };
  const raw=localStorage.getItem(KEY); if(!raw) return { v:"v1", necessary:true, functional:true, analytics:false, marketing:false, dismissed:false };
  try { return JSON.parse(raw) as Consent; } catch { return { v:"v1", necessary:true, functional:true, analytics:false, marketing:false, dismissed:false }; }
}
export function setConsent(c: Consent){ if(typeof window!=="undefined") localStorage.setItem(KEY, JSON.stringify(c)); }
export const canAnalytics=()=>getConsent().analytics;
