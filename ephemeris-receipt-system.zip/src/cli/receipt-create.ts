import { readFileSync, mkdirSync, appendFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import { ReceiptSchemaV1 } from "../receipt/types.js";
import { canonicalJson, sha256Hex } from "../receipt/canonical.js";
import { makeLedgerEntry } from "../receipt/ledger.js";

function arg(name: string): string | undefined {
  const idx = process.argv.indexOf(name);
  return idx >= 0 ? process.argv[idx + 1] : undefined;
}

const inputPath = arg("--input");
const outputPath = arg("--output");
const ledgerPath = arg("--ledger") ?? "./receipts/ledger.jsonl";
const secret = process.env.RECEIPT_HMAC_SECRET ?? "dev-secret-change-me";

if (!inputPath || !outputPath) {
  console.error("Usage: receipt-create --input <input.json> --output <output.json> [--ledger <path>]");
  process.exit(1);
}

const inputObj = JSON.parse(readFileSync(resolve(inputPath), "utf-8"));
const outputObj = JSON.parse(readFileSync(resolve(outputPath), "utf-8"));

const receipt = ReceiptSchemaV1.parse({
  schema: "CanonicalEphemerisReceipt@v1",
  createdAt: new Date().toISOString(),
  engine: {
    name: "Solari Ephemeris",
    version: "0.1.0",
    gitSha: process.env.GIT_SHA,
    buildId: process.env.BUILD_ID,
    runtime: `node ${process.version}`,
  },
  input: {
    inputHash: sha256Hex(canonicalJson(inputObj)),
    redacted: true,
  },
  output: {
    outputHash: sha256Hex(canonicalJson(outputObj)),
    contract: outputObj?.schema ?? "CanonicalEphemerisOutput@v1",
  },
  provenance: {
    kernel: {
      id: outputObj?.provenance?.kernel?.id ?? "UNKNOWN",
      bytesSha256: outputObj?.provenance?.kernel?.bytesSha256 ?? "UNKNOWN",
      segment: outputObj?.provenance?.kernel?.segment,
      degree: outputObj?.provenance?.kernel?.degree,
      subintervalDays: outputObj?.provenance?.kernel?.subintervalDays,
      coverage: outputObj?.provenance?.kernel?.coverage,
    },
    time: outputObj?.provenance?.time,
    iau: outputObj?.provenance?.iau,
  },
  validation: outputObj?.validation,
});

mkdirSync(resolve(ledgerPath, ".."), { recursive: true });

let prevChainHash: string | null = null;
if (existsSync(resolve(ledgerPath))) {
  const lines = readFileSync(resolve(ledgerPath), "utf-8").trim().split("\n").filter(Boolean);
  if (lines.length > 0) {
    const last = JSON.parse(lines[lines.length - 1]);
    prevChainHash = last.chainHash ?? null;
  }
}

const entry = makeLedgerEntry({ receipt, prevChainHash, secret });
appendFileSync(resolve(ledgerPath), JSON.stringify(entry) + "\n", "utf-8");

console.log(JSON.stringify({ ok: true, ledgerPath, chainHash: entry.chainHash, entryHash: entry.entryHash }, null, 2));
