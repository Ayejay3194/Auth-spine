import { Container } from "@/components/Container";
import { prisma } from "@/lib/prisma";
import { StylistCard } from "@/components/StylistCard";

export default async function Discover(){
  const stylists = await prisma.stylistProfile.findMany({ where:{ isActive:true }, orderBy:{ createdAt:"desc" } });
  return (
    <main className="py-10">
      <Container>
        <div>
          <div className="text-xs tracking-[.22em] uppercase" style={{color:"var(--dim)"}}>Discover</div>
          <h1 className="serif mt-2 text-3xl">Stylists near you (demo).</h1>
          <div className="mt-2 text-sm" style={{color:"var(--muted)"}}>In real life you filter by location, specialty, price, availability. Humans love filters.</div>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {stylists.map(s => <StylistCard key={s.id} slug={s.slug} displayName={s.displayName} title={s.title} heroUrl={s.heroUrl} />)}
        </div>
      </Container>
    </main>
  );
}
