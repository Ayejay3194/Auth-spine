import { AgentContext } from "../core/types.js";
import { SessionStore } from "../memory/session.js";
import { PolicyDecision, PolicyEngine } from "./types.js";

export interface SimplePolicyConfig {
  allow: Record<string, string[]>;
  rate: { windowSeconds: number; max: number };
  confirmIntents: string[];
}

export class SimplePolicyEngine implements PolicyEngine {
  constructor(private store: SessionStore<{ count: number }>, private cfg: SimplePolicyConfig) {}
  private key(ctx: AgentContext) { return `rl:${ctx.businessId}:${ctx.userId}`; }

  private async rateLimit(ctx: AgentContext): Promise<PolicyDecision> {
    const cur = (await this.store.get(this.key(ctx))) ?? { count: 0 };
    if (cur.count >= this.cfg.rate.max) return { ok: false, code: "RATE_LIMIT", message: "Too many requests. Try again shortly." };
    await this.store.set(this.key(ctx), { count: cur.count + 1 }, this.cfg.rate.windowSeconds);
    return { ok: true };
  }

  async checkTool(ctx: AgentContext, toolId: string): Promise<PolicyDecision> {
    const rl = await this.rateLimit(ctx);
    if (!rl.ok) return rl;
    const ok = this.cfg.allow[ctx.role]?.includes(toolId) ?? false;
    if (!ok) return { ok: false, code: "FORBIDDEN", message: "Not allowed." };
    return { ok: true };
  }

  async checkCommit(_ctx: AgentContext, intent: string, confirm?: string): Promise<PolicyDecision> {
    if (!this.cfg.confirmIntents.includes(intent)) return { ok: true };
    if ((confirm ?? "").trim().toUpperCase() != "YES") return { ok: false, code: "CONFIRM_REQUIRED", message: "Type YES to confirm." };
    return { ok: true };
  }
}
