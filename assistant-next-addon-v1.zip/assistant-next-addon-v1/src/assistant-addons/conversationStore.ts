import type { ConversationState } from "./types";

/**
 * Minimal in-memory store. Swap with Redis/DB in production.
 * TTL eviction keeps it from growing forever (because humans love abandoning chats).
 */

const TTL_MS = 1000 * 60 * 60 * 24; // 24h
const store = new Map<string, ConversationState>();

export function getConversationState(sessionId: string): ConversationState {
  const now = Date.now();
  const existing = store.get(sessionId);
  if (existing && now - existing.lastSeenAt < TTL_MS) {
    existing.lastSeenAt = now;
    return existing;
  }
  const fresh: ConversationState = {
    sessionId,
    lastSeenAt: now,
    lastEntities: {},
  };
  store.set(sessionId, fresh);
  return fresh;
}

export function saveConversationState(state: ConversationState) {
  state.lastSeenAt = Date.now();
  store.set(state.sessionId, state);
}

export function resetConversationState(sessionId: string) {
  store.delete(sessionId);
}

export function evictExpired() {
  const now = Date.now();
  for (const [k, v] of store.entries()) {
    if (now - v.lastSeenAt >= TTL_MS) store.delete(k);
  }
}
