import type { EntitySpan, NLUModel } from "../types";
import { regexEntities } from "./regex";
import { dictionaryEntities } from "./dictionary";
import { mergeEntities } from "./merge";
import { normalizeEntities } from "./normalize";

export function extract(model: NLUModel, text: string): EntitySpan[] {
  const raw = [
    ...regexEntities(model, text),
    ...dictionaryEntities(model, text),
  ];
  const merged = mergeEntities(raw);
  return normalizeEntities(model, text, merged);
}
