export type Entities = {
  money?: number;
  percent?: number;
  dateISO?: string;
  timeHint?: "morning" | "afternoon" | "evening";
  clientId?: string;
  providerId?: string;
  bookingId?: string;
  holdId?: string;
  invoiceId?: string;
  disputeId?: string;
  promoCode?: string;
  service?: string;
  location?: string;
};

const moneyRe = /\$\s*(\d+(?:\.\d{1,2})?)/;
const pctRe = /(\d{1,3})\s*%/;

export function extractEntities(text: string): Entities {
  const t = text.trim();
  const e: Entities = {};
  const m = t.match(moneyRe); if (m) e.money = Number(m[1]);
  const p = t.match(pctRe); if (p) e.percent = Number(p[1]);
  const d = t.match(/\b(20\d{2}-\d{2}-\d{2})\b/); if (d) e.dateISO = d[1];
  if (/\bmorning\b/i.test(t)) e.timeHint = "morning";
  if (/\bafternoon\b/i.test(t)) e.timeHint = "afternoon";
  if (/\bevening\b/i.test(t)) e.timeHint = "evening";
  const pid = t.match(/\bprov_[a-z0-9_-]+\b/i); if (pid) e.providerId = pid[0];
  const cid = t.match(/\bcl_[a-z0-9_-]+\b/i); if (cid) e.clientId = cid[0];
  const bid = t.match(/\bbk_[a-z0-9_-]+\b/i); if (bid) e.bookingId = bid[0];
  const hid = t.match(/\bhold_[a-z0-9_-]+\b/i); if (hid) e.holdId = hid[0];
  const iid = t.match(/\binv_[a-z0-9_-]+\b/i); if (iid) e.invoiceId = iid[0];
  const did = t.match(/\bdisp_[a-z0-9_-]+\b/i); if (did) e.disputeId = did[0];
  const code = t.match(/\bpromo[_-]?[a-z0-9]+\b/i); if (code) e.promoCode = code[0];
  const svc = t.match(/\b(?:for|service)\s+([a-z][a-z\s]{2,40})\b/i); if (svc) e.service = svc[1].trim();
  const loc = t.match(/\bnear\s+([a-z0-9\s,]{2,40})\b/i); if (loc) e.location = loc[1].trim();
  return e;
}
