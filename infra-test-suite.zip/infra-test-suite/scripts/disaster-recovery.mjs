import { section, ok, fail, exists, run, readJson } from "./_util.mjs";
import fs from "node:fs";

const cfg = readJson("./infra.config.json");

async function optional(cmd, args, name){
  section(name);
  const code = await run(cmd, args);
  if(code===127 || code===9009){
    console.log(`⚠️  ${cmd} not found. Skipping ${name}. Install it to enforce this check.`);
    return 0;
  }
  if(code!==0) fail(`${name} failed`);
  else ok(`${name} passed`);
  return code;
}

section("Backup artifacts present (and not vibes)");
const expected = [
  "./runbooks/backup-restore.md",
  "./runbooks/incident-response.md",
  "./runbooks/dr-drill.md",
];
let missing = expected.filter(p=>!exists(p));
if(missing.length){
  for(const m of missing) console.log("Missing: " + m);
  fail("DR runbooks missing. Untested backups are just expensive lies.");
} else {
  ok("DR runbooks exist");
}

section("Optional: execute a local restore drill script (safe sandbox)");
if(exists("./scripts/drills/restore-drill.sh")){
  await optional("bash", ["./scripts/drills/restore-drill.sh"], "restore-drill.sh");
} else {
  console.log("No ./scripts/drills/restore-drill.sh found. Add one for your stack (Postgres/S3/Redis/etc).");
}
