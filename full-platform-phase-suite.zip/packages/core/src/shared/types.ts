export type ID = string;
export type ISODateTime = string;

export type Result<T> =
  | { ok: true; data: T }
  | { ok: false; error: { code: string; message: string; details?: any } };

export type TenantContext = { tenantId: ID; userId?: ID; roles?: string[] };

export const ok = <T>(data: T): Result<T> => ({ ok: true, data });
export const err = (code: string, message: string, details?: any): Result<never> =>
  ({ ok: false, error: { code, message, details } });
