# Ultimate Web Dev Career Starter Kit

This is a **full-stack career starter** for building modern web apps:

- Next.js (App Router) + React + TypeScript
- TailwindCSS + basic design system
- Prisma ORM (SQLite)
- Stubbed auth + routes ready for real auth library
- Stripe-ready billing scaffolding
- Admin area
- Blog/CMS-style content
- AI prompts + learning roadmap + curriculum

It's designed so a junior can go from:
"I've done tutorials" → "I can ship and maintain a small SaaS-style app."
