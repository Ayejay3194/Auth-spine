import type { BodyName, SampleRow } from "./types.js";
import { SegmentIndex, evalState } from "./runtime.js";

function norm3(v: [number,number,number]): number {
  return Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
}

export interface AuditResult {
  body: BodyName;
  n: number;
  maxPosErr: number;
  meanPosErr: number;
  maxVelErr: number;
  meanVelErr: number;
}

export function auditBody(samples: SampleRow[], body: BodyName, index: SegmentIndex): AuditResult {
  let n = 0, maxPos = 0, sumPos = 0, maxVel = 0, sumVel = 0;

  for (const row of samples) {
    const teacher = row.states[body];
    const est = evalState(index, row.jd);

    const dr: any = [teacher.r[0]-est.r[0], teacher.r[1]-est.r[1], teacher.r[2]-est.r[2]];
    const dv: any = [teacher.v[0]-est.v[0], teacher.v[1]-est.v[1], teacher.v[2]-est.v[2]];

    const pe = norm3(dr);
    const ve = norm3(dv);

    maxPos = Math.max(maxPos, pe);
    maxVel = Math.max(maxVel, ve);
    sumPos += pe;
    sumVel += ve;
    n++;
  }

  return { body, n, maxPosErr: maxPos, meanPosErr: sumPos/Math.max(1,n), maxVelErr: maxVel, meanVelErr: sumVel/Math.max(1,n) };
}
