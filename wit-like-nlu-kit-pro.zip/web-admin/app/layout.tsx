import React from "react";

export const metadata = { title: "NLU Admin" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "ui-sans-serif, system-ui", margin: 0, background: "#0b1220", color: "#e6edf3" }}>
        {children}
      </body>
    </html>
  );
}
