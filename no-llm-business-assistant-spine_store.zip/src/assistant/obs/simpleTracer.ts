export class SimpleTracer {
  event(name: string, data?: Record<string, unknown>) {
    // Swap with OpenTelemetry later. This is intentionally boring.
    if (process.env.ASSISTANT_TRACE === "1") {
      console.log(`[trace] ${name}`, data ?? {});
    }
  }
}
