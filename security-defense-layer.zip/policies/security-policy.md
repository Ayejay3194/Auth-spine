Security Policy Summary

- Zero trust by default
- Least privilege everywhere
- No raw data leaves internal boundaries
- All access is logged, reviewed, and revocable
- Security > convenience > speed
