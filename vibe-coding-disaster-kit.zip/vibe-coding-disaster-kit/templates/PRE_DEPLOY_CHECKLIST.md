# Pre-Deploy Checklist

- [ ] Secrets scanned (repo + CI logs) and clean
- [ ] Migrations applied in staging and verified
- [ ] Health checks pass (API, DB, queue, background jobs)
- [ ] Rate limits enabled and tested
- [ ] Error tracking configured (release tag set)
- [ ] Backups verified (latest snapshot + restore dry run schedule)
- [ ] Feature flags in correct state
- [ ] Admin endpoints protected (MFA/allowlist if applicable)
- [ ] Status page + incident channel ready
- [ ] Rollback plan documented and feasible
