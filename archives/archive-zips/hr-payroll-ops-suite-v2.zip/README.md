
# HR + Payroll + Ops Suite (V2)

This update adds **real timesheets** and a **payroll engine V1** that pulls from **APPROVED** timesheets.

## Run
1) `cp .env.example .env` (set DATABASE_URL)
2) `npm install`
3) `npm run db:push && npm run db:generate`
4) `npm run seed`
5) `npm run dev`

## Demo auth (V1)
Send header: `x-user-email` with one of:
- admin@demo.com
- hr@demo.com
- payroll@demo.com
- manager@demo.com
- employee@demo.com

## Flows
- Time Entries -> Timesheet -> Submit -> Manager Approves
- Payroll Run -> Generate Items (uses approved timesheets) -> Review -> Finalize

Notes:
- Taxes are still a flat placeholder.
- Adjustments are supported per employee per run.
