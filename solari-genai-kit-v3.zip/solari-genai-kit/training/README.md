# training/

## Typical flow
```bash
python scripts/convert_jsonl.py --in raw.jsonl --out data/chat.jsonl --mode chat
python scripts/validate_jsonl.py --in data/chat.jsonl --mode chat --out_bad data/rejects.jsonl
python scripts/dedupe_jsonl.py --in data/chat.jsonl --out data/chat.dedup.jsonl
python scripts/stats_report.py --in data/chat.dedup.jsonl --mode chat --out data/stats.json
python scripts/group_split_jsonl.py --in data/chat.dedup.jsonl --outdir data/splits --group_key meta.userId --seed 42
# then train on GPU using Axolotl configs under axolotl/
```

## Why group split?
To prevent leakage: if the same user/chart/document appears in both train and val/test, you will think you're smart when you're just cheating.
