import fs from "node:fs";
import path from "node:path";
import type { FeatureContract } from "./feature-contract.types";

export function loadContract(contractPath: string): FeatureContract {
  const raw = fs.readFileSync(contractPath, "utf-8");
  return JSON.parse(raw) as FeatureContract;
}

export function loadAllContracts(rootDir: string): FeatureContract[] {
  const contracts: FeatureContract[] = [];
  const walk = (dir: string) => {
    for (const item of fs.readdirSync(dir)) {
      const full = path.join(dir, item);
      const stat = fs.statSync(full);
      if (stat.isDirectory()) walk(full);
      else if (item === "contract.json") contracts.push(loadContract(full));
    }
  };
  walk(rootDir);
  return contracts;
}
