# Product Requirements: Cookie Consent

- Geo-based behavior (opt-in where required)
- Categories: essential, functional, analytics, marketing
- Store consent choice with timestamp + policy version
- Block non-essential scripts until consent
- Settings link in footer
