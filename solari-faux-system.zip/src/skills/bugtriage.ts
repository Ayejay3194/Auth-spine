import { Skill } from "./base.js";
import { SkillContext, SkillResult } from "../types.js";

export class BugTriageSkill implements Skill {
  name = "BugTriageSkill";

  async run(ctx: SkillContext): Promise<SkillResult> {
    return {
      kind: "clarify",
      question: "Drop the exact error text and where it happens (file + line if you have it).",
      options: ["Paste stack trace", "Describe steps to reproduce"],
      tags: ["bug","clarify"]
    };
  }
}
