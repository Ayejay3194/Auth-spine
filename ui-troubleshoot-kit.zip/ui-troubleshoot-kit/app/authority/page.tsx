import Link from "next/link";

const LADDER = [
  { z: 1, name: "Content", notes: "Main page content" },
  { z: 10, name: "Right rail", notes: "Mini-map or feed rail" },
  { z: 20, name: "Nav", notes: "Top nav / bottom nav" },
  { z: 40, name: "Drawers/Sheets", notes: "Slide-over panels" },
  { z: 60, name: "Modals", notes: "Blocking overlays" },
  { z: 80, name: "Toasts", notes: "Notifications" }
];

export default function AuthorityRules() {
  return (
    <div className="bg-white rounded-2xl shadow-soft p-6 md:p-8 border border-slate-200/60">
      <h1 className="text-3xl font-black text-slate-900">UI Authority Rules</h1>
      <p className="mt-2 text-slate-700">
        If your UI feels like it’s fighting itself, it’s almost always because the same concept is owned by multiple authorities.
        Pick one. Delete the rest.
      </p>

      <div className="mt-6 grid gap-4">
        <Rule title="Route owns navigation state" body="If you have routes, you don’t also need activeTab state. Route is truth." />
        <Rule title="Global store owns global toggles" body="Theme, glow, radius, filters, modal stack. One store. Not per-page." />
        <Rule title="Local components own local UI" body="Input text, a dropdown open state, a local accordion. If it doesn't matter outside the component, keep it local." />
        <Rule title="Server state owns server data" body="Do not mirror server data into local state unless you have a clear reason. Fetch/cache layer should own it." />
        <Rule title="CSS owns layout" body="Use responsive classes. Don't build two apps in JS for mobile vs desktop." />
      </div>

      <h2 className="mt-8 text-xl font-extrabold text-slate-900">Z-index ladder</h2>
      <p className="mt-1 text-slate-700">Stop freelancing z-index. Pick a ladder and obey it.</p>

      <div className="mt-4 overflow-hidden rounded-xl border border-slate-200">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-700">
            <tr>
              <th className="px-4 py-3 text-left font-bold">z</th>
              <th className="px-4 py-3 text-left font-bold">Layer</th>
              <th className="px-4 py-3 text-left font-bold">Notes</th>
            </tr>
          </thead>
          <tbody>
            {LADDER.map((r) => (
              <tr key={r.z} className="border-t border-slate-200">
                <td className="px-4 py-3 font-mono">{r.z}</td>
                <td className="px-4 py-3 font-semibold">{r.name}</td>
                <td className="px-4 py-3 text-slate-700">{r.notes}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <Link className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-2 font-semibold hover:bg-slate-100" href="/">
          Back to toolkit
        </Link>
        <Link className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-2 font-semibold hover:bg-slate-100" href="/quickfix">
          Quick fix pack
        </Link>
      </div>
    </div>
  );
}

function Rule({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
      <div className="font-bold text-slate-900">{title}</div>
      <div className="mt-1 text-slate-700">{body}</div>
    </div>
  );
}
