# Memory Core
Template for persistent memory.