# Astro Marketplace Output Contract (AMC)

This kit gives you **two “can’t-break-it” layers** for your astrology platform:

1) **AMO-1**: a strict, versioned JSON schema (machine contract)
2) **AMT-1**: a Solar Fire-ish text export (human contract)

Then we glue it together with:

- **AMJCS-1 canonicalization** (stable, sorted, number-normalized string)
- **sha256 integrity hash** over the canonical string

If an AI refactor, library upgrade, or “helpful” teammate changes anything meaningful, the hash changes. If the hash changes, you catch it. Simple.

---

## 1. Machine Contract: `amc.chart.v1`

See: `fixtures/sample.chart.v1.json`

### Rules
- JSON MUST include `schema: "amc.chart.v1"`.
- Fields are strongly typed (see `src/types.ts`).
- Store original high-precision floats in JSON where you want them.
- For hashing, we canonicalize numbers to a fixed precision string (default: 10 decimal places) so the hash is stable across runtime / serializer quirks.

### Required minimum to be “valid enough”
- `subject.birth.date`, `subject.birth.time`, and either a real location OR `location.source: "unknown"`.
- `points` list present with at least: Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto.
- `angles` present with Ascendant + MC.
- `houses` present with 12 cusps.

---

## 2. Human Contract: AMT-1 text export

See: `fixtures/sample.chart.v1.txt`

Purpose:
- A stable text representation you can show users, export to support, and use as regression “goldens”.

The formatter is in: `src/format.ts` (`formatChartLikeSolarFire`).

---

## 3. Canonicalization (AMJCS-1)

Implemented in: `src/canonicalize.ts`

Canonicalization rules:
- Object keys are lexicographically sorted.
- Arrays keep order.
- Numbers become strings in the canonical output, normalized to a fixed decimal precision.
- `null` stays `null`.

This prevents “same data, different JSON string” problems.

---

## 4. Integrity Hash

Implemented in: `src/hash.ts`

We compute:
- canonical string: `canonicalizeChart(chart)`
- hash: `sha256(canonicalString)`

Store the hash alongside the saved chart and also embed it in the text export.

---

## 5. Validation

Implemented in: `src/validate.ts`

Validation does two things:
- **errors**: must-fix, chart is unusable
- **warnings**: chart can exist, but you probably hate the input (ex: `0,0` coords, missing timezone)

---

## Quick start

```bash
npm i
npm run gen:sample
npm test
```

---

## How to use in your API

- On chart calculation response:
  1) build `ChartDataV1`
  2) `validateChartData(chart)`
  3) `computeChartIntegrity(chart)`
  4) return JSON + integrity hash, and optionally the text export

- On every deploy:
  - run regression tests that compare stored “golden” hashes for known charts.

