# Tenant Enforcement Middleware (Prisma)
File: `src/tenant/prismaTenantMiddleware.ts`

This middleware auto-injects `tenantId` in:
- reads (where.tenantId)
- writes (data.tenantId)
- updates/deletes (where.tenantId)

You must:
- Add your actual tenant-scoped models into TENANT_MODELS
- Use `withTenant(prisma, () => tenantId)` in request context (route handlers)
