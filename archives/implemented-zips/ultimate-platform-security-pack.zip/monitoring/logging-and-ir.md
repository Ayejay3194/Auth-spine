Monitoring & Incident Response

- Centralized logs
- SIEM ingestion
- Alerts for auth, abuse, exfiltration
- Incident response plan tested regularly
