# Universal Professional Platform – V1

Vertical-agnostic core + vertical configs + "unfair advantage" moat modules.

Run:
```bash
npm i
npm run build
npm run demo
```
