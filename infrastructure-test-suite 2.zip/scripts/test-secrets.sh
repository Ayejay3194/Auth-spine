#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

log "Gitleaks secret scan"
docker_run zricethezav/gitleaks:latest detect --source . --no-git --redact --exit-code 1
