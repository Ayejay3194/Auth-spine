import crypto from "crypto";
import type { Receipt } from "./types.js";

export function sha256Hex(input: string): string {
  return crypto.createHash("sha256").update(input, "utf8").digest("hex");
}

export function safePreview(text: string, max = 64): string {
  const t = text.replace(/\s+/g, " ").trim();
  if (t.length <= max) return t;
  return t.slice(0, max - 1) + "…";
}

export function nowUtcIso(): string {
  return new Date().toISOString();
}

export function buildBaseReceipt(args: {
  text: string;
  userId?: string;
  requestId?: string;
}): Receipt {
  return {
    kind: "wit_parse_receipt",
    tsUtc: nowUtcIso(),
    requestId: args.requestId,
    userId: args.userId,
    input: {
      rawLen: args.text.length,
      sha256: sha256Hex(args.text),
      preview: safePreview(args.text),
    },
    wit: {},
    result: { accepted: false },
  };
}

export function payloadHash(payload: unknown): string {
  return sha256Hex(JSON.stringify(payload ?? null));
}
