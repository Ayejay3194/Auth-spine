import { describe, it, expect } from "vitest";
import { validateChartDataV1 } from "../src/validate/validate.js";
import { MockEngine } from "../src/engine/mock-engine.js";
import { computeNatalWithIntegrity } from "../src/pipeline/build.js";

describe("ChartDataV1 contract", () => {
  it("produces a valid payload with integrity", async () => {
    const engine = new MockEngine();
    const out = await computeNatalWithIntegrity(engine, {
      chartType: "natal",
      dobUtc: "2000-01-01T00:00:00Z",
      geo: { lat: 0, lon: 0, tz: "Etc/UTC" },
      houseSystem: "placidus",
      zodiac: "tropical",
      flags: ["test"],
    });

    const parsed = validateChartDataV1(out);
    expect(parsed.integrity.sha256).toMatch(/^[a-f0-9]{64}$/);
    expect(parsed.integrity.canonical.length).toBeGreaterThan(10);
  });
});
