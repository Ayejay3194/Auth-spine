import { AgentContext, AuditLogger, Clock } from "../core/types.js";
import { Tool, ToolResult } from "./types.js";

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  let to: any;
  const t = new Promise<T>((_, rej) => { to = setTimeout(() => rej(new Error("TIMEOUT")), ms); });
  return Promise.race([p.finally(() => clearTimeout(to)), t]);
}

export async function runTool<TI, TO>(opts: { ctx: AgentContext; tool: Tool<TI, TO>; input: TI; audit: AuditLogger; clock: Clock; }): Promise<ToolResult<TO>> {
  const { ctx, tool, input, audit, clock } = opts;
  await audit.write({ at: clock.now(), userId: ctx.userId, role: ctx.role, type: "tool.called", details: { toolId: tool.id, input } });

  if (!tool.allowed(ctx)) {
    const res = { ok: false, error: { code: "FORBIDDEN", message: "Not allowed" } } as const;
    await audit.write({ at: clock.now(), userId: ctx.userId, role: ctx.role, type: "tool.error", details: { toolId: tool.id, error: res.error } });
    return res;
  }

  try {
    tool.validate(input);
    const res = await (tool.timeoutMs ? withTimeout(tool.run(ctx, input), tool.timeoutMs) : tool.run(ctx, input));
    await audit.write({ at: clock.now(), userId: ctx.userId, role: ctx.role, type: "tool.result", details: { toolId: tool.id, ok: res.ok } });
    return res;
  } catch (e: any) {
    const res = { ok: false, error: { code: e?.message === "TIMEOUT" ? "TIMEOUT" : "ERROR", message: String(e?.message ?? e) } } as const;
    await audit.write({ at: clock.now(), userId: ctx.userId, role: ctx.role, type: "tool.error", details: { toolId: tool.id, error: res.error } });
    return res;
  }
}
