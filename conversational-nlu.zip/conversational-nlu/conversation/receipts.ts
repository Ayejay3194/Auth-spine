export function writeReceipt(payload) {
  const receipt = {
    id: crypto.randomUUID(),
    ts: new Date().toISOString(),
    payload
  };
  console.log(JSON.stringify(receipt));
}
