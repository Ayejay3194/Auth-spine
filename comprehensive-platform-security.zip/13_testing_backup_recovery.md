TESTING, BACKUP & RECOVERY

Covers:
- Security testing
- Vulnerability management
- Backups
- Disaster recovery