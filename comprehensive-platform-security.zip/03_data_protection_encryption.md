DATA PROTECTION & ENCRYPTION

Covers:
- Encryption at rest & in transit
- Key management (KMS/HSM)
- Tokenization & masking
- Data minimization & retention
- PII, PCI, HIPAA handling