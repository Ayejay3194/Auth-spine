/**
 * Bans corporate / botty phrases. If your assistant says these, users will hate it.
 */
const BANNED = [
  "how may i assist you",
  "please be advised",
  "thank you for your patience",
  "i'm here to help",
  "i am here to help",
  "kindly",
];

export function sanitizeCopy(text: string) {
  let out = text;
  const lower = out.toLowerCase();
  for (const phrase of BANNED) {
    if (lower.includes(phrase)) {
      // simple replacement: remove the phrase and tidy spacing
      out = out.replace(new RegExp(escapeRegExp(phrase), "ig"), "");
    }
  }
  out = out.replace(/\s{2,}/g, " ").trim();
  return out;
}

function escapeRegExp(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
