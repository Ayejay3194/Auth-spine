'use client'
import React, { useMemo, useState } from 'react'
import { Search, AlertTriangle, Code, Zap, XCircle, CheckCircle, Copy, ChevronDown, ChevronRight } from 'lucide-react'

type Item = {
  id: string
  problem: string
  wrongCode: string
  rightCode: string
  explanation: string
  additionalIssues: string[]
}

type Data = Record<string, Item[]>

const conflictData: Data = {
  'JSX vs HTML Syntax Conflicts': [
    {
      id: 'jsx-1',
      problem: 'class attribute causing errors',
      wrongCode: `<div class="container">Content</div>`,
      rightCode: `<div className="container">Content</div>`,
      explanation: 'In JSX/React, "class" is reserved. Use "className".',
      additionalIssues: ['Replace class= everywhere', 'Check dynamic class strings too'],
    },
    {
      id: 'jsx-2',
      problem: 'for attribute on labels breaking',
      wrongCode: `<label for="email">Email</label>`,
      rightCode: `<label htmlFor="email">Email</label>`,
      explanation: 'JSX uses "htmlFor" instead of "for".',
      additionalIssues: ['Update all <label> elements'],
    },
    {
      id: 'jsx-3',
      problem: 'Inline style strings not working',
      wrongCode: `<div style="color: red; font-size: 16px;">Text</div>`,
      rightCode: `<div style={{ color: 'red', fontSize: '16px' }}>Text</div>`,
      explanation: 'JSX styles are objects with camelCase keys.',
      additionalIssues: ['background-color → backgroundColor', 'Use double braces {{ }}'],
    },
  ],
  'Quick Fixes': [
    {
      id: 'quick-1',
      problem: 'Everything seems broken',
      wrongCode: `// panic`,
      rightCode: `rm -rf node_modules package-lock.json
npm install
# restart dev server
# clear .next if needed`,
      explanation: 'Reset dependencies and caches before you spiral.',
      additionalIssues: ['Read the console first', 'One change at a time', 'Git is your undo button'],
    },
  ],
}

export default function HTMLToTSPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [copiedId, setCopiedId] = useState<string | null>(null)

  const filtered = useMemo(() => {
    if (!searchTerm) return conflictData
    const out: Data = {}
    for (const [category, items] of Object.entries(conflictData)) {
      const keep = items.filter(i =>
        i.problem.toLowerCase().includes(searchTerm.toLowerCase()) ||
        i.explanation.toLowerCase().includes(searchTerm.toLowerCase()) ||
        i.additionalIssues.some(a => a.toLowerCase().includes(searchTerm.toLowerCase()))
      )
      if (keep.length) out[category] = keep
    }
    return out
  }, [searchTerm])

  const copyCode = async (code: string, id: string) => {
    await navigator.clipboard.writeText(code)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl shadow p-6 border-4 border-red-500">
        <div className="flex items-center gap-3 mb-2">
          <AlertTriangle className="w-8 h-8 text-red-600" />
          <div>
            <h1 className="text-2xl font-bold">HTML → TypeScript Conflict Resolver</h1>
            <p className="text-red-600 font-semibold">Fix the stuff that&apos;s fighting each other.</p>
          </div>
        </div>
        <div className="relative mt-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search conflicts (class, onclick, style...)"
            className="w-full pl-12 pr-4 py-3 border-2 border-slate-200 rounded-lg focus:border-red-500 focus:outline-none"
          />
        </div>
      </div>

      <div className="space-y-3">
        {Object.keys(filtered).length === 0 ? (
          <div className="bg-white rounded-xl shadow p-6 text-center text-slate-600">
            <XCircle className="w-10 h-10 mx-auto mb-2 text-slate-400" />
            No results.
          </div>
        ) : (
          Object.entries(filtered).map(([category, items]) => (
            <div key={category} className="bg-white rounded-xl shadow overflow-hidden border">
              <button
                className="w-full px-5 py-4 flex items-center justify-between bg-gradient-to-r from-red-100 to-orange-100 hover:from-red-200 hover:to-orange-200"
                onClick={() => setExpanded(prev => ({ ...prev, [category]: !prev[category] }))}
              >
                <div className="font-semibold flex items-center gap-2"><Code className="w-5 h-5" />{category}</div>
                <div className="flex items-center gap-2 text-slate-700">
                  <span className="text-xs bg-white px-2 py-1 rounded-full">{items.length}</span>
                  {expanded[category] ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
                </div>
              </button>

              {expanded[category] && (
                <div className="p-5 space-y-6">
                  {items.map(item => (
                    <div key={item.id} className="border-l-4 border-red-500 pl-4">
                      <div className="font-semibold mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-orange-600" />
                        {item.problem}
                      </div>

                      <div className="bg-red-50 border rounded-lg p-4 mb-4">
                        <div className="flex items-center gap-2 mb-2 text-red-900 font-semibold">
                          <XCircle className="w-4 h-4" /> WRONG
                        </div>
                        <pre className="bg-slate-900 text-slate-100 rounded p-3 overflow-x-auto text-sm"><code>{item.wrongCode}</code></pre>
                      </div>

                      <div className="bg-green-50 border rounded-lg p-4 mb-4 relative">
                        <div className="flex items-center gap-2 mb-2 text-green-900 font-semibold">
                          <CheckCircle className="w-4 h-4" /> RIGHT
                        </div>
                        <button
                          className="absolute top-3 right-3 p-2 bg-green-600 hover:bg-green-700 rounded"
                          onClick={() => copyCode(item.rightCode, item.id)}
                          title="Copy code"
                        >
                          {copiedId === item.id ? <CheckCircle className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4 text-white" />}
                        </button>
                        <pre className="bg-slate-900 text-slate-100 rounded p-3 overflow-x-auto text-sm pr-12"><code>{item.rightCode}</code></pre>
                      </div>

                      <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-4">
                        <div className="flex items-center gap-2 font-semibold text-blue-900"><Zap className="w-4 h-4" /> Why this matters</div>
                        <div className="text-slate-700 mt-1">{item.explanation}</div>
                      </div>

                      <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4">
                        <div className="font-semibold text-yellow-900 mb-2">Also check for:</div>
                        <ul className="space-y-1 text-sm text-slate-700">
                          {item.additionalIssues.map((a, idx) => (
                            <li key={idx} className="flex gap-2"><span className="font-bold text-yellow-600">•</span>{a}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  )
}
