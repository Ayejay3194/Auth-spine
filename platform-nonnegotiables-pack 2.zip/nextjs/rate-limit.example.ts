// Example interface. Implement with Redis or a managed KV.
// This exists because "we'll do rate limiting later" is how platforms get owned.

export async function rateLimitOrThrow(key: string, limit: number, windowSec: number) {
  // pseudo:
  // const count = await redis.incr(key)
  // if (count === 1) await redis.expire(key, windowSec)
  // if (count > limit) throw new Error("RATE_LIMITED")
  return;
}
