# MULTI-TENANCY DISASTERS

## Tenant Isolation Failures

- [ ] No tenant isolation
- [ ] Data bleeding between tenants
- [ ] One tenant seeing another’s data
- [ ] Tenant ID not checked
- [ ] Hardcoded tenant ID
- [ ] Tenant context lost
- [ ] Query forgetting tenant filter
- [ ] Admin can’t access all tenants
- [ ] Cross-tenant queries too easy
- [ ] No audit of cross-tenant access
- [ ] Shared resources causing interference
- [ ] One tenant affecting another’s performance
- [ ] Resource quotas not enforced per tenant
- [ ] Tenant deletion not complete
- [ ] Orphaned data after tenant deletion

## Multi-Tenant Specific Issues

- [ ] Cannot provision new tenants
- [ ] Tenant provisioning too slow
- [ ] Tenant onboarding broken
- [ ] Cannot customize per tenant
- [ ] Tenant branding not working
- [ ] Tenant-specific features broken
- [ ] Cannot manage tenant settings
- [ ] Tenant billing issues
- [ ] Cannot track usage per tenant
- [ ] Tenant suspension not working
- [ ] Reactivation not working
- [ ] Data export per tenant broken
- [ ] Tenant analytics broken

---
