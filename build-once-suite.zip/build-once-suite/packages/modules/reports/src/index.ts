export type ReportType = "users" | "revenue" | "activity" | "audits";
export type ReportRequest = { type: ReportType; filters: Record<string,string>; format: "csv" | "xlsx" | "pdf" };

export interface ReportEngine {
  generate(req: ReportRequest): Promise<Uint8Array>;
  filename(req: ReportRequest): string;
}

export class CsvReportEngine implements ReportEngine {
  async generate(req: ReportRequest): Promise<Uint8Array> {
    // demo: outputs filters as CSV
    const rows = [["key","value"], ...Object.entries(req.filters)];
    const csv = rows.map(r => r.map(x => `"${String(x).replaceAll('"','""')}"`).join(",")).join("\n");
    return new TextEncoder().encode(csv);
  }
  filename(req: ReportRequest) { return `${req.type}-${Date.now()}.csv`; }
}
