// subscriptions entities.ts
