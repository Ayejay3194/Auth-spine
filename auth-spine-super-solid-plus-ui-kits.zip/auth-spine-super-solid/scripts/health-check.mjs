const url = process.env.HEALTH_URL || "http://localhost:3000/api/health";
const res = await fetch(url);
const body = await res.text();
if(!res.ok){
  console.error("Health check failed:", res.status, body);
  process.exit(1);
}
console.log("✅ Health OK:", body);
