import type { Incident } from "../types.js";

export interface IIncidentNotifier {
  notify(incident: Incident): Promise<void>;
}
