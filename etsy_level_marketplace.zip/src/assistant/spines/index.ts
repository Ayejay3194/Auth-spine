import type { ToolRegistry } from "../../core/types.js";
import type { SessionStore } from "../storage/sessionStore.js";
import type { BookingProvider, CRMProvider, PaymentsProvider, MarketingProvider, AnalyticsProvider, OpsProvider, AdminProvider, InventoryProvider, FulfillmentProvider } from "../providers/types.js";

// In this repo, the deterministic kernel already exists under /src.
// We expose provider-backed tools with IDs that match runtime intent strings.

export type Providers = {
  booking: BookingProvider;
  crm: CRMProvider;
  payments: PaymentsProvider;
  marketing: MarketingProvider;
  analytics: AnalyticsProvider;
  ops: OpsProvider;
  admin: AdminProvider;
  inventory: InventoryProvider;
  fulfillment: FulfillmentProvider;
};

export function loadAllSpines(opts: { providers: Providers; slotCache: SessionStore<any> }) {
  const tools: ToolRegistry = {
    "booking.create": async ({ ctx, input }) => {
      // Option A: if slotId provided, book directly. Else find slots then ask user to pick.
      const slotId = input.slotId as string | undefined;
      if (!slotId) return { ok: false, error: { code: "missing_slot", message: "Missing slotId. Use findSlots first." } };
      const res = await opts.providers.booking.createBooking({ userId: ctx.actor.userId, slotId, service: String(input.service) });
      return { ok: true, data: res };
    },
    "booking.find_slots": async ({ ctx, input }) => {
      const res = await opts.providers.booking.findSlots({
        userId: ctx.actor.userId,
        dateISO: input.dateISO as any,
        durationMin: Number(input.durationMin),
        service: input.service as any,
      });
      // cache last slots to allow "pick slot 2" flows later
      await opts.slotCache.set(`slots:${ctx.tenantId}:${ctx.actor.userId}`, res, 600);
      return { ok: true, data: res };
    },
    "booking.cancel": async ({ _ctx, input }) => {
      const res = await opts.providers.booking.cancelBooking({ bookingId: String(input.bookingId) });
      return { ok: true, data: res };
    },
    "booking.list": async ({ ctx }) => {
      const res = await opts.providers.booking.listBookings({ userId: ctx.actor.userId });
      return { ok: true, data: res };
    },

    "crm.find_client": async ({ _ctx, input }) => {
      const res = await opts.providers.crm.findClient({ query: String(input.clientQuery ?? input.query ?? "") });
      return { ok: true, data: res };
    },
    "crm.add_note": async ({ _ctx, input }) => {
      await opts.providers.crm.addNote({ clientId: String(input.clientId), note: String(input.note) });
      return { ok: true, data: { ok: true } };
    },
    "crm.tag_client": async ({ _ctx, input }) => {
      await opts.providers.crm.tagClient({ clientId: String(input.clientId), tag: String(input.tag) });
      return { ok: true, data: { ok: true } };
    },

    "payments.create_invoice": async ({ _ctx, input }) => {
      const res = await opts.providers.payments.createInvoice({ clientId: String(input.clientId), amount: Number(input.amount) });
      return { ok: true, data: res };
    },
    "payments.refund": async ({ _ctx, input }) => {
      const res = await opts.providers.payments.refund({ invoiceId: String(input.invoiceId), amount: input.amount ? Number(input.amount) : undefined });
      return { ok: true, data: res };
    },

    "marketing.create_promo": async ({ _ctx, input }) => {
      const res = await opts.providers.marketing.createPromo({ code: String(input.code), percentOff: Number(input.percentOff), expiresISO: input.expiresISO as any });
      return { ok: true, data: res };
    },
    "marketing.send_campaign": async ({ _ctx, input }) => {
      const res = await opts.providers.marketing.sendCampaign({ segment: String(input.segment), message: String(input.message) });
      return { ok: true, data: res };
    },

    "analytics.kpi": async ({ ctx }) => {
      const res = await opts.providers.analytics.kpis({ businessId: ctx.tenantId, userId: ctx.actor.userId });
      return { ok: true, data: res };
    },
    "analytics.report_export": async ({ _ctx, input }) => {
      const res = await opts.providers.analytics.exportReport({ report: String(input.report), format: (String(input.format) as any) ?? "csv" });
      return { ok: true, data: res };
    },

    "ops.list_tasks": async ({ _ctx }) => {
      const res = await opts.providers.ops.listTasks({});
      return { ok: true, data: res };
    },
    "ops.create_task": async ({ _ctx, input }) => {
      const res = await opts.providers.ops.createTask({ title: String(input.title) });
      return { ok: true, data: res };
    },

    "gdpr.export_request": async ({ ctx, _input }) => {
      const res = await opts.providers.admin.gdprExport({ userId: ctx.actor.userId });
      return { ok: true, data: res };
    },

    "admin.show_audit": async ({ _ctx, input }) => {
      const res = await opts.providers.admin.showAudit({ limit: Number(input.limit ?? 50) });
      return { ok: true, data: res };
    },

"inventory.list_products": async ({ _ctx, input }) => {
  const res = await opts.providers.inventory.listProducts({ query: input.query as any, limit: Number(input.limit ?? 50) });
  return { ok: true, data: res };
},
"inventory.create_product": async ({ _ctx, input }) => {
  const res = await opts.providers.inventory.createProduct({ sku: String(input.sku), name: String(input.name), price: Number(input.price), active: input.active as any });
  return { ok: true, data: res };
},
"inventory.update_stock": async ({ _ctx, input }) => {
  const res = await opts.providers.inventory.updateStock({ productId: String(input.productId), delta: Number(input.delta), reason: String(input.reason ?? "adjustment") });
  return { ok: true, data: res };
},
"inventory.low_stock": async ({ _ctx, input }) => {
  const res = await opts.providers.inventory.lowStock({ threshold: Number(input.threshold ?? 5), limit: Number(input.limit ?? 50) });
  return { ok: true, data: res };
},

"fulfillment.list_orders": async ({ _ctx, input }) => {
  const res = await opts.providers.fulfillment.listOrders({ status: input.status as any, limit: Number(input.limit ?? 50) });
  return { ok: true, data: res };
},
"fulfillment.create_shipment": async ({ _ctx, input }) => {
  const res = await opts.providers.fulfillment.createShipment({ orderId: String(input.orderId), carrier: input.carrier as any, serviceLevel: input.serviceLevel as any });
  return { ok: true, data: res };
},
"fulfillment.add_tracking": async ({ _ctx, input }) => {
  const res = await opts.providers.fulfillment.addTracking({ shipmentId: String(input.shipmentId), carrier: String(input.carrier), tracking: String(input.tracking) });
  return { ok: true, data: res };
},
"fulfillment.mark_delivered": async ({ _ctx, input }) => {
  const res = await opts.providers.fulfillment.markDelivered({ shipmentId: String(input.shipmentId) });
  return { ok: true, data: res };
},
  };

  // flows are provided by the core kernel already; this wrapper keeps it as "tool calls + confirmations"
  const flows = {};
  return { tools, flows };
}
