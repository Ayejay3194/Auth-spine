import { ProductCaps, RiskContext, ToneCategory, ToneDecisionInput, ToneDecisionOutput, ToneLine, ToneState } from "./types";

const HIGH_INTENSITY = 4;

const CAPS: Record<string, ProductCaps> = {
  support: { maxLines: 2, maxHighIntensity: 0, snarkMax: 0, annoyedMax: 0, disallowed: ["annoyed","snark"] },
  consumer_app: { maxLines: 3, maxHighIntensity: 1, snarkMax: 1, annoyedMax: 0 },
  internal_tools: { maxLines: 3, maxHighIntensity: 1, snarkMax: 1, annoyedMax: 1 },
  other: { maxLines: 3, maxHighIntensity: 1, snarkMax: 1, annoyedMax: 0 },
};

function isRisky(risk: RiskContext) {
  return risk !== "none";
}

function recentlyEscalated(state: ToneState): boolean {
  const last = state.lastIntensities.slice(-2);
  return last.length === 2 && last[0] >= HIGH_INTENSITY && last[1] >= HIGH_INTENSITY;
}

function allowedCategories(input: ToneDecisionInput, state: ToneState): Set<ToneCategory> {
  const base = new Set<ToneCategory>([
    "clarity","technical","corrective","probing","mentoring","sharp-care","deescalation","meta","confidence",
    "executive","product-voice","terse","apology-lite","dry","amused","playful","boundary","snark","annoyed",
  ]);

  if (isRisky(input.risk) || state.sarcasmLock) {
    base.delete("snark");
    base.delete("annoyed");
  }
  if (input.confidence < 0.6) {
    base.delete("snark");
    base.delete("annoyed");
  }
  if (input.trigger === "hostility" || input.trigger === "user_frustration") {
    base.delete("snark");
    base.delete("annoyed");
    base.add("deescalation");
    base.add("clarity");
  }
  return base;
}

function applyCaps(lines: ToneLine[], caps: ProductCaps): ToneLine[] {
  const disallowed = new Set(caps.disallowed ?? []);
  let highs = 0, snark = 0, annoyed = 0;
  const out: ToneLine[] = [];
  for (const l of lines) {
    if (disallowed.has(l.category)) continue;
    if (l.intensity >= HIGH_INTENSITY) {
      if (highs >= caps.maxHighIntensity) continue;
      highs++;
    }
    if (l.category === "snark") {
      if (snark >= caps.snarkMax) continue;
      snark++;
    }
    if (l.category === "annoyed") {
      if (annoyed >= caps.annoyedMax) continue;
      annoyed++;
    }
    out.push(l);
    if (out.length >= caps.maxLines) break;
  }
  return out;
}

function avoidRepetition(lines: ToneLine[], state: ToneState): ToneLine[] {
  return lines.filter(l => !state.usedIds.has(l.id));
}

function score(line: ToneLine, input: ToneDecisionInput, state: ToneState): number {
  let s = 0;
  if (line.trigger === input.trigger) s += 50;
  if (input.trigger === "implementation" && (line.category === "technical" || line.category === "clarity")) s += 20;
  if ((input.trigger === "user_frustration" || input.trigger === "hostility") && line.category === "deescalation") s += 25;
  if (input.confidence < 0.75 && line.intensity >= HIGH_INTENSITY) s -= 30;

  const tol = state.tolerance ?? 0.5;
  if (line.category === "snark") s += Math.round((tol - 0.5) * 20);

  if (recentlyEscalated(state) && line.intensity >= HIGH_INTENSITY) s -= 50;

  s += (6 - line.intensity);
  return s;
}

export function chooseToneLines(pool: ToneLine[], input: ToneDecisionInput, state: ToneState): ToneDecisionOutput {
  const caps = CAPS[input.product] ?? CAPS.other;
  const maxLines = input.maxLines ?? caps.maxLines;

  const allowed = allowedCategories(input, state);
  let candidates = pool.filter(l => allowed.has(l.category));

  const triggerMatches = candidates.filter(l => l.trigger === input.trigger);
  const filteredByTrigger = triggerMatches.length > 0;
  if (filteredByTrigger) candidates = triggerMatches;

  candidates = avoidRepetition(candidates, state);

  const appliedDeescalation = recentlyEscalated(state);
  candidates.sort((a, b) => score(b, input, state) - score(a, input, state));

  const prePick = candidates.slice(0, Math.max(50, maxLines * 20));
  const selected = applyCaps(prePick, { ...caps, maxLines });

  const reason =
    isRisky(input.risk) || state.sarcasmLock
      ? "risk/lock gating"
      : input.confidence < 0.6
      ? "low confidence gating"
      : appliedDeescalation
      ? "auto de-escalation"
      : filteredByTrigger
      ? "trigger match"
      : "best available";

  return {
    selected,
    reason,
    diagnostics: {
      candidateCount: candidates.length,
      filteredByTrigger,
      appliedDeescalation,
      appliedCaps: true,
    },
  };
}
