    import { Spine, Intent, AssistantContext, Extraction, FlowStep } from "../../core/types.js";
    import { detectByPatterns } from "../../core/intent.js";
    import { requireFields } from "../../core/entities.js";
    import { patterns } from "./intents.js";

    const REQUIRED: Record<string, string[]> = {
  "list_products": [],
  "create_product": [
    "sku",
    "name",
    "price"
  ],
  "update_stock": [
    "productId",
    "delta"
  ],
  "low_stock": []
};
    const MAP: Record<string, { tool: string; action: string; sensitivity: "low"|"medium"|"high" }> = {
  "list_products": {
    "tool": "inventory.list_products",
    "action": "inventory.list_products",
    "sensitivity": "low"
  },
  "create_product": {
    "tool": "inventory.create_product",
    "action": "inventory.create_product",
    "sensitivity": "high"
  },
  "update_stock": {
    "tool": "inventory.update_stock",
    "action": "inventory.update_stock",
    "sensitivity": "high"
  },
  "low_stock": {
    "tool": "inventory.low_stock",
    "action": "inventory.low_stock",
    "sensitivity": "low"
  }
};

    function baseEntities(text: string): Record<string, unknown> {
      const out: Record<string, unknown> = {};

      // productId / orderId / shipmentId / sku extraction
      const pid = text.match(/\b(product_[a-z0-9]+)\b/i);
      if (pid) out.productId = pid[1];
      const oid = text.match(/\b(order_[a-z0-9]+)\b/i);
      if (oid) out.orderId = oid[1];
      const sid = text.match(/\b(shipment_[a-z0-9]+)\b/i);
      if (sid) out.shipmentId = sid[1];

      const sku = text.match(/\bsku\s*[:#]?\s*([a-z0-9_-]{3,32})\b/i);
      if (sku) out.sku = sku[1].toUpperCase();

      const price = text.match(/\$\s*(\d+(?:\.\d{1,2})?)/);
      if (price) out.price = Number(price[1]);

      // delta stock: +5, -3, "add 5", "remove 2"
      const d1 = text.match(/\b([+-]\d+)\b/);
      if (d1) out.delta = Number(d1[1]);
      const d2 = text.match(/\b(?:add|increase)\s+(\d+)\b/i);
      if (d2) out.delta = Number(d2[1]);
      const d3 = text.match(/\b(?:remove|decrease)\s+(\d+)\b/i);
      if (d3) out.delta = -Number(d3[1]);

      const th = text.match(/\bthreshold\s+(\d+)\b/i);
      if (th) out.threshold = Number(th[1]);

      // tracking / carrier
      const tr = text.match(/\btracking\s*[:#]?\s*([a-z0-9-]{6,40})\b/i);
      if (tr) out.tracking = tr[1];
      const cr = text.match(/\bcarrier\s*[:#]?\s*([a-z][a-z0-9_-]{2,20})\b/i);
      if (cr) out.carrier = cr[1];

      // name: "name X", or after "product"
      const nm = text.match(/\bname\s+(.+)$/i);
      if (nm) out.name = nm[1].trim();

      // reason: "reason X"
      const rs = text.match(/\breason\s+(.+)$/i);
      if (rs) out.reason = rs[1].trim();

      return out;
    }

    export const spine: Spine = {
      name: "inventory",
      description: "Inventory: products, stock levels, low-stock alerts",
      detectIntent: (text, _ctx) => detectByPatterns(text, patterns),
      extractEntities: (intent: Intent, text: string, _ctx: AssistantContext): Extraction => {
        const entities = baseEntities(text);



        const req = REQUIRED[intent.name] ?? [];
        const missing = requireFields(entities, req);
        return { entities, missing };
      },
      buildFlow: (intent, extraction, _ctx): FlowStep[] => {
        if (extraction.missing.length) {
          return [{ kind: "ask", prompt: `Missing: ${extraction.missing.join(", ")}`, missing: extraction.missing }];
        }
        const m = MAP[intent.name];
        if (!m) return [{ kind: "respond", message: `No mapping for intent: ${intent.name}` }];

        return [{
          kind: "execute",
          action: m.action,
          sensitivity: m.sensitivity,
          tool: m.tool,
          input: extraction.entities,
        }];
      },
    };
