import Link from "next/link";

export default function Home() {
  return (
    <div className="glass rounded-xl2 p-6">
      <div className="text-xs font-extrabold tracking-[0.22em] text-white/60 uppercase">Starter</div>
      <h1 className="mt-2 text-4xl font-black tracking-tight">
        Responsive layout + <span className="text-gold">Auth Gate</span>
      </h1>
      <p className="mt-3 text-white/70 leading-relaxed max-w-2xl">
        Mobile vs desktop layout is handled by Tailwind breakpoints (CSS). Auth + authorization is handled once with a Protected gate.
      </p>

      <div className="mt-6 flex flex-wrap gap-3">
        <Link className="btn btn-primary" href="/map">Map</Link>
        <Link className="btn" href="/inbox">Inbox</Link>
        <Link className="btn" href="/boards">Boards</Link>
        <Link className="btn" href="/profile">Me</Link>
        <Link className="btn" href="/natal">Natal</Link>
        <Link className="btn" href="/hd">HD</Link>
      </div>

      <div className="mt-6 flex flex-wrap gap-2 text-xs text-white/65">
        <span className="pill">Rule: Non-map pages show mini-map rail</span>
        <span className="pill">Rule: Map page shows feed rail</span>
        <span className="pill">Fake auth: use top-right button</span>
      </div>
    </div>
  );
}
