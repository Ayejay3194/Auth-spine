import { RequestContext } from "../types";

export type TenantSource = "header" | "body" | "query" | "ctx";

export type TenantGuardOptions = {
  headerName?: string; // default: x-tenant-id
  allowMissing?: boolean; // default false
};

export function resolveTenantId(input: {
  headers?: Record<string,string>;
  query?: Record<string,string|undefined>;
  body?: any;
  ctx?: RequestContext;
}, opts: TenantGuardOptions = {}): { tenantId?: string; source?: TenantSource } {
  const headerName = (opts.headerName ?? "x-tenant-id").toLowerCase();
  const fromHeader = input.headers?.[headerName] ?? input.headers?.[headerName.toUpperCase()];
  if (fromHeader) return { tenantId: fromHeader, source: "header" };

  const fromCtx = input.ctx?.tenantId;
  if (fromCtx) return { tenantId: fromCtx, source: "ctx" };

  const fromBody = input.body?.tenantId;
  if (typeof fromBody === "string" && fromBody) return { tenantId: fromBody, source: "body" };

  const fromQuery = input.query?.tenantId;
  if (typeof fromQuery === "string" && fromQuery) return { tenantId: fromQuery, source: "query" };

  return { tenantId: undefined, source: undefined };
}

export function assertTenant(ctx: RequestContext): void {
  if (!ctx?.tenantId) throw new Error("Missing tenantId (fail closed).");
  if (!/^[a-zA-Z0-9_\-]{3,128}$/.test(ctx.tenantId)) {
    throw new Error("Invalid tenantId format.");
  }
}

export function withTenantGuard<TReq>(
  handler: (req: TReq, ctx: RequestContext) => Promise<any>,
  opts: TenantGuardOptions = {}
) {
  return async (req: any, ctx: RequestContext) => {
    const { tenantId } = resolveTenantId({ headers: req?.headers, body: req?.body, query: req?.query, ctx }, opts);
    if (tenantId) ctx.tenantId = tenantId;
    if (!opts.allowMissing) assertTenant(ctx);
    return handler(req, ctx);
  };
}
