# Validation Framework Test Suite (Hardened)

This pack replaces brittle tests with deterministic, behavior-driven tests.

## What you get
- Deterministic harness (frozen time)
- Golden fixtures pattern
- Behavior assertions (no fragile hard-coded counts)
- Perf tests gated behind `RUN_PERF=1`

## Drop-in usage
1. Copy this folder into your repo (e.g. `tests/validation/`).
2. Ensure Jest uses the setup file:
   - `setupFilesAfterEnv: ["<rootDir>/tests/validation/jest.setup.ts"]`
3. Run:
   - `npm test`
   - `RUN_PERF=1 npm test` (optional perf checks)

## Assumptions
Your implementation exports the imports used in the tests. If paths differ, adjust imports in:
- `comprehensive.validation.stable.test.ts`
- `perf.validation.bench.test.ts`
