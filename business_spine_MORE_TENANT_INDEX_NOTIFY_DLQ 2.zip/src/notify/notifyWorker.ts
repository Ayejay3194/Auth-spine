import type { Notification } from "./types";
import { templates } from "./templates";
import { deliver, ConsoleEmail, ConsoleSMS, ConsolePush } from "./providers";
import { idempotency } from "@/src/queue/idempotency";

const providers = { email: ConsoleEmail, sms: ConsoleSMS, push: ConsolePush };

export async function handleNotifyJob(job: any) {
  if (job.name !== "notify_send") return null;
  const n = job.data as Notification;

  // Idempotency
  if (n.idempotencyKey) {
    const ok = await idempotency.claim(`notify:${n.idempotencyKey}`, 60 * 60);
    if (!ok) return { ok: true, deduped: true };
  }

  const render = templates[n.template];
  if (!render) throw new Error(`Unknown template: ${n.template}`);

  const rendered = render(n.vars ?? {});
  await deliver(providers, n, rendered);
  return { ok: true };
}
