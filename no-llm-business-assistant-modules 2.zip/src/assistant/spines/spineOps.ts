import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerOpsTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "ops.list_tasks",
    title: "List tasks",
    description: "Lists open tasks.",
    inputSchema: { type: "object", properties: {} },
    async run(ctx, input) {
      const data = await p.ops.listTasks({});
      return { ok: true, data };
    }
  });

  reg.register({
    id: "ops.create_task",
    title: "Create task",
    description: "Creates a new task.",
    inputSchema: { type: "object", properties: { title: { type: "string" } }, required: ["title"] },
    async run(ctx, input) {
      const data = await p.ops.createTask({ title: input.title });
      return { ok: true, data };
    }
  });
}
