import { expect } from "vitest";

export function expectNotAllowed(status: number) {
  expect([401, 403, 404]).toContain(status);
}
