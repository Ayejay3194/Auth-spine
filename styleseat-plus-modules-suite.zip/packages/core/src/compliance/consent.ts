import type { ID, ISODateTime, Result } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type ConsentType = "email_marketing" | "sms_marketing" | "transactional";
export type Consent = { id: ID; businessId: ID; clientId: ID; type: ConsentType; granted: boolean; at: ISODateTime };

export class ConsentStore {
  private consents: Consent[] = [];
  grant(businessId: ID, clientId: ID, type: ConsentType, at: ISODateTime): Consent {
    const c: Consent = { id: cuid("cns"), businessId, clientId, type, granted: true, at };
    this.consents.push(c); return c;
  }
  revoke(businessId: ID, clientId: ID, type: ConsentType, at: ISODateTime): Consent {
    const c: Consent = { id: cuid("cns"), businessId, clientId, type, granted: false, at };
    this.consents.push(c); return c;
  }
  has(businessId: ID, clientId: ID, type: ConsentType): boolean {
    const latest = [...this.consents].reverse().find(c => c.businessId===businessId && c.clientId===clientId && c.type===type);
    return latest?.granted ?? (type === "transactional"); // transactional default true
  }
  require(businessId: ID, clientId: ID, type: ConsentType): Result<true> {
    return this.has(businessId, clientId, type) ? { ok: true, data: true } : { ok: false, error: { code: "CONSENT_REQUIRED", message: `Consent required: ${type}` } };
  }
}
