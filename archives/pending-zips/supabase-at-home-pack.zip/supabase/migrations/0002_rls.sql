-- RLS on
alter table profiles enable row level security;
alter table bookings enable row level security;
alter table salon_memberships enable row level security;

-- Profiles: self read
drop policy if exists "self profile" on profiles;
create policy "self profile"
on profiles for select
using (auth.uid() = id);

-- Bookings: stylist + client read
drop policy if exists "stylist bookings" on bookings;
create policy "stylist bookings"
on bookings for select
using (auth.uid() = stylist_id);

drop policy if exists "client bookings" on bookings;
create policy "client bookings"
on bookings for select
using (auth.uid() = client_id);

-- Salon manager/owner read bookings for their salon
drop policy if exists "salon manager bookings" on bookings;
create policy "salon manager bookings"
on bookings for select
using (
  exists (
    select 1 from salon_memberships sm
    where sm.user_id = auth.uid()
      and sm.salon_id = bookings.salon_id
      and sm.role in ('MANAGER','OWNER')
  )
);
