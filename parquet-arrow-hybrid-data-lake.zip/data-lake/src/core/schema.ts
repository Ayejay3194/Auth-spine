export type ResidualRow = {
  ts: string;            // ISO timestamp
  body: string;          // e.g. "Mercury"
  dx_arcsec: number;
  dy_arcsec: number;
  model_version: number; // int-ish
};

export const ResidualSchema = {
  schemaName: "residuals",
  schemaVersion: "1",
  required: ["ts", "body", "dx_arcsec", "dy_arcsec", "model_version"] as const,
};
