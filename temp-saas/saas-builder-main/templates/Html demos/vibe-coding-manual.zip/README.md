# Vibe Coding Manual – Multi-Model Workflow

This package explains how to:
- Ideate and design products with a chat model.
- Use GLM / chat.z.ai as a zip intake + system builder.
- Use Claude / code-focused models inside Windsurf or Cursor to build and refactor.
- Work specifically with React, Next.js, Tailwind, DaisyUI, MUI, shadcn/ui, lucide-react, and React Context.
- Keep the codebase clean, modular, and maintainable.

Read `manual/00-overview.md` first.
Then follow the workflow in order.
