export function validateNLU(nlu) {
  if (!nlu || !nlu.intent || nlu.confidence < 0.6) {
    return { intent: "fallback", confidence: 0 };
  }
  return nlu;
}
