APPROVAL RULES
--------------
Require approval for:
- refunds
- payroll runs
- role changes
- exports
- pricing changes
