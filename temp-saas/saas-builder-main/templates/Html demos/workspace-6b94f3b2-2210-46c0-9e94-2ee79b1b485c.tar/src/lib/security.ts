import { z } from 'zod'
import { NextRequest } from 'next/server'

// Rate limiting store (in production, use Redis)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

export function rateLimit(
  identifier: string,
  limit: number = 100,
  windowMs: number = 60 * 1000 // 1 minute
): { success: boolean; resetTime?: number } {
  const now = Date.now()
  const key = identifier

  const existing = rateLimitStore.get(key)
  
  if (!existing || now > existing.resetTime) {
    rateLimitStore.set(key, {
      count: 1,
      resetTime: now + windowMs,
    })
    return { success: true }
  }

  if (existing.count >= limit) {
    return { success: false, resetTime: existing.resetTime }
  }

  existing.count++
  return { success: true }
}

// Input validation schemas
export const schemas = {
  workspace: {
    create: z.object({
      name: z.string().min(1).max(100),
      slug: z.string().min(1).max(50).regex(/^[a-z0-9-]+$/),
      description: z.string().optional(),
    }),
    update: z.object({
      name: z.string().min(1).max(100).optional(),
      description: z.string().optional(),
      settings: z.any().optional(),
    }),
  },
  
  user: {
    invite: z.object({
      email: z.string().email(),
      role: z.enum(['OWNER', 'ADMIN', 'MEMBER', 'VIEWER']),
    }),
    updateRole: z.object({
      role: z.enum(['OWNER', 'ADMIN', 'MEMBER', 'VIEWER']),
    }),
  },
  
  project: {
    create: z.object({
      name: z.string().min(1).max(100),
      description: z.string().optional(),
    }),
    update: z.object({
      name: z.string().min(1).max(100).optional(),
      description: z.string().optional(),
      status: z.enum(['ACTIVE', 'COMPLETED', 'ARCHIVED', 'CANCELLED']).optional(),
    }),
  },
  
  task: {
    create: z.object({
      title: z.string().min(1).max(200),
      description: z.string().optional(),
      priority: z.enum(['LOW', 'MEDIUM', 'HIGH', 'URGENT']).optional(),
      assignedTo: z.string().optional(),
      dueDate: z.string().optional(),
      projectId: z.string(),
    }),
    update: z.object({
      title: z.string().min(1).max(200).optional(),
      description: z.string().optional(),
      status: z.enum(['TODO', 'IN_PROGRESS', 'REVIEW', 'DONE']).optional(),
      priority: z.enum(['LOW', 'MEDIUM', 'HIGH', 'URGENT']).optional(),
      assignedTo: z.string().optional(),
      dueDate: z.string().optional(),
    }),
  },
  
  billing: {
    subscribe: z.object({
      planId: z.string(),
      workspaceId: z.string(),
    }),
  },
}

// Security headers
export function setSecurityHeaders(response: Response) {
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('X-XSS-Protection', '1; mode=block')
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
  return response
}

// CSRF protection (simplified)
export function validateCSRF(request: NextRequest): boolean {
  const origin = request.headers.get('origin')
  const host = request.headers.get('host')
  
  // In production, validate against your allowed origins
  if (process.env.NODE_ENV === 'production') {
    const allowedOrigins = [
      `https://${host}`,
      'https://yourdomain.com',
    ]
    
    return origin ? allowedOrigins.includes(origin) : false
  }
  
  return true
}

// Input sanitization
export function sanitizeInput(input: string): string {
  return input
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .trim()
    .substring(0, 1000) // Limit length
}

// IP-based blocking
const blockedIPs = new Set<string>()

export function blockIP(ip: string, durationMs: number = 60 * 60 * 1000) {
  blockedIPs.add(ip)
  setTimeout(() => {
    blockedIPs.delete(ip)
  }, durationMs)
}

export function isIPBlocked(ip: string): boolean {
  return blockedIPs.has(ip)
}

// Get client IP
export function getClientIP(request: NextRequest): string {
  return (
    request.ip ||
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    request.headers.get('x-real-ip') ||
    'unknown'
  )
}