import { createAssistant } from "./assistant/assistant.js";
import { IntentDetector } from "./nlu/intents.js";
import { PolicyEngine, InMemoryRateStore } from "./policy/policy.js";
import { loadAllSpines } from "./spines/index.js";
import { makeSlotFillFlow } from "./flows/slotFillFlow.js";
import { makeConfirmFlow } from "./flows/confirmFlow.js";
import type { Providers } from "./providers/types.js";
import type { AuditLogger, Clock } from "./core/types.js";

export function buildRuntime(opts: { providers: Providers; audit: AuditLogger; clock: Clock }) {
  const { tools } = loadAllSpines(opts.providers);

  const detector = new IntentDetector(
    [
      // core
      { intent: "payments.create_invoice", any: ["invoice"], all: [] },
      { intent: "payments.refund", any: ["refund"], all: [] },
      { intent: "marketing.create_promo", any: ["promo", "discount"], all: [] },
      { intent: "analytics.kpi", any: ["kpi", "revenue", "metrics"], all: [] },
      { intent: "ops.list_tasks", any: ["tasks", "todo"], all: [] },
      { intent: "admin.show_audit", any: ["audit"], all: [] },
      { intent: "gdpr.export_request", any: ["gdpr", "export"], all: [] },

      // marketplace
      { intent: "market.search_providers", any: ["search", "find"], all: ["providers"] },
      { intent: "market.search_slots", any: ["slots", "availability"], all: [] },
      { intent: "market.booking.hold", any: ["hold", "reserve"], all: [] },
      { intent: "market.booking.confirm", any: ["confirm"], all: ["hold"] },
      { intent: "market.booking.cancel", any: ["cancel"], all: ["booking"] },
      { intent: "market.payments.create_intent", any: ["payment"], all: ["hold"] },
      { intent: "market.payout.schedule", any: ["payout"], all: [] },
      { intent: "market.refund.issue", any: ["refund"], all: ["booking"] },
      { intent: "market.message.send", any: ["message"], all: ["booking"] },
      { intent: "market.review.submit", any: ["review"], all: [] },
      { intent: "market.dispute.open", any: ["dispute"], all: ["open"] },
      { intent: "market.dispute.resolve", any: ["dispute"], all: ["resolve"] },
    ],
    [
      { intent: "market.search_providers", utterance: "search providers for braids near atlanta" },
      { intent: "market.booking.hold", utterance: "hold provider prov_1 for client cl_1 next friday evening" },
      { intent: "market.payments.create_intent", utterance: "create payment for hold hold_1 $120" },
      { intent: "market.booking.confirm", utterance: "confirm hold hold_1" },
      { intent: "market.dispute.open", utterance: "open dispute for bk_1 client no show" },
      { intent: "analytics.kpi", utterance: "show revenue" },
    ],
    { minScore: 0.25 }
  );

  const policy = new PolicyEngine(new InMemoryRateStore(), {
    allow: {
      owner: tools.list().map(t => t.id),
      admin: tools.list().map(t => t.id),
      support: tools.list().filter(t => t.id.startsWith("market.dispute") || t.id === "admin.show_audit").map(t => t.id),
      provider: tools.list().filter(t => !t.id.startsWith("admin.") && !t.id.startsWith("gdpr.")).map(t => t.id),
      client: tools.list().filter(t => t.id.startsWith("market.search") || t.id.startsWith("market.booking") || t.id === "market.message.send" || t.id === "market.review.submit").map(t => t.id),
      staff: tools.list().filter(t => !t.id.startsWith("admin.") && !t.id.startsWith("market.payout")).map(t => t.id),
      assistant: tools.list().filter(t => !t.id.startsWith("admin.") && !t.id.includes("refund") && !t.id.includes("payout")).map(t => t.id),
      accountant: tools.list().filter(t => t.id.includes("payments") || t.id.includes("payout") || t.id === "analytics.kpi").map(t => t.id),
    },
    rate: { windowSeconds: 10, max: 80 },
    confirmIntents: [
      "payments.create_invoice",
      "payments.refund",
      "gdpr.export_request",
      "market.booking.cancel",
      "market.refund.issue",
      "market.payout.schedule",
      "market.dispute.resolve"
    ],
    confirmPhrase: "YES"
  });

  const flows = [makeSlotFillFlow(opts.audit), makeConfirmFlow(opts.audit)];

  const assistant = createAssistant({ tools, policy, audit: opts.audit, clock: opts.clock, detector, flows });
  return { assistant };
}
