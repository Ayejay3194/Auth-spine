import { Role, Permission } from './types'

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  OWNER: [
    // Workspace permissions
    'workspace:read',
    'workspace:write',
    'workspace:delete',
    'workspace:members:read',
    'workspace:members:write',
    'workspace:billing:read',
    'workspace:billing:write',
    
    // Project permissions
    'project:read',
    'project:write',
    'project:delete',
    
    // Task permissions
    'task:read',
    'task:write',
    'task:delete',
  ],
  ADMIN: [
    // Workspace permissions (except delete and billing)
    'workspace:read',
    'workspace:write',
    'workspace:members:read',
    'workspace:members:write',
    
    // Project permissions
    'project:read',
    'project:write',
    'project:delete',
    
    // Task permissions
    'task:read',
    'task:write',
    'task:delete',
  ],
  MEMBER: [
    // Basic workspace access
    'workspace:read',
    
    // Project permissions
    'project:read',
    'project:write',
    
    // Task permissions
    'task:read',
    'task:write',
  ],
  VIEWER: [
    // Read-only access
    'workspace:read',
    'project:read',
    'task:read',
  ],
}

export const ADMIN_PERMISSIONS: Permission[] = [
  'admin:impersonate',
  'admin:system:read',
]

export function hasPermission(
  userRole: Role,
  permission: Permission,
  isAdmin: boolean = false
): boolean {
  // Admin users have all admin permissions
  if (isAdmin && ADMIN_PERMISSIONS.includes(permission)) {
    return true
  }
  
  const rolePermissions = ROLE_PERMISSIONS[userRole]
  return rolePermissions.includes(permission)
}

export function hasAnyPermission(
  userRole: Role,
  permissions: Permission[],
  isAdmin: boolean = false
): boolean {
  return permissions.some(permission => hasPermission(userRole, permission, isAdmin))
}

export function hasAllPermissions(
  userRole: Role,
  permissions: Permission[],
  isAdmin: boolean = false
): boolean {
  return permissions.every(permission => hasPermission(userRole, permission, isAdmin))
}

export function canAccessResource(
  userRole: Role,
  action: 'read' | 'write' | 'delete',
  resource: 'workspace' | 'project' | 'task' | 'members' | 'billing',
  isAdmin: boolean = false
): boolean {
  const permission = `${resource}:${action}` as Permission
  return hasPermission(userRole, permission, isAdmin)
}

// Higher-order function for API route protection
export function requirePermission(permission: Permission) {
  return (handler: (req: Request, context: any) => Promise<Response>) => {
    return async (req: Request, context: any) => {
      const { user, membership } = context
      
      if (!user) {
        return Response.json(
          { success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
          { status: 401 }
        )
      }
      
      if (!hasPermission(membership.role, permission, user.isAdmin)) {
        return Response.json(
          { success: false, error: { code: 'FORBIDDEN', message: 'Insufficient permissions' } },
          { status: 403 }
        )
      }
      
      return handler(req, context)
    }
  }
}

// Multiple permission checker
export function requireAnyPermission(permissions: Permission[]) {
  return (handler: (req: Request, context: any) => Promise<Response>) => {
    return async (req: Request, context: any) => {
      const { user, membership } = context
      
      if (!user) {
        return Response.json(
          { success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
          { status: 401 }
        )
      }
      
      if (!hasAnyPermission(membership.role, permissions, user.isAdmin)) {
        return Response.json(
          { success: false, error: { code: 'FORBIDDEN', message: 'Insufficient permissions' } },
          { status: 403 }
        )
      }
      
      return handler(req, context)
    }
  }
}

// Workspace ownership check
export function requireWorkspaceOwner() {
  return (handler: (req: Request, context: any) => Promise<Response>) => {
    return async (req: Request, context: any) => {
      const { user, membership } = context
      
      if (!user) {
        return Response.json(
          { success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
          { status: 401 }
        )
      }
      
      if (membership.role !== 'OWNER') {
        return Response.json(
          { success: false, error: { code: 'FORBIDDEN', message: 'Workspace owner access required' } },
          { status: 403 }
        )
      }
      
      return handler(req, context)
    }
  }
}

// Admin-only access
export function requireAdmin() {
  return (handler: (req: Request, context: any) => Promise<Response>) => {
    return async (req: Request, context: any) => {
      const { user } = context
      
      if (!user || !user.isAdmin) {
        return Response.json(
          { success: false, error: { code: 'FORBIDDEN', message: 'Admin access required' } },
          { status: 403 }
        )
      }
      
      return handler(req, context)
    }
  }
}