import crypto from "node:crypto";
import {
  BookingProvider, CRMProvider, PaymentsProvider, MarketingProvider, AnalyticsProvider, OpsProvider, AdminProvider,
  Slot, Booking, Client, Invoice, Promo, Referral, KPI, Task
} from "../providers/types.js";

function rid(prefix: string) { return `${prefix}_${crypto.randomBytes(3).toString("hex")}`; }

export class ProviderMock implements BookingProvider, CRMProvider, PaymentsProvider, MarketingProvider, AnalyticsProvider, OpsProvider, AdminProvider {
  private slots: Slot[] = [];
  private bookings: Booking[] = [];
  private clients: Client[] = [];
  private invoices: Invoice[] = [];
  private promos: Promo[] = [];
  private referrals: Referral[] = [{ code: "ref_abc123", referrerClientId: "cl_1", uses: 4 }];
  private tasks: Task[] = [{ taskId: "task_1", title: "Reply to leads", status: "open" }];

  constructor() {
    const now = new Date();
    for (let i=1;i<=10;i++) {
      const d = new Date(now); d.setDate(d.getDate()+i); d.setHours(18,0,0,0);
      this.slots.push({ slotId: rid("sl"), startISO: d.toISOString().slice(0,16), durationMin: 60 });
      d.setHours(19,0,0,0);
      this.slots.push({ slotId: rid("sl"), startISO: d.toISOString().slice(0,16), durationMin: 60 });
    }
    this.clients.push({ clientId: "cl_1", name: "Avery Client", email: "avery@example.com", phone: "555-111-2222", tags: ["vip"], notes: ["Prefers evenings"] });
  }

  // Booking
  async findSlots(input: { service: string; dateISO?: string; partOfDay?: string; durationMin: number }): Promise<Slot[]> {
    let s = this.slots.filter(x => x.durationMin === input.durationMin);
    if (input.dateISO) s = s.filter(x => x.startISO.startsWith(input.dateISO));
    if (input.partOfDay === "evening") s = s.filter(x => Number(x.startISO.slice(11,13)) >= 17);
    return s.slice(0, 8);
  }
  async createBooking(input: { userId: string; slotId: string; service: string }): Promise<Booking> {
    const b: Booking = { bookingId: rid("bk"), slotId: input.slotId, service: input.service, status: "confirmed" };
    this.bookings.push(b); return b;
  }
  async cancelBooking(input: { userId: string; bookingId: string }): Promise<Booking> {
    const b = this.bookings.find(x => x.bookingId === input.bookingId);
    if (!b) throw new Error("Booking not found");
    b.status = "canceled"; return b;
  }
  async listBookings(): Promise<Booking[]> { return this.bookings; }

  // CRM
  async findClient(input: { query: string }): Promise<Client | null> {
    const q = input.query.toLowerCase();
    return this.clients.find(c => c.name.toLowerCase().includes(q) || (c.email ?? "").toLowerCase() === q || (c.phone ?? "").includes(q)) ?? null;
  }
  async addNote(input: { clientId: string; note: string }): Promise<void> {
    const c = this.clients.find(x => x.clientId === input.clientId); if (!c) throw new Error("Client not found");
    c.notes.push(input.note);
  }
  async tagClient(input: { clientId: string; tag: string }): Promise<void> {
    const c = this.clients.find(x => x.clientId === input.clientId); if (!c) throw new Error("Client not found");
    if (!c.tags.includes(input.tag)) c.tags.push(input.tag);
  }
  async history(input: { clientId: string }) {
    return { bookings: this.bookings, invoices: this.invoices };
  }

  // Payments
  async createInvoice(input: { clientId: string; amount: number }): Promise<Invoice> {
    const inv: Invoice = { invoiceId: rid("in"), clientId: input.clientId, amount: input.amount, status: "sent" };
    this.invoices.push(inv); return inv;
  }
  async refund(input: { invoiceId: string; amount?: number }): Promise<Invoice> {
    const inv = this.invoices.find(x => x.invoiceId === input.invoiceId); if (!inv) throw new Error("Invoice not found");
    inv.status = "refunded"; return inv;
  }
  async applyCredit(_input: { clientId: string; amount: number }): Promise<void> { return; }

  // Marketing
  async createPromo(input: { code: string; percentOff: number }): Promise<Promo> {
    const p: Promo = { code: input.code, percentOff: input.percentOff, active: true };
    this.promos.push(p); return p;
  }
  async endPromo(input: { code: string }): Promise<Promo> {
    const p = this.promos.find(x => x.code === input.code); if (!p) throw new Error("Promo not found");
    p.active = false; return p;
  }
  async referralStatus(input: { code: string }): Promise<Referral | null> {
    return this.referrals.find(r => r.code === input.code) ?? null;
  }
  async sendCampaign(_input: { segment: string; message: string }): Promise<{ sent: number }> { return { sent: 42 }; }

  // Analytics
  async kpis(): Promise<KPI[]> {
    const revenue = this.invoices.filter(i => i.status !== "refunded").reduce((a,b) => a + b.amount, 0);
    const bookings = this.bookings.length;
    const cancels = this.bookings.filter(b => b.status === "canceled").length;
    return [
      { key: "revenue", value: revenue, unit: "USD" },
      { key: "bookings", value: bookings },
      { key: "cancellations", value: cancels },
    ];
  }
  async exportReport(input: { report: string; format: "csv" | "json" }): Promise<{ url: string }> {
    return { url: `https://example.local/exports/${input.report}.${input.format}` };
  }

  // Ops
  async createTask(input: { title: string }): Promise<Task> {
    const t: Task = { taskId: rid("task"), title: input.title, status: "open" };
    this.tasks.push(t); return t;
  }
  async listTasks(): Promise<Task[]> { return this.tasks; }
  async markDone(input: { taskId: string }): Promise<Task> {
    const t = this.tasks.find(x => x.taskId === input.taskId); if (!t) throw new Error("Task not found");
    t.status = "done"; return t;
  }
  async startChecklist(input: { name: string }): Promise<{ steps: string[] }> {
    const presets: Record<string,string[]> = {
      open: ["Check calendar", "Confirm supplies", "Review client notes"],
      close: ["Send follow-ups", "Reconcile payments", "Prep tomorrow slots"]
    };
    return { steps: presets[input.name] ?? ["Step 1", "Step 2"] };
  }

  // Admin
  async showAudit(input: { limit: number }): Promise<Array<{ at: string; type: string; details: any }>> {
    return Array.from({ length: Math.min(input.limit, 10) }).map((_, i) => ({ at: new Date(Date.now()-i*60000).toISOString(), type: "demo", details: { i } }));
  }
  async manageRole(_input: { targetUserId: string; role: string }): Promise<{ ok: boolean }> { return { ok: true }; }
  async gdprExport(input: { userId: string }): Promise<{ url: string }> { return { url: `https://example.local/gdpr/${input.userId}.zip` }; }
}
