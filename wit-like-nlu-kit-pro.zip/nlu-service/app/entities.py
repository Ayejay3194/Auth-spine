import re, json
from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
from rapidfuzz import fuzz
from .versioning import model_path

# Default regexes (add more as you like)
DEFAULT_REGEX = {
    "email": [r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"],
    "phone": [r"\b(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b"],
    "url":   [r"\bhttps?://[^\s]+\b"],
}

@dataclass
class Found:
    entity: str
    role: Optional[str]
    value: str
    start: int
    end: int
    confidence: float
    meta: Dict[str, Any]

def _iter_regex(regex_map: Dict[str, list[str]], text: str) -> List[Found]:
    found: List[Found] = []
    for ent, patterns in regex_map.items():
        for pat in patterns:
            for m in re.finditer(pat, text, flags=re.IGNORECASE):
                found.append(Found(ent, None, m.group(0), m.start(), m.end(), 0.9, {"source":"regex"}))
    return found

def _iter_lookups(lookups: Dict[str, Any], text: str, threshold: float) -> List[Found]:
    # lookups format:
    # { "service": { "primary": {"balayage":["balayage","balyage"], "cut":["haircut","cut"]}}}
    found: List[Found] = []
    lower = text.lower()
    for ent, roles in (lookups or {}).items():
        if not isinstance(roles, dict):
            continue
        for role, canon_map in roles.items():
            if not isinstance(canon_map, dict):
                continue
            for canon, syns in canon_map.items():
                if not isinstance(syns, list):
                    syns = [str(syns)]
                for s in [canon] + syns:
                    s_l = str(s).lower()
                    if not s_l.strip():
                        continue
                    # exact substring fast path
                    idx = lower.find(s_l)
                    if idx != -1:
                        found.append(Found(ent, role, text[idx:idx+len(s_l)], idx, idx+len(s_l), 0.98, {"source":"lookup","canon":canon}))
                        continue
                    # fuzzy: scan tokens window (cheap-ish)
                    tokens = re.findall(r"[\w']+|[^\w\s]", lower)
                    # if synonym is single token, fuzzy compare tokens
                    if " " not in s_l and len(s_l) >= 4:
                        for t in tokens:
                            if len(t) < 4:
                                continue
                            score = fuzz.ratio(t, s_l)/100.0
                            if score >= threshold:
                                # map back to span (best effort)
                                m = re.search(re.escape(t), lower)
                                if m:
                                    found.append(Found(ent, role, text[m.start():m.end()], m.start(), m.end(), float(score), {"source":"fuzzy","canon":canon,"match":t}))
    # Dedup overlaps by best confidence
    found.sort(key=lambda x: (x.start, -(x.end-x.start), -x.confidence))
    pruned: List[Found] = []
    for f in found:
        overlap = False
        for p in pruned:
            if not (f.end <= p.start or f.start >= p.end):
                overlap = True
                # keep higher confidence span
                if f.confidence > p.confidence and (f.end-f.start) >= (p.end-p.start):
                    pruned.remove(p)
                    pruned.append(f)
                break
        if not overlap:
            pruned.append(f)
    return pruned

def load_entity_rules(model_id: str) -> Dict[str, Any]:
    mp = model_path(model_id)
    p = mp / "entity_rules.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {"regex": DEFAULT_REGEX, "lookups": {}}

def extract_entities(model_id: str, text: str, threshold: float = 0.75) -> List[Dict[str, Any]]:
    rules = load_entity_rules(model_id)
    regex_map = rules.get("regex") or DEFAULT_REGEX
    lookups = rules.get("lookups") or {}
    found = []
    found += _iter_regex(regex_map, text)
    found += _iter_lookups(lookups, text, threshold)
    # sort final by start
    found.sort(key=lambda x: x.start)
    return [{
        "entity": f.entity,
        "role": f.role,
        "value": f.value,
        "start": f.start,
        "end": f.end,
        "confidence": f.confidence,
        "meta": f.meta
    } for f in found]
