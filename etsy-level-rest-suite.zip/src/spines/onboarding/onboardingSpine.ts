
export type SellerStatus = "applied" | "verified" | "active" | "limited" | "suspended";

export interface SellerOnboardingRecord {
  sellerId: string;
  status: SellerStatus;
  submittedAt: string;
  verifiedAt?: string;
  notes?: string;
}

export class SellerOnboardingSpine {
  async apply(sellerId: string): Promise<SellerOnboardingRecord> {
    return { sellerId, status: "applied", submittedAt: new Date().toISOString() };
  }

  async verify(sellerId: string): Promise<SellerOnboardingRecord> {
    return { sellerId, status: "verified", submittedAt: new Date().toISOString(), verifiedAt: new Date().toISOString() };
  }

  async activate(sellerId: string): Promise<SellerOnboardingRecord> {
    return { sellerId, status: "active", submittedAt: new Date().toISOString() };
  }

  async limit(sellerId: string, reason: string): Promise<SellerOnboardingRecord> {
    return { sellerId, status: "limited", submittedAt: new Date().toISOString(), notes: reason };
  }

  async suspend(sellerId: string, reason: string): Promise<SellerOnboardingRecord> {
    return { sellerId, status: "suspended", submittedAt: new Date().toISOString(), notes: reason };
  }
}
