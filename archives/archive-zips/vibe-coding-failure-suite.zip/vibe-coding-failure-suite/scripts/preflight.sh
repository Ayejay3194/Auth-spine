#!/usr/bin/env bash
set -euo pipefail

echo "== Preflight: basic repo sanity =="
echo "Node: $(node -v 2>/dev/null || echo 'missing')"
echo "npm:  $(npm -v 2>/dev/null || echo 'missing')"

fail=0

check() {
  local name="$1"
  shift
  echo "-- $name"
  if "$@"; then
    echo "   OK"
  else
    echo "   FAIL"
    fail=1
  fi
}

check "No .env committed" bash -lc 'git ls-files | grep -E "^\.env(\.|$)" >/dev/null && exit 1 || exit 0'
check "No obvious secrets committed (basic regex)" bash -lc 'git grep -nE "(SUPABASE_SERVICE_ROLE_KEY|AWS_SECRET_ACCESS_KEY|BEGIN PRIVATE KEY|sk-[A-Za-z0-9]{20,})" -- . ":!package-lock.json" ":!pnpm-lock.yaml" ":!yarn.lock" >/dev/null && exit 1 || exit 0'

if [ -f package.json ]; then
  check "Install deps" bash -lc 'npm ci --silent'
  check "Lint" bash -lc 'npm run -s lint'
  check "Typecheck" bash -lc 'npm run -s typecheck'
  check "Tests" bash -lc 'npm test --silent'
else
  echo "No package.json found. Skipping JS checks."
fi

if [ "$fail" -eq 1 ]; then
  echo ""
  echo "Preflight failed. Fix the problems before you ship chaos."
  exit 1
fi

echo ""
echo "Preflight passed. You may proceed to disappoint users at scale."
