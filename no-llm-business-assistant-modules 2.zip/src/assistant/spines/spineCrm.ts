import type { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";

export function registerCrmTools(reg: ToolRegistry, p: Providers) {
  reg.register({
    id: "crm.find_client",
    title: "Find client",
    description: "Finds a client by name/email/phone.",
    inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
    async run(ctx, input) {
      const data = await p.crm.findClient({ query: input.query });
      return { ok: true, data };
    }
  });

  reg.register({
    id: "crm.add_note",
    title: "Add client note",
    description: "Adds a note to a client record.",
    inputSchema: { type: "object", properties: { clientId: { type: "string" }, note: { type: "string" } }, required: ["clientId", "note"] },
    async run(ctx, input) {
      await p.crm.addNote({ clientId: input.clientId, note: input.note });
      return { ok: true, data: { saved: true } };
    }
  });
}
