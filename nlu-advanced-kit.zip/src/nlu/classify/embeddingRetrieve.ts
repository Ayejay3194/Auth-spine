import type { NLUModel, IntentMatch } from "../types";
import { tokenize } from "./tokenize";

/**
 * No real embeddings here (unless you add them).
 * This is a cheap similarity search over examples (token overlap w/ IDF-ish weighting).
 */
export function retrieveClassify(model: NLUModel, text: string): IntentMatch {
  const query = tokenize(text);
  if (query.length === 0) return { name: "unknown", confidence: 0, method: "retrieve" };

  const df = new Map<string, number>();
  const docs: { intent: string; tokens: string[]; raw: string }[] = [];
  for (const intent of model.intents) {
    for (const ex of intent.examples) {
      const toks = Array.from(new Set(tokenize(ex)));
      docs.push({ intent: intent.name, tokens: toks, raw: ex });
      for (const t of toks) df.set(t, (df.get(t) ?? 0) + 1);
    }
  }
  const N = docs.length || 1;
  const idf = (t: string) => Math.log((N + 1) / ((df.get(t) ?? 0) + 1)) + 1;

  const qVec = new Map<string, number>();
  for (const t of query) qVec.set(t, (qVec.get(t) ?? 0) + idf(t));

  const scoreDoc = (tokens: string[]) => {
    let dot = 0, qn = 0, dn = 0;
    for (const [t, w] of qVec) {
      qn += w * w;
      if (tokens.includes(t)) dot += w * idf(t);
    }
    for (const t of tokens) {
      const w = idf(t);
      dn += w * w;
    }
    const denom = Math.sqrt(qn) * Math.sqrt(dn);
    return denom === 0 ? 0 : dot / denom;
  };

  const bestByIntent = new Map<string, number>();
  for (const d of docs) {
    const s = scoreDoc(d.tokens);
    const prev = bestByIntent.get(d.intent) ?? 0;
    if (s > prev) bestByIntent.set(d.intent, s);
  }

  let best: { intent: string; score: number } | null = null;
  for (const [intent, score] of bestByIntent) {
    if (!best || score > best.score) best = { intent, score };
  }

  const confidence = best ? clamp(best.score, 0, 1) : 0;
  return {
    name: best?.intent ?? "unknown",
    confidence,
    method: "retrieve",
    reasoning: best ? `retrieve cosine≈${best.score.toFixed(3)}` : "no docs",
  };
}

function clamp(n: number, a: number, b: number) { return Math.max(a, Math.min(b, n)); }
