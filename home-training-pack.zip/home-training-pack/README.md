# Home Training Pack

You said “home training pack”, which could mean either:
1) an at-home fitness training plan, or
2) a “home-training” pack for your assistant/NLU (training data + eval + prompts).

So I included both. Use whichever isn’t cursed for your use-case.

## Contents
- `fitness/` — 4-week home program + tracking template
- `nlu/` — dataset + evaluation scaffolding + prompt templates for “real” conversational behavior
