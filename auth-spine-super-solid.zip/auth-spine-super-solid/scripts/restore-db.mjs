import path from "node:path";
import { execSync } from "node:child_process";
import fs from "node:fs";

const DATABASE_URL = process.env.DATABASE_URL;
if(!DATABASE_URL){
  console.error("Missing DATABASE_URL in env");
  process.exit(1);
}

const backupFile = process.argv[2];
if(!backupFile){
  console.error("Usage: npm run db:restore -- <backup-file>");
  process.exit(1);
}

const BACKUP_DIR = path.join(process.cwd(), "backups");
let backupPath = path.join(BACKUP_DIR, backupFile);
if(!fs.existsSync(backupPath)){
  console.error("Backup not found:", backupPath);
  process.exit(1);
}

console.log("⚠️ Restoring database from:", backupFile);

if(backupFile.endsWith(".gz")){
  execSync(`gunzip -k "${backupPath}"`, { stdio: "inherit" });
  backupPath = backupPath.replace(/\.gz$/, "");
}

const u = new URL(DATABASE_URL);
const host = u.hostname;
const port = u.port || "5432";
const user = decodeURIComponent(u.username);
const pass = decodeURIComponent(u.password);
const db = u.pathname.replace(/^\//, "");

execSync(
  `PGPASSWORD="${pass}" psql -h ${host} -p ${port} -U ${user} -d ${db} -f "${backupPath}"`,
  { stdio: "inherit" }
);

console.log("✅ Restore complete");
