// Stub classifier. Replace with real model / rules / external service.
export async function classify(input: string) {
  const text = (input ?? "").toLowerCase();
  if (text.includes("book")) {
    return { intent: "booking", confidence: 0.9, entities: [], reasoning: "keyword: book" };
  }
  return { intent: "fallback", confidence: 0.0, entities: [], reasoning: "no match" };
}
