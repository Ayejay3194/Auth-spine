// admin_security entities.ts
