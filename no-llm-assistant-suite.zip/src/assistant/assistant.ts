import { AgentContext, AgentReply, AuditLogger, Clock, Tracer } from "../core/types.js";
import { DefaultEntityExtractor } from "../nlu/entities.js";
import { IntentDetector, IntentId } from "../nlu/intents.js";
import { createFlowEngine } from "../flows/engine.js";
import { FlowDefinition, FlowState } from "../flows/types.js";
import { ToolRegistry } from "../tools/types.js";
import { PolicyEngine } from "../policy/types.js";

export interface AssistantDeps {
  tools: ToolRegistry;
  policy: PolicyEngine;
  audit: AuditLogger;
  clock: Clock;
  tracer: Tracer;
  intent: IntentDetector;
  flows: FlowDefinition[];
}

export interface ConversationState {
  active?: { intent: string; state: FlowState };
}

export function createAssistant(deps: AssistantDeps) {
  const extractor = new DefaultEntityExtractor();
  const engine = createFlowEngine({ tools: deps.tools, policy: deps.policy, audit: deps.audit, clock: deps.clock, tracer: deps.tracer });

  function findFlow(intent: string): FlowDefinition | undefined {
    return deps.flows.find((f) => f.intent === intent);
  }

  async function handle(ctx: AgentContext, conv: ConversationState, userText: string): Promise<{ state: ConversationState; reply: AgentReply }> {
    const span = deps.tracer.start("assistant.handle");
    const entities = extractor.extract(userText, deps.clock.now());
    await deps.audit.write({ at: deps.clock.now(), userId: ctx.userId, role: ctx.role, type: "entity.extracted", details: { count: entities.length } });

    // continue active flow if exists
    if (conv.active && !conv.active.state.completed) {
      const def = findFlow(conv.active.intent);
      if (!def) {
        conv.active = undefined;
      } else {
        const cont = await engine.continue(ctx, def, conv.active.state, userText, entities);
        deps.tracer.end(span, { path: "continue", intent: def.intent });
        return { state: { active: { intent: def.intent, state: cont.state } }, reply: cont.reply };
      }
    }

    // detect intent and start new flow
    const det = deps.intent.detect(userText);
    await deps.audit.write({ at: deps.clock.now(), userId: ctx.userId, role: ctx.role, type: "intent.detected", details: det as any });

    if (det.intent === "unknown") {
      deps.tracer.end(span, { path: "unknown" });
      return { state: {}, reply: { text: "I can help with booking (create/reschedule/cancel/list) or account support. Say what you want to do." } };
    }

    const def = findFlow(det.intent);
    if (!def) {
      deps.tracer.end(span, { path: "no_flow", intent: det.intent });
      return { state: {}, reply: { text: `I recognized "${det.intent}" but don’t have a flow wired for it yet.` } };
    }

    const started = await engine.start(ctx, def, entities);
    deps.tracer.end(span, { path: "start", intent: def.intent });
    return { state: { active: { intent: def.intent, state: started.state } }, reply: started.reply };
  }

  return { handle };
}
