# Browser Doctor (client-side)

A tiny TS module you can mount on an internal page (ex: `/diagnostics`) to collect:
- user agent + platform + locale + timezone
- network info (where available)
- service worker status
- storage availability (localStorage/sessionStorage/IndexedDB)
- cache storage status (where available)
- visibility/focus state
- error capture (window.onerror + unhandledrejection) while the page is open
- export as JSON + copy-to-clipboard helper

## Usage (vanilla)
```ts
import { mountBrowserDoctor } from "./doctor";

mountBrowserDoctor(document.getElementById("doctor")!, {
  appName: "MyApp",
  version: "1.2.3",
  reportEndpoint: "/api/diagnostics" // optional
});
```
