import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readJson, readText, findFirstExisting } from "../utils/fs.js";

export type Framework = "next" | "vite" | "unknown";

export function detectFramework(root: string): { framework: Framework; evidence: Record<string,unknown> } {
  const pkgPath = path.join(root, "package.json");
  if (!exists(pkgPath)) return { framework: "unknown", evidence: {} };
  const pkg = readJson<any>(pkgPath);
  const deps = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
  if (deps["next"]) return { framework: "next", evidence: { next: deps["next"] } };
  if (deps["vite"]) return { framework: "vite", evidence: { vite: deps["vite"] } };
  return { framework: "unknown", evidence: {} };
}

export function auditFramework(root: string): AuditSection {
  const section: AuditSection = { id: "framework", title: "Framework Heuristics (Next/Vite)", findings: [] };
  const { framework } = detectFramework(root);

  if (framework === "next") {
    const appDir = exists(path.join(root, "app"));
    const pagesDir = exists(path.join(root, "pages"));
    if (!appDir && !pagesDir) section.findings.push({
      id: "next.noRoutes",
      title: "Next.js detected but no app/ or pages/ directory found",
      severity: "ERROR",
      details: "Next needs `app/` (App Router) or `pages/` (Pages Router) to serve routes.",
      fix: "Add `app/` or `pages/`, or point the tool at the correct repo root.",
      evidence: { appDir, pagesDir },
    });

    const nextConfig = findFirstExisting(root, ["next.config.js","next.config.mjs","next.config.ts"]);
    if (!nextConfig) section.findings.push({
      id: "next.config.missing",
      title: "next.config not found",
      severity: "INFO",
      details: "Not required, but many deployments need rewrites/basePath/images configuration.",
      fix: "Add next.config if you deploy under a subpath or need rewrites/images domains.",
    });
  }

  if (framework === "vite") {
    const viteConfig = findFirstExisting(root, ["vite.config.ts","vite.config.js","vite.config.mjs"]);
    if (!viteConfig) section.findings.push({
      id: "vite.config.missing",
      title: "Vite detected but vite.config not found",
      severity: "INFO",
      details: "Often okay, but base path and build tweaks live there. Subpath deploys commonly break without `base`.",
      fix: "If deploying under a subpath, set `base` in vite.config.*.",
    });
    else {
      const raw = readText(viteConfig);
      const hasBase = /\bbase\s*:\s*['"`]/.test(raw);
      if (!hasBase) section.findings.push({
        id: "vite.base.missing",
        title: "Vite config has no base configured",
        severity: "INFO",
        details: "If you deploy under a subpath, missing `base` causes 404 assets and blank screens.",
        fix: "Set `base: '/your-subpath/'` in Vite config if applicable.",
        evidence: { viteConfig },
      });
    }
  }

  return section;
}
