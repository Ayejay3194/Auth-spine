-- Index usage stats (requires pg_stat_user_indexes)
create or replace view admin_index_usage as
select
  s.schemaname,
  s.relname as table_name,
  s.indexrelname as index_name,
  s.idx_scan,
  s.idx_tup_read,
  s.idx_tup_fetch,
  pg_relation_size(s.indexrelid) as index_bytes
from pg_stat_user_indexes s
order by s.idx_scan asc, index_bytes desc;
