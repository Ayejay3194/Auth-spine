export type IntentRule = { intent: string; any: string[]; all: string[] };
export type IntentExample = { intent: string; utterance: string };

type Scored = { intent: string; score: number; reason: string };

export class IntentDetector {
  constructor(
    private rules: IntentRule[],
    private examples: IntentExample[] = [],
    private opts: { minScore: number } = { minScore: 0.30 }
  ) {}

  detect(text: string): Scored[] {
    const t = tokenize(text);
    const joined = t.join(" ");

    const out: Scored[] = [];

    for (const r of this.rules) {
      const anyHit = r.any.length ? r.any.some(k => joined.includes(normalize(k))) : true;
      const allHit = r.all.length ? r.all.every(k => joined.includes(normalize(k))) : true;
      if (!anyHit || !allHit) continue;

      // crude score: fraction of keywords hit
      const hits = new Set<string>();
      for (const k of [...r.any, ...r.all]) if (joined.includes(normalize(k))) hits.add(normalize(k));
      const denom = Math.max(1, new Set([...r.any, ...r.all].map(normalize)).size);
      const score = 0.55 + 0.45 * (hits.size / denom);
      out.push({ intent: r.intent, score, reason: "rule" });
    }

    // example similarity: Jaccard on tokens
    for (const ex of this.examples) {
      const s = jaccard(t, tokenize(ex.utterance));
      if (s >= this.opts.minScore) out.push({ intent: ex.intent, score: s, reason: "example" });
    }

    // collapse by best score per intent
    const best = new Map<string, Scored>();
    for (const x of out) {
      const prev = best.get(x.intent);
      if (!prev || x.score > prev.score) best.set(x.intent, x);
    }
    return [...best.values()].sort((a, b) => b.score - a.score);
  }
}

function normalize(s: string): string {
  return s.trim().toLowerCase();
}

function tokenize(s: string): string[] {
  return normalize(s)
    .replace(/[.,!?;:()\[\]{}"]/g, " ")
    .replace(/\s+/g, " ")
    .split(" ")
    .filter(Boolean);
}

function jaccard(a: string[], b: string[]): number {
  const A = new Set(a);
  const B = new Set(b);
  const inter = [...A].filter(x => B.has(x)).length;
  const uni = new Set([...A, ...B]).size;
  return uni ? inter / uni : 0;
}
