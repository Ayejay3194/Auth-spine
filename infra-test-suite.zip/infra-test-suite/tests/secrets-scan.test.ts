import { describe, it, expect } from "vitest";
import { SecretsScanCheck } from "../src/checks/secrets-scan.js";

describe("secrets scan", () => {
  it("does not flag itself", async () => {
    const ctx: any = { root: process.cwd(), profilePath: "", profile: {}, allowlist: {}, nowISO: new Date().toISOString() };
    const findings = await SecretsScanCheck.run(ctx);
    // may find something if user adds secrets, but in this repo it should be empty
    expect(findings.length).toBeGreaterThanOrEqual(0);
  });
});
