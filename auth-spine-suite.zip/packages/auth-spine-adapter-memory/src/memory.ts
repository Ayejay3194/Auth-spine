import type { UserStore, UserRecord, SessionStore, SessionRecord, SessionRevocationReason, DeviceStore, DeviceRecord, RateLimitPort, AuditPort, AuditEntry } from "@spine/auth-core";
import { sha256 } from "@spine/auth-core";

export class MemoryUserStore implements UserStore {
  private byId = new Map<string, UserRecord>();
  private byEmail = new Map<string, string>();

  async create(u: Omit<UserRecord, "createdAt" | "updatedAt">): Promise<UserRecord> {
    const now = new Date().toISOString();
    const rec: UserRecord = { ...u, createdAt: now, updatedAt: now } as any;
    this.byId.set(rec.id, rec);
    this.byEmail.set(rec.email, rec.id);
    return rec;
  }
  async byEmail(email: string): Promise<UserRecord | null> {
    const id = this.byEmail.get(email);
    return id ? (this.byId.get(id) ?? null) : null;
  }
  async byId(id: string): Promise<UserRecord | null> { return this.byId.get(id) ?? null; }
  async update(id: string, patch: Partial<UserRecord>): Promise<UserRecord> {
    const cur = this.byId.get(id);
    if (!cur) throw new Error("User not found");
    const next = { ...cur, ...patch, updatedAt: new Date().toISOString() } as any;
    if (patch.email && patch.email !== cur.email) { this.byEmail.delete(cur.email); this.byEmail.set(patch.email, id); }
    this.byId.set(id, next);
    return next;
  }
}

export class MemorySessionStore implements SessionStore {
  private byId = new Map<string, SessionRecord>();
  async create(s: Omit<SessionRecord, "createdAt" | "lastSeenAt">): Promise<SessionRecord> {
    const now = new Date().toISOString();
    const rec: SessionRecord = { ...s, createdAt: now, lastSeenAt: now } as any;
    this.byId.set(rec.id, rec);
    return rec;
  }
  async byId(id: string): Promise<SessionRecord | null> { return this.byId.get(id) ?? null; }
  async listByUser(userId: string): Promise<SessionRecord[]> { return [...this.byId.values()].filter(s=>s.userId===userId); }
  async touch(id: string, lastSeenAt: string): Promise<void> { const s=this.byId.get(id); if(s) this.byId.set(id,{...s,lastSeenAt}); }
  async revoke(id: string, reason: SessionRevocationReason, revokedBy?: string, revokedAt?: string): Promise<void> {
    const s=this.byId.get(id); if(!s) return;
    this.byId.set(id,{...s, revokedAt: revokedAt ?? new Date().toISOString(), revokedReason: reason, revokedBy});
  }
  async revokeAllForUser(userId: string, reason: SessionRevocationReason, revokedBy?: string): Promise<number> {
    const list = (await this.listByUser(userId)).filter(s=>!s.revokedAt);
    for(const s of list) await this.revoke(s.id, reason, revokedBy);
    return list.length;
  }
  async enforceConcurrency(userId: string, max: number): Promise<void> {
    if (max <= 0) return;
    const active = (await this.listByUser(userId)).filter(s=>!s.revokedAt).sort((a,b)=>a.createdAt.localeCompare(b.createdAt));
    if (active.length < max) return;
    const toRevoke = active.slice(0, active.length - (max - 1));
    for(const s of toRevoke) await this.revoke(s.id, "EXPIRED", userId);
  }
}

export class MemoryDeviceStore implements DeviceStore {
  private map = new Map<string, DeviceRecord>();
  private key(u:string,d:string){ return `${u}:${d}`; }
  async upsert(d: Omit<DeviceRecord, "createdAt" | "lastSeenAt">): Promise<DeviceRecord> {
    const k=this.key(d.userId,d.id);
    const now=new Date().toISOString();
    const cur=this.map.get(k);
    const next: DeviceRecord = cur ? { ...cur, ...d, lastSeenAt: now } as any : { ...d, createdAt: now, lastSeenAt: now } as any;
    this.map.set(k,next); return next;
  }
  async listByUser(userId: string): Promise<DeviceRecord[]> { return [...this.map.values()].filter(x=>x.userId===userId); }
  async trust(userId: string, deviceId: string, trusted: boolean): Promise<void> { const k=this.key(userId,deviceId); const cur=this.map.get(k); if(cur) this.map.set(k,{...cur,trusted}); }
  async revoke(userId: string, deviceId: string, at: string): Promise<void> { const k=this.key(userId,deviceId); const cur=this.map.get(k); if(cur) this.map.set(k,{...cur,revokedAt:at,trusted:false}); }
}

export class MemoryRateLimit implements RateLimitPort {
  private buckets = new Map<string, { resetAt: number; count: number }>();
  async hit(key: string, limit: number, windowSeconds: number): Promise<{ allowed: boolean; remaining: number }> {
    const now=Date.now();
    const b=this.buckets.get(key);
    if(!b || now>=b.resetAt){ this.buckets.set(key,{resetAt: now + windowSeconds*1000, count: 1}); return {allowed:true, remaining: limit-1}; }
    if(b.count>=limit) return {allowed:false, remaining:0};
    b.count += 1; this.buckets.set(key,b);
    return {allowed:true, remaining: limit - b.count};
  }
}

export class MemoryAudit implements AuditPort {
  private entries: AuditEntry[]=[];
  private lastHash: string | undefined;
  async append(entry: Omit<AuditEntry, "hash">): Promise<AuditEntry> {
    const material = JSON.stringify({ ...entry, prevHash: this.lastHash });
    const hash = sha256(material);
    const rec: AuditEntry = { ...entry, prevHash: this.lastHash, hash };
    this.entries.push(rec);
    this.lastHash = hash;
    return rec;
  }
  async list(filter?: { actorId?: string; targetId?: string; actionPrefix?: string; limit?: number }): Promise<AuditEntry[]> {
    let out=[...this.entries];
    if(filter?.actorId) out=out.filter(e=>e.actorId===filter.actorId);
    if(filter?.targetId) out=out.filter(e=>e.targetId===filter.targetId);
    if(filter?.actionPrefix) out=out.filter(e=>e.action.startsWith(filter.actionPrefix));
    if(filter?.limit) out=out.slice(-filter.limit);
    return out;
  }
}
