import { AuditLogger } from "../core/types.js";
import { InMemoryToolRegistry } from "../tools/registry.js";
import { Tool } from "../tools/types.js";

const emailLike = (s: string) => /@/.test(s);

export function buildDemoTools(audit: AuditLogger) {
  const reg = new InMemoryToolRegistry();

  const sendForgotUsername: Tool<{ email: string }, { sent: boolean }> = {
    id: "auth.send_forgot_username",
    description: "Send username reminder email",
    allowed: () => true,
    validate: (i) => { if (!emailLike(i.email)) throw new Error("Invalid email"); },
    run: async (_ctx, input) => {
      await audit.write({ at: new Date(), userId: "demo", role: "user", type: "tool.result", details: { mocked: true, tool: "forgot_username", to: input.email } });
      return { ok: true, data: { sent: true } };
    },
    timeoutMs: 1500,
  };

  const sendReset: Tool<{ identifier: string }, { sent: boolean }> = {
    id: "auth.send_password_reset",
    description: "Send password reset email/code",
    allowed: () => true,
    validate: (i) => { if (!i.identifier || i.identifier.length < 2) throw new Error("Invalid identifier"); },
    run: async (_ctx, input) => {
      await audit.write({ at: new Date(), userId: "demo", role: "user", type: "tool.result", details: { mocked: true, tool: "password_reset", ident: input.identifier } });
      return { ok: true, data: { sent: true } };
    },
    timeoutMs: 1500,
  };

  const gdprExport: Tool<{}, { queued: boolean }> = {
    id: "gdpr.queue_export",
    description: "Queue GDPR export request",
    allowed: (ctx) => ctx.role === "user" || ctx.role === "admin",
    validate: () => {},
    run: async (ctx) => {
      await audit.write({ at: new Date(), userId: ctx.userId, role: ctx.role, type: "tool.result", details: { mocked: true, tool: "gdpr_export" } });
      return { ok: true, data: { queued: true } };
    },
    timeoutMs: 1500,
  };

  const changePlan: Tool<{ plan: string; confirm: string }, { updated: boolean }> = {
    id: "billing.change_plan",
    description: "Change subscription plan",
    allowed: (ctx) => ctx.role === "user",
    validate: (i) => {
      if (!["free","paid","pro","starter"].includes(i.plan)) throw new Error("Unknown plan");
      if (i.confirm.trim().toUpperCase() !== "YES") throw new Error("Confirmation required");
    },
    run: async (ctx, input) => {
      await audit.write({ at: new Date(), userId: ctx.userId, role: ctx.role, type: "tool.result", details: { mocked: true, tool: "change_plan", plan: input.plan } });
      return { ok: true, data: { updated: true } };
    },
    timeoutMs: 1500,
  };

  reg.register(sendForgotUsername).register(sendReset).register(gdprExport).register(changePlan);
  return reg;
}
