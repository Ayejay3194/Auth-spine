export const ARCSEC_PER_RAD = 206264.80624709636;

export function radToArcsec(rad: number): number {
  return rad * ARCSEC_PER_RAD;
}

export function wrap2pi(x: number): number {
  const twoPi = 2 * Math.PI;
  x %= twoPi;
  if (x < 0) x += twoPi;
  return x;
}

export function hypot2(a: number, b: number): number {
  return Math.sqrt(a*a + b*b);
}

export function clamp(x: number, cap: number): number {
  if (cap <= 0) return x;
  if (x > cap) return cap;
  if (x < -cap) return -cap;
  return x;
}
