# Dev deps to install (Node/Next)
npm i -D eslint prettier typescript
npm i -D @typescript-eslint/parser @typescript-eslint/eslint-plugin
npm i -D eslint-plugin-react eslint-plugin-react-hooks eslint-plugin-jsx-a11y
npm i -D eslint-plugin-import eslint-plugin-security
npm i -D husky lint-staged
# optional
npm i -D gitleaks (or run via CI action only)
