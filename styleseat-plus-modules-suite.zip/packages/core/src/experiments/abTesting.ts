import type { ID, Result, ISODateTime } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type Experiment = {
  id: ID;
  key: string;
  variants: Array<{ id: string; weight: number }>; // weights sum to 1.0
  startsAt: ISODateTime;
  endsAt?: ISODateTime;
  enabled: boolean;
};

export type Assignment = { assignmentId: ID; experimentId: ID; userId: ID; variantId: string; at: ISODateTime };

export class ABTestingService {
  private assignments: Assignment[] = [];

  assign(exp: Experiment, userId: ID, atISO: ISODateTime): Result<Assignment> {
    if (!exp.enabled) return { ok: false, error: { code: "EXPERIMENT_DISABLED", message: "Experiment disabled" } };
    const existing = this.assignments.find(a => a.experimentId === exp.id && a.userId === userId);
    if (existing) return { ok: true, data: existing };
    const v = pickVariant(exp, userId);
    const a: Assignment = { assignmentId: cuid("asgn"), experimentId: exp.id, userId, variantId: v, at: atISO };
    this.assignments.push(a);
    return { ok: true, data: a };
  }

  listAssignments(userId?: ID) { return userId ? this.assignments.filter(a => a.userId === userId) : [...this.assignments]; }
}

function pickVariant(exp: Experiment, userId: ID): string {
  // stable weighted pick based on userId + key
  const s = `${userId}:${exp.key}`;
  let h = 0; for (let i=0;i<s.length;i++) h = (h*33 + s.charCodeAt(i)) >>> 0;
  const r = (h % 10000) / 10000;
  let acc = 0;
  for (const v of exp.variants) { acc += v.weight; if (r <= acc) return v.id; }
  return exp.variants[0].id;
}
