import { describe, it, expect } from "vitest";
import { BASE_URL, TEST } from "../tools/config";
import { http } from "../tools/http";
import { ensureTenant, loginUser, authHeaders } from "../tools/auth";
import { expectForbiddenOrNotFound } from "../tools/assertions";

/**
 * This suite is the one that actually saves you from lawsuits.
 * It attempts cross-tenant access to common resources.
 *
 * You MUST customize `resourceProbes` to match your API.
 */
describe("security: tenant isolation (IDOR)", () => {
  it("token from tenant A cannot read tenant B resources", async () => {
    await ensureTenant(TEST.tenants.a);
    await ensureTenant(TEST.tenants.b);

    const tokenA = await loginUser(TEST.users.a);
    const tokenB = await loginUser(TEST.users.b);

    // Sanity: each can read their own sessions (if implemented)
    const sessA = await http("GET", `${BASE_URL}/auth/sessions`, { headers: await authHeaders(tokenA) });
    if (![200, 404].includes(sessA.status)) throw new Error(`Unexpected /auth/sessions status=${sessA.status}`);

    const sessB = await http("GET", `${BASE_URL}/auth/sessions`, { headers: await authHeaders(tokenB) });
    if (![200, 404].includes(sessB.status)) throw new Error(`Unexpected /auth/sessions status=${sessB.status}`);

    // --- Customize these probes to match your real endpoints ---
    // Each probe should attempt to fetch a resource by ID belonging to the OTHER tenant.
    // If you don't have those endpoints yet, keep them as placeholders.
    const resourceProbes: Array<{ name: string; method: "GET"|"POST"; url: string; body?: any }> = [
      { name: "providers list", method: "GET", url: `${BASE_URL}/api/providers` },
      // Example of ID-based endpoint:
      // { name: "booking by id", method: "GET", url: `${BASE_URL}/api/bookings/<TENANT_B_BOOKING_ID>` },
    ];

    // If providers is tenant-scoped, token A should not see tenant B's providers.
    // Without a real seeded ID, we enforce at least that cross-tenant queries are not trivially possible.
    for (const probe of resourceProbes) {
      const rA = await http(probe.method, probe.url, { headers: await authHeaders(tokenA), body: probe.body });
      const rB = await http(probe.method, probe.url, { headers: await authHeaders(tokenB), body: probe.body });

      // Both may be 200. That's fine for a list endpoint.
      // What matters is *filtering* and *scoping*. We can't assert content without fixtures.
      expect([200, 401, 403, 404]).toContain(rA.status);
      expect([200, 401, 403, 404]).toContain(rB.status);
    }

    // Hard check: if your API exposes tenant details by ID, it must block cross-tenant reads.
    const tenantReadBFromA = await http("GET", `${BASE_URL}/tenants/${TEST.tenants.b.id}`, { headers: await authHeaders(tokenA) });
    if (tenantReadBFromA.status >= 200 && tenantReadBFromA.status < 300) {
      throw new Error(`Cross-tenant tenant read succeeded. IDOR. status=${tenantReadBFromA.status} body=${tenantReadBFromA.text}`);
    }
    expectForbiddenOrNotFound(tenantReadBFromA.status);
  });
});
