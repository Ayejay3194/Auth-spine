INSTANT PAYOUTS & DIRECT DEPOSIT ADDON
=====================================

Adds:
- ACH direct deposit
- Instant cash-out (feature-flagged)
- Payout eligibility rules
- Ledger-safe accounting
- Admin controls + alerts

This module snaps into the Ultimate Business Spine.
