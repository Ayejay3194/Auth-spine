Third-Party & Supply Chain Security

- Vendor assessments
- SBOM required
- Dependency scanning
- Integration permission reviews
