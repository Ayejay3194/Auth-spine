export const dnt=()=> typeof window!=='undefined' && (((navigator as any).doNotTrack||'')==='1' || ((window as any).doNotTrack||'')==='1');
