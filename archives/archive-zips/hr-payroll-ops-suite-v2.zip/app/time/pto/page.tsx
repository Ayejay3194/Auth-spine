
import { db } from "@/lib/db";
import { approvePto, denyPto } from "@/lib/actions/pto";

export default async function Pto() {
  const reqs = await db.ptoRequest.findMany({ take: 50, orderBy: { createdAt: "desc" }, include: { employee: true, policy: true } });
  return (
    <div className="grid">
      <div className="panel">
        <div className="h1">PTO Requests</div>
        <div className="small">Approve/deny included.</div>
      </div>
      <div className="panel">
        <table className="table">
          <thead><tr><th>Employee</th><th>Policy</th><th>Dates</th><th>Hours</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {reqs.map(r => (
              <tr key={r.id}>
                <td>{r.employee.firstName} {r.employee.lastName}</td>
                <td>{r.policy.name}</td>
                <td>{r.startDate.toISOString().slice(0,10)} → {r.endDate.toISOString().slice(0,10)}</td>
                <td>{r.hours}</td>
                <td><span className={"pill " + (r.status==="APPROVED" ? "good" : r.status==="PENDING" ? "warn":"bad")}>{r.status}</span></td>
                <td className="row">
                  <form action={approvePto}><input type="hidden" name="id" value={r.id} /><button className="button">Approve</button></form>
                  <form action={denyPto}><input type="hidden" name="id" value={r.id} /><button className="button">Deny</button></form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
