# Monorepo Template
Starter structure for scalable SaaS.