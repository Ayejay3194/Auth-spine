export type PromoCode = {
  code: string;
  kind: "percent" | "fixed";
  amount: number; // percent or cents
  active: boolean;
  startsAt?: string;
  endsAt?: string;
  maxRedemptions?: number;
  perUserLimit?: number;
};

export interface PromoStore {
  get(code: string): Promise<PromoCode | null>;
  countRedemptions(code: string): Promise<number>;
  countUserRedemptions(userId: string, code: string): Promise<number>;
}

export class PromoService {
  constructor(private store: PromoStore) {}

  async validate(userId: string, code: string, cartTotalCents: number) {
    const p = await this.store.get(code);
    if (!p || !p.active) return { ok: false, reason: "invalid" as const };
    const now = Date.now();
    if (p.startsAt && now < Date.parse(p.startsAt)) return { ok:false, reason:"not_started" as const };
    if (p.endsAt && now > Date.parse(p.endsAt)) return { ok:false, reason:"expired" as const };

    if (p.maxRedemptions != null) {
      const used = await this.store.countRedemptions(code);
      if (used >= p.maxRedemptions) return { ok:false, reason:"maxed_out" as const };
    }
    if (p.perUserLimit != null) {
      const used = await this.store.countUserRedemptions(userId, code);
      if (used >= p.perUserLimit) return { ok:false, reason:"user_limit" as const };
    }

    const discountCents = p.kind === "fixed"
      ? Math.min(p.amount, cartTotalCents)
      : Math.floor(cartTotalCents * (p.amount / 100));

    return { ok: true, discountCents };
  }
}
