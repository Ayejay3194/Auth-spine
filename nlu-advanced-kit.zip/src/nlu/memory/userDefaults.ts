export type UserDefaults = {
  timezone?: string;
  defaultLocation?: string;
};

const mem = new Map<string, UserDefaults>();

export function getUserDefaults(userId: string): UserDefaults | null {
  return mem.get(userId) ?? null;
}

export function setUserDefaults(userId: string, defaults: UserDefaults): void {
  mem.set(userId, defaults);
}
