import AstrologyLLM from './components/AstrologyLLM'

export default function App() {
  return <AstrologyLLM />
}
