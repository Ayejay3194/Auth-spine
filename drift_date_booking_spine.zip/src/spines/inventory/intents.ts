import { Pattern } from "../../core/intent.js";

export const patterns: Pattern[] = [
  {
    "spine": "inventory",
    "intent": "list_products",
    "re": "list products|show products|catalog|inventory list",
    "baseConfidence": 0.7,
    "hint": "list products"
  },
  {
    "spine": "inventory",
    "intent": "create_product",
    "re": "create product|add product|new product",
    "baseConfidence": 0.75,
    "hint": "create product"
  },
  {
    "spine": "inventory",
    "intent": "update_stock",
    "re": "update stock|adjust stock|stock (?:add|remove)|restock",
    "baseConfidence": 0.78,
    "hint": "update stock"
  },
  {
    "spine": "inventory",
    "intent": "low_stock",
    "re": "low stock|running low|reorder",
    "baseConfidence": 0.75,
    "hint": "low stock"
  }
];
