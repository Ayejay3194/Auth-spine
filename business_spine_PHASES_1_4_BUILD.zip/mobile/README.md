# Mobile App (Expo RN)
cd mobile
npm i
npm run start
Set EXPO_PUBLIC_API_BASE_URL.
