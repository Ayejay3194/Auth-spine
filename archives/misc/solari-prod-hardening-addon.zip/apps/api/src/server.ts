import express from "express";
import cors from "cors";
import path from "node:path";
import fs from "node:fs";
import { SqliteIndex } from "../../packages/indexer/src/runtime.js";

const app = express();
app.use(cors());
app.use(express.json());

const OUT = path.resolve(process.cwd(), "out");
const SQLITE = path.join(OUT, "index.sqlite");

function ensureIndex() {
  if (!fs.existsSync(SQLITE)) throw new Error("index.sqlite not found. Run: pnpm ingest && pnpm pack");
  return new SqliteIndex(SQLITE);
}

app.get("/health", (_req,res) => res.json({ ok:true }));

app.get("/node/:id", (req,res) => {
  const idx = ensureIndex();
  try {
    const node = idx.getById(req.params.id);
    res.json({ node });
  } finally { idx.close(); }
});

app.get("/search", (req,res) => {
  const q = String(req.query.q ?? "");
  const kind = req.query.kind ? String(req.query.kind) : null;
  const limit = req.query.limit ? Number(req.query.limit) : 25;
  const idx = ensureIndex();
  try {
    const nodes = idx.search(kind, q, limit);
    res.json({ nodes });
  } finally { idx.close(); }
});

app.get("/audit", (_req,res) => {
  const p = path.join(OUT, "audit.report.json");
  res.json({ audit: fs.existsSync(p) ? JSON.parse(fs.readFileSync(p,"utf-8")) : [] });
});

const port = Number(process.env.PORT ?? 4399);
app.listen(port, () => console.log(`Solari API on http://localhost:${port}`));
