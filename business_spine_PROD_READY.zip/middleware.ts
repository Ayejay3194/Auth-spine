import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { verifyToken } from "@/src/auth/jwt";

const PROTECTED_PREFIXES = [
  "/api/booking/create",
  "/api/marketing",
  "/api/automation",
  "/api/staff",
  "/api/loyalty",
  "/api/giftcards",
  "/api/webhooks",
];

export function middleware(req: NextRequest) {
  const res = NextResponse.next();

  res.headers.set("X-Frame-Options", "DENY");
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("Referrer-Policy", "no-referrer");
  res.headers.set("Permissions-Policy", "geolocation=(), microphone=(), camera=()");

  const pathname = req.nextUrl.pathname;
  const needsAuth = PROTECTED_PREFIXES.some(p => pathname.startsWith(p));
  if (!needsAuth) return res;

  const auth = req.headers.get("authorization") ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  try {
    const claims = verifyToken(token);
    res.headers.set("x-user-id", claims.sub);
    res.headers.set("x-role", claims.role);
    return res;
  } catch {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
}

export const config = { matcher: ["/api/:path*"] };
