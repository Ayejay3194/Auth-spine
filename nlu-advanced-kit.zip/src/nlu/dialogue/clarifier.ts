import type { DialogueState, NLUModel, AssistantReply } from "../types";
import { getIntentSlots, missingRequiredSlots } from "./slots";

export function nextClarifyingQuestion(model: NLUModel, state: DialogueState): AssistantReply | null {
  const intent = state.activeIntent;
  if (!intent) return null;

  const missing = missingRequiredSlots(model, state, intent);
  if (missing.length === 0) return null;

  // Ask ONE thing. Always.
  const slot = missing[0];
  const prompt = slot.prompt ?? defaultPrompt(slot.name);

  return {
    text: prompt,
    suggestions: suggestionsForSlot(model, slot.entity),
  };
}

function defaultPrompt(slotName: string): string {
  const pretty = slotName.replace(/_/g, " ");
  return `Quick question: what's the ${pretty}?`;
}

function suggestionsForSlot(model: NLUModel, entityName: string): string[] | undefined {
  const entity = model.entities.find(e => e.name === entityName);
  if (!entity) return undefined;
  return entity.examples.slice(0, 5);
}
