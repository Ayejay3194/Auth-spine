import crypto from "crypto";

export function newCsrfToken(secret: string) {
  const nonce = crypto.randomBytes(16).toString("hex");
  const mac = crypto.createHmac("sha256", secret).update(nonce).digest("hex");
  return `${nonce}.${mac}`;
}

export function verifyCsrfToken(token: string, secret: string) {
  const [nonce, mac] = token.split(".");
  if (!nonce || !mac) return false;
  const expected = crypto.createHmac("sha256", secret).update(nonce).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(expected));
}
