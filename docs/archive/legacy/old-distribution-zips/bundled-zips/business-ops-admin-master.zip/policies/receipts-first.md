RECEIPTS FIRST POLICY
---------------------
Every change that touches:
- money
- payroll
- schedules
- permissions

Must log:
- who
- when
- why
- before/after
