# Don’t Embarrass Me Out In Public Pack (TypeScript)

This is a drop-in hardening layer for an AI/agent-enabled API (or Next.js/Node service).
It focuses on: **fail-closed**, **kill switches**, **policy-first tooling**, **receipts**, **redacted logs**, and **release gates**.

## What you get
- Feature flags + kill switches (global + per-tenant)
- Fail-closed policy engine (RBAC + allowlists)
- Tool-call guardrails (budget, timeouts, recursion caps)
- Structured logging with **PII redaction**
- Request correlation IDs + tracing hooks
- Rate limiting middleware (in-memory + pluggable store)
- “Receipt” system for critical actions (hash-chained)
- CI release gates (typecheck/lint/tests/security scans)
- Ready-to-run smoke checks

## Install / Integrate
1) Copy `src/` into your repo (or mount as a package).
2) Wire middlewares in your API entry:
   - `withRequestContext()`
   - `rateLimit()`
   - `enforcePolicy()`
   - `guardAgent()`
3) Wrap tool execution with `withToolGuardrails()` and `enforcePolicy()`.

## Minimal wiring (Express example)
```ts
import express from "express";
import { withRequestContext } from "./src/runtime/requestContext";
import { rateLimit } from "./src/security/rateLimit";
import { enforcePolicy } from "./src/security/policyMiddleware";
import { buildDefaultPolicy } from "./src/security/policyDefaults";
import { featureFlags } from "./src/security/featureFlags";

const app = express();
app.use(express.json());
app.use(withRequestContext());
app.use(rateLimit({ max: 120, windowMs: 15*60*1000 }));

const policy = buildDefaultPolicy();

app.post("/api/chat",
  enforcePolicy(policy, { resource: "chat", action: "invoke" }),
  async (req, res) => {
    if (!featureFlags.isEnabled("CHAT_ENABLED", req.ctx.tenantId)) {
      return res.status(503).json({ error: "Chat disabled" });
    }
    res.json({ ok: true });
  }
);
```

## Environment
Copy `.env.example` to `.env` and set at least:
- `JWT_SECRET`
- `AUDIT_SECRET`
- `FEATURE_FLAG_DEFAULTS`

## Notes
- This pack **fails closed** by default. If something is misconfigured, the system denies access instead of “guessing”.
- Replace the in-memory rate limiter store with Redis for production.

