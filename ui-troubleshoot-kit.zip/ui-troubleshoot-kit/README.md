# UI Troubleshoot Kit (Next + React + Tailwind)

This is a drop-in mini app that:
- Gives you a searchable UI troubleshooting library
- Adds **UI Authority** tags: ROUTE vs GLOBAL_STORE vs LOCAL vs SERVER_STATE vs CSS_ONLY
- Includes verification steps + anti-patterns so you don’t "fix" it by making it worse

## Run
```bash
npm install
npm run dev
```

## Where to edit
- `components/data/troubleshootData.ts` -> add issues, causes, solutions
- `components/UITroubleshootKit.tsx` -> UI + search + copy behavior
- `app/authority/page.tsx` -> authority rules + z-index ladder
- `app/quickfix/page.tsx` -> copy/paste fix snippets

## How to use this for your real app
When your UI fights itself, classify the problem:
- ROUTE-owned (navigation state)
- GLOBAL_STORE-owned (global toggles: theme/glow/radius/filters/modals)
- LOCAL_COMPONENT-owned (dropdown open, input text)
- SERVER_STATE (fetched data)
- CSS_ONLY (layout/visibility)

If the same concept is owned by more than one, delete duplicates until it stops.
