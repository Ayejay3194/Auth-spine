# Control Mapping (Starter)

| Control | Evidence |
|---|---|
| MFA for ops | screenshot + config export |
| Host separation | middleware + proxy config + test |
| RBAC perms | rbac.ts + endpoint guards |
| Audit logs | AuditLog table + sample entries |
| Secret scanning | CI run artifacts |
| Dependency scanning | CI run artifacts |
| Incident response | runbook + postmortems |
| Backups | restore drill logs |
