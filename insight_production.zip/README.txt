Production Mode
This configuration is designed for public users.
The assistant presents multiple frames, avoids deterministic advice,
and ties tone to confidence levels.
