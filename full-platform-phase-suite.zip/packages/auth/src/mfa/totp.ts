import crypto from "node:crypto";

export type TotpConfig = { issuer: string; periodSeconds?: number; digits?: number };

export function generateSecret(bytes=20): string {
  return crypto.randomBytes(bytes).toString("base64").replace(/=+$/,"");
}

// Minimal RFC6238-ish TOTP (HMAC-SHA1).
export function totp(secretB64: string, at: Date, cfg: TotpConfig): string {
  const period = cfg.periodSeconds ?? 30;
  const digits = cfg.digits ?? 6;
  const counter = Math.floor(at.getTime() / 1000 / period);

  const key = Buffer.from(secretB64, "base64");
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter), 0);

  const h = crypto.createHmac("sha1", key).update(msg).digest();
  const offset = h[h.length - 1] & 0xf;
  const code = ((h[offset] & 0x7f) << 24) | (h[offset+1] << 16) | (h[offset+2] << 8) | (h[offset+3]);
  return String(code % (10 ** digits)).padStart(digits, "0");
}

export function verifyTotp(secretB64: string, token: string, now: Date, cfg: TotpConfig, window=1): boolean {
  for (let w=-window; w<=window; w++) {
    const t = new Date(now.getTime() + w*(cfg.periodSeconds ?? 30)*1000);
    if (totp(secretB64, t, cfg) === token) return true;
  }
  return false;
}
