ADMIN CONTROLS
==============

Admin can:
- enable/disable instant payouts globally
- enable/disable per user
- freeze all payouts
- override holds (requires reason)
- view failure reasons
