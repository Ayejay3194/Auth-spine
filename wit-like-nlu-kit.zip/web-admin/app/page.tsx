import Link from "next/link";

export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <h1>NLU Admin</h1>
      <p>Minimal dashboard for a Wit-like NLU service.</p>
      <Link href="/admin/nlu">Go to /admin/nlu</Link>
    </main>
  );
}
