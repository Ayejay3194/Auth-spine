// security-headers.ts
export const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "no-referrer" },
  { key: "Permissions-Policy", value: "geolocation=(), microphone=(), camera=()" },
  // Configure CSP per app. Start in report-only if you're migrating.
  // { key: "Content-Security-Policy", value: "default-src 'self'; ..." },
  // HSTS only if you are fully HTTPS:
  // { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
];
