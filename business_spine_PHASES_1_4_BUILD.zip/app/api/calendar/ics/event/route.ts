import { api } from "@/src/core/api";
import { generateICS } from "@/src/calendar/ics";
export async function GET() {
  return api(async () => {
    const ics = generateICS({
      uid: "demo",
      startISO: new Date(Date.now() + 3600_000).toISOString(),
      endISO: new Date(Date.now() + 5400_000).toISOString(),
      summary: "Demo Booking",
    });
    return new Response(ics, { headers: { "Content-Type": "text/calendar" } });
  });
}
