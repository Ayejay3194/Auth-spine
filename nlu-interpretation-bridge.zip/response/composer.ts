
export function composeResponse(text: string, tone: "clinical" | "conversational" = "conversational") {
  if (tone === "clinical") return text;
  return text.replace(".", ", and it’s meant to teach you something.");
}
