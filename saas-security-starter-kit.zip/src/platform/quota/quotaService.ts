import { TenantId } from "../tenant/types";
import { Quota, QuotaName } from "./types";

/**
 * Replace with DB-backed + atomic increments.
 * Must be tenant-isolated, concurrency-safe.
 */
const mem: Record<string, Record<QuotaName, Quota>> = {};

export async function getQuota(tenantId: TenantId, name: QuotaName): Promise<Quota> {
  const t = (mem[String(tenantId)] ??= {} as any);
  return (t[name] ??= { name, limit: 1000, used: 0 });
}

export async function consumeQuota(tenantId: TenantId, name: QuotaName, amount: number): Promise<Quota> {
  const q = await getQuota(tenantId, name);
  q.used += amount;
  if (q.used > q.limit) {
    const err = new Error("QUOTA_EXCEEDED");
    (err as any).status = 402; // or 429 depending on policy
    throw err;
  }
  return q;
}
