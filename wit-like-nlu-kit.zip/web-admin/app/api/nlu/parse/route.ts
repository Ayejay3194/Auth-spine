import { NextRequest, NextResponse } from "next/server";
import { getNLUBaseUrl } from "@/lib/serverEnv";

export async function POST(req: NextRequest) {
  const { text } = await req.json();
  const base = getNLUBaseUrl();
  const r = await fetch(`${base}/parse`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ text })
  });
  const body = await r.json();
  return NextResponse.json(body, { status: r.status });
}
