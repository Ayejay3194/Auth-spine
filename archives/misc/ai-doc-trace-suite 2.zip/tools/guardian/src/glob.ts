export function match(pattern: string, filePath: string): boolean {
  const esc = (s: string) => s.replace(/[.+^${}()|[\]\\]/g, "\\$&");
  let re = esc(pattern);
  re = re.replace(/\\\*\\\*\//g, "(?:.*\/)?"); // **/
  re = re.replace(/\\\*\\\*/g, ".*");            // **
  re = re.replace(/\\\*/g, "[^/]*");                // *
  re = re.replace(/\\\?/g, "[^/]");                 // ?
  return new RegExp("^" + re + "$").test(filePath);
}
export function anyMatch(patterns: string[], filePath: string): boolean {
  return patterns.some(p => match(p, filePath));
}
