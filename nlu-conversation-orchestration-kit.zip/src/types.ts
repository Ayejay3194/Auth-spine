export type ToneLevel = 0 | 1 | 2 | 3;

export type NluResult = {
  intent: string;
  confidence: number; // 0..1
  entities: Array<{ entity: string; value: string; start?: number; end?: number }>;
};

export type InterpretationSignals = Record<string, number>; // e.g. { saturn: 0.7, neptune: 0.2 }

export type ConversationState = {
  turnIndex: number;

  // User-specific tuning
  userTolerance: number; // 0..1 (low = easily annoyed)
  lastToneLevel: ToneLevel;
  lastPassiveAggressiveAtTurn: number | null; // turn index

  // Behavioral signals
  recentUserComplianceScore: number; // 0..1
  recentUserEmotionalReactivity: number; // 0..1

  // Safety knobs
  maxPassiveAggressiveEveryNTurns?: number; // default 4
};

export type TurnInput = {
  text: string;
  nlu: NluResult;
  signals?: InterpretationSignals;
  state: ConversationState;
};

export type DeliveryStyle = {
  brevity: "short" | "medium" | "long";
  indirectness: "low" | "medium" | "high";
  warmth: "low" | "medium" | "high";
  punch: "low" | "medium" | "high";
};

export type ResponsePlan = {
  intent: string;
  toneLevel: ToneLevel;
  toneTag: string; // e.g. "neutral", "polite_shade", "dry_passive", "surgical"
  shouldUsePassiveAggressiveLine: boolean;
  deliveryStyle: DeliveryStyle;
  reasoning: string[]; // operational notes (not user-facing)
};
