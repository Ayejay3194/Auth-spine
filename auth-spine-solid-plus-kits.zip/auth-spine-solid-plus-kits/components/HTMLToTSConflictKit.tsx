"use client";
import React, { useMemo, useState } from "react";
import {
  Search,
  AlertTriangle,
  Code,
  Zap,
  XCircle,
  CheckCircle,
  Copy,
  ChevronDown,
  ChevronRight
} from "lucide-react";

type ConflictItem = {
  id: string;
  problem: string;
  wrongCode: string;
  rightCode: string;
  explanation: string;
  additionalIssues: string[];
};

type ConflictData = Record<string, ConflictItem[]>;

export default function HTMLToTSConflictKit() {
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const conflictData: ConflictData = useMemo(
    () => ({
      "JSX vs HTML Syntax Conflicts": [
        {
          id: "jsx-1",
          problem: "class attribute causing errors",
          wrongCode: `<div class="container">Content</div>`,
          rightCode: `<div className="container">Content</div>`,
          explanation: `In JSX/React, "class" is reserved. Use "className".`,
          additionalIssues: ["Replace all class= with className=", "Check dynamic class strings too"]
        },
        {
          id: "jsx-2",
          problem: "for attribute on labels breaking",
          wrongCode: `<label for="email">Email</label>`,
          rightCode: `<label htmlFor="email">Email</label>`,
          explanation: `JSX uses htmlFor instead of for.`,
          additionalIssues: ["Update all <label> elements"]
        },
        {
          id: "jsx-3",
          problem: "Inline style strings not working",
          wrongCode: `<div style="color: red; font-size: 16px;">Text</div>`,
          rightCode: `<div style={{ color: 'red', fontSize: '16px' }}>Text</div>`,
          explanation: "JSX styles are objects with camelCase properties, not strings.",
          additionalIssues: ["background-color → backgroundColor", "Wrap values in quotes", "Use double braces {{ }}"]
        },
        {
          id: "jsx-4",
          problem: "Self-closing tags must close",
          wrongCode: `<img src="image.jpg"> <input type="text"> <br>`,
          rightCode: `<img src="image.jpg" /> <input type="text" /> <br />`,
          explanation: "JSX requires all tags to be closed.",
          additionalIssues: ["Fix img/input/br/hr/meta/link", "Check custom components too"]
        },
        {
          id: "jsx-5",
          problem: "onclick/onchange attributes not working",
          wrongCode: `<button onclick="handleClick()">Click</button>`,
          rightCode: `<button onClick={handleClick}>Click</button>`,
          explanation: "JSX events are camelCase and take function refs, not strings.",
          additionalIssues: ["Remove quotes", "Remove () unless wrapping in arrow fn"]
        },
        {
          id: "jsx-6",
          problem: "HTML comments break JSX",
          wrongCode: `<!-- comment -->`,
          rightCode: `{/* comment */}`,
          explanation: "Use JSX comment syntax inside JSX.",
          additionalIssues: ["Replace all <!-- --> inside JSX"]
        }
      ],
      "State & Event Handling": [
        {
          id: "state-1",
          problem: "Direct DOM manipulation breaking React",
          wrongCode: `document.getElementById('x').innerHTML = 'New';`,
          rightCode: `const [x,setX]=useState('Old'); setX('New');`,
          explanation: "React owns the DOM. Use state.",
          additionalIssues: ["Remove querySelector/getElementById", "Replace innerHTML/style hacks with state"]
        },
        {
          id: "state-2",
          problem: "Event handler receiving string instead of function",
          wrongCode: `<button onClick="handleClick()">Click</button>`,
          rightCode: `<button onClick={handleClick}>Click</button>`,
          explanation: "Pass function refs, not strings/invocations.",
          additionalIssues: ["Use arrow function to pass args"]
        }
      ],
      "TypeScript Issues": [
        {
          id: "type-1",
          problem: "Type errors on event handlers",
          wrongCode: `const onSubmit = (e) => e.preventDefault();`,
          rightCode: `const onSubmit = (e: React.FormEvent<HTMLFormElement>) => e.preventDefault();`,
          explanation: "TypeScript needs explicit event types.",
          additionalIssues: ["MouseEvent, ChangeEvent, FormEvent, KeyboardEvent"]
        }
      ]
    }),
    []
  );

  const copyCode = async (code: string, id: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1500);
    } catch {}
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories((prev) => ({ ...prev, [category]: !prev[category] }));
  };

  const filteredData = useMemo(() => {
    if (!searchTerm) return conflictData;
    const term = searchTerm.toLowerCase();
    const filtered: ConflictData = {};
    for (const category of Object.keys(conflictData)) {
      const items = conflictData[category].filter((item) => {
        return (
          item.problem.toLowerCase().includes(term) ||
          item.explanation.toLowerCase().includes(term) ||
          item.additionalIssues.some((i) => i.toLowerCase().includes(term))
        );
      });
      if (items.length) filtered[category] = items;
    }
    return filtered;
  }, [searchTerm, conflictData]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl shadow-soft p-6 md:p-8 mb-6 border-4 border-red-500">
          <div className="flex items-center gap-3 mb-4">
            <AlertTriangle className="w-10 h-10 text-red-600" />
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-800">HTML → TypeScript Conflict Resolver</h1>
              <p className="text-red-600 font-semibold">Fix all the things fighting each other.</p>
            </div>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search: class, onclick, style, state, types..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border-2 border-slate-200 rounded-lg focus:border-red-500 focus:outline-none text-slate-800"
            />
          </div>
        </div>

        <div className="space-y-4">
          {Object.keys(filteredData).length === 0 ? (
            <div className="bg-white rounded-lg p-8 text-center">
              <XCircle className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <p className="text-slate-600">No results. Try: class, onclick, style, state, props</p>
            </div>
          ) : (
            Object.entries(filteredData).map(([category, items]) => (
              <div key={category} className="bg-white rounded-xl shadow-soft overflow-hidden border-2 border-slate-200">
                <button
                  onClick={() => toggleCategory(category)}
                  className="w-full px-6 py-4 flex items-center justify-between bg-gradient-to-r from-red-100 to-orange-100 hover:from-red-200 hover:to-orange-200 transition-colors"
                >
                  <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <Code className="w-6 h-6" />
                    {category}
                  </h2>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600 bg-white px-3 py-1 rounded-full font-semibold">
                      {items.length} {items.length === 1 ? "conflict" : "conflicts"}
                    </span>
                    {expandedCategories[category] ? (
                      <ChevronDown className="w-5 h-5 text-slate-600" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-slate-600" />
                    )}
                  </div>
                </button>

                {expandedCategories[category] && (
                  <div className="p-6 space-y-8">
                    {items.map((item) => (
                      <div key={item.id} className="border-l-4 border-red-500 pl-6 py-2">
                        <h3 className="text-lg font-bold text-slate-800 mb-3 flex items-center gap-2">
                          <AlertTriangle className="w-5 h-5 text-orange-600" />
                          {item.problem}
                        </h3>

                        <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 mb-4">
                          <div className="flex items-center gap-2 mb-2">
                            <XCircle className="w-5 h-5 text-red-600" />
                            <p className="font-bold text-red-900">WRONG</p>
                          </div>
                          <div className="bg-slate-900 rounded p-3">
                            <pre className="text-sm text-slate-100 overflow-x-auto">
                              <code>{item.wrongCode}</code>
                            </pre>
                          </div>
                        </div>

                        <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4 mb-4">
                          <div className="flex items-center gap-2 mb-2">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <p className="font-bold text-green-900">RIGHT</p>
                          </div>
                          <div className="bg-slate-900 rounded p-3 relative">
                            <button
                              onClick={() => copyCode(item.rightCode, item.id)}
                              className="absolute top-2 right-2 p-2 bg-green-600 hover:bg-green-700 rounded transition-colors"
                              title="Copy code"
                            >
                              {copiedId === item.id ? (
                                <CheckCircle className="w-4 h-4 text-white" />
                              ) : (
                                <Copy className="w-4 h-4 text-white" />
                              )}
                            </button>
                            <pre className="text-sm text-slate-100 overflow-x-auto pr-12">
                              <code>{item.rightCode}</code>
                            </pre>
                          </div>
                        </div>

                        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-4">
                          <p className="text-blue-900 font-semibold flex items-center gap-2">
                            <Zap className="w-4 h-4" />
                            Why this matters
                          </p>
                          <p className="text-slate-700 mt-2">{item.explanation}</p>
                        </div>

                        <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4">
                          <p className="text-yellow-900 font-semibold mb-2">Also check for</p>
                          <ul className="space-y-1">
                            {item.additionalIssues.map((issue, idx) => (
                              <li key={idx} className="text-slate-700 text-sm flex items-start gap-2">
                                <span className="text-yellow-600 font-bold mt-0.5">•</span>
                                <span>{issue}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
