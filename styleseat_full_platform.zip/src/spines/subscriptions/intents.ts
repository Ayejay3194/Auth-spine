// subscriptions intents.ts
