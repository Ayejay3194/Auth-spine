import type { EphemerisEngine, ChartRequest } from "../engine/engine.js";
import { canonicalizeChartDataV1 } from "../canonical/canonicalize.js";
import { sha256Hex } from "../integrity/hash.js";
import { validateChartDataV1 } from "../validate/validate.js";

export async function computeNatalWithIntegrity(engine: EphemerisEngine, req: ChartRequest) {
  const raw = await engine.computeNatal(req);

  const canonical = canonicalizeChartDataV1(raw);
  const sha256 = sha256Hex(canonical);

  const payload = {
    ...raw,
    integrity: { canonical, sha256 },
  };

  return validateChartDataV1(payload);
}
