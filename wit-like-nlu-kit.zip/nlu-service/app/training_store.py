import os, json
from typing import List, Dict, Any
from .config import TRAINING_PATH

def read_training(path: str = TRAINING_PATH) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        return []
    out=[]
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out

def append_example(example: Dict[str, Any], path: str = TRAINING_PATH) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(example, ensure_ascii=False) + "\n")
