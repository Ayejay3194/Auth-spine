import { z } from 'zod'

export const baseEnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  DATABASE_URL: z.string().url(),
  JWT_SECRET: z.string().min(32, 'JWT secret must be at least 32 characters'),
  JWT_EXPIRES_IN: z.string().default('7d'),
  REDIS_URL: z.string().url().optional(),

  STRIPE_SECRET_KEY: z.string().optional(),
  SENDGRID_API_KEY: z.string().optional(),
  RESEND_API_KEY: z.string().optional(),

  LOG_LEVEL: z.string().optional(),
})

export type EnvConfig = z.infer<typeof baseEnvSchema>

export function validateEnv(env: NodeJS.ProcessEnv = process.env): EnvConfig {
  const parsed = baseEnvSchema.safeParse(env)
  if (!parsed.success) {
    console.error('❌ Invalid environment configuration:')
    for (const err of parsed.error.errors) {
      console.error(`  - ${err.path.join('.')}: ${err.message}`)
    }
    process.exit(1)
  }
  return parsed.data
}
