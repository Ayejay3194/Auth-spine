-- Billing state tables (provider-agnostic)
create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  provider text not null, -- stripe
  provider_subscription_id text not null,
  status text not null,
  current_period_end timestamptz,
  created_at timestamptz default now(),
  unique (provider, provider_subscription_id)
);
