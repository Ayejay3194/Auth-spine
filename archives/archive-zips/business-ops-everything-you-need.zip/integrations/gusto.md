Payroll provider integration notes.
