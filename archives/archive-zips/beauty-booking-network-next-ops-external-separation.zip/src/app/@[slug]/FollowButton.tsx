"use client";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";

export function FollowButton({ stylistId }:{ stylistId: string }){
  const { data } = useSession();
  const [following, setFollowing] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(()=>{
    (async()=>{
      const r = await fetch(`/api/follow/status/${stylistId}`, { cache:"no-store" });
      const j = await r.json();
      setFollowing(Boolean(j.following));
    })();
  },[stylistId]);

  async function toggle(){
    if(!data?.user) {
      window.location.href = "/auth/sign-in";
      return;
    }
    setBusy(true);
    const action = following ? "unfollow" : "follow";
    await fetch("/api/follow", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify({ stylistId, action }) });
    setFollowing(!following);
    setBusy(false);
  }

  return (
    <button
      onClick={toggle}
      disabled={busy}
      className="rounded-2xl border px-5 py-3 text-sm font-semibold disabled:opacity-60"
      style={{borderColor:"var(--border)", background:"var(--panel2)", color:"var(--text)"}}
    >
      {following ? "Following" : "Follow"}
    </button>
  );
}
