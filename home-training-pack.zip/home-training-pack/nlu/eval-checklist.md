# Conversational Realism Eval Checklist

Score each 0–2 (0 = bad, 1 = meh, 2 = good). Target >= 14/20.

- Context carryover (remembers the last turn)
- Clarifying question quality (single, specific)
- Natural variation (doesn’t sound templated)
- Error handling (useful next step)
- Tone stability (no random personality swings)
- Concision (not 700 words for a yes/no)
- Task completion (actually does the thing)
- Safety consistency (doesn’t leak secrets/PII)
- Multi-tenant awareness (doesn’t cross streams)
- “Human” micro-behaviors (acknowledges, confirms, moves on)
