import Link from 'next/link';
import type { ReactNode } from 'react';

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex bg-slate-950 text-slate-50">
      <aside className="w-64 border-r border-slate-800 p-4 space-y-4">
        <div className="text-lg font-semibold">Ultimate SaaS</div>
        <nav className="space-y-2 text-sm">
          <Link href="/dashboard" className="block hover:underline">
            Dashboard
          </Link>
          <Link href="/dashboard/projects" className="block hover:underline">
            Projects
          </Link>
          <Link href="/dashboard/billing" className="block hover:underline">
            Billing
          </Link>
          <Link href="/blog" className="block hover:underline">
            Blog
          </Link>
          <Link href="/admin" className="block hover:underline">
            Admin
          </Link>
        </nav>
      </aside>
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
