import { NextResponse } from "next/server";
import { getNLUBaseUrl } from "@/lib/serverEnv";

export async function POST() {
  const base = getNLUBaseUrl();
  const r = await fetch(`${base}/train`, { method: "POST" });
  const body = await r.json();
  return NextResponse.json(body, { status: r.status });
}
