
export function interpret(payload: {
  intent: string;
  entities: Record<string, any>;
}) {
  if (payload.intent === "ask_transit_meaning") {
    const { planet, house } = payload.entities;
    return `This is a ${planet} activation in your ${house} house.`;
  }

  return "No interpretation available.";
}
