# Backup Strategy
Run `scripts/backup_pg.sh backups/` on a schedule and store backups off-box.
