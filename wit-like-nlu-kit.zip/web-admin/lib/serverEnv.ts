export function getNLUBaseUrl() {
  const url = process.env.NLU_BASE_URL;
  if (!url) throw new Error("Missing NLU_BASE_URL env var");
  return url;
}
