import type { UserRole, User } from "@prisma/client";

export type Perm =
  | "ops.read.users"
  | "ops.write.users"
  | "ops.read.bookings"
  | "ops.write.bookings"
  | "ops.view.pii"
  | "ops.refund.payments"
  | "studio.write.profile"
  | "studio.write.services"
  | "studio.write.availability"
  | "studio.read.bookings";

const ROLE_PERMS: Record<UserRole, Perm[]> = {
  CLIENT: [],
  STYLIST: ["studio.write.profile","studio.write.services","studio.write.availability","studio.read.bookings"],
  RECEPTION: ["ops.read.bookings","ops.write.bookings"],
  MANAGER: ["ops.read.users","ops.read.bookings","ops.write.bookings","ops.view.pii"],
  OWNER: ["ops.read.users","ops.write.users","ops.read.bookings","ops.write.bookings","ops.view.pii","ops.refund.payments"],
  ADMIN: ["ops.read.users","ops.write.users","ops.read.bookings","ops.write.bookings","ops.view.pii","ops.refund.payments"],
  SUPPORT: ["ops.read.users","ops.read.bookings"],
};

export function permsFor(user: Pick<User, "role"> | null | undefined): Perm[] {
  if(!user) return [];
  return ROLE_PERMS[user.role] ?? [];
}

export async function requireRole(user: Pick<User, "role"> | null | undefined, roles: UserRole[]) {
  if(!user) throw new Error("UNAUTHORIZED");
  if(!roles.includes(user.role)) throw new Error("FORBIDDEN");
}

export async function requirePerm(user: Pick<User, "role"> | null | undefined, perm: Perm) {
  if(!user) throw new Error("UNAUTHORIZED");
  const perms = permsFor(user);
  if(!perms.includes(perm)) throw new Error("FORBIDDEN");
}
