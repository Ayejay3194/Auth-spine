#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/out"
BASE_URL="$(cat "$OUT/target_base_url.txt")"

echo "== OWASP ZAP baseline scan =="
echo "Target: $BASE_URL"

docker run --rm -t   -v "$OUT:/zap/wrk/:rw"   zaproxy/zap-stable   zap-baseline.py     -t "$BASE_URL"     -r zap-report.html     -J zap-report.json     -w zap-warnings.md     -x zap-report.xml     -I   || true
