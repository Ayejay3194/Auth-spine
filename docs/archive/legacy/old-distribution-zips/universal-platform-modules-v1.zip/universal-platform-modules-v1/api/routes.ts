import routes from "./routes.json";
export const API_ROUTES = routes as { method: string; path: string; module: string }[];
