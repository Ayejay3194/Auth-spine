import type { PrismaClient } from "@prisma/client";
import type { VenueProvider, DateProvider, ReservationProvider, SafetyProvider, SafetyRules } from "./types.js";

// Template only. Replace prisma.* calls with your schema.

export function driftDateProviders(prisma: PrismaClient, businessId: string) {
  const venue: VenueProvider = {
    async searchVenues(input) {
      // Replace with your venue catalog or external places API.
      const rows = await prisma.venue.findMany({
        where: {
          businessId,
          ...(input.query ? { name: { contains: input.query, mode: "insensitive" } } : {}),
          ...(input.category ? { category: input.category } : {}),
          ...(input.neighborhood ? { neighborhood: input.neighborhood } : {}),
        },
        take: Math.min(input.limit ?? 10, 50),
      }) as any[];
      return rows.map(r => ({ venueId: r.id, name: r.name, category: r.category, neighborhood: r.neighborhood, lat: r.lat, lon: r.lon, priceLevel: r.priceLevel })) as any;
    }
  };

  const dates: DateProvider = {
    async createDateRequest(input) {
      const row = await prisma.dateRequest.create({
        data: {
          businessId,
          matchId: input.matchId,
          proposerUserId: input.proposerUserId,
          inviteeUserId: input.inviteeUserId,
          title: input.title,
          category: input.category,
          budget: input.budget ?? null,
          proposedStartISO: input.proposedStartISO ?? null,
          windowStartISO: input.windowStartISO ?? null,
          windowEndISO: input.windowEndISO ?? null,
          partySize: input.partySize ?? 2,
          status: "awaiting_acceptance",
        }
      }) as any;
      return { dateRequestId: row.id, matchId: row.matchId, proposerUserId: row.proposerUserId, inviteeUserId: row.inviteeUserId, title: row.title, category: row.category, budget: row.budget ?? undefined, windowStartISO: row.windowStartISO ?? undefined, windowEndISO: row.windowEndISO ?? undefined, proposedStartISO: row.proposedStartISO ?? undefined, status: row.status, createdISO: row.createdAt.toISOString() } as any;
    },
    async getDateRequest(input) {
      const row = await prisma.dateRequest.findUnique({ where: { id: input.dateRequestId } }) as any;
      if (!row) return null;
      return { dateRequestId: row.id, matchId: row.matchId, proposerUserId: row.proposerUserId, inviteeUserId: row.inviteeUserId, title: row.title, category: row.category, budget: row.budget ?? undefined, windowStartISO: row.windowStartISO ?? undefined, windowEndISO: row.windowEndISO ?? undefined, proposedStartISO: row.proposedStartISO ?? undefined, status: row.status, createdISO: row.createdAt.toISOString() } as any;
    },
    async acceptDateRequest(input) {
      const row = await prisma.dateRequest.update({ where: { id: input.dateRequestId }, data: { status: "accepted" } }) as any;
      return { dateRequestId: row.id, matchId: row.matchId, proposerUserId: row.proposerUserId, inviteeUserId: row.inviteeUserId, title: row.title, category: row.category, budget: row.budget ?? undefined, proposedStartISO: row.proposedStartISO ?? undefined, status: row.status, createdISO: row.createdAt.toISOString() } as any;
    },
    async declineDateRequest(input) {
      const row = await prisma.dateRequest.update({ where: { id: input.dateRequestId }, data: { status: "cancelled" } }) as any;
      return { dateRequestId: row.id, matchId: row.matchId, proposerUserId: row.proposerUserId, inviteeUserId: row.inviteeUserId, title: row.title, category: row.category, budget: row.budget ?? undefined, proposedStartISO: row.proposedStartISO ?? undefined, status: row.status, createdISO: row.createdAt.toISOString() } as any;
    },
    async cancelDateRequest(input) {
      const row = await prisma.dateRequest.update({ where: { id: input.dateRequestId }, data: { status: "cancelled" } }) as any;
      return { dateRequestId: row.id, matchId: row.matchId, proposerUserId: row.proposerUserId, inviteeUserId: row.inviteeUserId, title: row.title, category: row.category, budget: row.budget ?? undefined, proposedStartISO: row.proposedStartISO ?? undefined, status: row.status, createdISO: row.createdAt.toISOString() } as any;
    },
    async setProposedTime(input) {
      const row = await prisma.dateRequest.update({ where: { id: input.dateRequestId }, data: { proposedStartISO: input.proposedStartISO, status: "awaiting_acceptance" } }) as any;
      return { dateRequestId: row.id, matchId: row.matchId, proposerUserId: row.proposerUserId, inviteeUserId: row.inviteeUserId, title: row.title, category: row.category, budget: row.budget ?? undefined, proposedStartISO: row.proposedStartISO ?? undefined, status: row.status, createdISO: row.createdAt.toISOString() } as any;
    },
  };

  const reservations: ReservationProvider = {
    async createReservation(input) {
      const row = await prisma.reservation.create({
        data: { businessId, dateRequestId: input.dateRequestId, venueId: input.venueId, startISO: input.startISO, partySize: input.partySize, status: "created" }
      }) as any;
      await prisma.dateRequest.update({ where: { id: input.dateRequestId }, data: { status: "reserved" } });
      return { reservationId: row.id, venueId: row.venueId, startISO: row.startISO, partySize: row.partySize, status: row.status, confirmationCode: row.confirmationCode ?? undefined } as any;
    },
    async cancelReservation(input) {
      const row = await prisma.reservation.update({ where: { id: input.reservationId }, data: { status: "cancelled" } }) as any;
      return { reservationId: row.id, venueId: row.venueId, startISO: row.startISO, partySize: row.partySize, status: row.status, confirmationCode: row.confirmationCode ?? undefined } as any;
    }
  };

  const safety: SafetyProvider = {
    async setSafetyRules(input) {
      const rules = input.rules as SafetyRules;
      await prisma.safetyRule.upsert({
        where: { matchId_userId: { matchId: input.matchId, userId: input.userId } } as any,
        create: { businessId, matchId: input.matchId, userId: input.userId, ...rules },
        update: { ...rules },
      });
      return { ok: true };
    },
    async getSafetyRules(input) {
      const row = await prisma.safetyRule.findUnique({ where: { matchId_userId: { matchId: input.matchId, userId: input.userId } } as any }) as any;
      if (!row) return null;
      return {
        shareExactLocationAt: row.shareExactLocationAt ?? undefined,
        shareAtISO: row.shareAtISO ?? undefined,
        checkinTimerMin: row.checkinTimerMin ?? undefined,
        emergencyContactEnabled: Boolean(row.emergencyContactEnabled),
      } as any;
    },
    async checkIn(input) {
      const ev = await prisma.checkInEvent.create({ data: { businessId, dateRequestId: input.dateRequestId, userId: input.userId } }) as any;
      return { ok: true, atISO: ev.createdAt.toISOString() };
    }
  };

  return { venue, dates, reservations, safety };
}
