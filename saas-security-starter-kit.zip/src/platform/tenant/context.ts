import { TenantContext } from "./types";

export class TenantContextError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "TenantContextError";
  }
}

// In real life: derive from signed session/JWT + tenant membership table.
// NEVER trust request headers from the client for tenant identity.
export async function deriveTenantContext(req: {
  headers: Record<string, string | string[] | undefined>;
  ip?: string;
  url?: string;
}): Promise<TenantContext> {
  const requestId = cryptoRandomId();

  const auth = req.headers["authorization"];
  if (!auth || Array.isArray(auth)) throw new TenantContextError("Missing Authorization");

  // TODO: verify JWT / session token, then lookup tenant membership.
  // Placeholder safe defaults:
  const tenantId = ("t_demo" as any);
  const userId = ("u_demo" as any);
  const roles = ["EMPLOYEE"];
  const plan = "FREE";
  const region = "us-east";

  return { tenantId, userId, roles, plan, region, requestId };
}

function cryptoRandomId(): string {
  // Node 18+ has crypto.randomUUID()
  // Avoid importing node crypto for edge runtimes; swap impl as needed.
  return (globalThis.crypto?.randomUUID?.() ?? `${Date.now()}_${Math.random().toString(16).slice(2)}`);
}
