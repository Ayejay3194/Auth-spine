export type Slot = { slotId: string; startISO: string; durationMin: number };
export type Booking = { bookingId: string; slotId: string; service?: string; status: "confirmed" | "canceled" | "completed" };
export type Client = { clientId: string; name: string; email?: string; phone?: string; tags: string[] };
export type Invoice = { invoiceId: string; clientId: string; amount: number; status: "draft" | "sent" | "paid" | "refunded" };
export type Promo = { code: string; percentOff: number; active: boolean };
export type Referral = { code: string; referrerClientId: string; uses: number };
export type KPI = { key: string; value: number; unit?: string };
export type Task = { taskId: string; title: string; status: "open" | "done" };

export interface BookingProvider {
  findSlots(input: { durationMin: number; dateISO?: string; timeHint?: string; service?: string }): Promise<Slot[]>;
  createBooking(input: { userId: string; clientId?: string; slotId: string; service?: string }): Promise<Booking>;
  cancelBooking(input: { bookingId: string }): Promise<Booking>;
  listBookings(input: { userId: string }): Promise<Booking[]>;
}

export interface CRMProvider {
  findClient(input: { query: string }): Promise<Client | null>;
  addNote(input: { clientId: string; note: string }): Promise<void>;
  tagClient(input: { clientId: string; tag: string }): Promise<void>;
}

export interface PaymentsProvider {
  createInvoice(input: { clientId: string; amount: number }): Promise<Invoice>;
  refund(input: { invoiceId: string }): Promise<Invoice>;
}

export interface MarketingProvider {
  createPromo(input: { code: string; percentOff: number }): Promise<Promo>;
  referralStatus(input: { code: string }): Promise<Referral | null>;
  sendCampaign(input: { segment: string; message: string }): Promise<{ queued: boolean }>;
}

export interface AnalyticsProvider {
  kpis(input: {}): Promise<KPI[]>;
  exportReport(input: { report: string; format: "csv" | "json" }): Promise<{ url: string }>;
}

export interface OpsProvider {
  listTasks(input: {}): Promise<Task[]>;
  createTask(input: { title: string }): Promise<Task>;
  markDone(input: { taskId: string }): Promise<Task>;
  startChecklist(input: { name: "open" | "close" }): Promise<{ steps: string[] }>;
}

export interface AdminProvider {
  showAudit(input: { limit: number }): Promise<Array<{ at: string; type: string; details: any }>>;
  gdprExport(input: { userId: string }): Promise<{ url: string }>;
}

export type Providers = {
  booking: BookingProvider;
  crm: CRMProvider;
  payments: PaymentsProvider;
  marketing: MarketingProvider;
  analytics: AnalyticsProvider;
  ops: OpsProvider;
  admin: AdminProvider;
};
