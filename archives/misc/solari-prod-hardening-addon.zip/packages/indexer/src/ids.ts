/**
 * ID stability helpers:
 * - if node.id missing, derive from kind+slug
 * - if id exists, enforce it doesn't change unless version bump
 */
export function slugify(s: string) {
  return s.trim().toLowerCase()
    .replace(/['"]/g,"")
    .replace(/[^a-z0-9]+/g,"-")
    .replace(/^-+|-+$/g,"");
}

export function deriveId(kind: string, title: string) {
  // kind example "hd:gate" -> domain "hd", kind "gate"
  const parts = kind.split(":");
  const domain = parts[0] ?? "solari";
  const k = parts[1] ?? "node";
  return `${domain}:${k}:${slugify(title)}`;
}
