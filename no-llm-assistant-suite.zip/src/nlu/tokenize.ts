export function normalize(text: string): string {
  return text.toLowerCase().trim();
}
export function tokenize(text: string): string[] {
  const t = normalize(text)
    .replace(/[^a-z0-9\s@._:/-]/g, " ")
    .replace(/\s+/g, " ");
  return t.split(" ").filter(Boolean);
}
export function bag(tokens: string[]): Map<string, number> {
  const m = new Map<string, number>();
  for (const tok of tokens) m.set(tok, (m.get(tok) ?? 0) + 1);
  return m;
}
export function cosine(a: Map<string, number>, b: Map<string, number>): number {
  let dot = 0, na = 0, nb = 0;
  for (const [k, va] of a) {
    na += va * va;
    const vb = b.get(k);
    if (vb) dot += va * vb;
  }
  for (const vb of b.values()) nb += vb * vb;
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}
