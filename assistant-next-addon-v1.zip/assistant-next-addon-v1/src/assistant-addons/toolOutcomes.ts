import type { Intent, ToolResult } from "./types";

export function toolOutcomeReply(intent: Intent, result: ToolResult) {
  switch (result.outcome) {
    case "ok":
      return okReply(intent, result);
    case "needs_more_info":
      return `I need ${result.missing?.join(", ") ?? "a bit more info"} to finish that.`;
    case "conflict":
      return result.message ?? "That time isn’t available. Want the next closest opening?";
    case "not_found":
      return result.message ?? "I couldn’t find that. Double-check the details and try again.";
    case "payment_required":
      return result.message ?? "Payment is needed before I can confirm this. Want a payment link?";
    case "blocked":
      return result.message ?? "I can’t do that due to policy rules.";
    case "error":
    default:
      return result.message ?? "Something failed on my side. Try again.";
  }
}

function okReply(intent: Intent, result: ToolResult) {
  // Keep replies short. Humans don’t want novels.
  switch (intent) {
    case "book_service":
      return `Booked. ${fmt(result.data)}`;
    case "reschedule_booking":
      return `Rescheduled. ${fmt(result.data)}`;
    case "cancel_booking":
      return "Canceled.";
    case "check_availability":
      return `Openings: ${fmt(result.data)}`;
    default:
      return "Done.";
  }
}

function fmt(v: any) {
  if (!v) return "";
  if (typeof v === "string") return v;
  if (Array.isArray(v)) return v.join(", ");
  if (typeof v === "object") return Object.entries(v).map(([k,val]) => `${k}=${val}`).join(" ");
  return String(v);
}
