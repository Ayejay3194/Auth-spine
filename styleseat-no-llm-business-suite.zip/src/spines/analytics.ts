import { FlowDefinition } from "../flows/types.js";
import { Tool } from "../tools/types.js";
import { AnalyticsProvider } from "../providers/types.js";

export function analyticsSpine(opts: { provider: AnalyticsProvider }) {
  const { provider } = opts;

  const tools: Tool<any, any>[] = [
    {
      id: "analytics.kpis",
      description: "Get KPI metrics",
      validate: () => {},
      run: async (_ctx, input) => ({ ok: true, data: { kpis: await provider.kpis({ dateISO: input.dateISO }) } }),
      timeoutMs: 2500,
    },
    {
      id: "analytics.export",
      description: "Export report",
      validate: (i) => { if (!i.report) throw new Error("Missing report"); if (!["csv","json"].includes(i.format)) throw new Error("Bad format"); },
      run: async (_ctx, input) => ({ ok: true, data: await provider.exportReport({ report: input.report, format: input.format }) }),
      timeoutMs: 5000,
    },
  ];

  const flows: FlowDefinition[] = [
    {
      intent: "analytics.kpi",
      slots: [{ name: "dateISO", required: false, fromEntity: (e) => (e.find(x => x.type === "datetime")?.meta as any)?.dateISO ?? null }],
      steps: () => [
        { call: { toolId: "analytics.kpis", inputFromSlots: (s) => ({ dateISO: s.dateISO }) } },
        { done: { message: "Here are your KPIs." } },
      ],
    },
    {
      intent: "analytics.report_export",
      slots: [{ name: "report", required: true }, { name: "format", required: true }, { name: "confirm", required: true }],
      steps: () => [
        { ask: { slot: "report", prompt: "Which report? (revenue|bookings|clients)", hint: "revenue" } },
        { ask: { slot: "format", prompt: "Format? (csv|json)", hint: "csv" } },
        { ask: { slot: "confirm", prompt: "Type YES to export.", hint: "YES" } },
        { call: { toolId: "analytics.export", commitIntent: "analytics.report_export", confirmSlot: "confirm", inputFromSlots: (s) => ({ report: s.report, format: s.format }) } },
        { done: { message: "Export started." } },
      ],
    },
  ];

  return { tools, flows };
}
