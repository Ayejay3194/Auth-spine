import { describe, test, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";

function exists(p: string) {
  return fs.existsSync(p);
}

describe("Repo organization", () => {
  test("expected directories exist (relative, not hard-coded)", () => {
    const repoRoot = process.cwd();
    const srcDir = path.join(repoRoot, "src");

    // If your repo structure differs, update this list.
    const expected = [
      path.join(srcDir, "core"),
      path.join(srcDir, "spines"),
      path.join(srcDir, "api"),
      path.join(srcDir, "smart"),
      path.join(srcDir, "plugins"),
      path.join(srcDir, "utils"),
      path.join(srcDir, "adapters")
    ];

    // Only enforce if /src exists. If you're running tests from a package, skip.
    if (!exists(srcDir)) return;

    for (const p of expected) {
      expect(exists(p)).toBe(true);
    }
  });

  test("config files exist", () => {
    const repoRoot = process.cwd();
    const expected = ["package.json", "tsconfig.json", ".gitignore"].map(f => path.join(repoRoot, f));
    for (const p of expected) {
      if (exists(path.join(repoRoot, "package.json"))) {
        expect(exists(p)).toBe(true);
      }
    }
  });
});