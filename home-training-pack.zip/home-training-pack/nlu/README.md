# Conversational “Home Training” Pack (NLU + Dialogue)

Goal: make your assistant sound real without needing a giant model.
This pack gives you:
- an intent/entity schema you can expand
- dialogue patterns (tone, repair, follow-ups)
- evaluation harness ideas (consistency, memory, safety, tenant isolation)
- data templates (JSONL) you can generate/label at home

## What “sounds real” actually means
1) it acknowledges context and constraints
2) it repairs misunderstandings smoothly
3) it uses varied phrasing (no robotic repeats)
4) it has conversational micro-behaviors (backchannels, clarifying re-asks, summaries)
5) it keeps policy boundaries consistent (no random personality flips)

## Folder contents
- `intent-schema.json`
- `templates/dialogue-jsonl.template`
- `templates/prompt-library.md`
- `eval-checklist.md`
