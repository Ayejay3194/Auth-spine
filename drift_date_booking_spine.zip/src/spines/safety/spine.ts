    import { Spine, Intent, AssistantContext, Extraction, FlowStep } from "../../core/types.js";
    import { detectByPatterns } from "../../core/intent.js";
    import { requireFields, extractDateTime } from "../../core/entities.js";
    import { patterns } from "./intents.js";

    const REQUIRED: Record<string, string[]> = {
  "safety_set_rules": [
    "matchId"
  ],
  "safety_checkin": [
    "dateRequestId"
  ]
};
    const MAP: Record<string, { tool: string; action: string; sensitivity: "low"|"medium"|"high" }> = {
  "safety_set_rules": {
    "tool": "safety.set_rules",
    "action": "safety.set_rules",
    "sensitivity": "high"
  },
  "safety_checkin": {
    "tool": "safety.checkin",
    "action": "safety.checkin",
    "sensitivity": "medium"
  }
};

    function baseEntities(text: string, ctx: AssistantContext): Record<string, unknown> {
      const out: Record<string, unknown> = {};

      const mid = text.match(/\b(match_[a-z0-9]+)\b/i);
      if (mid) out.matchId = mid[1];

      const dr = text.match(/\b(date_[a-z0-9]+|daterequest_[a-z0-9]+)\b/i);
      if (dr) out.dateRequestId = dr[1];

      const uid = text.match(/\b(invitee|for)\s+(user_[a-z0-9]+)\b/i);
      if (uid) out.inviteeUserId = uid[2];

      const cat = text.match(/\b(dinner|drinks|coffee|museum|minigolf|mini golf|movie|walk)\b/i);
      if (cat) out.category = cat[1].toLowerCase().replace("mini golf","minigolf");

      const bud = text.match(/\$\s*(\d+)\b/);
      if (bud) out.budget = Number(bud[1]);

      const ps = text.match(/\bparty\s*(\d+)\b/i);
      if (ps) out.partySize = Number(ps[1]);

      const dt = extractDateTime(text, ctx.nowISO);
      if (dt.dateTimeISO) out.proposedStartISO = dt.dateTimeISO;

      const venue = text.match(/\bvenue\s+(venue_[a-z0-9]+)\b/i);
      if (venue) out.venueId = venue[1];

      const tr = text.match(/\btitle\s+(.+)$/i);
      if (tr) out.title = tr[1].trim();

      return out;
    }

    export const spine: Spine = {
      name: "safety",
      description: "Drift safety: location share rules + check-in",
      detectIntent: (text, _ctx) => detectByPatterns(text, patterns),
      extractEntities: (intent: Intent, text: string, ctx: AssistantContext): Extraction => {
        const entities = baseEntities(text, ctx);

        if (intent.name === "safety_set_rules") {
  const rules: any = {};
  if (/never\s+share\s+location/i.test(text)) rules.shareExactLocationAt = "never";
  if (/share\s+at\s+check\s*in/i.test(text)) rules.shareExactLocationAt = "checkin";
  const tm = text.match(/share\s+at\s+(.+)/i);
  if (tm) {
    const dt2 = extractDateTime(tm[1], ctx.nowISO);
    if (dt2.dateTimeISO) { rules.shareExactLocationAt = "time"; rules.shareAtISO = dt2.dateTimeISO; }
  }
  const cm = text.match(/check[- ]?in\s*(?:timer)?\s*(\d+)\s*(?:min|minutes)/i);
  if (cm) rules.checkinTimerMin = Number(cm[1]);
  if (/emergency\s+contact\s+on/i.test(text)) rules.emergencyContactEnabled = true;
  if (/emergency\s+contact\s+off/i.test(text)) rules.emergencyContactEnabled = false;
  (entities as any).rules = rules;
}


        const req = REQUIRED[intent.name] ?? [];
        const missing = requireFields(entities, req);
        return { entities, missing };
      },
      buildFlow: (intent, extraction, _ctx): FlowStep[] => {
        if (extraction.missing.length) {
          return [{ kind: "ask", prompt: `Missing: ${extraction.missing.join(", ")}`, missing: extraction.missing }];
        }
        const m = MAP[intent.name];
        if (!m) return [{ kind: "respond", message: `No mapping for intent: ${intent.name}` }];

        return [{
          kind: "execute",
          action: m.action,
          sensitivity: m.sensitivity,
          tool: m.tool,
          input: extraction.entities,
        }];
      },
    };
