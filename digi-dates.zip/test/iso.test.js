import test from "node:test";
import assert from "node:assert/strict";
import { parseISO, formatISO } from "../dist/index.js";

test("parseISO parses Z timestamps", () => {
  const d = parseISO("2000-01-01T00:00:00Z");
  assert.equal(formatISO(d), "2000-01-01T00:00:00.000Z");
});

test("parseISO parses offset timestamps", () => {
  const d = parseISO("2000-01-01T00:00:00-05:00");
  assert.equal(formatISO(d), "2000-01-01T05:00:00.000Z");
});
