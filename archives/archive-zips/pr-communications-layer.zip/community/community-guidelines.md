COMMUNITY GUIDELINES
====================

Tone:
- Respectful
- Calm
- Helpful

Moderation:
- Clear escalation
- Zero tolerance for harassment
- Protect staff from abuse
