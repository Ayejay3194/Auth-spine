import { FlowDefinition } from "../flows/types.js";
import { Tool } from "../tools/types.js";
import { PaymentsProvider } from "../providers/types.js";

export function paymentsSpine(opts: { provider: PaymentsProvider }) {
  const { provider } = opts;

  const tools: Tool<any, any>[] = [
    {
      id: "payments.createInvoice",
      description: "Create invoice",
      validate: (i) => { if (!i.clientId) throw new Error("Missing clientId"); if (!i.amount || i.amount <= 0) throw new Error("Bad amount"); },
      run: async (_ctx, input) => ({ ok: true, data: { invoice: await provider.createInvoice({ clientId: input.clientId, amount: input.amount }) } }),
      timeoutMs: 2500,
    },
    {
      id: "payments.refund",
      description: "Refund invoice",
      validate: (i) => { if (!i.invoiceId) throw new Error("Missing invoiceId"); },
      run: async (_ctx, input) => ({ ok: true, data: { invoice: await provider.refund({ invoiceId: input.invoiceId, amount: input.amount }) } }),
      timeoutMs: 2500,
    },
    {
      id: "payments.applyCredit",
      description: "Apply credit to client",
      validate: (i) => { if (!i.clientId) throw new Error("Missing clientId"); if (!i.amount || i.amount <= 0) throw new Error("Bad amount"); },
      run: async (_ctx, input) => { await provider.applyCredit({ clientId: input.clientId, amount: input.amount }); return { ok: true, data: { ok: true } }; },
      timeoutMs: 2500,
    },
  ];

  const flows: FlowDefinition[] = [
    {
      intent: "payments.create_invoice",
      slots: [{ name: "clientId", required: true }, { name: "amount", required: true, fromEntity: (e) => (e.find(x => x.type === "money")?.meta as any)?.amount ? String((e.find(x => x.type === "money")?.meta as any).amount) : null }, { name: "confirm", required: true }],
      steps: (s) => [
        { ask: { slot: "clientId", prompt: "Client ID?", hint: "cl_123" } },
        { ask: { slot: "amount", prompt: "Amount ($)?", hint: "75" } },
        { ask: { slot: "confirm", prompt: `Type YES to create invoice for $${s.amount}.`, hint: "YES" } },
        { call: { toolId: "payments.createInvoice", commitIntent: "payments.create_invoice", confirmSlot: "confirm", inputFromSlots: (x) => ({ clientId: x.clientId, amount: Number(x.amount) }) } },
        { done: { message: "Invoice created." } },
      ],
    },
    {
      intent: "payments.refund",
      slots: [{ name: "invoiceId", required: true }, { name: "confirm", required: true }],
      steps: () => [
        { ask: { slot: "invoiceId", prompt: "Invoice ID?", hint: "in_123" } },
        { ask: { slot: "confirm", prompt: "Type YES to refund.", hint: "YES" } },
        { call: { toolId: "payments.refund", commitIntent: "payments.refund", confirmSlot: "confirm", inputFromSlots: (s) => ({ invoiceId: s.invoiceId }) } },
        { done: { message: "Refunded (if allowed)." } },
      ],
    },
  ];

  return { tools, flows };
}
