SCALABILITY & PERFORMANCE

Horizontal Scaling
- Stateless app + autoscaling
- Orchestration (Kubernetes) or serverless controls
- Caching + CDN
- Sharding/partitioning + read replicas
- Queue/event driven systems
- API gateway + service discovery

Optimization
- Query/index optimization, N+1 prevention
- Compression (Brotli/Gzip), HTTP/2/3
- Pagination everywhere
- Bundle size + code splitting
- Background job tuning

Load/Chaos Testing
- Stress/spike/soak tests
- Capacity planning + baselines
- Failover testing
- Chaos experiments
