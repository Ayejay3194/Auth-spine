import { DataFrame } from "../df/DataFrame.js";

async function run() {
  const df = DataFrame.fromRows([
    { ts: "2026-02-27T00:00:00Z", body: "Mercury", dx: 1.36, dy: 0.44 },
    { ts: "2026-02-27T00:10:00Z", body: "Mercury", dx: 0.82, dy: 0.21 },
    { ts: "2026-02-27T00:20:00Z", body: "Venus",   dx: 0.44, dy: 0.12 },
    { ts: "2026-02-27T00:30:00Z", body: "Venus",   dx: 0.30, dy: 0.08 },
  ])
  .withColumn("err_mag", (r) => Math.sqrt(r.dx * r.dx + r.dy * r.dy));

  console.log("shape:", df.shape);
  console.log("head:", df.head(3));
  console.log("describe:", df.describe(["dx","dy","err_mag"]));

  const mercury = df.where("body", "==", "Mercury").sortBy("err_mag", "desc");
  console.log("mercury sorted:", mercury.head(10));

  const gb = df.groupBy(["body"]).agg({ err_mag: ["count","mean","min","max"] });
  console.log("groupby:", gb.head(10));

  await df.toParquet("./tmp/demo.parquet", { compression: "zstd", metadata: { dataset: "demo" } });
  const back = await DataFrame.fromParquet("./tmp/demo.parquet");
  console.log("roundtrip head:", back.head(5));
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
