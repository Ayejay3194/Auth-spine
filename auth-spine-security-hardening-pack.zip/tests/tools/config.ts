export const BASE_URL = process.env.BASE_URL || "http://localhost:3000";

export const TEST = {
  tenants: {
    a: {
      id: process.env.TEST_TENANT_A_ID || "tenant-a",
      name: "Tenant A",
      slug: "tenant-a",
    },
    b: {
      id: process.env.TEST_TENANT_B_ID || "tenant-b",
      name: "Tenant B",
      slug: "tenant-b",
    },
  },
  users: {
    a: {
      tenantId: process.env.TEST_TENANT_A_ID || "tenant-a",
      email: process.env.TEST_USER_A_EMAIL || "a@example.com",
      password: process.env.TEST_USER_PASSWORD || undefined,
      deviceLabel: "vitest-a",
    },
    b: {
      tenantId: process.env.TEST_TENANT_B_ID || "tenant-b",
      email: process.env.TEST_USER_B_EMAIL || "b@example.com",
      password: process.env.TEST_USER_PASSWORD || undefined,
      deviceLabel: "vitest-b",
    },
    admin: {
      tenantId: process.env.TEST_TENANT_A_ID || "tenant-a",
      email: process.env.TEST_ADMIN_EMAIL || "admin@example.com",
      password: process.env.TEST_ADMIN_PASSWORD || undefined,
      deviceLabel: "vitest-admin",
    },
  },
};

export const EXPECT = {
  rateLimit429: process.env.RATE_LIMIT_EXPECT_429 === "1",
};
