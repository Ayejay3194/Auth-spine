export class SkillGraph {
  private skills = new Map<string, Record<string, number>>();
}
