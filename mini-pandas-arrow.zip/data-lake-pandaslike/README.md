# mini-pandas-arrow

A tiny, pandas-ish DataFrame API on top of Apache Arrow Tables.

This is intentionally minimal and predictable:
- **Columnar** (Arrow under the hood)
- **No magic** (explicit types and operations)
- Works nicely with Parquet via `parquet-wasm`

## Install
```bash
npm i
```

## Quick demo
```bash
npm run dev
```

## Core API
- `DataFrame.fromRows(rows)`
- `df.select(cols)`
- `df.filter(row => boolean)` (simple, row-wise, fine for small/medium)
- `df.where(column, op, value)` (vector-friendly comparisons)
- `df.withColumn(name, fnOrVector)`
- `df.sortBy(column, dir?)`
- `df.groupBy(cols).agg({ col: ["sum","mean","min","max","count"] })`
- `df.describe()` (basic)
- `df.toParquet(path)` / `DataFrame.fromParquet(path)`

If you want **big** groupby performance, you pair this with DuckDB. This package is the ergonomic layer.
