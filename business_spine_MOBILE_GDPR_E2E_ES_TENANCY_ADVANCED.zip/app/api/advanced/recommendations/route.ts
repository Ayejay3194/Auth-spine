import { api } from "@/src/core/api";
import { getTenant } from "@/src/tenant/tenant";

export async function GET(req: Request) {
  return api(async () => {
    const { tenantId } = getTenant(req);
    return { tenantId, providers: [], services: [], note: "Stub: wire to booking history + tags." };
  });
}
