// inventory entities.ts
