import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

async function getStylistId(){
  const session = await auth();
  if(!session?.user?.email) return null;
  const user = await prisma.user.findUnique({ where:{ email: session.user.email }, include:{ stylistProfile:true } });
  return user?.stylistProfile?.id ?? null;
}

export async function DELETE(_:Request, { params }:{ params:{ id:string } }){
  const stylistId = await getStylistId();
  if(!stylistId) return new Response("Unauthorized", { status:401 });
  await prisma.availabilityRule.deleteMany({ where:{ id: params.id, stylistId, ownerType:"STYLIST" } });
  return Response.json({ ok:true });
}
