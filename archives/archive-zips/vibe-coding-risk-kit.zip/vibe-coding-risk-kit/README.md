# Vibe Coding Risk Kit (No-Nonsense)

This is a **drop-in governance + guardrails pack** for Next.js/React + Supabase style projects.
It turns “we shipped something” into “we shipped something that won’t burn the house down.”

## What's included
- **Pre-flight checklists** for auth, DB, API, frontend, deploy.
- **Security baseline** headers, cookie rules, secret hygiene.
- **RLS / IDOR / auth** test patterns (how to catch the most common disasters).
- **CI templates**: lint, typecheck, unit tests, dependency audit, secret scan.
- **PR templates** that force humans to prove they didn’t just freestyle.
- **Runbooks** for incident response and rollback.

## Use
1. Copy this folder into your repo (or unpack and merge).
2. Apply `checklists/` to your backlog (turn items into issues).
3. Add `.github/` to enforce PR hygiene.
4. Wire `ci/` into GitHub Actions (or copy snippets into your pipeline).
5. Keep `docs/THREAT_MODEL.md` updated when you add new features.

## Philosophy
If your app handles **logins, payments, files, or personal data**, you don’t get to “vibe” on security.
