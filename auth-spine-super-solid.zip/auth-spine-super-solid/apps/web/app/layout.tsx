import './globals.css'
import Link from 'next/link'

export const metadata = { title: 'Auth-Spine Super Solid' }

const Nav = () => (
  <div className="border-b bg-white/70 backdrop-blur">
    <div className="mx-auto max-w-6xl px-4 py-3 flex items-center gap-4">
      <Link href="/" className="font-semibold">Auth-Spine</Link>
      <Link href="/docs" className="text-sm text-slate-600 hover:text-slate-900">Docs</Link>
      <Link href="/ui-toolkit" className="text-sm text-slate-600 hover:text-slate-900">UI Toolkit</Link>
      <Link href="/html-to-ts" className="text-sm text-slate-600 hover:text-slate-900">HTML→TS</Link>
      <Link href="/health" className="text-sm text-slate-600 hover:text-slate-900">Health</Link>
    </div>
  </div>
)

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 text-slate-900">
        <Nav />
        <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
      </body>
    </html>
  )
}
