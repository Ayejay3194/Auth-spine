type AnthropicMessageResponse = {
  content?: Array<{ type?: string; text?: string }>;
  error?: unknown;
};

export type NLUResult = {
  intent: string;
  confidence: number;
  entities: Array<{ entity: string; value: string; start?: number; end?: number }>;
  reasoning?: string;
};

function getModel() {
  return process.env.ANTHROPIC_MODEL || "claude-sonnet-4-20250514";
}

export async function callAnthropicJSON<T>(opts: {
  system: string;
  user: string;
  temperature: number;
  maxTokens: number;
}): Promise<T> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error("Missing ANTHROPIC_API_KEY");

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: getModel(),
      max_tokens: opts.maxTokens,
      temperature: opts.temperature,
      system: opts.system,
      messages: [{ role: "user", content: opts.user }],
    }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Anthropic error: ${res.status} ${res.statusText} ${text}`.trim());
  }

  const data = (await res.json()) as AnthropicMessageResponse;
  const raw = data?.content?.[0]?.text ?? "";

  // Strip markdown fences if the model decides to be cute.
  const clean = raw.replace(/```json\s*|```\s*/g, "").trim();

  try {
    return JSON.parse(clean) as T;
  } catch {
    // If it returned non-JSON, surface it.
    throw new Error(`Failed to parse JSON from model. Raw: ${clean.slice(0, 500)}`);
  }
}
