import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const admin = await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      email: 'admin@example.com',
      name: 'Admin User',
      role: 'admin',
    },
  });

  const user = await prisma.user.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: {
      email: 'demo@example.com',
      name: 'Demo User',
    },
  });

  await prisma.project.create({
    data: {
      name: 'Seeded Project',
      description: 'This is a demo project.',
      ownerId: user.id,
    },
  });

  await prisma.post.createMany({
    data: [
      {
        slug: 'welcome',
        title: 'Welcome to the Starter',
        content: 'This is a blog post you can edit.',
      },
      {
        slug: 'second-post',
        title: 'Second Post',
        content: 'More content for testing.',
      },
    ],
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
