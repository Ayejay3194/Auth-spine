import type { AnalyzeTurnInput, AnalyzeTurnOutput, DialogueState } from "../types";
import { classify } from "../classify/router";
import { extract } from "../extract/ner";
import { carryContext } from "../memory/contextCarry";
import { getSessionState, setSessionState, seedReferencesFromEntities } from "../memory/sessionMemory";
import { newState, bumpTurn } from "../dialogue/state";
import { fillSlots } from "../dialogue/slots";
import { respond } from "../dialogue/responder";
import { withDefaults } from "../model/schema";
import { defaultModel } from "../model/defaultModel";

// optional browser persistence (safe no-op on server)
import { loadState as loadStateLS, saveState as saveStateLS } from "../model/store";

export async function analyzeTurn(input: AnalyzeTurnInput): Promise<AnalyzeTurnOutput> {
  const model = withDefaults(input.model ?? defaultModel);

  // Load state: prefer in-memory; in browser also pick persisted.
  let state: DialogueState | null = getSessionState(input.sessionId);
  if (!state && typeof window !== "undefined") state = loadStateLS(input.sessionId);
  if (!state) state = newState(input.sessionId);

  state = bumpTurn(state, input.text);

  // NLU intent
  const nluBase = await classify(model, input.text);

  // Entities: extract + context carry + merge into NLU
  const extracted = extract(model, input.text);
  const carried = carryContext(state, input.text, extracted);

  const nlu = { ...nluBase, entities: carried };

  // Update references (location/date)
  state = seedReferencesFromEntities(state, carried);

  // Decide active intent
  const intent = nlu.intent.name !== "unknown" ? nlu.intent.name : state.activeIntent;

  if (intent) {
    state = fillSlots(model, state, intent, carried);
  }

  // Generate reply
  const reply = respond(model, state, nlu);
  const out: AnalyzeTurnOutput = { nlu, state, reply };

  // Persist state
  setSessionState(state);
  if (input.persistState && typeof window !== "undefined") saveStateLS(state);

  if (input.debug) {
    out.reply.debug = {
      intent: nlu.intent,
      entities: nlu.entities,
      slots: state.slots,
      refs: state.references,
      turn: state.turn,
    };
  }

  return out;
}
