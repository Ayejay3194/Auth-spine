import fs from "node:fs/promises";
import path from "node:path";
import { WarehouseConfig, dayPartitionDir } from "../core/paths.js";

export type SnapshotArgs = {
  cfg: WarehouseConfig;
  dayISO: string;
  targetDir: string; // e.g. ./snapshots
};

/**
 * Minimal MVP snapshot:
 * - copies part-0001.parquet for the day into a single snapshot file.
 * Extend later to merge multiple parts if needed.
 */
export async function snapshotDay(args: SnapshotArgs): Promise<string> {
  const srcDir = dayPartitionDir(args.cfg, args.dayISO);
  const src = path.join(srcDir, "part-0001.parquet");
  const dst = path.join(
    args.targetDir,
    `${args.cfg.dataset}-${args.cfg.datasetVersion}-${args.dayISO}.parquet`
  );

  await fs.mkdir(args.targetDir, { recursive: true });
  await fs.copyFile(src, dst);
  return dst;
}
