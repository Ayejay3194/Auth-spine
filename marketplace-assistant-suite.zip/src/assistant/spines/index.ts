import { ToolRegistry } from "../tools/registry.js";
import type { Providers } from "../providers/types.js";
import { registerCoreTools } from "./spineCore.js";
import { registerMarketDiscoveryTools } from "./spineMarketDiscovery.js";
import { registerMarketBookingTools } from "./spineMarketBooking.js";
import { registerMarketPaymentsTools } from "./spineMarketPayments.js";
import { registerMarketMessagingTools } from "./spineMarketMessaging.js";
import { registerMarketReputationTools } from "./spineMarketReputation.js";
import { registerMarketDisputesTools } from "./spineMarketDisputes.js";

export function loadAllSpines(p: Providers) {
  const tools = new ToolRegistry();
  registerCoreTools(tools, p);

  registerMarketDiscoveryTools(tools, p);
  registerMarketBookingTools(tools, p);
  registerMarketPaymentsTools(tools, p);
  registerMarketMessagingTools(tools, p);
  registerMarketReputationTools(tools, p);
  registerMarketDisputesTools(tools, p);

  return { tools };
}
