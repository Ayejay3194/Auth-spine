Compliance Mapping

Supports:
- SOC 2
- ISO 27001
- NIST CSF
- GDPR / CCPA
- PCI / HIPAA (if applicable)

Each control must map to evidence.
