/**
 * Adapter layer: plug in the governor from solari-overdone-pack (or your own).
 * This repo intentionally does NOT bundle tone packs to keep it lightweight.
 */
export type RiskContext = "none" | "medical" | "legal" | "grief" | "panic" | "trauma" | "risk_sensitive";

export interface ToneState {
  usedIds: Set<string>;
  lastIntensities: number[];
  sarcasmLock?: boolean;
  tolerance?: number;
}

export interface ToneDecisionInput {
  intent: string;
  trigger: string;
  confidence: number;
  risk: RiskContext;
  product: "support" | "consumer_app" | "internal_tools" | "other";
  maxLines?: number;
}

export interface ToneLine {
  id: string;
  category: string;
  trigger: string;
  intensity: number;
  text: string;
}

export interface ToneDecisionOutput {
  selected: ToneLine[];
  reason: string;
}

export function chooseToneLinesStub(pool: ToneLine[], input: ToneDecisionInput, state: ToneState): ToneDecisionOutput {
  // Replace with your imported governor.chooseToneLines
  const safe = pool.filter(l => l.trigger === input.trigger).slice(0, input.maxLines ?? 2);
  return { selected: safe, reason: "stub" };
}
