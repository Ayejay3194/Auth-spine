'use client';

import React, { useEffect, useState } from "react";
import { Brain, Plus, Trash2, Play, Download, Upload } from "lucide-react";
import type { NLUModel, NLUResult } from "@/lib/types";
import { analyze } from "@/lib/nlu";
import { loadModelFromStorage, saveModelToStorage } from "@/lib/storage";

const DEFAULT_MODEL: NLUModel = {
  version: 1,
  intents: [
    { name: "greeting", examples: ["hello", "hi", "hey", "good morning", "howdy"] },
    { name: "weather", examples: ["what is the weather", "how is the weather in", "will it rain today", "weather forecast"] },
  ],
  entities: [
    { name: "location", values: ["new york", "london", "paris", "tokyo", "san francisco"] },
    { name: "date", values: ["today", "tomorrow", "yesterday", "next week", "monday"] },
  ],
};

function downloadText(filename: string, content: string, mime = "text/plain") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function safeTrim(x: string) {
  return x.replace(/\s+/g, " ").trim();
}

export default function NLUSystem() {
  const [model, setModel] = useState<NLUModel>(DEFAULT_MODEL);

  const [testInput, setTestInput] = useState("");
  const [testResult, setTestResult] = useState<NLUResult | null>(null);

  const [newIntentName, setNewIntentName] = useState("");
  const [newEntityName, setNewEntityName] = useState("");

  // Load saved model once (client only)
  useEffect(() => {
    const saved = loadModelFromStorage();
    if (saved) setModel(saved);
  }, []);

  // Persist on change
  useEffect(() => {
    saveModelToStorage(model);
  }, [model]);

  const intents = model.intents;
  const entities = model.entities;

  const handleTest = () => {
    if (!testInput.trim()) return;
    setTestResult(analyze(testInput, model));
  };

  const addIntent = () => {
    const name = safeTrim(newIntentName);
    if (!name) return;
    if (intents.some((i) => i.name.toLowerCase() === name.toLowerCase())) return;
    setModel((prev) => ({ ...prev, intents: [...prev.intents, { name, examples: [] }] }));
    setNewIntentName("");
  };

  const addEntity = () => {
    const name = safeTrim(newEntityName);
    if (!name) return;
    if (entities.some((e) => e.name.toLowerCase() === name.toLowerCase())) return;
    setModel((prev) => ({ ...prev, entities: [...prev.entities, { name, values: [] }] }));
    setNewEntityName("");
  };

  const addExample = (intentIndex: number, example: string) => {
    const ex = safeTrim(example);
    if (!ex) return;
    setModel((prev) => {
      const updated = [...prev.intents];
      const list = updated[intentIndex].examples;
      if (list.some((x) => x.toLowerCase() === ex.toLowerCase())) return prev;
      updated[intentIndex] = { ...updated[intentIndex], examples: [...list, ex] };
      return { ...prev, intents: updated };
    });
  };

  const addEntityValue = (entityIndex: number, value: string) => {
    const v = safeTrim(value);
    if (!v) return;
    setModel((prev) => {
      const updated = [...prev.entities];
      const list = updated[entityIndex].values;
      if (list.some((x) => x.toLowerCase() === v.toLowerCase())) return prev;
      updated[entityIndex] = { ...updated[entityIndex], values: [...list, v] };
      return { ...prev, entities: updated };
    });
  };

  const removeIntent = (index: number) => {
    setModel((prev) => ({ ...prev, intents: prev.intents.filter((_, i) => i !== index) }));
  };

  const removeEntity = (index: number) => {
    setModel((prev) => ({ ...prev, entities: prev.entities.filter((_, i) => i !== index) }));
  };

  const removeExample = (intentIndex: number, exampleIndex: number) => {
    setModel((prev) => {
      const updated = [...prev.intents];
      updated[intentIndex] = {
        ...updated[intentIndex],
        examples: updated[intentIndex].examples.filter((_, i) => i !== exampleIndex),
      };
      return { ...prev, intents: updated };
    });
  };

  const removeEntityValue = (entityIndex: number, valueIndex: number) => {
    setModel((prev) => {
      const updated = [...prev.entities];
      updated[entityIndex] = {
        ...updated[entityIndex],
        values: updated[entityIndex].values.filter((_, i) => i !== valueIndex),
      };
      return { ...prev, entities: updated };
    });
  };

  const exportModel = () => {
    downloadText("nlu-model.json", JSON.stringify(model, null, 2), "application/json");
  };

  const exportResult = () => {
    if (!testResult) return;
    downloadText(
      `nlu-result-${new Date().toISOString().slice(0, 10)}.json`,
      JSON.stringify(testResult, null, 2),
      "application/json"
    );
  };

  const importModel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(String(event.target?.result ?? "{}"));
        if (!parsed || typeof parsed !== "object") return;

        const next: NLUModel = {
          version: typeof parsed.version === "number" ? parsed.version : 1,
          intents: Array.isArray(parsed.intents) ? parsed.intents : [],
          entities: Array.isArray(parsed.entities) ? parsed.entities : [],
        };

        next.intents = next.intents
          .filter((i: any) => i?.name)
          .map((i: any) => ({
            name: String(i.name),
            examples: Array.isArray(i.examples) ? i.examples.map(String) : [],
          }));

        next.entities = next.entities
          .filter((en: any) => en?.name)
          .map((en: any) => ({
            name: String(en.name),
            values: Array.isArray(en.values) ? en.values.map(String) : [],
          }));

        setModel(next);
        setTestResult(null);
      } catch {
        alert("Invalid model file");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Brain className="w-8 h-8 text-purple-600" />
              <h1 className="text-3xl font-bold text-gray-800">NLU System</h1>
            </div>
            <div className="flex gap-2">
              <button
                onClick={exportModel}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Download className="w-4 h-4" />
                Export Model
              </button>

              <label className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer">
                <Upload className="w-4 h-4" />
                Import Model
                <input type="file" accept=".json" onChange={importModel} className="hidden" />
              </label>
            </div>
          </div>

          <div className="bg-purple-50 rounded-lg p-4 mb-6">
            <h2 className="text-lg font-semibold mb-3 text-gray-700">Test Your Model</h2>
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleTest()}
                placeholder="Enter text to analyze..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <button
                onClick={handleTest}
                className="flex items-center gap-2 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
              >
                <Play className="w-4 h-4" />
                Analyze
              </button>

              <button
                onClick={exportResult}
                disabled={!testResult}
                className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-lg disabled:opacity-40 hover:bg-slate-700"
              >
                <Download className="w-4 h-4" />
                Export Result
              </button>
            </div>

            {testResult && (
              <div className="bg-white rounded-lg p-4 border border-purple-200">
                <div className="mb-3">
                  <span className="text-sm font-semibold text-gray-600">Intent:</span>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full font-medium">
                      {testResult.intent.name}
                    </span>
                    <span className="text-sm text-gray-500">
                      {(testResult.intent.confidence * 100).toFixed(0)}% confidence (score {testResult.intent.score})
                    </span>
                  </div>
                </div>

                {testResult.entities.length > 0 ? (
                  <div>
                    <span className="text-sm font-semibold text-gray-600">Entities:</span>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {testResult.entities.map((entity, idx) => (
                        <div key={idx} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                          <span className="font-medium">{entity.entity}:</span> {entity.value}
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-gray-500">No entities found.</div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Intents</h2>

            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newIntentName}
                onChange={(e) => setNewIntentName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addIntent()}
                placeholder="New intent name..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <button onClick={addIntent} className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
                <Plus className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto">
              {intents.map((intent, idx) => (
                <IntentEditor
                  key={`${intent.name}-${idx}`}
                  intent={intent}
                  onAddExample={(ex) => addExample(idx, ex)}
                  onRemoveExample={(exIdx) => removeExample(idx, exIdx)}
                  onRemove={() => removeIntent(idx)}
                />
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Entities</h2>

            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newEntityName}
                onChange={(e) => setNewEntityName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addEntity()}
                placeholder="New entity name..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button onClick={addEntity} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <Plus className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto">
              {entities.map((entity, idx) => (
                <EntityEditor
                  key={`${entity.name}-${idx}`}
                  entity={entity}
                  onAddValue={(val) => addEntityValue(idx, val)}
                  onRemoveValue={(valIdx) => removeEntityValue(idx, valIdx)}
                  onRemove={() => removeEntity(idx)}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 bg-slate-50 border border-slate-200 p-4 rounded-lg">
          <h3 className="font-semibold text-slate-900 mb-2">What this actually is</h3>
          <ul className="text-sm text-slate-700 space-y-1">
            <li>• Intent classification is token overlap + phrase match scoring.</li>
            <li>• Entity extraction is dictionary phrase matching with overlap resolution (longest match wins).</li>
            <li>• The model persists to localStorage so you don’t lose work when you refresh.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function IntentEditor({
  intent,
  onAddExample,
  onRemoveExample,
  onRemove,
}: {
  intent: { name: string; examples: string[] };
  onAddExample: (example: string) => void;
  onRemoveExample: (exampleIndex: number) => void;
  onRemove: () => void;
}) {
  const [newExample, setNewExample] = useState("");

  const handleAdd = () => {
    onAddExample(newExample);
    setNewExample("");
  };

  return (
    <div className="border border-purple-200 rounded-lg p-4 bg-purple-50">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-gray-800">{intent.name}</h3>
        <button onClick={onRemove} className="text-red-500 hover:text-red-700" aria-label="Remove intent">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="flex gap-2 mb-2">
        <input
          type="text"
          value={newExample}
          onChange={(e) => setNewExample(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          placeholder="Add training example..."
          className="flex-1 px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
        />
        <button onClick={handleAdd} className="px-2 py-1 bg-purple-600 text-white rounded hover:bg-purple-700">
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-1">
        {intent.examples.map((example, idx) => (
          <div key={idx} className="flex items-center justify-between bg-white px-2 py-1 rounded text-sm">
            <span className="text-gray-700">{example}</span>
            <button
              onClick={() => onRemoveExample(idx)}
              className="text-red-500 hover:text-red-700"
              aria-label="Remove example"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function EntityEditor({
  entity,
  onAddValue,
  onRemoveValue,
  onRemove,
}: {
  entity: { name: string; values: string[] };
  onAddValue: (value: string) => void;
  onRemoveValue: (valueIndex: number) => void;
  onRemove: () => void;
}) {
  const [newValue, setNewValue] = useState("");

  const handleAdd = () => {
    onAddValue(newValue);
    setNewValue("");
  };

  return (
    <div className="border border-blue-200 rounded-lg p-4 bg-blue-50">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-gray-800">{entity.name}</h3>
        <button onClick={onRemove} className="text-red-500 hover:text-red-700" aria-label="Remove entity">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="flex gap-2 mb-2">
        <input
          type="text"
          value={newValue}
          onChange={(e) => setNewValue(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          placeholder="Add entity value..."
          className="flex-1 px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button onClick={handleAdd} className="px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-1">
        {entity.values.map((value, idx) => (
          <div key={idx} className="flex items-center justify-between bg-white px-2 py-1 rounded text-sm">
            <span className="text-gray-700">{value}</span>
            <button
              onClick={() => onRemoveValue(idx)}
              className="text-red-500 hover:text-red-700"
              aria-label="Remove entity value"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
