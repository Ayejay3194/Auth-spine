# Deep-link / refresh 404

Symptoms: `/settings` works via in-app nav, but refresh gives 404.

## Cause
Host isn't rewriting unknown routes back to your SPA entry (index.html), or SSR route doesn't exist.

## Fix
- SPA static hosting: add catch-all rewrite (`/* -> /index.html 200` on Netlify, `** -> /index.html` Firebase, etc.)
- SSR: ensure route exists and build output includes it

Run:
- auditor `--serve auto --crawl` to catch this locally.
