import type { ID, ISODateTime } from "../shared/types.js";
import { toCSV } from "../shared/csv.js";

export type ReportType = "bookings" | "payments" | "clients" | "campaigns" | "payouts";

export interface ReportSource {
  bookings(businessId: ID, fromISO: ISODateTime, toISO: ISODateTime): Promise<Array<Record<string, any>>>;
  payments(businessId: ID, fromISO: ISODateTime, toISO: ISODateTime): Promise<Array<Record<string, any>>>;
  clients(businessId: ID, fromISO: ISODateTime, toISO: ISODateTime): Promise<Array<Record<string, any>>>;
  campaigns(businessId: ID, fromISO: ISODateTime, toISO: ISODateTime): Promise<Array<Record<string, any>>>;
  payouts(businessId: ID, fromISO: ISODateTime, toISO: ISODateTime): Promise<Array<Record<string, any>>>;
}

export async function exportCSV(src: ReportSource, type: ReportType, businessId: ID, fromISO: ISODateTime, toISO: ISODateTime): Promise<{ filename: string; csv: string }> {
  const rows = await (type === "bookings" ? src.bookings(businessId, fromISO, toISO)
    : type === "payments" ? src.payments(businessId, fromISO, toISO)
    : type === "clients" ? src.clients(businessId, fromISO, toISO)
    : type === "campaigns" ? src.campaigns(businessId, fromISO, toISO)
    : src.payouts(businessId, fromISO, toISO));
  const csv = toCSV(rows);
  return { filename: `${type}_${businessId}_${fromISO.slice(0,10)}_${toISO.slice(0,10)}.csv`, csv };
}
