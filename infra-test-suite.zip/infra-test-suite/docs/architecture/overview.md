# Architecture Overview (stub)

System boundaries, data flows.
