import { z } from "zod";
import { AspectId, BodyId, HouseSystem, Zodiac } from "./enums.js";
import { CONTRACT_VERSION, CANONICAL_VERSION } from "./version.js";

/**
 * The ONE true output contract.
 * Everything else (renderers, apps, reports, marketplace, caching) consumes this.
 * You change this only via version bump + migration.
 */

const IsoDateTime = z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$/, "must be ISO UTC timestamp (Z)");

export const Geo = z.object({
  lat: z.number().min(-90).max(90),
  lon: z.number().min(-180).max(180),
  // IANA timezone, ex: "America/New_York"
  tz: z.string().min(1),
  label: z.string().optional(), // city name, etc.
});

export const BirthInput = z.object({
  dobUtc: IsoDateTime,                 // source of truth input time
  originalLocal: z.object({            // for traceability only
    date: z.string().min(1),
    time: z.string().min(1),
    tz: z.string().min(1),
  }).optional(),
  geo: Geo,
});

export const BodyPos = z.object({
  id: BodyId,
  lon: z.number().min(0).max(360),
  lat: z.number().min(-90).max(90).optional(),
  speedLon: z.number().optional(),     // deg/day
  retrograde: z.boolean(),
  // derived
  sign: z.string().min(1),
  degInSign: z.number().min(0).max(30),
  house: z.number().int().min(1).max(12).optional(),
});

export const HouseCusp = z.object({
  house: z.number().int().min(1).max(12),
  lon: z.number().min(0).max(360),
  sign: z.string().min(1),
  degInSign: z.number().min(0).max(30),
});

export const Angle = z.object({
  id: z.enum(["ASC","MC","DSC","IC"]),
  lon: z.number().min(0).max(360),
  sign: z.string().min(1),
  degInSign: z.number().min(0).max(30),
});

export const Aspect = z.object({
  a: BodyId,
  b: BodyId,
  type: AspectId,
  orb: z.number().min(0).max(30),
  exact: z.number().min(0).max(180), // exact angle for that aspect
  sep: z.number().min(0).max(180),   // actual separation
  applying: z.boolean().optional(),
});

export const EngineMeta = z.object({
  engineId: z.string().min(1),          // "swisseph@2.10.03-node", "vsop87a@..."
  engineCommit: z.string().optional(),  // git sha if your own engine
  flags: z.array(z.string()).default([]),
  computedAtUtc: IsoDateTime,
  canonicalVersion: z.literal(CANONICAL_VERSION),
});

export const ChartDataV1 = z.object({
  version: z.literal(CONTRACT_VERSION),
  chartType: z.enum(["natal","synastry","transit","solar_return","progressed","custom"]),
  houseSystem: HouseSystem,
  zodiac: Zodiac,
  ayanamsa: z.string().optional(),
  input: BirthInput,
  bodies: z.array(BodyPos).min(5),
  houses: z.array(HouseCusp).length(12),
  angles: z.array(Angle).min(2),
  aspects: z.array(Aspect).default([]),
  // Optional: extra calculated things (dignities, element balance etc.)
  extras: z.record(z.any()).default({}),
  meta: EngineMeta,
  integrity: z.object({
    canonical: z.string().min(1),       // AMJCS-1 canonical string
    sha256: z.string().regex(/^[a-f0-9]{64}$/),
  }),
});

export type ChartDataV1 = z.infer<typeof ChartDataV1>;
