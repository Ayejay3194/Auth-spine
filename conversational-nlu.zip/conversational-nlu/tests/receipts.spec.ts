describe("receipts", () => {
  it("placeholder", () => {
    expect(true).toBe(true);
  });
});
