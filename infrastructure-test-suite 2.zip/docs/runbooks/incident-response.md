# Incident Response Runbook (starter)

1) Triage: scope, severity, start incident channel
2) Stabilize: rollback/scale/disable non-critical jobs
3) Investigate: dashboards -> logs -> traces -> change history
4) Fix: minimal safe change, validate with smoke tests
5) Postmortem: add tests/policies so it never happens again
