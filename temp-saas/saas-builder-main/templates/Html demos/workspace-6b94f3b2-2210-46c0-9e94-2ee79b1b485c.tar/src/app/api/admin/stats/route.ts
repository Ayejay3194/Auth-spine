import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/permissions'

// GET /api/admin/stats - Get admin statistics
export async function GET(request: NextRequest) {
  const handler = requireAdmin(async (req: Request) => {
    try {
      const [
        totalUsers,
        totalWorkspaces,
        activeSubscriptions,
        monthlyRevenue,
      ] = await Promise.all([
        db.user.count(),
        db.workspace.count(),
        db.subscription.count({
          where: {
            status: 'ACTIVE'
          }
        }),
        // Calculate monthly revenue (simplified)
        db.subscription.aggregate({
          where: {
            status: 'ACTIVE'
          },
          _sum: {
            // This would normally come from Stripe, but for demo we'll use plan price
          }
        })
      ])

      // Mock data for demo purposes
      const stats = {
        totalUsers,
        totalWorkspaces,
        activeSubscriptions,
        monthlyRevenue: 2900 * activeSubscriptions / 100, // Convert to dollars
        churnRate: 2.1, // Mock churn rate
      }

      return NextResponse.json({
        success: true,
        data: stats
      })
    } catch (error) {
      console.error('Failed to fetch admin stats:', error)
      return NextResponse.json(
        { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch stats' } },
        { status: 500 }
      )
    }
  })

  return handler(request, { user: { isAdmin: true } })
}