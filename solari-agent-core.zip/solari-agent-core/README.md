# Solari Agent Core

This is the **agent spine**: intent → plan → critique → execute → reflect, with memory + audit.
Pair it with your **Solari Overdone Pack** (tone library) for the full "great assistant" experience.

## What you get
- Identity + principles + limits (JSON)
- Memory layers: working/session/long-term + pruning
- Governance: risk detection + plan validation + audit log
- Reasoning: intent classifier, planner, critic, executor, reflector
- Tone integration stubs (plug in your tone governor)

## Quick start
```bash
npm i
npm run build
npm test
```

## How to integrate your tone packs
1) Put your tone pack folder somewhere (ex: `../solari-overdone-pack/`).
2) Load JSONL into a pool using `loadTonePack(dir)`.
3) Replace `chooseToneLinesStub` with your governor's `chooseToneLines`.

## Non-negotiables
- No tool or file action without an audited plan step.
- Always emit audit events.
- Risk contexts block snark/annoyed.
