KILL SWITCH
===========
- Pause all payouts
- Pause instant only
- Logged + permission gated
