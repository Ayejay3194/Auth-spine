import type { EventBus } from "@suite/core-events";
import type { AuditStore } from "@suite/core-audit";
import type { Plan, Subscription } from "@suite/core-entitlements";

export type PaymentProvider = "stripe" | "paddle" | "braintree" | "manual";

export type BillingCustomer = { userId: string; provider: PaymentProvider; providerCustomerId: string };

export interface BillingAdapter {
  createCheckout(userId: string, planId: string, returnUrl: string): Promise<{ url: string }>;
  cancelSubscription(userId: string): Promise<void>;
  handleWebhook(rawBody: string, headers: Record<string,string>): Promise<void>;
}

export class BillingService {
  constructor(
    private plans: Plan[],
    private subs: Map<string, Subscription>,
    private bus: EventBus,
    private audit: AuditStore,
    private adapter: BillingAdapter
  ) {}

  listPlans() { return this.plans; }

  async startCheckout(userId: string, planId: string, returnUrl: string) {
    await this.audit.append({ actor: { actorType: "user", userId }, action: "billing.checkout.started", targetType: "plan", targetId: planId });
    return this.adapter.createCheckout(userId, planId, returnUrl);
  }

  async setSubscription(userId: string, sub: Subscription) {
    this.subs.set(userId, sub);
    await this.audit.append({ actor: { actorType: "system" }, action: "billing.subscription.updated", targetType: "subscription", targetId: sub.planId, metadata: sub });
    await this.bus.publish({ id: `evt_${Math.random().toString(16).slice(2)}`, type: "billing.subscription.updated", ts: new Date().toISOString(), actor: { actorType: "system" }, payload: sub });
  }
}
