import { Plan, PlanStep, RiskContext } from "../types";

function step(id: string, title: string, action: PlanStep["action"], successCriteria: string[], toolName?: string): PlanStep {
  return { id, title, action, toolName, successCriteria };
}

export function makePlan(args: { intent: string; risk: RiskContext }): Plan {
  const steps: PlanStep[] = [];

  if (args.risk !== "none") {
    steps.push(step("s1", "Use de-escalation + clarity tone; avoid snark", "respond", ["Response avoids restricted tones", "User understands next step"]));
    return { id: "plan_risk", intent: args.intent, risk: args.risk, steps };
  }

  if (args.intent === "build_artifact") {
    steps.push(step("s1", "Clarify required inputs or assume safe defaults", "respond", ["Inputs are explicit or defaults stated"]));
    steps.push(step("s2", "Generate artifact and save to filesystem", "write_file", ["Files created", "Zip created"]));
    steps.push(step("s3", "Respond with download link + brief contents", "respond", ["User receives link", "Contents described"]));
    return { id: "plan_build", intent: args.intent, risk: args.risk, steps };
  }

  steps.push(step("s1", "Respond with clarity-first answer", "respond", ["User receives a direct answer"]));
  return { id: "plan_general", intent: args.intent, risk: args.risk, steps };
}
