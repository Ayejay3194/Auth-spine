Code Security Baseline

- Secure coding standards
- Mandatory reviews
- SAST, SCA, DAST
- Dependency pinning
- Signed commits
