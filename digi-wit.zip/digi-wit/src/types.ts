import type { z } from "zod";

export type WitEntityValue =
  | string
  | number
  | boolean
  | null
  | { [k: string]: WitEntityValue }
  | WitEntityValue[];

export type WitEntity = {
  id?: string;
  name?: string;
  role?: string;
  value: WitEntityValue;
  confidence?: number;
  type?: string;
};

export type WitResponse = {
  text: string;
  intents: { id?: string; name: string; confidence: number }[];
  entities: Record<string, WitEntity[]>;
  traits?: Record<string, { id?: string; value: string; confidence: number }[]>;
};

export type Receipt = {
  kind: "wit_parse_receipt";
  tsUtc: string;

  requestId?: string;
  userId?: string;

  input: {
    rawLen: number;
    sha256: string;
    preview: string; // short, non-PII friendly snippet
  };

  wit: {
    model?: string;
    apiVersion?: string;
    intent?: string;
    confidence?: number;
  };

  result: {
    accepted: boolean;
    reason?: string;
    schema?: string;
    payloadSha256?: string;
  };
};

export type ReceiptSink = (r: Receipt) => void | Promise<void>;

export type IntentSpec<Name extends string, Schema extends z.ZodTypeAny> = {
  name: Name;
  schema: Schema;
};

export type IntentMap = Record<string, IntentSpec<string, any>>;

export type ParseRequest = {
  text: string;
  userId?: string;
  requestId?: string;
  locale?: string; // e.g. "en_US"
};

export type ParseOk = {
  ok: true;
  intent: string;
  confidence: number;
  payload: unknown;
};

export type ParseNo = {
  ok: false;
  reason: string;
  confidence?: number;
  intent?: string;
};

export type ParseResult = ParseOk | ParseNo;
