Analytics must be aggregated, delayed, rounded, and de-identified.
No per-user or per-provider raw views allowed externally.