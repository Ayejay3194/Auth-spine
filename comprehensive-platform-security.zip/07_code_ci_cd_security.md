CODE, VERSION CONTROL & CI/CD SECURITY

Covers:
- Secure development practices
- SAST / DAST / IAST
- Dependency & supply chain security
- Pipeline hardening