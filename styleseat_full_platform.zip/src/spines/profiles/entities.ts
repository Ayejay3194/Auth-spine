// profiles entities.ts
