# Recommended Implementation Order

1) identity_auth
2) workspace_tenancy
3) service_catalog
4) availability_scheduler
5) booking_core
6) notification_hub
7) client_profiles
8) payments_core
9) client_portal
10) pro_directory (discovery)
11) messaging_dm (grow tier)
12) ops_analytics + no_show_prediction
13) campaigns + review_engine + referrals
14) pos_checkout + inventory_costing + compensation_commissions (salon tier)
15) shared_client_identity + bundle_marketplace (enterprise)

Rule: don't build "AI" before your data/events are real.
