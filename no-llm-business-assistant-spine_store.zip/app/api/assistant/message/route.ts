import { NextResponse } from "next/server";
import { PrismaAuditLogger } from "@/src/assistant/obs/prismaAudit";
import { buildAssistantRuntime } from "@/src/assistant/runtime";
import { getConversation, setConversationState } from "@/src/assistant/storage/conversation";

// You provide these in your app:
import { prisma } from "@/lib/prisma";
import { realProviders } from "@/src/assistant/providers/realProviders";

export async function POST(req: Request) {
  const body = await req.json();
  const text = String(body.text ?? "");
  const businessId = String(body.businessId ?? "biz_1");
  const userId = String(body.userId ?? "user_1");
  const role = (body.role ?? "owner") as any;
  const timezone = String(body.timezone ?? "America/New_York");
  const locale = String(body.locale ?? "en-US");

  const convo = await getConversation(prisma, businessId, userId);

  const audit = new PrismaAuditLogger(prisma);
  const clock = { now: () => new Date() };

  const { assistant } = buildAssistantRuntime({
    providers: realProviders(prisma, businessId),
    audit,
    clock
  });

  const ctx = { userId, role, businessId, timezone, locale, channel: "web" as const };
  const result = await assistant.handle(ctx, (convo.stateJson as any) ?? {}, text);

  await setConversationState(prisma, convo.id, result.state);

  return NextResponse.json({
    reply: result.reply.text,
    ui: result.reply.ui ?? null,
    done: result.reply.done ?? false,
  });
}
