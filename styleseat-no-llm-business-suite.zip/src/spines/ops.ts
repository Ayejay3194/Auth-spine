import { FlowDefinition } from "../flows/types.js";
import { Tool } from "../tools/types.js";
import { OpsProvider } from "../providers/types.js";

export function opsSpine(opts: { provider: OpsProvider }) {
  const { provider } = opts;

  const tools: Tool<any, any>[] = [
    {
      id: "ops.createTask",
      description: "Create task",
      validate: (i) => { if (!i.title) throw new Error("Missing title"); },
      run: async () => ({ ok: true, data: { task: await provider.createTask({ title: "" }) } }),
      timeoutMs: 2500,
    },
    {
      id: "ops.listTasks",
      description: "List tasks",
      validate: () => {},
      run: async () => ({ ok: true, data: { tasks: await provider.listTasks() } }),
      timeoutMs: 2500,
    },
    {
      id: "ops.markDone",
      description: "Mark task done",
      validate: (i) => { if (!i.taskId) throw new Error("Missing taskId"); },
      run: async () => ({ ok: true, data: { task: await provider.markDone({ taskId: "" }) } }),
      timeoutMs: 2500,
    },
    {
      id: "ops.startChecklist",
      description: "Start checklist",
      validate: (i) => { if (!i.name) throw new Error("Missing name"); },
      run: async () => ({ ok: true, data: await provider.startChecklist({ name: "" }) }),
      timeoutMs: 2500,
    },
  ];

  // NOTE: demo tools use stubs above; you will replace with real provider wiring.
  const flows: FlowDefinition[] = [
    {
      intent: "ops.list_tasks",
      slots: [],
      steps: () => [
        { call: { toolId: "ops.listTasks", inputFromSlots: () => ({}) } },
        { done: { message: "Tasks listed." } },
      ],
    },
    {
      intent: "ops.create_task",
      slots: [{ name: "title", required: true }],
      steps: () => [
        { ask: { slot: "title", prompt: "Task title?", hint: "Reorder supplies" } },
        { call: { toolId: "ops.createTask", commitIntent: "ops.create_task", confirmSlot: "confirm", inputFromSlots: (s) => ({ title: s.title }) } },
        { done: { message: "Task created." } },
      ],
    },
  ];

  return { tools, flows };
}
