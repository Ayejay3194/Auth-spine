// ai_insights index.ts
