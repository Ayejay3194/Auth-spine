
/**
 * Comprehensive Validation Framework (Hardened)
 *
 * Deterministic + behavior-driven. Less "it passed yesterday" energy.
 */

import goldenTxn from './__fixtures__/golden-transaction.json';
import goldenReceiptExpected from './__fixtures__/golden-receipt.expected.json';

import { ValidationService, DataValidator } from '../../packages/enterprise/validation/service';
import { ReceiptGenerator, ReceiptManager } from '../../packages/enterprise/validation/receipts';
import { AuditTrailManager } from '../../packages/enterprise/validation/audit-trail';
import { ComplianceValidator } from '../../packages/enterprise/validation/compliance';
import { FinancialAuditor } from '../../packages/enterprise/validation/financial-auditor';
import { ReportGenerator } from '../../packages/enterprise/validation/reports';

import {
  TransactionType,
  ReceiptStatus,
  ComplianceStatus,
  ValidationType,
  ErrorSeverity,
} from '../../packages/enterprise/validation/types';

describe('Comprehensive Validation Framework (Hardened)', () => {
  let validationService: ValidationService;
  let receiptGenerator: ReceiptGenerator;
  let auditManager: AuditTrailManager;
  let complianceValidator: ComplianceValidator;
  let financialAuditor: FinancialAuditor;
  let reportGenerator: ReportGenerator;

  beforeEach(() => {
    validationService = new ValidationService();
    receiptGenerator = new ReceiptGenerator();
    auditManager = new AuditTrailManager();
    complianceValidator = new ComplianceValidator();
    financialAuditor = new FinancialAuditor();
    reportGenerator = new ReportGenerator();
  });

  describe('Validation Service', () => {
    test('valid financial transaction passes with correct metadata', async () => {
      const tx = {
        id: 'txn_ok_001',
        amount: 1000,
        currency: 'USD',
        fromAccount: 'acc_001',
        toAccount: 'acc_002',
        description: 'Test transaction',
      };

      const result = await validationService.validateFinancialTransaction(tx as any);

      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);

      expect(result.metadata).toEqual(
        expect.objectContaining({
          validationType: ValidationType.FINANCIAL,
        })
      );
      expect(result.metadata.complianceLevel).toBeDefined();
    });

    test('invalid financial transaction fails with critical errors', async () => {
      const tx = {
        id: 'txn_bad_001',
        amount: -100,
        currency: 'USD',
        fromAccount: '',
        toAccount: '',
        description: '',
      };

      const result = await validationService.validateFinancialTransaction(tx as any);

      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors).toEqual(
        expect.arrayContaining([expect.objectContaining({ severity: ErrorSeverity.CRITICAL })])
      );
    });

    test('booking time range validation behaves correctly', async () => {
      const good = {
        id: 'book_ok_001',
        customerId: 'cust_001',
        serviceId: 'svc_001',
        startTime: new Date('2024-01-16T12:00:00Z'),
        endTime: new Date('2024-01-16T13:00:00Z'),
        price: 100,
      };

      const bad = {
        id: 'book_bad_001',
        customerId: 'cust_002',
        serviceId: 'svc_002',
        startTime: new Date('2024-01-16T13:00:00Z'),
        endTime: new Date('2024-01-16T12:00:00Z'),
        price: 100,
      };

      const ok = await validationService.validateBooking(good as any);
      expect(ok.isValid).toBe(true);
      expect(ok.metadata.validationType).toBe(ValidationType.BUSINESS_RULE);

      const nope = await validationService.validateBooking(bad as any);
      expect(nope.isValid).toBe(false);
      expect(nope.errors).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            message: expect.stringMatching(/start time must be before end time/i),
          }),
        ])
      );
    });

    test('batch validation returns aligned results', async () => {
      const txs = Array.from({ length: 25 }, (_, i) => ({
        id: `txn_${i}`,
        amount: 100 + i,
        currency: 'USD',
        fromAccount: `acc_${i}`,
        toAccount: `acc_${i + 1}`,
        description: `Transaction ${i}`,
      }));

      const results = await validationService.validateBatch('financial_transaction' as any, txs as any);

      expect(results).toHaveLength(25);
      expect(results[0]).toEqual(expect.objectContaining({ isValid: expect.any(Boolean) }));
    });
  });

  describe('Rules Engine', () => {
    test('rejects invalid custom rules (hardening)', () => {
      const dataValidator = new DataValidator();

      expect(() =>
        dataValidator.addRule('custom_entity' as any, {
          id: 'custom_001',
          name: 'Custom Validation Rule',
          description: 'Test custom validation rule',
          type: ValidationType.DATA_INTEGRITY,
          entityType: 'custom_entity',
          conditions: [{ field: 'requiredField', operator: 'not_equals', value: null, required: true }],
          actions: [],
          isActive: true,
          priority: 1,
        } as any)
      ).not.toThrow();

      // Previously your sample test literally asserted "not to throw" for empty rules.
      // That's how systems rot.
      expect(() => dataValidator.addRule('custom_entity' as any, {} as any)).toThrow();
    });
  });

  describe('Receipt System', () => {
    test('generates receipt with core invariants', async () => {
      const receipt = await receiptGenerator.generateReceipt(
        goldenTxn.id,
        TransactionType.PAYMENT,
        goldenTxn as any
      );

      expect(receipt).toBeDefined();
      expect(receipt.transactionId).toBe(goldenReceiptExpected.transactionId);
      expect(receipt.currency).toBe(goldenReceiptExpected.currency);
      expect(receipt.amount).toBe(goldenReceiptExpected.amount);

      expect([ReceiptStatus.VALIDATED, ReceiptStatus.APPROVED]).toContain(receipt.status);

      expect(receipt.validationResults).toBeDefined();
      expect(receipt.auditTrail).toBeDefined();
      expect(receipt.complianceChecks).toBeDefined();

      expect(receipt.digitalSignature).toBeDefined();
      expect((receipt as any).blockchainHash ?? (receipt as any).integrityHash).toBeDefined();
    });

    test('verifyReceipt consistency: valid => not tampered; tampered => not valid', async () => {
      const receipt = await receiptGenerator.generateReceipt(
        'txn_verify_001',
        TransactionType.PAYMENT,
        { id: 'txn_verify_001', amount: 750, currency: 'USD' } as any
      );

      const verification = await receiptGenerator.verifyReceipt(receipt.id);

      expect(verification).toEqual(
        expect.objectContaining({
          isValid: expect.any(Boolean),
          tampered: expect.any(Boolean),
          verificationDetails: expect.anything(),
        })
      );

      if (verification.isValid) expect(verification.tampered).toBe(false);
      if (verification.tampered) expect(verification.isValid).toBe(false);
    });

    test('exportReceipt supports json + pdf', async () => {
      const receipt = await receiptGenerator.generateReceipt(
        'txn_export_001',
        TransactionType.PAYMENT,
        { id: 'txn_export_001', amount: 250, currency: 'USD' } as any
      );

      const jsonExport = await receiptGenerator.exportReceipt(receipt.id, 'json' as any);
      expect(typeof jsonExport).toBe('string');
      expect(() => JSON.parse(jsonExport)).not.toThrow();

      const pdfExport = await receiptGenerator.exportReceipt(receipt.id, 'pdf' as any);
      const size = (pdfExport as any).byteLength ?? (pdfExport as any).length ?? 0;
      expect(size).toBeGreaterThan(20);
    });

    test('ReceiptManager batch returns one receipt per transaction', async () => {
      const receiptManager = new ReceiptManager();

      const txs = Array.from({ length: 10 }, (_, i) => ({
        type: TransactionType.PAYMENT,
        data: { id: `txn_batch_${i}`, amount: 100 + i, currency: 'USD' },
        autoApprove: false,
      }));

      const receipts = await receiptManager.processBatchTransactions(txs as any);

      expect(receipts).toHaveLength(10);
      expect(new Set(receipts.map((r: any) => r.transactionId)).size).toBe(10);
    });
  });

  describe('Audit Trail', () => {
    test('logs changes with stable shape', async () => {
      const oldData = { id: 'entity_001', name: 'Old', value: 100 };
      const newData = { id: 'entity_001', name: 'New', value: 200 };

      const entry = await auditManager.logDataChange(
        'entity_001',
        'test_entity',
        oldData as any,
        newData as any,
        'user_001'
      );

      expect(entry).toEqual(
        expect.objectContaining({
          entityId: 'entity_001',
          entityType: 'test_entity',
          userId: 'user_001',
          timestamp: expect.anything(),
          changes: expect.any(Array),
        })
      );

      expect(entry.changes).toEqual(
        expect.arrayContaining([
          expect.objectContaining({ field: 'name' }),
          expect.objectContaining({ field: 'value' }),
        ])
      );
    });

    test('verifyAuditIntegrity returns a result object', async () => {
      await auditManager.createAuditTrail(
        'entity_integrity_001',
        'test_entity',
        { id: 'entity_integrity_001', value: 1 } as any,
        'user_001',
        'create' as any
      );

      const verification = await auditManager.verifyAuditIntegrity('entity_integrity_001');

      expect(verification).toEqual(
        expect.objectContaining({
          isValid: expect.any(Boolean),
          issues: expect.any(Array),
          checksum: expect.any(String),
        })
      );
    });
  });

  describe('Compliance', () => {
    test('financial compliance returns checks with known statuses', async () => {
      const tx = { id: 'txn_comp_001', amount: 10000, currency: 'USD', fromAccount: 'acc_001', toAccount: 'acc_002' };

      const checks = await complianceValidator.validateFinancialCompliance(tx as any);

      expect(Array.isArray(checks)).toBe(true);
      expect(checks.length).toBeGreaterThan(0);
      expect(checks.map((c: any) => c.status)).not.toContain(ComplianceStatus.UNKNOWN);
    });

    test('privacy compliance respects region', async () => {
      const userData = { id: 'user_001', personalData: 'sensitive', consentGiven: true };

      const eu = await complianceValidator.validatePrivacyCompliance(userData as any, 'EU' as any);
      const us = await complianceValidator.validatePrivacyCompliance(userData as any, 'US' as any);

      expect(eu.length).toBeGreaterThan(0);
      expect(us.length).toBeGreaterThan(0);
    });
  });

  describe('Financial Auditor + Reports', () => {
    test('auditTransaction returns required sections', async () => {
      const tx = {
        id: 'txn_audit_001',
        type: TransactionType.PAYMENT,
        amount: 5000,
        currency: 'USD',
        fromAccount: 'acc_001',
        toAccount: 'acc_002',
        description: 'Large payment',
        createdAt: new Date(),
      };

      const audit = await financialAuditor.auditTransaction(tx as any);

      expect(audit).toEqual(
        expect.objectContaining({
          isValid: expect.any(Boolean),
          auditReport: expect.anything(),
          complianceStatus: expect.anything(),
          riskAssessment: expect.anything(),
          recommendations: expect.any(Array),
        })
      );
    });

    test('report generation + export works', async () => {
      const report = await reportGenerator.generateComplianceReport({
        start: new Date('2024-01-01'),
        end: new Date('2024-01-31'),
        type: 'monthly',
      } as any);

      expect(report.report).toBeDefined();

      const pdf = await reportGenerator.exportReport(report.report.id, 'pdf' as any);
      const json = await reportGenerator.exportReport(report.report.id, 'json' as any);

      expect(pdf).toBeTruthy();
      expect(typeof json).toBe('string');
    });
  });

  describe('Integration workflow', () => {
    test('validate -> receipt -> audit -> compliance -> report', async () => {
      const tx = { id: 'workflow_001', amount: 2500, currency: 'USD', fromAccount: 'acc_001', toAccount: 'acc_002' };

      const validation = await validationService.validateFinancialTransaction(tx as any);
      expect(validation.isValid).toBe(true);

      const receipt = await receiptGenerator.generateReceipt(tx.id, TransactionType.PAYMENT, tx as any);
      expect([ReceiptStatus.VALIDATED, ReceiptStatus.APPROVED]).toContain(receipt.status);

      const auditEntry = await auditManager.logDataChange(tx.id, 'financial_transaction', null as any, tx as any, 'system');
      expect(auditEntry.changes.length).toBeGreaterThan(0);

      const checks = await complianceValidator.validateFinancialCompliance(tx as any);
      expect(checks.length).toBeGreaterThan(0);

      const audit = await financialAuditor.auditTransaction({ ...tx, type: TransactionType.PAYMENT } as any);
      expect(audit.auditReport).toBeDefined();

      const report = await reportGenerator.generateTransactionAuditReport([tx.id] as any);
      expect(report.report).toBeDefined();
    });
  });

  describe('Security inputs', () => {
    test('malicious input fails without crashing', async () => {
      const malicious = {
        id: '<script>alert("xss")</script>',
        amount: -1000000,
        currency: 'INVALID',
        fromAccount: '../../etc/passwd',
        toAccount: 'DROP TABLE users;',
        description: '<img src=x onerror=alert("xss")>',
      };

      const result = await validationService.validateFinancialTransaction(malicious as any);

      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors).toEqual(
        expect.arrayContaining([expect.objectContaining({ severity: ErrorSeverity.CRITICAL })])
      );
    });
  });
});
