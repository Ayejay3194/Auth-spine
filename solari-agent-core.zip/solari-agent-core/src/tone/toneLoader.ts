import fs from "fs";
import path from "path";

export interface ToneLine {
  id: string;
  category: string;
  trigger: string;
  intensity: number;
  text: string;
  notes?: string;
}

export function loadJsonl(filePath: string): ToneLine[] {
  const raw = fs.readFileSync(filePath, "utf-8");
  return raw
    .split(/\r?\n/)
    .filter(Boolean)
    .map(line => JSON.parse(line));
}

export function loadTonePack(dir: string): ToneLine[] {
  const files = fs.readdirSync(dir).filter(f => f.endsWith(".jsonl"));
  return files.flatMap(f => loadJsonl(path.join(dir, f)));
}
