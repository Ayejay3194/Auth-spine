import type { JobName, JobPayloads } from "../jobs/jobTypes.js";

export interface JobQueue {
  enqueue<N extends JobName>(name: N, payload: JobPayloads[N], opts?: { delayMs?: number }): Promise<void>;
}

export class InMemoryQueue implements JobQueue {
  private items: Array<{ name: JobName; payload: any; at: number }> = [];
  async enqueue(name: any, payload: any, opts?: any) {
    this.items.push({ name, payload, at: Date.now() + (opts?.delayMs ?? 0) });
  }
  drain() { return this.items.splice(0); }
}
