import { AgentContext } from "../core/types.js";
import { SessionStore } from "../memory/types.js";
import { PolicyDecision, PolicyEngine } from "./types.js";

export interface SimplePolicyConfig {
  // allowlist tools per role
  allow: Record<string, string[]>;
  // per-user rate limits (requests per window)
  rate: { windowSeconds: number; max: number };
  // intents that require YES confirmation before commit
  confirmIntents: string[];
}

export class SimplePolicyEngine implements PolicyEngine {
  constructor(private store: SessionStore<{ count: number }>, private cfg: SimplePolicyConfig) {}

  private key(ctx: AgentContext) { return `rl:${ctx.userId}`; }

  async rateLimit(ctx: AgentContext): Promise<PolicyDecision> {
    const k = this.key(ctx);
    const cur = (await this.store.get(k)) ?? { count: 0 };
    if (cur.count >= this.cfg.rate.max) return { ok: false, code: "RATE_LIMIT", message: "Too many requests. Try again shortly." };
    await this.store.set(k, { count: cur.count + 1 }, this.cfg.rate.windowSeconds);
    return { ok: true };
  }

  async checkTool(ctx: AgentContext, toolId: string): Promise<PolicyDecision> {
    const rl = await this.rateLimit(ctx);
    if (!rl.ok) return rl;

    const allowed = this.cfg.allow[ctx.role]?.includes(toolId) ?? false;
    if (!allowed) return { ok: false, code: "FORBIDDEN", message: "Not allowed." };
    return { ok: true };
  }

  async checkFlowCommit(ctx: AgentContext, intent: string, meta?: Record<string, unknown>): Promise<PolicyDecision> {
    if (!this.cfg.confirmIntents.includes(intent)) return { ok: true };
    const ok = meta?.confirm === "YES";
    if (!ok) return { ok: false, code: "CONFIRM_REQUIRED", message: "Type YES to confirm.", meta: { required: "YES" } };
    return { ok: true };
  }
}
