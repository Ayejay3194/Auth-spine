
import { db } from "../lib/db";

async function main() {
  await db.user.upsert({ where: { email: "admin@demo.com" }, update: {}, create: { email: "admin@demo.com", role: "ADMIN" } });
  await db.user.upsert({ where: { email: "hr@demo.com" }, update: {}, create: { email: "hr@demo.com", role: "HR" } });
  await db.user.upsert({ where: { email: "payroll@demo.com" }, update: {}, create: { email: "payroll@demo.com", role: "PAYROLL" } });
  await db.user.upsert({ where: { email: "manager@demo.com" }, update: {}, create: { email: "manager@demo.com", role: "MANAGER" } });
  const empUser = await db.user.upsert({ where: { email: "employee@demo.com" }, update: {}, create: { email: "employee@demo.com", role: "EMPLOYEE" } });

  const e1 = await db.employee.upsert({
    where: { employeeNo: "E-1001" },
    update: {},
    create: { employeeNo: "E-1001", firstName: "Riley", lastName: "Nguyen", department: "Ops", location: "NYC", payType: "HOURLY", rateCents: 2800, userId: empUser.id }
  });

  await db.employee.upsert({
    where: { employeeNo: "E-1002" },
    update: {},
    create: { employeeNo: "E-1002", firstName: "Morgan", lastName: "Patel", department: "Engineering", location: "Remote", payType: "SALARY", rateCents: 450000 }
  });

  const policy = await db.ptoPolicy.upsert({
    where: { name: "Standard PTO" },
    update: {},
    create: { name: "Standard PTO", accrualType: "MONTHLY", accrualRate: 8, maxBalance: 200 }
  });

  await db.ptoRequest.create({
    data: { employeeId: e1.id, policyId: policy.id, startDate: new Date(Date.now() + 7*86400000), endDate: new Date(Date.now() + 8*86400000), hours: 8, status: "PENDING", reason: "Doctor appointment" }
  });

  const pg = await db.payGroup.upsert({ where: { name: "Default Biweekly" }, update: {}, create: { name: "Default Biweekly", cadence: "BIWEEKLY" } });
  await db.payRun.create({ data: { payGroupId: pg.id, status: "DRAFT", notes: "Seed draft run" } });

  await db.task.create({ data: { title: "Run onboarding checklist for new hire", status: "OPEN" } });

  console.log("Seeded.");
}
main().finally(async () => db.$disconnect());
