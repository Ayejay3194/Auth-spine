import { test, expect } from "@playwright/test";
test("health: swagger UI loads", async ({ page }) => {
  await page.goto("/swagger-ui");
  await expect(page.getByText("Swagger UI")).toBeVisible();
});
