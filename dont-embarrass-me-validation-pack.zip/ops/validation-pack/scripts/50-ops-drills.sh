#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/out"

echo "== Ops drills =="
cp "$ROOT/templates/BACKUP_RESTORE_DRILL.md" "$OUT/BACKUP_RESTORE_DRILL.md"
cp "$ROOT/templates/INCIDENT_RUNBOOK.md" "$OUT/INCIDENT_RUNBOOK.md"
cp "$ROOT/templates/ROLLBACK.md" "$OUT/ROLLBACK.md"
