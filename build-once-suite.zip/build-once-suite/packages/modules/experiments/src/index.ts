import { InMemoryEventBus, type EventBus } from "@suite/core-events";

export type FlagRule =
  | { kind: "percentage"; pct: number }
  | { kind: "targetUsers"; userIds: string[] }
  | { kind: "attribute"; attr: string; op: "eq" | "in"; value: string | string[] };

export type FeatureFlag = {
  key: string;
  enabled: boolean;
  variants: string[]; // ["control","v1",...]
  rules: FlagRule[];
};

export type Assignment = { key: string; variant: string; reason: string };

export interface FlagService {
  evaluate(user: { id: string; attrs?: Record<string,string> }, flagKey: string): Promise<Assignment>;
}

function hashToPct(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) h = Math.imul(h ^ input.charCodeAt(i), 16777619);
  return (h >>> 0) % 100;
}

export class InMemoryFlags implements FlagService {
  constructor(private flags: FeatureFlag[], private bus: EventBus = new InMemoryEventBus()) {}

  async evaluate(user: { id: string; attrs?: Record<string,string> }, flagKey: string): Promise<Assignment> {
    const flag = this.flags.find(f => f.key === flagKey);
    if (!flag || !flag.enabled) return { key: flagKey, variant: "off", reason: "disabled" };

    // rule checks
    for (const r of flag.rules) {
      if (r.kind === "targetUsers" && r.userIds.includes(user.id)) {
        return this.expose(user.id, flagKey, pickVariant(user.id, flag.variants), "targetUsers");
      }
      if (r.kind === "attribute") {
        const v = user.attrs?.[r.attr];
        if (!v) continue;
        if (r.op === "eq" && typeof r.value === "string" && v === r.value) {
          return this.expose(user.id, flagKey, pickVariant(user.id, flag.variants), "attribute:eq");
        }
        if (r.op === "in" && Array.isArray(r.value) && r.value.includes(v)) {
          return this.expose(user.id, flagKey, pickVariant(user.id, flag.variants), "attribute:in");
        }
      }
      if (r.kind === "percentage") {
        const pct = hashToPct(`${user.id}:${flagKey}`);
        if (pct < r.pct) return this.expose(user.id, flagKey, pickVariant(user.id, flag.variants), `percentage:${r.pct}`);
      }
    }

    return { key: flagKey, variant: flag.variants[0] ?? "control", reason: "default" };
  }

  private async expose(userId: string, key: string, variant: string, reason: string): Promise<Assignment> {
    await this.bus.publish({
      id: `evt_${Math.random().toString(16).slice(2)}`,
      type: "experiment.exposure",
      ts: new Date().toISOString(),
      actor: { actorType: "user", userId },
      payload: { key, variant, reason },
    });
    return { key, variant, reason };
  }
}

function pickVariant(userId: string, variants: string[]): string {
  if (variants.length <= 1) return variants[0] ?? "control";
  const idx = hashToPct(userId) % variants.length;
  return variants[idx];
}
