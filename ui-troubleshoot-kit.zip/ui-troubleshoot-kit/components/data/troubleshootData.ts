import type { TroubleshootData } from '@/components/types';

export const troubleshootData: TroubleshootData = {
  "Layout Issues": [
    {
      "id": "layout-1",
      "problem": "Element not visible or cut off",
      "symptomSignals": [
        "It exists in DOM but you can't see it",
        "Click area is missing",
        "Partially clipped"
      ],
      "authority": [
        "CSS_ONLY",
        "LOCAL_COMPONENT"
      ],
      "rootCauses": [
        "Ancestor has overflow: hidden or a fixed height",
        "Z-index is lower than an overlapping layer",
        "Element is display:none / hidden due to breakpoint class",
        "Absolute element positioned outside parent bounds"
      ],
      "solutions": [
        "Inspect ancestor overflow and height constraints",
        "Fix stacking context (position + z-index on the right layer)",
        "Confirm responsive utility classes (hidden, md:hidden, etc.)",
        "Temporarily add outline to see bounds"
      ],
      "verifySteps": [
        "In DevTools, select the element and confirm computed display/visibility/opacity",
        "Toggle overflow: hidden off on ancestors until it appears",
        "Use the DevTools 'Layers' / z-index stacking check (or raise z-index temporarily)",
        "Add outline: 1px solid red to confirm bounds"
      ],
      "antiPatterns": [
        "Throwing z-index: 999999 on everything",
        "Adding random wrappers with overflow hidden",
        "Fixing it with negative margins"
      ],
      "code": "/* Fix overflow issues */\n.parent { overflow: visible; /* or auto */ }\n\n/* Fix stacking order on the layer that actually creates the stacking context */\n.layer { position: relative; z-index: 20; }\n\n/* Debug bounds */\n.debug { outline: 1px solid red; }"
    },
    {
      "id": "layout-2",
      "problem": "Flexbox not working as expected",
      "authority": [
        "CSS_ONLY"
      ],
      "rootCauses": [
        "Parent isn't display:flex",
        "Wrong axis: confusing justify-content vs align-items",
        "Children have fixed widths that force overflow",
        "Missing flex-wrap when expecting wrap"
      ],
      "solutions": [
        "Set parent display:flex and decide direction first",
        "Use gap instead of margin hacks",
        "Add flex-wrap if wrapping is expected",
        "Set min-width:0 on flex children that contain long text"
      ],
      "verifySteps": [
        "Check computed styles: display, flex-direction, align-items, justify-content",
        "Temporarily set background colors on children to visualize layout",
        "If text overflows: add min-w-0 (Tailwind) to the flex child"
      ],
      "code": "/* Common flexbox setup */\n.container {\n  display: flex;\n  flex-direction: row; /* or column */\n  justify-content: space-between;\n  align-items: center;\n  gap: 1rem;\n}\n\n/* Prevent text from forcing overflow */\n.flex-child { min-width: 0; }"
    }
  ],
  "State & React Issues": [
    {
      "id": "state-1",
      "problem": "UI toggles reset when navigating",
      "symptomSignals": [
        "Theme/glow/radius changes then snaps back",
        "Drawer closes on route change unexpectedly"
      ],
      "authority": [
        "GLOBAL_STORE",
        "ROUTE"
      ],
      "rootCauses": [
        "State stored inside a page component that unmounts on route change",
        "Using useState in multiple components for the same global toggle",
        "Not persisting store to localStorage/session"
      ],
      "solutions": [
        "Move global toggles to a single UI store/provider above routes (layout.tsx)",
        "Remove duplicate state owners (one source of truth only)",
        "Optionally persist critical toggles to localStorage"
      ],
      "verifySteps": [
        "Navigate between pages and confirm the provider is not remounting",
        "Search codebase for the same toggle name used in multiple useState hooks",
        "Log provider mount/unmount once to confirm it is stable"
      ],
      "antiPatterns": [
        "Storing 'activeTab' in state while also using routing",
        "Copy-pasting toggle state into each page"
      ],
      "code": "// \u2705 Put UI state in one place (top-level provider), not in pages.\n// app/layout.tsx: <UIProvider> wraps your routes.\n// Then read it anywhere: const { theme, setTheme } = useUI();\n\n// Optional persistence:\nuseEffect(() => localStorage.setItem(\"theme\", theme), [theme]);"
    },
    {
      "id": "state-2",
      "problem": "Infinite re-render / UI jitter",
      "authority": [
        "LOCAL_COMPONENT"
      ],
      "rootCauses": [
        "Setting state during render",
        "Effect without dependency array causing loop",
        "Derived state stored instead of computed"
      ],
      "solutions": [
        "Never call setState in render path",
        "Add correct dependency arrays to effects",
        "Use useMemo for derived values instead of storing them"
      ],
      "verifySteps": [
        "Check console for 'Too many re-renders'",
        "Temporarily comment out effects to locate the looping one",
        "Turn on React DevTools 'Highlight updates' to see jitter source"
      ],
      "code": "// \u274c bad\n// if (x) setOpen(true)\n\n// \u2705 good\nuseEffect(() => {\n  if (x) setOpen(true);\n}, [x]);"
    },
    {
      "id": "state-3",
      "problem": "Hydration mismatch in Next.js (server vs client)",
      "authority": [
        "SERVER_STATE",
        "LOCAL_COMPONENT"
      ],
      "rootCauses": [
        "Using window/document during SSR render",
        "Rendering time/random values on server and client differently",
        "Conditional rendering based on media queries in JS"
      ],
      "solutions": [
        "Guard browser-only APIs inside useEffect or 'use client' components",
        "Move random/time rendering to client-only after mount",
        "Let CSS handle responsiveness; avoid JS media query rendering for layout"
      ],
      "verifySteps": [
        "Check console for hydration warnings",
        "Search for window/document usage in server components",
        "Replace JS-based layout branching with Tailwind responsive classes"
      ],
      "code": "// \u2705 browser-only access\nconst [mounted, setMounted] = useState(false);\nuseEffect(() => setMounted(true), []);\nif (!mounted) return null; // or render a skeleton\n\n// \u2705 use CSS for layout instead of JS media query branching"
    }
  ],
  "Z-Index & Overlays": [
    {
      "id": "z-1",
      "problem": "Dropdown/modal appears behind other UI",
      "authority": [
        "CSS_ONLY",
        "GLOBAL_STORE"
      ],
      "rootCauses": [
        "Parent creates a new stacking context (transform/filter/opacity)",
        "Modal is rendered inside a low z-index container",
        "Multiple overlay systems compete (two portals)"
      ],
      "solutions": [
        "Render overlays via a single portal root at document body",
        "Define a z-index ladder and stick to it",
        "Avoid transform on high-level wrappers unless you know why"
      ],
      "verifySteps": [
        "Inspect ancestors for transform/filter/opacity which create stacking contexts",
        "Confirm overlay root is at the end of body",
        "Compare computed z-index values in DevTools"
      ],
      "code": "/* Z-index ladder (example) */\n:root {\n  --z-content: 1;\n  --z-rail: 10;\n  --z-nav: 20;\n  --z-drawer: 40;\n  --z-modal: 60;\n  --z-toast: 80;\n}\n\n/* Avoid accidental stacking contexts on wrappers */\n.wrapper { transform: none; filter: none; }"
    }
  ],
  "Tailwind & Styling": [
    {
      "id": "tw-1",
      "problem": "Tailwind class not applying",
      "authority": [
        "CSS_ONLY"
      ],
      "rootCauses": [
        "Class not in content paths so it gets purged",
        "Conflicting classes later in the className string",
        "Using dynamic class strings that Tailwind can't detect"
      ],
      "solutions": [
        "Ensure tailwind.config content includes your folders",
        "Prefer explicit classes instead of dynamic string building",
        "Use classnames/clsx but keep classes literal"
      ],
      "verifySteps": [
        "Check generated CSS for the class (search in devtools)",
        "Verify tailwind.config.ts content paths",
        "Simplify className to isolate conflicts"
      ],
      "code": "// tailwind.config.ts\ncontent: [\"./app/**/*.{ts,tsx}\", \"./components/**/*.{ts,tsx}\"]\n\n// \u2705 keep classes literal\nconst cls = isOpen ? \"bg-slate-900 text-white\" : \"bg-white text-slate-900\";"
    }
  ]
} as const;
