export type DatasetMeta = {
  dataset: string;
  datasetVersion: string;   // v1, v2...
  schemaVersion: string;    // 1, 2...
  createdAtISO: string;
  generatorCommit?: string;
};

export function makeMeta(meta: Omit<DatasetMeta, "createdAtISO">): DatasetMeta {
  return { ...meta, createdAtISO: new Date().toISOString() };
}
