export type ID = string;
export type ISODateTime = string;
export type Money = { currency: "USD"; amountCents: number };
