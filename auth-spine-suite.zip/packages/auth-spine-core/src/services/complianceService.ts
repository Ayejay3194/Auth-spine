import type { ClockPort } from "../ports/clockPort.js";
import type { EventBus } from "../model/events.js";
import { randomId } from "../util/crypto.js";

export class ComplianceService {
  constructor(private clock: ClockPort, private bus: EventBus) {}

  async requestExport(userId: string): Promise<{ exportId: string }> {
    const exportId = randomId("gdprx_");
    await this.bus.publish({ type: "auth.gdpr.export.requested", userId, exportId, at: this.clock.nowIso() });
    return { exportId };
  }

  async requestDelete(userId: string): Promise<{ deleteId: string }> {
    const deleteId = randomId("gdprd_");
    await this.bus.publish({ type: "auth.gdpr.delete.requested", userId, deleteId, at: this.clock.nowIso() });
    return { deleteId };
  }
}
