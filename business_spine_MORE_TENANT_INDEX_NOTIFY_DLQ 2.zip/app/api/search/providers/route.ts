import { z } from "zod";
import { api } from "@/src/core/api";
import { getTenant } from "@/src/tenant/tenant";
import { searchProviders } from "@/src/search/providerIndex";

const Q = z.object({ q: z.string().default(""), size: z.number().int().min(1).max(50).optional() });

export async function POST(req: Request) {
  return api(async () => {
    const { tenantId } = getTenant(req);
    const body = Q.parse(await req.json());
    return { results: await searchProviders({ tenantId, q: body.q, size: body.size }) };
  });
}
