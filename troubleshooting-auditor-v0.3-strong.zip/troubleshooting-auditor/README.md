# Troubleshooting Auditor (TypeScript) — v0.3 "strongest"

Local auditing module + CLI that:
- audits the obvious + the sneaky
- **can run a local preview server**
- **crawls routes** to detect deep-link/refresh 404s before you ship

## New in v0.3
- **Local route refresh simulation**
  - Builds (optional), starts preview/start (optional), then fetches discovered routes
  - Reports which routes return 404/500 and captures body tail
- Supports:
  - Next: `npm run build` + `npm run start`
  - Vite: `npm run build` + `npm run preview`
  - Fallback: `npm run preview` if it exists

## CLI
```bash
# Standard audit
ts-audit --root . --format md --out audit.md

# Add deep-link / refresh simulation
ts-audit --root . --serve auto --port 4173 --crawl --format md --out audit.md

# Also run commands (captured)
ts-audit --root . --run typecheck --run build --run lint --serve auto --crawl
```

### Flags
- `--serve auto|next|vite|none` (default: none)
- `--crawl` crawls discovered routes (Next app/pages) or basic SPA sanity if not Next
- `--port 3000|4173|...` port to check (default: 3000 for next, 4173 for vite)
- `--baseUrl http://localhost:3000` overrides base url for crawl
- `--crawlMax 200` limit routes fetched (default 120)

Read-only by default. If you enable `--run` or `--serve`, it executes commands in your repo and records outputs.
