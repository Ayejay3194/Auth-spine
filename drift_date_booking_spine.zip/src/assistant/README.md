# /src/assistant (drop-in runtime wrapper)

This folder adds the **"build once" runtime glue**:
- persisted conversation state (Prisma example)
- audit logger (Prisma example)
- provider interfaces (your business logic)
- deterministic intent detector (rules + examples)
- simple policy engine (RBAC + rate limits + confirmations)
- Next.js App Router route templates (under /app/api/*)

This is still **No-LLM**: structured workflows, not improv.


## Store mode
This package now includes **Inventory** and **Fulfillment** spines. Providers required: `inventory`, `fulfillment`.


## Drift Date Booking
Includes `dates` + `safety` spines. Providers required: `venue`, `dates`, `reservations`, `safety`.
