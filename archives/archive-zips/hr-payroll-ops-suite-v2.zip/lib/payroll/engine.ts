
import { db } from "@/lib/db";

type Item = {
  employeeId: string;
  grossCents: number;
  taxesCents: number;
  deductionsCents: number;
  netCents: number;
  breakdown: any;
};

export async function buildItemsFromApprovedTimesheets(payRunId: string, periodStart: Date, periodEnd: Date) {
  const employees = await db.employee.findMany({ where: { status: "ACTIVE" } });

  // Pull adjustments already created for this run (if any)
  const adjustments = await db.payRunAdjustment.findMany({ where: { payRunId } });
  const adjByEmp = new Map<string, typeof adjustments>();
  for (const a of adjustments) {
    adjByEmp.set(a.employeeId, [...(adjByEmp.get(a.employeeId) || []), a]);
  }

  const items: Item[] = [];
  const exceptions: Array<{ employeeId?: string; kind: string; message: string }> = [];

  for (const e of employees) {
    // Require an APPROVED timesheet overlapping the run period (V1 simple: one timesheet fully covering)
    const ts = await db.timesheet.findFirst({
      where: {
        employeeId: e.id,
        status: "APPROVED",
        periodStart: { lte: periodStart },
        periodEnd: { gte: periodEnd }
      },
      include: { entries: true }
    });

    if (!ts && e.payType === "HOURLY") {
      exceptions.push({ employeeId: e.id, kind: "MISSING_APPROVED_TIMESHEET", message: "Hourly employee has no approved timesheet covering the pay period." });
      continue;
    }

    let gross = 0;
    const breakdown: any = { payType: e.payType, baseRateCents: e.rateCents, minutes: 0, earnings: [] };

    if (e.payType === "HOURLY") {
      const minutes = (ts?.entries || [])
        .filter(x => x.minutes != null)
        .reduce((s, x) => s + (x.minutes || 0), 0);

      breakdown.minutes = minutes;

      // cents/hour * minutes/60 -> cents
      gross = Math.round(e.rateCents * (minutes / 60));
      breakdown.earnings.push({ kind: "HOURLY", minutes, amountCents: gross });
    } else {
      // SALARY: cents per pay period (V1)
      gross = e.rateCents;
      breakdown.earnings.push({ kind: "SALARY", amountCents: gross });
    }

    // Apply adjustments
    const empAdjs = adjByEmp.get(e.id) || [];
    let adjEarnings = 0;
    let adjDeductions = 0;

    for (const a of empAdjs) {
      if (a.type === "EARNING") adjEarnings += a.amountCents;
      if (a.type === "DEDUCTION") adjDeductions += a.amountCents;
    }

    gross += adjEarnings;
    const deductions = Math.max(0, adjDeductions);

    // Placeholder tax: 15% of taxable wages (gross - pretax deductions would go here)
    const taxes = Math.max(0, Math.round(gross * 0.15));
    const net = gross - taxes - deductions;

    if (net < 0) exceptions.push({ employeeId: e.id, kind: "NEGATIVE_NET", message: "Net pay is negative after taxes/deductions." });

    items.push({
      employeeId: e.id,
      grossCents: gross,
      taxesCents: taxes,
      deductionsCents: deductions,
      netCents: net,
      breakdown: { ...breakdown, adjustments: empAdjs.map(a => ({ type: a.type, label: a.label, amountCents: a.amountCents })) }
    });
  }

  return { items, exceptions };
}
