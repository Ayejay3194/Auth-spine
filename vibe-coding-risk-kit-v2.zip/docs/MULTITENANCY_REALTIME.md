# Multi-tenancy, Realtime, and Isolation Checklist

## Tenant Isolation
- [ ] Tenant context derived server-side (not client-provided only)
- [ ] Tenant ID included in every row that is tenant-scoped
- [ ] Queries always include tenant filter (enforced by RLS/policies where possible)
- [ ] Cross-tenant admin access audited

## Realtime/WebSockets
- [ ] Auth on connection + re-auth/expiry handling
- [ ] Channel-level authorization enforced server-side
- [ ] Reconnect logic avoids storms (exponential backoff + jitter)
- [ ] Message size limits + rate limits
