import React from "react";
import { SafeAreaView, Text, Button } from "react-native";

export default function App() {
  return (
    <SafeAreaView style={{ padding: 16 }}>
      <Text style={{ fontSize: 22, fontWeight: "600" }}>Mobile Skeleton</Text>
      <Text style={{ marginTop: 12 }}>Wire to your API: bookings, notifications, profile.</Text>
      <Button title="Refresh" onPress={() => {}} />
    </SafeAreaView>
  );
}
