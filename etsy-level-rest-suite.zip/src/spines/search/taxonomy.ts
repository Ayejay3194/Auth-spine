
export interface ServiceCategory {
  id: string;
  name: string;
  parentId?: string;
}

export interface ServiceListing {
  providerId: string;
  serviceName: string;
  price: number;
  durationMin: number;
}

export function rankProviders(input: {
  rating: number;
  distanceMi: number;
  availabilityScore: number;
  trustScore: number;
}): number {
  return (
    input.rating * 0.35 +
    (1 / Math.max(input.distanceMi, 0.5)) * 0.2 +
    input.availabilityScore * 0.25 +
    input.trustScore * 0.2
  );
}
