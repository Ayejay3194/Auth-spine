import { reportQueue } from "@/src/queue/queues";
import type { Notification } from "./types";

export async function enqueueNotification(n: Notification) {
  await reportQueue.add("notify_send", n, {
    attempts: 8,
    backoff: { type: "exponential", delay: 1500 },
    removeOnComplete: true,
  });
}
