import { readJson, section, ok, fail, exists, run, findFiles } from "./_util.mjs";
import path from "node:path";

const cfg = readJson("./infra.config.json");

async function optional(cmd, args, name){
  section(name);
  const code = await run(cmd, args);
  if(code===127 || code===9009){ // common "command not found" codes
    console.log(`⚠️  ${cmd} not found. Skipping ${name}. Install it to enforce this check.`);
    return 0;
  }
  if(code!==0) fail(`${name} failed`);
  else ok(`${name} passed`);
  return code;
}

section("Terraform validation (format + validate)");
for(const dir of (cfg.paths.terraform ?? [])){
  if(!exists(dir)) { console.log(`Skipping missing ${dir}`); continue; }
  await optional("terraform", ["-chdir="+dir, "fmt", "-check"], `terraform fmt -check (${dir})`);
  await optional("terraform", ["-chdir="+dir, "validate"], `terraform validate (${dir})`);
  await optional("tflint", ["--chdir", dir], `tflint (${dir})`);
  await optional("checkov", ["-d", dir], `checkov IaC scan (${dir})`);
}

section("Kubernetes/Helm validation (yaml + schema)");
for(const dir of (cfg.paths.kubernetes ?? [])){
  if(!exists(dir)) { console.log(`Skipping missing ${dir}`); continue; }
  const yamls = findFiles(dir, [".yml",".yaml"]);
  if(!yamls.length){ console.log(`No yaml found in ${dir}`); continue; }
  await optional("kubeconform", ["-strict", dir], `kubeconform (${dir})`);
  await optional("conftest", ["test", dir], `conftest policy tests (${dir})`);
  ok(`YAML discovered: ${yamls.length} file(s) in ${dir}`);
}

for(const dir of (cfg.paths.helm ?? [])){
  if(!exists(dir)) { console.log(`Skipping missing ${dir}`); continue; }
  await optional("helm", ["lint", dir], `helm lint (${dir})`);
  await optional("checkov", ["-d", dir], `checkov scan (${dir})`);
}
