PRESS RELEASE TEMPLATE
======================

Headline:
Subhead:

Opening paragraph:
Who we are, what changed, why it matters.

Quote:
Founder or spokesperson.

Details:
What this unlocks for users.

Closing:
Calm confidence.
