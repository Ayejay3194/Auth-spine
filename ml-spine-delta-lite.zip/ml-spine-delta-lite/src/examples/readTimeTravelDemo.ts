import path from "node:path";
import { latestCommitId, resolveFilesAtCommit } from "../delta/log.js";
import { readParquetToArrowTable } from "../io/parquetArrow.js";

async function run() {
  const cfg = { root: "./lake" };
  const table = "de440_residuals";
  const tableVersion = "v3";

  const head = await latestCommitId(cfg, table, tableVersion);
  if (!head) throw new Error("No commits yet. Run dev:write first.");

  const files = await resolveFilesAtCommit(cfg, table, tableVersion, head);
  console.log("files at head:", files);

  // read first file
  const abs = path.join(cfg.root, files[0].path);
  const t = await readParquetToArrowTable(abs);
  console.log("rows:", t.numRows, "cols:", t.schema.fields.map(f => f.name));
}

run().catch((e) => { console.error(e); process.exit(1); });
