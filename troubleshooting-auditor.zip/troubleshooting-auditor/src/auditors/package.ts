import path from "node:path";
import type { AuditSection } from "../types.js";
import { exists, readJson } from "../utils/fs.js";

type Pkg = {
  scripts?: Record<string, string>;
  engines?: Record<string, string>;
  type?: string;
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
};

export function auditPackage(root: string): AuditSection {
  const section: AuditSection = { id: "package", title: "Package & Scripts", findings: [] };
  const pkgPath = path.join(root, "package.json");

  if (!exists(pkgPath)) {
    section.findings.push({
      id: "package.missing",
      title: "package.json missing",
      severity: "ERROR",
      details: "No package.json means no scripts and no reproducible dependency graph.",
      fix: "Create package.json and define scripts for dev/build/start/lint/typecheck.",
      evidence: { pkgPath },
    });
    return section;
  }

  let pkg: Pkg;
  try {
    pkg = readJson<Pkg>(pkgPath);
  } catch (e) {
    section.findings.push({
      id: "package.invalid",
      title: "package.json is not valid JSON",
      severity: "ERROR",
      details: "Your package.json failed to parse.",
      fix: "Fix JSON syntax.",
      evidence: { pkgPath, error: String(e) },
    });
    return section;
  }

  const scripts = pkg.scripts ?? {};
  const required = ["build", "dev"] as const;

  for (const k of required) {
    if (!scripts[k]) {
      section.findings.push({
        id: `package.scripts.${k}`,
        title: `No ${k} script`,
        severity: k === "build" ? "ERROR" : "WARN",
        details: `Deployments/local dev typically rely on \`npm run ${k}\`. Missing it causes friction and CI failures.`,
        fix: k === "build"
          ? "Add build script (Next: `next build`, Vite: `vite build`, custom: `tsc -p tsconfig.json`)."
          : "Add dev script (Next: `next dev`, Vite: `vite`).",
        evidence: { scripts },
      });
    }
  }

  if (!scripts["start"]) {
    section.findings.push({
      id: "package.scripts.start",
      title: "No start script",
      severity: "INFO",
      details: "Production parity is easier when `npm start` exists.",
      fix: "Add start script (Next: `next start`, Node: `node dist/server.js`).",
      evidence: { scripts },
    });
  }

  const lockfiles = ["package-lock.json", "yarn.lock", "pnpm-lock.yaml"];
  const present = lockfiles.filter((f) => exists(path.join(root, f)));
  if (present.length === 0) {
    section.findings.push({
      id: "package.lockfile.missing",
      title: "No lockfile found",
      severity: "WARN",
      details: "No lockfile means dependency versions drift across machines/CI and you get random breakage.",
      fix: "Commit a lockfile. Use npm/yarn/pnpm consistently.",
      evidence: { checked: lockfiles },
    });
  }

  if (!pkg.engines?.node) {
    section.findings.push({
      id: "package.engines.node",
      title: "No Node engine pinned",
      severity: "INFO",
      details: "Node version mismatches are a top cause of prod-only failures.",
      fix: "Add `engines: { node: '>=18' }` and optionally `.nvmrc`.",
      evidence: { engines: pkg.engines ?? null },
    });
  }

  if (pkg.type && pkg.type !== "module") {
    section.findings.push({
      id: "package.type.cjs",
      title: "package.json type is not 'module'",
      severity: "INFO",
      details: "Not always wrong, but ESM/CJS mismatches are common when deploying.",
      fix: "If using ESM at runtime, set `type: module` or align bundler/runtime settings.",
      evidence: { type: pkg.type },
    });
  }

  return section;
}
