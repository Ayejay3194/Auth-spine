# RLS Safety Rules (Supabase/Postgres)
- RLS enabled on every tenant/user-scoped table
- Policies cover SELECT/INSERT/UPDATE/DELETE
- No service-role key in the browser. Ever.
- Test as anon + normal user (not service role)

CI anti-footgun idea:
Fail if any public table (except allowlist) has relrowsecurity=false.
