LUXE EXPERIENCE SIGNALS
=======================

User-facing:
- Clear timelines
- Predictable language
- Fewer notifications, better phrasing
- No raw error messages

Internal:
- Confidence indicators
- Resolution previews
- "Next best action" hints for agents
