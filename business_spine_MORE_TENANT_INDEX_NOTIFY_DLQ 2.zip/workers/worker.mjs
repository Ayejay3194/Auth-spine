import { Worker } from "bullmq";
import Redis from "ioredis";
import crypto from "node:crypto";
import { PrismaClient } from "@prisma/client";
import { stringify } from "csv-stringify/sync";
import fs from "node:fs";
import path from "node:path";

import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

const prisma = new PrismaClient();
const redisUrl = process.env.REDIS_URL || "redis://localhost:6379";
const connection = new Redis(redisUrl);

const log = (m) => console.log("[worker]", m);

function sign(secret, body, ts) {
  return crypto.createHmac("sha256", secret).update(ts + "." + body).digest("hex");
}

function s3() {
  const region = process.env.AWS_REGION || "us-east-1";
  return new S3Client({ region });
}

async function uploadExport(key, bytes) {
  const bucket = process.env.EXPORTS_S3_BUCKET;
  if (!bucket) return null;
  const client = s3();
  await client.send(new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: bytes,
    ContentType: "text/csv"
  }));
  const base = process.env.EXPORTS_PUBLIC_BASE_URL;
  if (base) return base.replace(/\/$/, "") + "/" + key;
  const region = process.env.AWS_REGION || "us-east-1";
  return `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
}

new Worker("webhooks", async job => {
  const { deliveryId } = job.data;
  const delivery = await prisma.webhookDelivery.findUnique({ where: { id: deliveryId } });
  if (!delivery) return { ok: false };

  const wh = await prisma.webhookEndpoint.findUnique({ where: { id: delivery.webhookId } });
  if (!wh || !wh.active) {
    await prisma.webhookDelivery.update({ where: { id: deliveryId }, data: { status: "failed", lastError: "endpoint_inactive" } });
    return { ok: false };
  }

  const body = JSON.stringify({ type: delivery.eventType, payload: delivery.payload });
  const ts = String(Date.now());
  const sig = sign(wh.secret, body, ts);

  const res = await fetch(wh.url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Webhook-Timestamp": ts,
      "X-Webhook-Signature": sig
    },
    body
  });

  if (!res.ok) {
    const err = `http_${res.status}`;
    await prisma.webhookDelivery.update({
      where: { id: deliveryId },
      data: { attempt: { increment: 1 }, lastError: err }
    });
    throw new Error(err);
  }

  await prisma.webhookDelivery.update({
    where: { id: deliveryId },
    data: { status: "delivered", deliveredAt: new Date(), lastError: null }
  });

  return { delivered: true };
}, { connection });

new Worker("reports", async job => {
// Search indexing jobs
if (job.name === "index_provider" || job.name === "reindex_all_providers") {
  const mod = await import("../src/search/indexJobs.js");
  const res = await mod.handleIndexJob(job);
  if (res) return res;
}

  if (job.name === "dsr_export") {
    const { dsrId } = job.data;
    await prisma.dataSubjectRequest.update({ where: { id: dsrId }, data: { status: "processing" } });
    await prisma.dataSubjectRequest.update({ where: { id: dsrId }, data: { status: "ready", url: `/exports/dsr_${dsrId}.zip` } });
    return { ok: true };
  }
// Notifications
if (job.name === "notify_send") {
  const mod = await import("../src/notify/notifyWorker.js");
  const res = await mod.handleNotifyJob(job);
  if (res) return res;
}
  if (job.name === "dsr_delete") {
    const { dsrId } = job.data;
    await prisma.dataSubjectRequest.update({ where: { id: dsrId }, data: { status: "processing" } });
    await prisma.dataSubjectRequest.update({ where: { id: dsrId }, data: { status: "done" } });
    return { ok: true };
  }
// Notifications
if (job.name === "notify_send") {
  const mod = await import("../src/notify/notifyWorker.js");
  const res = await mod.handleNotifyJob(job);
  if (res) return res;
}

  const { exportId } = job.data;
  const exp = await prisma.reportExport.findUnique({ where: { id: exportId } });
  if (!exp) return { ok: false };

  const invoices = await prisma.invoice.findMany({ where: { providerId: exp.providerId }, take: 500, orderBy: { createdAt: "desc" } });
  const rows = invoices.map(i => ({ invoiceId: i.id, amount: i.amount, status: i.status, createdAt: i.createdAt.toISOString() }));

  const csv = stringify(rows, { header: true });
  const bytes = Buffer.from(csv, "utf8");

  const key = `exports/export_${exportId}.csv`;

  // Prefer S3 if configured
  const s3Url = await uploadExport(key, bytes);
  if (s3Url) {
    await prisma.reportExport.update({ where: { id: exportId }, data: { status: "ready", url: s3Url } });
    return { url: s3Url };
  }

  // Fallback: local public dir
  const dir = path.join(process.cwd(), "public", "exports");
  fs.mkdirSync(dir, { recursive: true });
  const filename = `export_${exportId}.csv`;
  fs.writeFileSync(path.join(dir, filename), csv);

  const url = `/exports/${filename}`;
  await prisma.reportExport.update({ where: { id: exportId }, data: { status: "ready", url } });
  return { url };
}, { connection });

log("Final polish workers up.");
