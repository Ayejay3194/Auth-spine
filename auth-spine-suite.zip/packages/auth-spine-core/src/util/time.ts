export function minutesFromNowIso(nowMs: number, minutes: number): string {
  return new Date(nowMs + minutes * 60_000).toISOString();
}

export function isIsoBefore(a: string, b: string): boolean {
  return new Date(a).getTime() < new Date(b).getTime();
}
