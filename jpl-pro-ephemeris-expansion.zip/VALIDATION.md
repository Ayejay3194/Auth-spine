
# Validation Strategy

- Horizons comparison (random sampling across kernel span)
- Historical date edge cases
- Polar latitude stress tests
- Leap second boundaries
- House cusp monotonicity checks

No merge without passing validation.
