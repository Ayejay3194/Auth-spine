# Troubleshooting Auditor (TypeScript) — v0.2

A local auditing module + CLI that checks the most common "my TS website is broken" causes
and produces a report (Markdown or JSON).

## New in v0.2
- **Rewrite rules audit** (SPA deep-link 404 killers):
  - `netlify.toml`, `public/_redirects`
  - `vercel.json`
  - `firebase.json`
  - `staticwebapp.config.json` (Azure Static Web Apps)
  - `nginx.conf`/common nginx snippets (best-effort)
- **Service worker cache traps** audit:
  - Detects SW files in `public/` + common registration patterns
  - Flags if assets likely not fingerprinted and SW can serve stale bundles
- **Route crawl** audit:
  - Next.js App Router: `app/**/page.*`
  - Next.js Pages Router: `pages/**` (excluding `api/`)
  - Flags missing rewrites when SPA routing is detected
  - Produces a route list summary (useful for "why is /settings 404 in prod?")

## Install & run (inside your repo)
```bash
mkdir -p tools && cp -R troubleshooting-auditor tools/troubleshooting-auditor
cd tools/troubleshooting-auditor
npm i
npm run build

node dist/cli.js --root ../../ --format md --out ../../audit-report.md
```

## CLI
```bash
ts-audit --root . --format md --out audit.md
ts-audit --root . --format json --out audit.json
ts-audit --root . --run typecheck --run build --run lint
ts-audit --root . --endpoints https://example.com/health,https://example.com/api/ping
```

- Read-only by default.
- `--run` executes commands in your repo and records outputs.
