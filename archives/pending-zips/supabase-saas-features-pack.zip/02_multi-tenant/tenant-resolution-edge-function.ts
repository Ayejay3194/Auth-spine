/**
 * Edge Function: resolve tenant from Host header (custom domains/subdomains)
 * - Looks up domain -> tenant
 * - Returns tenant_id and plan/status
 *
 * You can call this from your app server and then set `app.tenant_id` in DB session.
 */
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const host = req.headers.get("host") ?? "";
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const sb = createClient(supabaseUrl, serviceKey);

  const { data, error } = await sb
    .from("tenant_domains")
    .select("tenant_id, tenants:tenants(plan,status,region,slug,name)")
    .eq("domain", host)
    .maybeSingle();

  if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  if (!data) return new Response(JSON.stringify({ error: "TENANT_NOT_FOUND" }), { status: 404 });

  return new Response(JSON.stringify({ tenant_id: data.tenant_id, ...data.tenants }), {
    headers: { "content-type": "application/json" },
  });
});
