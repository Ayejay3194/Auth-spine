# StyleSeat-like No-LLM Business Assistant Suite (TypeScript)
You asked for "everything they'd need to run their business" without a large model.

This suite is:
- Deterministic NLU (rules + lightweight similarity)
- Entity extraction (regex + pragmatic date/time parsing)
- Slot-filling flows (state machine)
- Tool router (timeouts, retries, validation)
- Policy engine (role allowlists, rate limits, YES confirmations)
- Audit logging + tracing
- Plugin spines: booking, CRM, payments, marketing, analytics, ops, admin/gdpr

## Run the demo
```bash
corepack enable
corepack prepare pnpm@9.0.0 --activate
pnpm i
pnpm build
pnpm demo
```

## Integrate into your app
Replace the demo providers in `src/demo/providerMock.ts` with your real DB/email/payments/calendar implementations.
The assistant logic doesn't change.
