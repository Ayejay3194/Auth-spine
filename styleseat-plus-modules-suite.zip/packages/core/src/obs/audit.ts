import type { ISODateTime, ID } from "../shared/types.js";

export type AuditEvent = {
  id: ID;
  at: ISODateTime;
  actorId: ID;
  businessId: ID;
  type: string;
  details: Record<string, any>;
};

export interface AuditLogger { write(ev: AuditEvent): Promise<void>; }

export class InMemoryAuditLogger implements AuditLogger {
  private events: AuditEvent[] = [];
  async write(ev: AuditEvent) { this.events.unshift(ev); }
  list(limit = 100) { return this.events.slice(0, limit); }
}
