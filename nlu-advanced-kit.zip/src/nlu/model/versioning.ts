import type { NLUModel } from "../types";
import { validateModel, withDefaults } from "./schema";

export function bumpUpdatedAt(model: NLUModel): NLUModel {
  return { ...model, updatedAt: new Date().toISOString() };
}

export function importModel(jsonText: string): { ok: true; model: NLUModel } | { ok: false; error: string } {
  try {
    const parsed = JSON.parse(jsonText) as NLUModel;
    const v = validateModel(parsed);
    if (!v.ok) return { ok: false, error: v.error };
    return { ok: true, model: withDefaults(parsed) };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "Invalid JSON" };
  }
}

export function exportModel(model: NLUModel): string {
  return JSON.stringify(model, null, 2);
}
