import { Skill } from "./base.js";
import { SkillContext, SkillResult } from "../types.js";

export class FallbackSkill implements Skill {
  name = "FallbackSkill";

  async run(ctx: SkillContext): Promise<SkillResult> {
    return {
      kind: "clarify",
      question: "What do you want the output to be: a plan, code, an interpretation, or a file?",
      options: ["Plan", "Code", "Interpretation", "File"],
      tags: ["fallback","clarify"]
    };
  }
}
