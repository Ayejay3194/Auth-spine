'use client'

import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { useSession } from 'next-auth/react'
import { Workspace, WorkspaceMember, WorkspaceContext } from '@/lib/types'

interface WorkspaceContextType {
  activeWorkspace: Workspace | null
  activeMembership: WorkspaceMember | null
  permissions: string[]
  switchWorkspace: (workspaceId: string) => void
  refreshWorkspace: () => void
  isLoading: boolean
}

const WorkspaceContext = createContext<WorkspaceContextType | undefined>(undefined)

interface WorkspaceProviderProps {
  children: ReactNode
}

export function WorkspaceProvider({ children }: WorkspaceProviderProps) {
  const { data: session, status } = useSession()
  const [activeWorkspace, setActiveWorkspace] = useState<Workspace | null>(null)
  const [activeMembership, setActiveMembership] = useState<WorkspaceMember | null>(null)
  const [permissions, setPermissions] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const switchWorkspace = async (workspaceId: string) => {
    try {
      const response = await fetch(`/api/workspaces/${workspaceId}/switch`, {
        method: 'POST',
      })
      
      if (response.ok) {
        const data = await response.json()
        setActiveWorkspace(data.workspace)
        setActiveMembership(data.membership)
        setPermissions(data.permissions)
        
        // Store in localStorage for persistence
        localStorage.setItem('activeWorkspaceId', workspaceId)
      }
    } catch (error) {
      console.error('Failed to switch workspace:', error)
    }
  }

  const refreshWorkspace = async () => {
    if (!session?.user) return

    try {
      const response = await fetch('/api/workspaces/active')
      if (response.ok) {
        const data = await response.json()
        setActiveWorkspace(data.workspace)
        setActiveMembership(data.membership)
        setPermissions(data.permissions)
      }
    } catch (error) {
      console.error('Failed to refresh workspace:', error)
    }
  }

  useEffect(() => {
    if (status === 'authenticated') {
      // Load active workspace on mount
      const loadActiveWorkspace = async () => {
        try {
          const response = await fetch('/api/workspaces/active')
          if (response.ok) {
            const data = await response.json()
            setActiveWorkspace(data.workspace)
            setActiveMembership(data.membership)
            setPermissions(data.permissions)
          } else {
            // Try to get from localStorage as fallback
            const storedWorkspaceId = localStorage.getItem('activeWorkspaceId')
            if (storedWorkspaceId) {
              await switchWorkspace(storedWorkspaceId)
            }
          }
        } catch (error) {
          console.error('Failed to load active workspace:', error)
        } finally {
          setIsLoading(false)
        }
      }

      loadActiveWorkspace()
    } else {
      setIsLoading(false)
    }
  }, [status, session])

  const value = {
    activeWorkspace,
    activeMembership,
    permissions,
    switchWorkspace,
    refreshWorkspace,
    isLoading,
  }

  return (
    <WorkspaceContext.Provider value={value}>
      {children}
    </WorkspaceContext.Provider>
  )
}

export function useWorkspace() {
  const context = useContext(WorkspaceContext)
  if (context === undefined) {
    throw new Error('useWorkspace must be used within a WorkspaceProvider')
  }
  return context
}