
# Supabase Security & Architecture Pack
Luxury Booking Platform – Hardened Setup

This pack gives you **Supabase-first security** with:
- Auth + MFA
- Row Level Security (RLS)
- Ops vs Public separation
- Storage security
- Audit logging
- Production-safe defaults

This is the *correct* way to use Supabase for a multi-role booking platform.
