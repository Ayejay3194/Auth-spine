// reviews entities.ts
