Golden tests that hit runtime + your model endpoint.
