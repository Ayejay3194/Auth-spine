Solari Comprehensive NLU JSONL Pack
Generated: 2025-12-17

What you get
- train.jsonl / valid.jsonl / test.jsonl  (total 1200 examples)
- schema.json  (field + entity span format)
- intents.json (canonical intent list)
- entities.json (canonical entity list)

Each JSONL line:
{
  "text": "...",
  "intent": "...",
  "intent_description": "...",
  "entities": [{"entity":"...","value":"...","start":0,"end":5}]
}

Recommended use
1) Start with these as a bootstrap classifier/extractor.
2) As soon as you have real logs, add a "human-labeled" set and keep this synthetic set as augmentation.
3) Freeze intent names as API contracts. If you must change, version them (intent_v2) not rename.

Suggested training approach
- Intent model: text -> intent
- Entity model: text -> BIO tagging OR span extraction
- Joint model: multi-task fine-tune
- Eval: use test.jsonl only for final checks; keep a separate "golden" set for release gates.
