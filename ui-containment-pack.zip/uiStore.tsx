"use client";
import React from "react";
export const UIProvider=({children}:{children:React.ReactNode})=>(<>{children}</>);