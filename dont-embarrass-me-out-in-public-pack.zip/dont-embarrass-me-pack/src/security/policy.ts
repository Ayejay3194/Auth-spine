import type { Role } from "../runtime/types";

export type Action = "read" | "create" | "update" | "delete" | "invoke" | "export" | "admin";
export type Resource =
  | "chat"
  | "tools"
  | "receipts"
  | "audit"
  | "payments"
  | "bookings"
  | "crm"
  | "system"
  | string;

export interface PolicyRule {
  role: Role;
  resource: Resource;
  actions: Action[];
}

export interface Policy {
  rules: PolicyRule[];
  // optional: per-tenant allowlist for specific tool names
  toolAllowlist?: Record<string, string[]>; // role -> toolNames
}

export function isAllowed(policy: Policy, role: Role, resource: Resource, action: Action): boolean {
  // owner is god-mode; keep it explicit.
  if (role === "owner") return true;

  return policy.rules.some(r =>
    r.role === role &&
    (r.resource === resource || r.resource === "*") &&
    r.actions.includes(action)
  );
}

export function isToolAllowed(policy: Policy, role: Role, toolName: string): boolean {
  if (role === "owner") return true;
  const list = policy.toolAllowlist?.[role];
  if (!list) return false; // FAIL CLOSED
  return list.includes(toolName);
}
