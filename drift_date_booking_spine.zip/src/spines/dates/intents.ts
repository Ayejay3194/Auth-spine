import { Pattern } from "../../core/intent.js";

export const patterns: Pattern[] = [
  {
    "spine": "dates",
    "intent": "date_propose",
    "re": "book (?:a )?date|plan (?:a )?date|set up (?:a )?date|date night",
    "baseConfidence": 0.78,
    "hint": "propose date"
  },
  {
    "spine": "dates",
    "intent": "date_accept",
    "re": "accept (?:the )?date|i'm in|sounds good",
    "baseConfidence": 0.65,
    "hint": "accept date"
  },
  {
    "spine": "dates",
    "intent": "date_decline",
    "re": "decline (?:the )?date|not interested|no thanks",
    "baseConfidence": 0.7,
    "hint": "decline date"
  },
  {
    "spine": "dates",
    "intent": "date_cancel",
    "re": "cancel (?:the )?date|call off date",
    "baseConfidence": 0.75,
    "hint": "cancel date"
  },
  {
    "spine": "dates",
    "intent": "date_set_time",
    "re": "reschedule|change time|move it to",
    "baseConfidence": 0.72,
    "hint": "set time"
  },
  {
    "spine": "dates",
    "intent": "venue_search",
    "re": "find (?:a )?(?:place|restaurant|bar)|search venues|venue search",
    "baseConfidence": 0.7,
    "hint": "venue search"
  },
  {
    "spine": "dates",
    "intent": "reservation_create",
    "re": "reserve|book table|make reservation",
    "baseConfidence": 0.75,
    "hint": "reserve"
  }
];
