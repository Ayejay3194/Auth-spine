import { FlowDefinition } from "../flows/types.js";
import { Tool } from "../tools/types.js";
import { SessionStore } from "../memory/session.js";
import { BookingProvider } from "../providers/types.js";

export interface SlotCache { slots: Array<{ slotId: string; label: string }>; }

export function bookingSpine(opts: { provider: BookingProvider; slotCache: SessionStore<SlotCache> }) {
  const { provider, slotCache } = opts;

  const tools: Tool<any, any>[] = [
    {
      id: "availability.findSlots",
      description: "Find available booking slots",
      validate: (i) => { if (!i.service) throw new Error("Missing service"); if (!i.durationMin) throw new Error("Missing duration"); },
      run: async (ctx, input) => {
        const slots = await provider.findSlots({ ...input, timezone: ctx.timezone });
        const labeled = slots.slice(0, 6).map((s, idx) => ({ slotId: s.slotId, label: `${idx+1}) ${s.startISO} (${s.durationMin}m)` }));
        await slotCache.set(`slots:${ctx.userId}`, { slots: labeled }, 10 * 60);
        return { ok: true, data: { slots: labeled } };
      },
      timeoutMs: 2500,
      retries: 1,
    },
    {
      id: "booking.create",
      description: "Create a booking",
      validate: (i) => { const n = Number(i.slotChoice); if (!Number.isFinite(n) || n < 1 || n > 6) throw new Error("Pick slot 1-6"); if (!i.service) throw new Error("Missing service"); },
      run: async (ctx, input) => {
        const cache = await slotCache.get(`slots:${ctx.userId}`);
        if (!cache) return { ok: false, error: { code: "NO_SLOTS", message: "No cached slots. Ask for availability first." } };
        const slotId = cache.slots[Number(input.slotChoice)-1]?.slotId;
        if (!slotId) return { ok: false, error: { code: "BAD_SLOT", message: "Invalid slot choice." } };
        const bk = await provider.createBooking({ userId: ctx.userId, slotId, service: input.service });
        return { ok: true, data: { bookingId: bk.bookingId } };
      },
      timeoutMs: 2500,
    },
    {
      id: "booking.cancel",
      description: "Cancel booking",
      validate: (i) => { if (!String(i.bookingId ?? "").startsWith("bk_")) throw new Error("Bad bookingId"); },
      run: async (ctx, input) => {
        const bk = await provider.cancelBooking({ userId: ctx.userId, bookingId: input.bookingId });
        return { ok: true, data: { bookingId: bk.bookingId } };
      },
      timeoutMs: 2500,
    },
    {
      id: "booking.list",
      description: "List bookings",
      validate: () => {},
      run: async (ctx) => {
        const list = await provider.listBookings({ userId: ctx.userId });
        return { ok: true, data: { bookings: list } };
      },
      timeoutMs: 2500,
    },
  ];

  const flows: FlowDefinition[] = [
    {
      intent: "booking.create",
      slots: [
        { name: "service", required: true, fromEntity: (e) => e.find(x => x.type === "service")?.value ?? null },
        { name: "durationMin", required: true, fromEntity: (e) => String((e.find(x => x.type === "duration")?.meta as any)?.minutes ?? "") || null },
        { name: "dateISO", required: false, fromEntity: (e) => (e.find(x => x.type === "datetime")?.meta as any)?.dateISO ?? null },
        { name: "partOfDay", required: false, fromEntity: (e) => (e.find(x => x.type === "datetime")?.meta as any)?.partOfDay ?? null },
        { name: "slotChoice", required: true },
        { name: "confirm", required: true },
      ],
      steps: () => [
        { ask: { slot: "service", prompt: "What service are we booking?", hint: "astrology" } },
        { ask: { slot: "durationMin", prompt: "How long (minutes)?", hint: "60" } },
        { call: { toolId: "availability.findSlots", inputFromSlots: (s) => ({ service: s.service, durationMin: Number(s.durationMin), dateISO: s.dateISO, partOfDay: s.partOfDay }) } },
        { ask: { slot: "slotChoice", prompt: "Pick a slot number (1-6).", hint: "1" } },
        { ask: { slot: "confirm", prompt: "Type YES to confirm booking.", hint: "YES" } },
        { call: { toolId: "booking.create", commitIntent: "booking.create", confirmSlot: "confirm", inputFromSlots: (s) => ({ slotChoice: s.slotChoice, service: s.service }) } },
        { done: { message: "Booked." } },
      ],
    },
    {
      intent: "booking.cancel",
      slots: [
        { name: "bookingId", required: true, fromEntity: (e) => e.find(x => x.type === "bookingId")?.value ?? null },
        { name: "confirm", required: true },
      ],
      steps: () => [
        { ask: { slot: "bookingId", prompt: "Booking id to cancel? (bk_...)", hint: "bk_abc123" } },
        { ask: { slot: "confirm", prompt: "Type YES to confirm cancellation.", hint: "YES" } },
        { call: { toolId: "booking.cancel", commitIntent: "booking.cancel", confirmSlot: "confirm", inputFromSlots: (s) => ({ bookingId: s.bookingId }) } },
        { done: { message: "Canceled." } },
      ],
    },
    {
      intent: "booking.list",
      slots: [],
      steps: () => [
        { call: { toolId: "booking.list", inputFromSlots: () => ({}) } },
        { done: { message: "Listed your bookings." } },
      ],
    },
  ];

  return { tools, flows };
}
