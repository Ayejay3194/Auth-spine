'use client'
import React, { useMemo, useState } from 'react'
import { Search, AlertCircle, CheckCircle, Copy, ChevronDown, ChevronRight } from 'lucide-react'

type Item = { id: string; problem: string; solutions: string[]; code: string }
type Data = Record<string, Item[]>

const troubleshootData: Data = {
  'Layout Issues': [
    {
      id: 'layout-1',
      problem: 'Element not visible or cut off',
      solutions: [
        'Check if parent has overflow: hidden',
        'Verify z-index stacking',
        'Check display: none / visibility: hidden',
        'Inspect parent height/width constraints',
      ],
      code: `.parent { overflow: visible; }
.element { position: relative; z-index: 999; }`,
    },
    {
      id: 'layout-2',
      problem: 'Flexbox not working as expected',
      solutions: [
        'Ensure parent has display: flex',
        'Check flex-direction (row vs column)',
        'Use flex-wrap: wrap if items should wrap',
        'Adjust justify-content and align-items',
      ],
      code: `.container{display:flex;flex-direction:row;justify-content:center;align-items:center;gap:1rem;}`,
    },
  ],
  'Responsiveness': [
    {
      id: 'responsive-1',
      problem: 'Mobile layout broken',
      solutions: [
        'Add viewport meta tag',
        'Use mobile-first breakpoints',
        'Test common widths: 320, 768, 1024, 1440',
        'Use relative units instead of fixed pixels',
      ],
      code: `.container{width:100%;padding:1rem;}
@media(min-width:768px){.container{width:750px;margin:0 auto;}}`,
    },
  ],
}

export default function UIToolkitPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [copiedId, setCopiedId] = useState<string | null>(null)

  const filtered = useMemo(() => {
    if (!searchTerm) return troubleshootData
    const out: Data = {}
    for (const [category, items] of Object.entries(troubleshootData)) {
      const keep = items.filter(i =>
        i.problem.toLowerCase().includes(searchTerm.toLowerCase()) ||
        i.solutions.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()))
      )
      if (keep.length) out[category] = keep
    }
    return out
  }, [searchTerm])

  const copyCode = async (code: string, id: string) => {
    await navigator.clipboard.writeText(code)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl shadow p-6">
        <div className="flex items-center gap-3 mb-2">
          <AlertCircle className="w-7 h-7 text-blue-600" />
          <h1 className="text-2xl font-bold">UI Troubleshooting Toolkit</h1>
        </div>
        <p className="text-slate-600 mb-4">Search your problem or browse categories.</p>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search..."
            className="w-full pl-12 pr-4 py-3 border-2 border-slate-200 rounded-lg focus:border-blue-500 focus:outline-none"
          />
        </div>
      </div>

      <div className="space-y-3">
        {Object.keys(filtered).length === 0 ? (
          <div className="bg-white rounded-xl shadow p-6 text-slate-600">No results.</div>
        ) : (
          Object.entries(filtered).map(([category, items]) => (
            <div key={category} className="bg-white rounded-xl shadow overflow-hidden">
              <button
                className="w-full px-5 py-4 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100"
                onClick={() => setExpanded(prev => ({ ...prev, [category]: !prev[category] }))}
              >
                <div className="font-semibold">{category}</div>
                <div className="flex items-center gap-2 text-slate-600">
                  <span className="text-xs bg-white px-2 py-1 rounded-full">{items.length}</span>
                  {expanded[category] ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
                </div>
              </button>

              {expanded[category] && (
                <div className="p-5 space-y-5">
                  {items.map(item => (
                    <div key={item.id} className="border-l-4 border-blue-500 pl-4">
                      <div className="font-semibold mb-2">{item.problem}</div>
                      <ul className="list-disc pl-5 text-sm text-slate-700 space-y-1 mb-3">
                        {item.solutions.map((s, idx) => <li key={idx}>{s}</li>)}
                      </ul>
                      <div className="bg-slate-900 rounded-lg p-3 relative">
                        <button
                          className="absolute top-2 right-2 p-2 bg-slate-700 hover:bg-slate-600 rounded"
                          onClick={() => copyCode(item.code, item.id)}
                          title="Copy code"
                        >
                          {copiedId === item.id ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-slate-200" />}
                        </button>
                        <pre className="text-slate-100 text-sm overflow-x-auto pr-12"><code>{item.code}</code></pre>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  )
}
