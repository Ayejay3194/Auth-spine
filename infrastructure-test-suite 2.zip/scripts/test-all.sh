#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

log "Running IaC checks"
./scripts/test-iac.sh

log "Running policy checks"
./scripts/test-policies.sh

log "Running secrets scan"
./scripts/test-secrets.sh

log "Running OpenAPI contract checks (if specs exist)"
./scripts/test-contracts.sh || true

log "Running smoke tests (optional)"
./scripts/test-smoke.sh || true

log "Running performance tests (optional)"
./scripts/test-perf.sh || true

log "Done."
