# SaaS/PaaS Security Checklist (Canonical)

Use this repo as the enforcement layer.
If a control isn't implemented OR explicitly risk-accepted, it's a release blocker.

Key blockers for v1:
- Tenant context validation on EVERY request
- Object-level authorization on EVERY read/write
- Per-tenant rate limiting + quotas
- Webhook signature verification
- Secrets management (no secrets in code)
- Audit logging for auth + admin + boundary events
- Support access is JIT, time-limited, consented, and logged
