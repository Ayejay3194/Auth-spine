import type { Check } from "../types.js";
import { DocumentsCheck } from "./documents.js";
import { SecretsScanCheck } from "./secrets-scan.js";
import { IAMWildcardsCheck } from "./iam-wildcards.js";
import { K8sBaselineCheck } from "./k8s-baseline.js";
import { OpenApiAuthCheck } from "./openapi-auth.js";
import { BackupsConfigCheck } from "./backups-config.js";

export const CHECKS: Check[] = [
  DocumentsCheck,
  SecretsScanCheck,
  IAMWildcardsCheck,
  K8sBaselineCheck,
  OpenApiAuthCheck,
  BackupsConfigCheck,
];
