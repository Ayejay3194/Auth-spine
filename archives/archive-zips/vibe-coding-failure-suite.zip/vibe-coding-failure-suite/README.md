# Vibe Coding Failure Suite

This repo is a **guardrail pack** for “vibe coding” so you stop shipping security holes, spaghetti, and regret.

## What’s inside

- `checklists/` The actual “things that go wrong” checklist (MD + JSON).
- `scripts/` Preflight scripts to catch common faceplants before you deploy.
- `.github/` Minimal CI to enforce the basics (lint, typecheck, tests).
- `templates/` Issue + PR templates that force humans to be accountable.
- `risk/` A starter risk register you can actually maintain.
- `docs/` Runbooks and baselines so you can debug without psychic powers.
- `prompts/` Copy-paste prompts for Cursor/LLM audits (architecture, security, perf).

## Quick start

1. Copy this folder into your repo (or unzip at project root).
2. Enable the GitHub Actions workflow.
3. Run `scripts/preflight.sh` (Mac/Linux) or `scripts/preflight.ps1` (Windows) before pushing.

## License

MIT for the template scaffolding. Your bugs are still proprietary.
