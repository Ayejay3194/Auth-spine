# Wit-like NLU Kit (Intent + Entities + Tiny Admin UI)

This repo gives you a **Wit.ai-style** stack:
- **NLU service (Python/FastAPI + scikit-learn)**: `/parse` returns `{intent, confidence, entities[]}`
- **Training**: JSONL examples + a `/train` endpoint + CLI script
- **Admin UI (Next.js)**: add examples, test parsing, retrain
- **Optional Supabase schema**: store intents/entities/examples/logs if you want it “real”

## Quick start (local, no Supabase)

### 1) Start the NLU service
```bash
cd nlu-service
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m app.main
```

### 2) Train once
```bash
cd nlu-service
python scripts/train.py
```

### 3) Start the admin UI
```bash
cd web-admin
npm i
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000/admin/nlu`.

## JSONL training format

`nlu-service/data/training.jsonl` lines look like:
```json
{"text":"book me for friday at 2pm","intent":"booking.create","entities":[{"entity":"datetime","value":"friday 2pm"}]}
```

## /parse response shape

```json
{
  "text": "book me for friday at 2pm",
  "intent": { "name": "booking.create", "confidence": 0.92 },
  "entities": [
    { "entity": "datetime", "value": "friday at 2pm", "start": 12, "end": 26, "confidence": 0.80, "source": "regex" }
  ],
  "intents": [
    { "name": "booking.create", "confidence": 0.92 },
    { "name": "booking.reschedule", "confidence": 0.06 }
  ]
}
```

## Supabase (optional)
If you want persistence + multi-user:
- run the SQL in `supabase/schema.sql`
- (optional) apply `supabase/rls.sql`

## Notes
- Simple, controllable: regex + lookup for entities; ML classifier for intent.
- Add more entity extractors in `nlu-service/app/extractors.py`.
