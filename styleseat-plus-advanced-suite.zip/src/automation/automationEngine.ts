export class AutomationEngine {
  run(trigger: string, payload: any) {
    return { trigger, payload, at: new Date().toISOString() };
  }
}
