import type { EmailTemplate, TemplateStore } from "@suite/modules-email";

export class InMemoryTemplateStore implements TemplateStore {
  private map = new Map<string, EmailTemplate>();
  async get(key: string) { return this.map.get(key) ?? null; }
  async upsert(tpl: EmailTemplate) { this.map.set(tpl.key, tpl); }
}
