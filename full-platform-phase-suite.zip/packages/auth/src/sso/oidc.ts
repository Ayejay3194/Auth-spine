export type OIDCProvider = {
  issuer: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  scopes: string[];
};

export function buildAuthUrl(p: OIDCProvider, state: string, nonce: string): string {
  const url = new URL(p.issuer.replace(/\/+$/,"") + "/authorize");
  url.searchParams.set("client_id", p.clientId);
  url.searchParams.set("redirect_uri", p.redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", p.scopes.join(" "));
  url.searchParams.set("state", state);
  url.searchParams.set("nonce", nonce);
  return url.toString();
}
