# Prompt: Monorepo Assembly & Wiring

You are my refactor & integration assistant **inside this repo**.

I will paste:
- A target monorepo structure
- A list of source paths and where they should move
- Module boundary rules

Your job:

1. Create the target folder structure.
2. Move existing code to new locations.
3. Update imports, paths, and tsconfig references.
4. Try to ensure:
   - `pnpm install`
   - `pnpm lint`
   - `pnpm test`
   - `pnpm build`
   can run (or tell me exactly what's missing).

Rules:
- Do NOT rewrite or "improve" core logic unless I explicitly ask.
- Keep changes minimal and mechanical.
- If you must stub something, mark it clearly with a TODO.
- Maintain an `INTEGRATION_LOG.md` summarizing:
  - file moves
  - import changes
  - stubs added.
