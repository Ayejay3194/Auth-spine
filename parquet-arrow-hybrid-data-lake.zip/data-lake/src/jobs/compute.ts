import { Float64Vector, Int32Vector, Utf8Vector, Table as ArrowTable } from "apache-arrow";
import { readParquetToArrowTable, writeArrowTableToParquet } from "../core/parquetArrowHybrid.js";
import { WarehouseConfig, partFile } from "../core/paths.js";
import { makeMeta } from "../core/versioning.js";

export type ComputeArgs = {
  input: { cfg: WarehouseConfig; dayISO: string; part?: number };
  output: { cfg: WarehouseConfig; dayISO: string; part?: number };
};

/**
 * Toy example:
 * - read residuals
 * - compute magnitude and bucket
 * - write feature table
 */
export async function computeFeatures(args: ComputeArgs): Promise<string> {
  const inPart = args.input.part ?? 1;
  const outPart = args.output.part ?? 1;

  const inFile = partFile(args.input.cfg, args.input.dayISO, inPart);
  const t = await readParquetToArrowTable(inFile);

  const tsCol = t.getChild("ts")!;
  const bodyCol = t.getChild("body")!;
  const dxCol = t.getChild("dx_arcsec")!;
  const dyCol = t.getChild("dy_arcsec")!;

  const ts: string[] = [];
  const body: string[] = [];
  const mag: number[] = [];
  const bucket: number[] = [];

  for (let i = 0; i < t.numRows; i++) {
    const x = Number(dxCol.get(i));
    const y = Number(dyCol.get(i));
    const m = Math.sqrt(x * x + y * y);

    ts.push(String(tsCol.get(i)));
    body.push(String(bodyCol.get(i)));
    mag.push(m);
    bucket.push(m < 0.5 ? 0 : m < 1.0 ? 1 : m < 2.0 ? 2 : 3);
  }

  const outTable = ArrowTable.new({
    ts: Utf8Vector.from(ts),
    body: Utf8Vector.from(body),
    err_mag_arcsec: Float64Vector.from(mag),
    err_bucket: Int32Vector.from(bucket),
  });

  const outFile = partFile(args.output.cfg, args.output.dayISO, outPart);
  const meta = makeMeta({
    dataset: args.output.cfg.dataset,
    datasetVersion: args.output.cfg.datasetVersion,
    schemaVersion: "1",
  });

  await writeArrowTableToParquet(outFile, outTable, {
    compression: "zstd",
    metadata: { ...meta, schemaName: "residual_features" },
  });

  return outFile;
}
