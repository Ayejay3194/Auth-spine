// subscriptions tools.ts
