# Incident Runbook (2am proof)

## Severity
- **SEV0**: breach, payments broken, auth bypass, system down
- **SEV1**: major outage for many users
- **SEV2**: partial degradation

## First 5 minutes
1. Flip maintenance/killswitch
2. Snapshot logs + relevant DB state
3. Identify last change: deploy/config/secret/traffic

## Containment
- Rotate secrets if leak suspected
- Block abusive IPs
- Disable write endpoints temporarily if needed

## Recovery
- Roll back deploy
- Restore backup if data integrity compromised
- Re-enable features gradually

## Postmortem checklist
- Timeline
- Root cause
- Fix + tests
- Action items (owner + date)
