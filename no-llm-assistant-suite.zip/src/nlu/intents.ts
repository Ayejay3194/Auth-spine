import { bag, cosine, tokenize } from "./tokenize.js";

export type IntentId =
  // booking
  | "booking.create"
  | "booking.reschedule"
  | "booking.cancel"
  | "booking.list"
  | "availability.search"
  // support
  | "auth.forgot_username"
  | "auth.password_reset_request"
  | "gdpr.export_request"
  | "billing.change_plan"
  // fallback
  | "unknown";

export interface IntentExample { intent: IntentId; utterance: string; }
export interface IntentRule { intent: IntentId; any: string[]; all?: string[]; }

export interface IntentResult {
  intent: IntentId;
  score: number;
  matchedBy: "rule" | "similarity" | "none";
  alternatives: Array<{ intent: IntentId; score: number }>;
}

export class IntentDetector {
  private exampleVecs: Array<{ intent: IntentId; vec: Map<string, number> }> = [];
  constructor(
    private rules: IntentRule[],
    examples: IntentExample[],
    private cfg: { minScore: number } = { minScore: 0.35 }
  ) {
    for (const ex of examples) this.exampleVecs.push({ intent: ex.intent, vec: bag(tokenize(ex.utterance)) });
  }

  detect(text: string): IntentResult {
    const norm = text.toLowerCase();

    for (const r of this.rules) {
      const anyOk = r.any.some((p) => norm.includes(p));
      const allOk = (r.all ?? []).every((p) => norm.includes(p));
      if (anyOk && allOk) return { intent: r.intent, score: 1, matchedBy: "rule", alternatives: [] };
    }

    const v = bag(tokenize(text));
    const scores = new Map<IntentId, number>();
    for (const ex of this.exampleVecs) {
      const s = cosine(v, ex.vec);
      scores.set(ex.intent, Math.max(scores.get(ex.intent) ?? 0, s));
    }

    const ranked = Array.from(scores.entries())
      .map(([intent, score]) => ({ intent, score }))
      .sort((a, b) => b.score - a.score);

    const top = ranked[0] ?? { intent: "unknown" as const, score: 0 };
    const intent = top.score >= this.cfg.minScore ? top.intent : ("unknown" as const);

    return { intent, score: top.score, matchedBy: intent === "unknown" ? "none" : "similarity", alternatives: ranked.slice(0, 4) };
  }
}
