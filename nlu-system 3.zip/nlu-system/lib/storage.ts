import type { NLUModel } from "./types";

const KEY = "nlu_model_v1";

export function loadModelFromStorage(): NLUModel | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as NLUModel;
    if (!parsed || typeof parsed !== "object") return null;
    if (!Array.isArray(parsed.intents) || !Array.isArray(parsed.entities)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveModelToStorage(model: NLUModel) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(model));
}

export function clearModelStorage() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(KEY);
}
