import { findFiles, readText, rel } from "../utils/fs.js";
import type { Check, Finding } from "../types.js";

function isWildcard(x: unknown) {
  return x === "*" || (Array.isArray(x) && x.includes("*"));
}

export const IAMWildcardsCheck: Check = {
  id: "security.iam_wildcards",
  title: "IAM policies avoid wildcard Action/Resource",
  category: "Security",
  async run(ctx) {
    const rule = ctx.profile.rules?.iam ?? {};
    const forbidA = rule.forbidWildcardActions ?? true;
    const forbidR = rule.forbidWildcardResources ?? true;
    const sev = rule.severity ?? "P0";

    const policyFiles = findFiles(ctx.root, ["**/*iam*.json", "**/*policy*.json"])
      .filter(f => !f.includes("node_modules/") && !f.includes("dist/"));

    const findings: Finding[] = [];
    for (const f of policyFiles) {
      const txt = readText(f);
      if (!txt) continue;
      let json: any;
      try { json = JSON.parse(txt); } catch { continue; }

      const statements = json.Statement ?? json.statement ?? [];
      for (const st of statements) {
        if (forbidA && isWildcard(st.Action ?? st.action)) {
          findings.push({
            id: this.id,
            title: this.title,
            category: this.category,
            severity: sev,
            evidence: [{
              message: `Wildcard Action in IAM policy: ${rel(ctx.root, f)}`,
              file: rel(ctx.root, f),
              hint: "Replace * with explicit actions. If you truly need broad perms, scope Resource tightly and justify it."
            }]
          });
        }
        if (forbidR && isWildcard(st.Resource ?? st.resource)) {
          findings.push({
            id: this.id,
            title: this.title,
            category: this.category,
            severity: sev,
            evidence: [{
              message: `Wildcard Resource in IAM policy: ${rel(ctx.root, f)}`,
              file: rel(ctx.root, f),
              hint: "Scope Resource to the minimal ARN set. Wildcard resources are how accidents become incidents."
            }]
          });
        }
      }
    }
    return findings;
  }
};
