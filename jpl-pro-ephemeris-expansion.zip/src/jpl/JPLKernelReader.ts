
/**
 * JPL SPK Kernel Reader
 * Reads NAIF SPK files and evaluates Chebyshev segments.
 * All coefficients are treated as immutable truth.
 */
export class JPLKernelReader {
  constructor(private kernelPath: string) {}

  getCoverage(): { startJD: number; endJD: number } {
    throw new Error("SPK coverage parsing not implemented");
  }

  evaluate(targetId: number, centerId: number, tdbJD: number) {
    throw new Error("Chebyshev evaluation not implemented");
  }
}
