import type { AuditReport, Severity } from "../types.js";
function rank(s: Severity) { return s === "ERROR" ? 0 : s === "WARN" ? 1 : 2; }
export function toMarkdown(r: AuditReport): string {
  const out: string[] = [];
  out.push(`# Troubleshooting Audit Report`);
  out.push(`- Root: \`${r.meta.root}\``);
  out.push(`- Timestamp: \`${r.meta.timestamp}\``);
  out.push(`- Node: \`${r.meta.node}\``);
  out.push(`- Platform: \`${r.meta.platform}\``);
  out.push("");
  out.push(`## Summary`);
  out.push(`- Errors: **${r.summary.errors}**`);
  out.push(`- Warnings: **${r.summary.warns}**`);
  out.push(`- Info: **${r.summary.infos}**`);
  out.push("");
  for (const s of r.sections) {
    out.push(`## ${s.title}`);
    const findings = [...s.findings].sort((a,b)=>rank(a.severity)-rank(b.severity));
    if (!findings.length) { out.push(`- ✅ No findings\n`); continue; }
    for (const f of findings) {
      out.push(`### [${f.severity}] ${f.title}`);
      out.push(f.details);
      if (f.fix) out.push(`**Fix:** ${f.fix}`);
      if (f.evidence && Object.keys(f.evidence).length) {
        out.push(`**Evidence:**`);
        out.push("```json");
        out.push(JSON.stringify(f.evidence, null, 2));
        out.push("```");
      }
      out.push("");
    }
  }
  return out.join("\n");
}
export function toJson(r: AuditReport): string { return JSON.stringify(r, null, 2); }
