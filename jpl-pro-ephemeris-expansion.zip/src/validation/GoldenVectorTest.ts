
/**
 * Golden vector regression test.
 * Any refactor changing output must fail this test.
 */

export interface GoldenVector {
  inputHash: string;
  outputHash: string;
}

export function validateGoldenVector(
  currentHash: string,
  golden: GoldenVector
): boolean {
  return currentHash === golden.outputHash;
}
