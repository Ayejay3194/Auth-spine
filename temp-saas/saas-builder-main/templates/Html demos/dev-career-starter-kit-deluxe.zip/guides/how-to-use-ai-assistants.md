# How to Use AI Assistants Without Letting Them Drive the Car

Good uses:
- "Explain this file and how it fits in."
- "Help me write tests for this route."
- "Refactor this to be cleaner without changing behavior."

Bad uses:
- "Build everything for me and I won't read it."
- Copy-pasting errors without logs or context.

Pattern:
- Use **Zip Intake** when juggling multiple codebases.
- Use **Architect** to design structure.
- Use **Assembly & Wiring** inside the repo.
- Use **DevLog & Ticket Writer** at the end of the day.
