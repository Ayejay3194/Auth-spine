import { AgentContext } from "../core/types.js";
import { Entity } from "../nlu/entities.js";
import { runTool } from "../tools/runner.js";
import { FlowDefinition, FlowDeps, FlowEngine, FlowState } from "./types.js";

function fill(def: FlowDefinition, slots: Record<string,string>, entities: Entity[]) {
  for (const s of def.slots) {
    if (!slots[s.name] && s.fromEntity) {
      const v = s.fromEntity(entities);
      if (v) slots[s.name] = v;
    }
  }
}

function missing(def: FlowDefinition, slots: Record<string,string>) {
  for (const s of def.slots) if (s.required && !slots[s.name]) return s.name;
  return null;
}

export function createFlowEngine(deps: FlowDeps): FlowEngine {
  async function advance(ctx: AgentContext, def: FlowDefinition, state: FlowState) {
    const steps = def.steps(state.slots);
    for (let i = state.stepIndex; i < steps.length; i++) {
      state.stepIndex = i;
      const step = steps[i];

      if (step.ask && !state.slots[step.ask.slot]) {
        await deps.audit.write({ at: deps.clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "slot.asked", details: { intent: state.intent, slot: step.ask.slot } });
        return { state, reply: { text: step.ask.prompt, ui: { type: "form", data: { slot: step.ask.slot, hint: step.ask.hint } } } };
      }

      if (step.call) {
        if (step.call.commitIntent) {
          const confirm = step.call.confirmSlot ? state.slots[step.call.confirmSlot] : undefined;
          const dec = await deps.policy.checkCommit(ctx, step.call.commitIntent, confirm);
          if (!dec.ok) {
            await deps.audit.write({ at: deps.clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "policy.blocked", details: { intent: step.call.commitIntent, code: dec.code } });
            return { state, reply: { text: dec.message ?? "Confirmation required.", ui: { type: "form", data: { slot: step.call.confirmSlot ?? "confirm", hint: "YES" } } } };
          }
        }
        const tool = deps.tools.get(step.call.toolId);
        const input = step.call.inputFromSlots(state.slots);
        const res = await runTool({ ctx, tool, input, audit: deps.audit, clock: deps.clock, tracer: deps.tracer, policy: deps.policy });
        if (!res.ok) {
          state.completed = true;
          await deps.audit.write({ at: deps.clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "flow.failed", details: { intent: state.intent, error: res.error } });
          return { state, reply: { text: `That failed: ${res.error?.message ?? "unknown error"}`, done: true } };
        }
      }

      if (step.done) {
        state.completed = true;
        await deps.audit.write({ at: deps.clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "flow.completed", details: { intent: state.intent } });
        return { state, reply: { text: step.done.message, done: true } };
      }
    }
    state.completed = true;
    return { state, reply: { text: "Done.", done: true } };
  }

  async function start(ctx: AgentContext, def: FlowDefinition, entities: Entity[]) {
    const slots: Record<string,string> = {};
    fill(def, slots, entities);
    return advance(ctx, def, { intent: def.intent, stepIndex: 0, slots, completed: false });
  }

  async function cont(ctx: AgentContext, def: FlowDefinition, state: FlowState, userText: string, entities: Entity[]) {
    if (state.completed) return { state, reply: { text: "Nothing to do.", done: true } };
    const m = missing(def, state.slots);
    if (m) {
      state.slots[m] = userText.trim();
      await deps.audit.write({ at: deps.clock.now(), businessId: ctx.businessId, actorId: ctx.userId, role: ctx.role, type: "slot.filled", details: { intent: state.intent, slot: m } });
    }
    fill(def, state.slots, entities);
    return advance(ctx, def, state);
  }

  return { start, cont };
}
