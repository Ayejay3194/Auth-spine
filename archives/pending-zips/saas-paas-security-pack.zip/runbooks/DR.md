# Disaster Recovery drill
- Restore DB to isolated environment
- Validate auth + core flows
- Validate tenant boundaries post-restore
- Measure RTO/RPO
- Record evidence in `evidence/backup-drills/`
