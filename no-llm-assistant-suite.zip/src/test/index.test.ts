import test from "node:test";
import assert from "node:assert/strict";
import { parseDateTime } from "../nlu/datetime.js";
import { IntentDetector } from "../nlu/intents.js";

test("parseDateTime handles next tuesday evening", () => {
  const now = new Date("2025-12-13T12:00:00Z");
  const dt = parseDateTime("next tuesday evening", now);
  assert.ok(dt.dateISO);
  assert.equal(dt.partOfDay, "evening");
});

test("intent detector picks booking.create", () => {
  const det = new IntentDetector([{ intent: "booking.create", any: ["book"], all: [] }], [{ intent: "booking.create", utterance: "book appointment" }], { minScore: 0.2 });
  const r = det.detect("book me please");
  assert.equal(r.intent, "booking.create");
});
