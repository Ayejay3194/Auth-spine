# API stubs

Minimal route outlines you can map to Next.js `app/api/*/route.ts`.
Wire these to your Auth-Spine + DB layer.

See `api/routes.ts` and `api/handlers/*`.
