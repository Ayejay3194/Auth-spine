import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'configs/endpoints.json'), 'utf8'));
const baseUrl = (process.env.TARGET_BASE_URL || fs.readFileSync(path.join(root, 'out/target_base_url.txt'), 'utf8')).trim();

function nowISO() { return new Date().toISOString(); }

async function req(method, url, body) {
  const init = { method, headers: { 'Content-Type': 'application/json' } };
  if (body && method !== 'GET') init.body = JSON.stringify(body);
  const res = await fetch(url, init);
  let text = '';
  try { text = await res.text(); } catch {}
  return { status: res.status, text };
}

const results = [];

async function run() {
  results.push({ name: 'health', ...(await req('GET', baseUrl + cfg.health)) });

  const evil = {
    id: "<script>alert('xss')</script>",
    q: "' OR 1=1;--",
    path: "../../etc/passwd",
    memo: "DROP TABLE users; --"
  };

  if (cfg.chat) {
    const body = {
      ...cfg.chat.body,
      message: `${cfg.chat.body.message} ${evil.q} ${evil.id}`,
      context: { nowISO: nowISO(), actor: { userId: 'test', role: 'admin' }, tenantId: 'abuse-test' }
    };
    results.push({ name: 'chat', ...(await req(cfg.chat.method, baseUrl + cfg.chat.path, body)) });
  }

  if (cfg.intent) {
    const body = {
      ...cfg.intent.body,
      text: `${cfg.intent.body.text} ${evil.q} ${evil.id}`,
      context: { nowISO: nowISO(), actor: { userId: 'test', role: 'admin' }, tenantId: 'abuse-test' }
    };
    results.push({ name: 'intent', ...(await req(cfg.intent.method, baseUrl + cfg.intent.path, body)) });
  }

  for (const p of (cfg.protected || [])) {
    const r = await req(p.method, baseUrl + p.path);
    results.push({ name: `protected:${p.method}:${p.path}`, ...r, expected: p.expect });
  }

  if (cfg.auth?.login) {
    const counts = {};
    for (let i = 0; i < 60; i++) {
      const r = await req(cfg.auth.login.method, baseUrl + cfg.auth.login.path, cfg.auth.login.body);
      counts[r.status] = (counts[r.status] || 0) + 1;
    }
    results.push({ name: 'login-spam', status: 200, text: JSON.stringify(counts) });
  }

  fs.writeFileSync(path.join(root, 'out', 'api-abuse-results.json'), JSON.stringify({ baseUrl, results }, null, 2));
  console.log(JSON.stringify({ baseUrl, summary: results.map(r => ({ name: r.name, status: r.status, expected: r.expected })) }, null, 2));
}

run().catch((e) => {
  console.error('api-abuse-tests failed', e);
  process.exit(1);
});
