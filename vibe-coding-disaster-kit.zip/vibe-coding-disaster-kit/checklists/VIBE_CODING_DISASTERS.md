# Complete “Things That Can Go Wrong With Vibe Coding” Checklist

Use this as:
- a **pre-flight** list before shipping
- a **post-mortem** prompt when something breaks
- a **threat model** starter

---

## Security Vulnerabilities

### Authentication & Authorization Disasters
- [ ] No authentication on critical endpoints
- [ ] Hardcoded admin credentials in code
- [ ] JWT tokens without expiration
- [ ] No token refresh mechanism
- [ ] Session tokens stored in localStorage (XSS vulnerable)
- [ ] Weak password requirements (no minimum length)
- [ ] No password hashing (storing plain text passwords)
- [ ] Using weak hashing algorithms (MD5, SHA1)
- [ ] No rate limiting on login attempts
- [ ] Missing CSRF protection
- [ ] No email verification on signup
- [ ] Authorization checks only on frontend
- [ ] User can edit their own role/permissions
- [ ] Missing authentication on API endpoints
- [ ] Anyone can access other users’ data
- [ ] No session timeout
- [ ] Forgot password without token expiration
- [ ] Password reset tokens never expire
- [ ] Using GET requests for sensitive operations
- [ ] No account lockout after failed attempts
- [ ] Predictable session IDs
- [ ] Session fixation vulnerabilities
- [ ] No logout functionality
- [ ] Logout doesn’t invalidate tokens
- [ ] Auth state only checked once on page load

### Injection Vulnerabilities
- [ ] SQL injection everywhere (string concatenation in queries)
- [ ] No parameterized queries
- [ ] Raw SQL with user input
- [ ] XSS attacks (no output encoding)
- [ ] Dangerously setting innerHTML with user content
- [ ] No input sanitization
- [ ] Command injection in system calls
- [ ] LDAP injection
- [ ] XML injection / XXE
- [ ] NoSQL injection
- [ ] GraphQL injection
- [ ] Template injection / SSTI
- [ ] Code injection via eval()
- [ ] Unsafe deserialization
- [ ] Path traversal vulnerabilities
- [ ] File inclusion vulnerabilities
- [ ] Header injection

### Data Exposure
- [ ] API returns sensitive fields (password hashes, tokens, secrets)
- [ ] Verbose error messages / stack traces in production
- [ ] Credentials or secrets in frontend bundles
- [ ] API keys committed to Git
- [ ] `.env` files in version control
- [ ] Secrets baked into container images
- [ ] Debug mode enabled in production
- [ ] Source maps publicly exposed
- [ ] Directory listing enabled
- [ ] Backup files accessible (`.bak`, `.old`)
- [ ] `.git` directory exposed
- [ ] Internal API docs publicly accessible
- [ ] GraphQL introspection enabled in prod without controls
- [ ] Database reachable from the public internet
- [ ] Admin panel at `/admin` with weak/no protection
- [ ] PII in URLs or logs
- [ ] Sensitive data in query parameters
- [ ] Logging passwords/tokens
- [ ] Over-permissive CORS (`*`)
- [ ] No encryption for sensitive data
- [ ] Storing card data directly

### Access Control Issues
- [ ] Horizontal privilege escalation (IDOR)
- [ ] Vertical privilege escalation (user to admin)
- [ ] Missing authorization checks server-side
- [ ] Sequential/predictable IDs with no ownership verification
- [ ] Mass assignment (client can set forbidden fields)
- [ ] Everyone is admin by default
- [ ] File uploads accessible by direct URL
- [ ] Private files stored in public folders

### File Upload Vulnerabilities
- [ ] No file type validation
- [ ] No file size limits
- [ ] Files saved with original names (collisions + injection)
- [ ] Uploaded files executable by server
- [ ] No malware scanning
- [ ] SVG accepted without sanitizing scripts
- [ ] Zip bombs / decompression bombs
- [ ] Path traversal in filenames

---

## Database Disasters

### Schema & Design Problems
- [ ] No schema discipline (everything becomes TEXT)
- [ ] Dates stored as strings
- [ ] No primary keys / broken uniqueness
- [ ] Missing foreign keys / referential integrity
- [ ] Missing or wrong indexes
- [ ] Over-indexing everything
- [ ] Money stored as floats
- [ ] Missing NOT NULL / CHECK constraints
- [ ] Soft deletes without thinking about relationships
- [ ] Circular FK dependencies

### Query Problems
- [ ] N+1 queries everywhere
- [ ] `SELECT *` everywhere
- [ ] No pagination on list endpoints
- [ ] Missing WHERE clauses
- [ ] Leading wildcard searches (`%term`)
- [ ] Full table scans on large tables
- [ ] Queries in loops
- [ ] Sorting/filtering in app instead of DB

### Data Integrity Issues
- [ ] No validation at write-time
- [ ] Orphaned records
- [ ] Mixed timezones
- [ ] No audit trail
- [ ] No transactions for multi-step operations
- [ ] Race conditions causing lost updates
- [ ] Migrations in production without testing/rollback

### Connection & Performance Issues
- [ ] No connection pooling
- [ ] Connection leaks
- [ ] No query timeout
- [ ] Long-running queries block everything
- [ ] No backups / backups never tested
- [ ] No PITR (point-in-time recovery)
- [ ] No monitoring / no slow query review

### RLS Issues (if using Row-Level Security)
- [ ] RLS not enabled
- [ ] Policies too permissive
- [ ] New tables shipped without policies
- [ ] Service role used on the client
- [ ] Multi-table queries leak because one table missing RLS
- [ ] Policies are so complex they DDOS your DB

---

## API & Backend Disasters
### API Design Problems
- [ ] No versioning
- [ ] Breaking changes without bump
- [ ] No standard error shape
- [ ] Everything returns 200
- [ ] No input validation
- [ ] No rate limiting
- [ ] No pagination/filtering/sorting
- [ ] No request IDs / correlation IDs
- [ ] No monitoring

### Error Handling Problems
- [ ] Empty catch blocks
- [ ] Swallowing errors silently
- [ ] Logging secrets
- [ ] Exposing stack traces to users
- [ ] No retry/backoff for transient failures
- [ ] No circuit breaker for external services

### Webhook & Integration Issues
- [ ] No signature verification
- [ ] No idempotency handling
- [ ] Duplicate events cause duplicate side effects
- [ ] No retries/backoff
- [ ] No DLQ (dead letter queue) or replay

---

## Frontend Disasters
### State Management Chaos
- [ ] Global state for everything
- [ ] Duplicate state in multiple places
- [ ] No loading/error states
- [ ] Optimistic updates without rollback
- [ ] Client/server state out of sync

### UI/UX Disasters
- [ ] No loading indicators
- [ ] No meaningful error messages
- [ ] Forms with no validation
- [ ] No accessibility (keyboard, labels, contrast)
- [ ] No mobile responsiveness

---

## Code Quality Disasters
- [ ] No project structure
- [ ] 5000-line files
- [ ] Business logic in UI components
- [ ] Copy-paste programming everywhere
- [ ] Magic numbers and hardcoded strings
- [ ] TypeScript but `any` everywhere
- [ ] `@ts-ignore` as a lifestyle

---

## Testing Disasters
- [ ] No tests
- [ ] Only happy path tests
- [ ] Flaky tests ignored
- [ ] No integration/E2E tests
- [ ] Testing in production because vibes

---

## Deployment & DevOps Disasters
- [ ] No CI/CD
- [ ] No staging
- [ ] Manual deployments
- [ ] No rollback plan
- [ ] No monitoring/alerting/on-call
- [ ] Debug logs and source maps in production

---

## Version Control Disasters
- [ ] Committing directly to main
- [ ] No PR reviews
- [ ] Secrets committed
- [ ] No branch protections

---

## Documentation Disasters
- [ ] No README/setup docs
- [ ] Docs outdated or lying
- [ ] No runbooks for incidents

---

## Performance & Scalability Disasters
- [ ] Memory leaks
- [ ] Blocking operations on main thread
- [ ] No timeouts/retries
- [ ] No caching strategy or cache invalidation plan

---

## Legal & Compliance Disasters
- [ ] No privacy policy
- [ ] No consent for tracking
- [ ] No account deletion/export
- [ ] PII in logs/analytics/URLs
