# Production Runbook (Tiny, Useful)

## When a user says “it’s broken”
1. Confirm scope: single user, tenant, region, or everyone.
2. Check deploys: what changed last?
3. Check health: uptime/latency/error rate.
4. Check logs with request IDs.
5. If data involved: verify RLS/policies and migrations.

## Fast checks
- Auth: login failures spiking? token refresh broken?
- DB: connection pool saturated? slow queries?
- Realtime/WebSockets: connection churn?
- Storage: 403/404 spikes? bucket policy changes?

## Rollback triggers
- Error rate sustained > baseline + 3x
- P95 latency doubles
- Auth failures > 5% of attempts
- Any confirmed data exposure

## Post-incident
- Write a 1-page postmortem: impact, root cause, fix, prevention.
