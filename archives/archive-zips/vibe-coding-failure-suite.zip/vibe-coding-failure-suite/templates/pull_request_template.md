## What changed

- 

## Why

- 

## Risk (pick one)
- [ ] Low (copy/typo/docs)
- [ ] Medium (feature change; isolated)
- [ ] High (auth/billing/data model/security/perf)

## Preflight
- [ ] `scripts/preflight.sh` (or `.ps1`) passed
- [ ] No secrets in diff
- [ ] RLS/authz reviewed (if touching data access)
- [ ] Migration plan + rollback plan (if schema changes)

## Test evidence
- [ ] Unit tests added/updated
- [ ] Manual verification notes:

## Screenshots (UI only)

