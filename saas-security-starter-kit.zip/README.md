SaaS/PaaS Security Starter Kit (Next.js + TypeScript)

This is a starter implementation kit for the SaaS/PaaS security checklist:
- Tenant isolation (context + object-level authorization)
- Per-tenant quotas and rate limits (interfaces + middleware)
- API keys (scoped, per-tenant) + rotation stubs
- Webhook verification (HMAC)
- Audit logging (tamper-evident chain)
- Support JIT access (break-glass + approval stubs)
- Security headers + CSP
- Data residency config scaffolding
- Billing/webhook security scaffolding (processor-agnostic)

This is NOT a full app. It's a security layer you can drop into your SaaS.
Wire it into your routes, handlers, and service layer.

Folder map:
- src/security/*  -> runtime enforcement
- src/platform/*  -> tenant, quota, plans, residency
- docs/*          -> governance + checklists
- .github/workflows -> CI gates
