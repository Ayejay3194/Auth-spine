import readline from "node:readline";
import crypto from "node:crypto";
import { ConsoleAuditLogger } from "../obs/consoleAudit.js";
import { SimpleTracer } from "../obs/simpleTracer.js";
import { InMemorySessionStore } from "../memory/types.js";
import { SimplePolicyEngine } from "../policy/simplePolicy.js";
import { InMemoryToolRegistry } from "../tools/registry.js";
import { bookingFlows } from "../booking/flows.js";
import { bookingTools } from "../booking/tools.js";
import { BookingProviderMock } from "./bookingProviderMock.js";
import { IntentDetector } from "../nlu/intents.js";
import { createAssistant } from "../assistant/assistant.js";
import { supportFlows } from "../support/flows.js";
import { supportTools } from "../support/tools.js";

const audit = new ConsoleAuditLogger();
const tracer = new SimpleTracer();
const sessions = new InMemorySessionStore<any>();

const policy = new SimplePolicyEngine(sessions, {
  allow: {
    user: ["availability.findSlots","booking.create","booking.reschedule","booking.cancel","booking.list","auth.send_forgot_username","auth.send_password_reset","gdpr.queue_export","billing.change_plan"],
    admin: ["booking.list"],
    system: []
  },
  rate: { windowSeconds: 10, max: 30 },
  confirmIntents: ["booking.create","booking.reschedule","booking.cancel","billing.change_plan"]
});

const tools = new InMemoryToolRegistry();
const provider = new BookingProviderMock();
const slotCache = new InMemorySessionStore<any>();

for (const t of bookingTools({ provider, slotCache })) tools.register(t);
for (const t of supportTools()) tools.register(t);

const detector = new IntentDetector(
  [
    { intent: "booking.create", any: ["book", "schedule", "make an appointment"], all: [] },
    { intent: "booking.reschedule", any: ["reschedule", "move my booking"], all: [] },
    { intent: "booking.cancel", any: ["cancel", "call off"], all: [] },
    { intent: "booking.list", any: ["my bookings", "upcoming", "appointments"], all: [] },
    { intent: "availability.search", any: ["availability", "open slots"], all: [] },
    { intent: "auth.forgot_username", any: ["forgot username"], all: [] },
    { intent: "auth.password_reset_request", any: ["forgot password","reset password"], all: [] },
    { intent: "gdpr.export_request", any: ["export my data","download my data","gdpr"], all: [] },
    { intent: "billing.change_plan", any: ["change plan","upgrade","downgrade"], all: [] },
  ],
  [
    { intent: "booking.create", utterance: "book me an astrology reading next tuesday evening" },
    { intent: "booking.create", utterance: "schedule tarot session tomorrow 6pm video" },
    { intent: "booking.reschedule", utterance: "reschedule my booking bk_ab12cd" },
    { intent: "booking.cancel", utterance: "cancel booking bk_ab12cd" },
    { intent: "booking.list", utterance: "show my upcoming bookings" },
    { intent: "gdpr.export_request", utterance: "download my data" },
  ],
  { minScore: 0.30 }
);

const flows = [...bookingFlows(), ...supportFlows];

const assistant = createAssistant({ tools, policy, audit, clock: { now: () => new Date() }, tracer, intent: detector, flows });

const ctx = { userId: "user_" + crypto.randomBytes(4).toString("hex"), role: "user" as const, timezone: "America/New_York", channel: "cli" as const };
let state: any = {};

console.log("No-LLM Booking Assistant demo.");
console.log("Try: 'book me an astrology reading next tuesday evening', then pick slot number, then YES.");
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.setPrompt("> ");
rl.prompt();

rl.on("line", async (line) => {
  const res = await assistant.handle(ctx, state, line);
  state = res.state;

  // If availability tool ran, it'll be in audit output, but we also print the slots nicely if present.
  const last = audit.events.slice(-1)[0];
  if (last?.type === "tool.result" && (last.details as any).toolId === "availability.findSlots") {
    // find cached slots
    const cache = await slotCache.get(`slots:${ctx.userId}`);
    if (cache?.slots?.length) {
      console.log("Available:");
      for (const s of cache.slots) console.log("  " + s.label);
    }
  }

  console.log(res.reply.text);
  rl.prompt();
});
