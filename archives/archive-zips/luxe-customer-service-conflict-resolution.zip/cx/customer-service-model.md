CUSTOMER SERVICE MODEL (LUXE)
=============================

Principles:
- Calm over speed
- Resolution over blame
- Fewer back-and-forths
- Clear ownership at every stage

Service tiers:
- Self-resolve (automated, instant)
- Assisted (support agent)
- Escalated (senior ops/admin)

All tickets have:
- owner
- SLA
- status
- next-action timestamp
