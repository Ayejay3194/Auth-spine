Place your JSONL knowledge packs here.
Each line = one node object.
