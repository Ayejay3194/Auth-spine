export type Role = "user" | "assistant" | "system";

export type Message = {
  id: string;
  role: Role;
  content: string;
  ts: number;
};

export type Intent =
  | "greeting"
  | "goodbye"
  | "smalltalk"
  | "ask_astrology"
  | "ask_weather"
  | "planning"
  | "bug_report"
  | "request_file"
  | "unknown";

export type Entity =
  | { kind: "location"; value: string }
  | { kind: "date"; value: string }
  | { kind: "person"; value: string }
  | { kind: "placement"; value: string } // e.g., "Moon in Scorpio"
  | { kind: "keyword"; value: string };

export type NLUResult = {
  intent: Intent;
  confidence: number; // 0..1
  entities: Entity[];
  sentiment: "neutral" | "positive" | "negative" | "intense";
  styleRequest?: {
    snark: number; // 0..1
    warmth: number; // 0..1
    verbosity: number; // 0..1
  };
};

export type RouteDecision = {
  skill: SkillName;
  action: "fulfill" | "clarify" | "refuse";
  reason: string;
  tone: {
    snark: number;
    warmth: number;
    verbosity: number;
  };
};

export type SkillName =
  | "ChitchatSkill"
  | "AstroInterpreterSkill"
  | "WeatherSkill"
  | "PlannerSkill"
  | "BugTriageSkill"
  | "FileHelperSkill"
  | "FallbackSkill";

export type SkillContext = {
  nlu: NLUResult;
  memory: MemorySnapshot;
  now: number;
};

export type SkillResult =
  | { kind: "text"; text: string; tags?: string[] }
  | { kind: "clarify"; question: string; options?: string[]; tags?: string[] }
  | { kind: "refuse"; text: string; tags?: string[] }
  | { kind: "structured"; data: unknown; summary: string; tags?: string[] };

export type MemorySnapshot = {
  facts: Record<string, string>;
  prefs: Record<string, string>;
  recent: Message[];
};

export type RenderContext = {
  route: RouteDecision;
  nlu: NLUResult;
  memory: MemorySnapshot;
  skillResult: SkillResult;
};

export type RenderedResponse = {
  message: Message;
  debug?: {
    intent: Intent;
    confidence: number;
    skill: SkillName;
    action: RouteDecision["action"];
    reason: string;
    retrievedPhrases?: string[];
  };
};
