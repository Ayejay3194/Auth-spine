export type ISO8601 = string;

export type Actor = {
  userId: string;
  role: string;
};

export type RequestContext = {
  tenantId: string;
  actor?: Actor;
  requestId?: string;
  nowISO?: ISO8601;
  ip?: string;
};

export type Result<T> = { ok: true; data: T } | { ok: false; error: string; status?: number; details?: any };

export type AuditAction =
  | "create"
  | "update"
  | "delete"
  | "approve"
  | "view"
  | "export"
  | "auth"
  | "security"
  | "system";

export type AuditEntry = {
  id: string;
  tsISO: ISO8601;
  tenantId: string;
  actor?: Actor;
  entityType: string;
  entityId: string;
  action: AuditAction;
  summary?: string;
  metadata?: Record<string, any>;
  // Tamper-evident fields
  prevHash?: string;
  entryHash: string;
};

export type AuditCheckpoint = {
  id: string;
  tsISO: ISO8601;
  tenantId: string;
  lastEntryId: string;
  lastEntryHash: string;
  checkpointHash: string;
};

export type IdempotencyRecord = {
  key: string;
  tenantId: string;
  createdAtISO: ISO8601;
  status: "in_progress" | "completed" | "failed";
  responseStatus?: number;
  responseBody?: any;
  responseHeaders?: Record<string, string>;
  expiresAtISO: ISO8601;
};

export type SignedRequest = {
  method: string;
  path: string; // canonical path (no host)
  ts: number; // unix seconds
  nonce: string;
  bodySha256: string;
  signature: string;
  keyId: string;
};
