// analytics entities.ts
