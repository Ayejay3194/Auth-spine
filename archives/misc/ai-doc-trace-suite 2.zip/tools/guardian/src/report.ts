import type { DiffResult, Policy } from "./types.js";
import { anyMatch } from "./glob.js";

export function buildMarkdownReport(diff: DiffResult, policy: Policy): string {
  const added = diff.changed.filter(c => c.status === "added");
  const modified = diff.changed.filter(c => c.status === "modified");
  const deleted = diff.changed.filter(c => c.status === "deleted");
  const protectedTouched = diff.changed.filter(c => anyMatch(policy.protected, c.path));

  const lines: string[] = [];
  lines.push(`# Guardian Report`);
  lines.push(`Generated: ${new Date(diff.createdAt).toISOString()}`);
  lines.push(``);
  lines.push(`## Summary`);
  lines.push(`- Added: ${added.length}`);
  lines.push(`- Modified: ${modified.length}`);
  lines.push(`- Deleted: ${deleted.length}`);
  lines.push(`- Protected touched: ${protectedTouched.length}`);
  lines.push(``);

  const section = (title: string, items: typeof diff.changed) => {
    lines.push(`## ${title}`);
    if (!items.length) { lines.push(`(none)\n`); return; }
    for (const it of items) lines.push(`- **${it.status.toUpperCase()}** \`${it.path}\``);
    lines.push(``);
  };

  section("Added", added);
  section("Modified", modified);
  section("Deleted", deleted);

  lines.push(`## Run synopsis template`);
  lines.push(`- **Goal:**`);
  lines.push(`- **What I changed:**`);
  lines.push(`- **Why:**`);
  lines.push(`- **Risk / blast radius:**`);
  lines.push(`- **How to verify:**`);
  lines.push(`- **Rollback plan:**`);
  lines.push(``);
  return lines.join("\n");
}
