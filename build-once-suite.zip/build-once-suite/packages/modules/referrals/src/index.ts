import type { AuditStore } from "@suite/core-audit";

export type ReferralClick = { code: string; ts: string; meta?: Record<string,string> };
export type Referral = { id: string; code: string; referrerUserId: string; refereeUserId?: string; convertedAt?: string };

export interface ReferralStore {
  createCode(userId: string): Promise<string>;
  logClick(c: ReferralClick): Promise<void>;
  attachSignup(newUserId: string, code: string): Promise<Referral | null>;
}

export class ReferralService {
  constructor(private store: ReferralStore, private audit: AuditStore) {}

  async createCode(userId: string) {
    const code = await this.store.createCode(userId);
    await this.audit.append({ actor:{actorType:"user", userId}, action:"referral.code.created", targetType:"referralCode", targetId: code });
    return code;
  }

  async trackClick(code: string, meta?: Record<string,string>) {
    await this.store.logClick({ code, ts: new Date().toISOString(), meta });
  }

  async attachSignup(newUserId: string, code?: string) {
    if (!code) return null;
    const ref = await this.store.attachSignup(newUserId, code);
    if (ref) await this.audit.append({ actor:{actorType:"system"}, action:"referral.signup.attached", targetType:"user", targetId: newUserId, metadata:{ code } });
    return ref;
  }
}
