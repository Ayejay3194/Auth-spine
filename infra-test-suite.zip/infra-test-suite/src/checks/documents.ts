import path from "node:path";
import { exists } from "../utils/fs.js";
import type { Check, Finding, Severity } from "../types.js";

export const DocumentsCheck: Check = {
  id: "docs.required",
  title: "Required documentation exists",
  category: "Documentation",
  async run(ctx) {
    const req = ctx.profile.expectations?.documents ?? [];
    const findings: Finding[] = [];
    for (const d of req) {
      const full = path.join(ctx.root, d.path);
      if (!exists(full)) {
        findings.push({
          id: this.id,
          title: this.title,
          category: this.category,
          severity: (d.severity as Severity) ?? "P1",
          evidence: [{
            message: `Missing required document: ${d.path}`,
            file: d.path,
            hint: d.why ?? "Create the document and keep it current."
          }]
        });
      }
    }
    return findings;
  }
};
