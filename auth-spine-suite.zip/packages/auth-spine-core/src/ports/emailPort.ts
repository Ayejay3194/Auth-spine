export type EmailType =
  | "VERIFY_EMAIL"
  | "PASSWORD_RESET"
  | "LOGIN_ALERT"
  | "PASSWORD_CHANGED_ALERT"
  | "EMAIL_CHANGED_ALERT_OLD"
  | "EMAIL_CHANGED_ALERT_NEW"
  | "GDPR_EXPORT_READY"
  | "GDPR_DELETE_CONFIRMED";

export interface EmailPort {
  send(to: string, type: EmailType, payload: Record<string, unknown>): Promise<void>;
}
