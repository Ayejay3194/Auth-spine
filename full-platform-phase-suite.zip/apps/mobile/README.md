Mobile App Notes
- This folder contains TSX source you can drop into an Expo app.
- Create app: npx create-expo-app apps/mobile-real
- Copy src/App.tsx from here into the Expo project.
