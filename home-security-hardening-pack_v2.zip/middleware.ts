export const config = { matcher: ['/(.*)'] };
