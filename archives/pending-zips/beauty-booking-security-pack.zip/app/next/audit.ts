/**
 * Audit logging template.
 * Store immutably. Never let audit failure break core flows.
 */
export async function auditLog(input: {
  actorUserId?: string|null;
  actorRole?: string|null;
  action: string;
  entityType: string;
  entityId: string;
  before?: any;
  after?: any;
  reason?: string;
  ip?: string|null;
  userAgent?: string|null;
}) {
  try {
    // write to DB: AuditLog table
  } catch {
    // swallow
  }
}
