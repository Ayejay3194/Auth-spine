# Support access rules (don’t get sued edition)
JIT Access:
- Default: zero prod access
- Request reason + TTL
- Approver required for write access
- Auto-expire
- Everything logged

Impersonation:
- Consent or ticket reference required
- Read-only by default
- Session time-limited
- Visible banner to customer
- Audit actor_type=SUPPORT
