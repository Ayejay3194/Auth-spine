import type { Request, Response, NextFunction } from "express";
import type { Policy, Resource, Action } from "./policy";
import { isAllowed } from "./policy";
import { logger } from "../observability/logger";

export function enforcePolicy(policy: Policy, opts: { resource: Resource; action: Action }) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const role = req.ctx?.actor?.role || "readonly";
      const ok = isAllowed(policy, role, opts.resource, opts.action);
      if (!ok) {
        logger.warn("policy.deny", {
          requestId: req.ctx?.requestId,
          tenantId: req.ctx?.tenantId,
          actor: req.ctx?.actor,
          resource: opts.resource,
          action: opts.action
        });
        return res.status(403).json({ error: "Insufficient permissions" });
      }
      next();
    } catch (e) {
      // FAIL CLOSED: if policy evaluation errors, deny
      logger.error("policy.error", { err: String(e), requestId: req.ctx?.requestId });
      return res.status(403).json({ error: "Access denied" });
    }
  };
}
