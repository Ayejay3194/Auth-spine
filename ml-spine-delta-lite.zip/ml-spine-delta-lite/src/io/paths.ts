import path from "node:path";

export type LakeConfig = { root: string };

export function tableRoot(cfg: LakeConfig, table: string) {
  // "table" == dataset name in your mental model
  return path.join(cfg.root, `table=${table}`);
}

export function dataRoot(cfg: LakeConfig, table: string, tableVersion: string) {
  return path.join(tableRoot(cfg, table), `ver=${tableVersion}`, "data");
}

export function logRoot(cfg: LakeConfig, table: string, tableVersion: string) {
  return path.join(tableRoot(cfg, table), `ver=${tableVersion}`, "_log");
}

export function headPath(cfg: LakeConfig, table: string, tableVersion: string) {
  return path.join(logRoot(cfg, table, tableVersion), "_head.json");
}

export function commitPath(cfg: LakeConfig, table: string, tableVersion: string, commitId: string) {
  return path.join(logRoot(cfg, table, tableVersion), `${commitId}.json`);
}

export function lockPath(cfg: LakeConfig, table: string, tableVersion: string) {
  return path.join(logRoot(cfg, table, tableVersion), "_lock");
}
