import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      boxShadow: {
        soft: "0 18px 50px rgba(11,13,16,.10)",
        deep: "0 22px 60px rgba(0,0,0,.55)",
      },
    },
  },
  plugins: [],
} satisfies Config;
