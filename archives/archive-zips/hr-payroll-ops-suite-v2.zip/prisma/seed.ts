
import { db } from "../lib/db";

async function main() {
  await db.user.upsert({ where: { email: "admin@demo.com" }, update: {}, create: { email: "admin@demo.com", role: "ADMIN" } });
  const hr = await db.user.upsert({ where: { email: "hr@demo.com" }, update: {}, create: { email: "hr@demo.com", role: "HR" } });
  await db.user.upsert({ where: { email: "payroll@demo.com" }, update: {}, create: { email: "payroll@demo.com", role: "PAYROLL" } });
  const mgr = await db.user.upsert({ where: { email: "manager@demo.com" }, update: {}, create: { email: "manager@demo.com", role: "MANAGER" } });
  const empUser = await db.user.upsert({ where: { email: "employee@demo.com" }, update: {}, create: { email: "employee@demo.com", role: "EMPLOYEE" } });

  const eHourly = await db.employee.upsert({
    where: { employeeNo: "E-1001" },
    update: {},
    create: { employeeNo: "E-1001", firstName: "Riley", lastName: "Nguyen", department: "Ops", location: "NYC", payType: "HOURLY", rateCents: 2800, userId: empUser.id }
  });

  await db.employee.upsert({
    where: { employeeNo: "E-1002" },
    update: {},
    create: { employeeNo: "E-1002", firstName: "Morgan", lastName: "Patel", department: "Engineering", location: "Remote", payType: "SALARY", rateCents: 450000 }
  });

  const policy = await db.ptoPolicy.upsert({
    where: { name: "Standard PTO" },
    update: {},
    create: { name: "Standard PTO", accrualType: "MONTHLY", accrualRate: 8, maxBalance: 200 }
  });

  await db.ptoRequest.create({
    data: { employeeId: eHourly.id, policyId: policy.id, startDate: new Date(Date.now() + 7*86400000), endDate: new Date(Date.now() + 8*86400000), hours: 8, status: "PENDING", reason: "Doctor appointment" }
  });

  // Create a timesheet for last 14 days, approve it, and attach time entries
  const now = new Date();
  const periodStart = new Date(now); periodStart.setDate(periodStart.getDate() - 14);
  const periodEnd = new Date(now);

  const ts = await db.timesheet.create({
    data: {
      employeeId: eHourly.id,
      periodStart,
      periodEnd,
      status: "APPROVED",
      submittedAt: new Date(),
      approvedAt: new Date(),
      decidedById: mgr.id
    }
  });

  // Create 10 workdays x 8 hours = 4800 minutes
  for (let d = 1; d <= 10; d++) {
    const day = new Date(periodStart);
    day.setDate(day.getDate() + d);
    const start = new Date(day); start.setHours(9,0,0,0);
    const end = new Date(day); end.setHours(17,0,0,0);
    await db.timeEntry.create({
      data: {
        employeeId: eHourly.id,
        timesheetId: ts.id,
        startAt: start,
        endAt: end,
        minutes: 480,
        notes: "Shift"
      }
    });
  }

  const pg = await db.payGroup.upsert({ where: { name: "Default Biweekly" }, update: {}, create: { name: "Default Biweekly", cadence: "BIWEEKLY" } });
  await db.payRun.create({ data: { payGroupId: pg.id, status: "DRAFT", notes: "Seed draft run", periodStart, periodEnd } });

  await db.task.create({ data: { title: "Run onboarding checklist for new hire", status: "OPEN" } });

  console.log("Seeded V2.");
}

main().finally(async () => db.$disconnect());
