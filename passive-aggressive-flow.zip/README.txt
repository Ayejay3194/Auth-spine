Passive-Aggressive Conversational Flow – JSONL

This dataset is designed for NLU / interpretation layers that need
socially plausible, passive-aggressive responses.

Fields:
- intent: trigger condition
- tone: delivery style
- text: output phrase
- confidence: suggested activation confidence

Usage:
Select ONE line per response based on intent + tone.
Do not stack multiple entries in a single turn.
