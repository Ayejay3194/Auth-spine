#!/usr/bin/env bash
set -euo pipefail
OUTDIR="${1:-./backups}"
mkdir -p "$OUTDIR"
TS="$(date +%Y%m%d_%H%M%S)"
FILE="$OUTDIR/pg_${TS}.dump"
echo "[backup] dumping to $FILE"
pg_dump "$DATABASE_URL" --format=custom --no-owner --no-acl --file "$FILE"
echo "[backup] done"
