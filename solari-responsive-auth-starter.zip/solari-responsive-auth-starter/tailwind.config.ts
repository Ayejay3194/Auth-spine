import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { bg0: "#070809", bg1: "#0b0c0e", gold: "#e7c776", text: "#f3f1ec" },
      boxShadow: {
        glass: "0 14px 36px rgba(0,0,0,.45)",
        glow: "0 0 26px rgba(231,199,118,.32), 0 0 70px rgba(231,199,118,.10)"
      },
      borderRadius: { xl2: "30px" }
    }
  },
  plugins: []
} satisfies Config;
