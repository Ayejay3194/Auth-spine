// booking tools.ts
