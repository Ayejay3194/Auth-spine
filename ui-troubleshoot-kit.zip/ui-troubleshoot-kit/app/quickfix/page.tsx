import Link from "next/link";

const FIXES = [
  {
    title: "Nuclear CSS reset",
    code: `* { margin: 0; padding: 0; box-sizing: border-box; }`
  },
  {
    title: "Debug bounds",
    code: `.debug { outline: 1px solid red; }`
  },
  {
    title: "Flex text overflow fix",
    code: `.flex-child { min-width: 0; } /* Tailwind: min-w-0 */`
  },
  {
    title: "Hydration-safe mount guard (Next)",
    code: `const [mounted,setMounted]=useState(false);
useEffect(()=>setMounted(true),[]);
if(!mounted) return null;`
  },
  {
    title: "Z-index ladder tokens",
    code: `:root{--z-content:1;--z-rail:10;--z-nav:20;--z-drawer:40;--z-modal:60;--z-toast:80;}`
  }
];

export default function QuickFix() {
  return (
    <div className="bg-white rounded-2xl shadow-soft p-6 md:p-8 border border-slate-200/60">
      <h1 className="text-3xl font-black text-slate-900">Quick Fix Pack</h1>
      <p className="mt-2 text-slate-700">Copy/paste fixes you end up using 400 times because UI is a hobby designed to punish joy.</p>

      <div className="mt-6 grid gap-4">
        {FIXES.map((f) => (
          <div key={f.title} className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <div className="font-bold text-slate-900">{f.title}</div>
            <pre className="mt-2 overflow-x-auto rounded-lg bg-slate-900 p-3 text-sm text-slate-100 whitespace-pre-wrap">
              <code>{f.code}</code>
            </pre>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <Link className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-2 font-semibold hover:bg-slate-100" href="/">
          Back to toolkit
        </Link>
      </div>
    </div>
  );
}
