import Database from "better-sqlite3";
import type { Node } from "@solari/schema";

export class SqliteIndex {
  private db: Database.Database;
  constructor(file: string) {
    this.db = new Database(file, { readonly: true });
  }
  close(){ this.db.close(); }

  getById(id: string): Node | null {
    const row = this.db.prepare("SELECT * FROM nodes WHERE id = ?").get(id) as any;
    return row ? this.rowToNode(row) : null;
  }
  search(kind: string | null, q: string, limit = 25): Node[] {
    const like = `%${q}%`;
    const rows = kind
      ? this.db.prepare("SELECT * FROM nodes WHERE kind = ? AND (title LIKE ? OR summary LIKE ?) LIMIT ?").all(kind, like, like, limit)
      : this.db.prepare("SELECT * FROM nodes WHERE (title LIKE ? OR summary LIKE ?) LIMIT ?").all(like, like, limit);
    return (rows as any[]).map(r => this.rowToNode(r));
  }

  private rowToNode(r: any): Node {
    return {
      id: r.id, kind: r.kind, title: r.title,
      summary: r.summary ?? undefined,
      body: r.body ?? undefined,
      tags: JSON.parse(r.tags ?? "[]"),
      aliases: JSON.parse(r.aliases ?? "[]"),
      links: JSON.parse(r.links ?? "[]"),
      version: r.version ?? undefined,
      provenance: r.provenance ? JSON.parse(r.provenance) : undefined
    };
  }
}
