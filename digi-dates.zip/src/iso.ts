import { ParseError } from "./errors.js";

export type ISODateParts = {
  year: number;
  month: number; // 1-12
  day: number;   // 1-31 (validated)
  hour: number;  // 0-23
  minute: number;// 0-59
  second: number;// 0-59
  ms: number;    // 0-999
  offsetMinutes: number; // minutes east of UTC (e.g. -300 for -05:00)
};

/**
 * Strict ISO 8601: YYYY-MM-DDTHH:mm:ss(.SSS)?(Z|±HH:MM)
 */
const ISO_RE =
  /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?(Z|[+-]\d{2}:\d{2})$/;

export function parseISOToParts(iso: string): ISODateParts {
  const m = ISO_RE.exec(iso);
  if (!m) throw new ParseError(`Invalid ISO timestamp: ${iso}`);

  const year = Number(m[1]);
  const month = Number(m[2]);
  const day = Number(m[3]);
  const hour = Number(m[4]);
  const minute = Number(m[5]);
  const second = Number(m[6]);
  const frac = m[7] ?? "";
  const ms = frac === "" ? 0 : Number(frac.padEnd(3, "0").slice(0, 3));
  const tz = m[8]!;

  if (month < 1 || month > 12) throw new ParseError(`Invalid month in: ${iso}`);
  if (day < 1 || day > 31) throw new ParseError(`Invalid day in: ${iso}`);
  if (hour < 0 || hour > 23) throw new ParseError(`Invalid hour in: ${iso}`);
  if (minute < 0 || minute > 59) throw new ParseError(`Invalid minute in: ${iso}`);
  if (second < 0 || second > 59) throw new ParseError(`Invalid second in: ${iso}`);
  if (ms < 0 || ms > 999) throw new ParseError(`Invalid milliseconds in: ${iso}`);

  let offsetMinutes = 0;
  if (tz !== "Z") {
    const sign = tz.startsWith("-") ? -1 : 1;
    const hh = Number(tz.slice(1, 3));
    const mm = Number(tz.slice(4, 6));
    if (hh > 23 || mm > 59) throw new ParseError(`Invalid timezone offset in: ${iso}`);
    offsetMinutes = sign * (hh * 60 + mm);
  }

  // Validate existence by round-trip
  const utcMs = Date.UTC(year, month - 1, day, hour, minute, second, ms) - offsetMinutes * 60_000;
  const d = new Date(utcMs);

  const checkMs = d.getTime() + offsetMinutes * 60_000;
  const c = new Date(checkMs);

  if (
    c.getUTCFullYear() !== year ||
    c.getUTCMonth() + 1 !== month ||
    c.getUTCDate() !== day ||
    c.getUTCHours() !== hour ||
    c.getUTCMinutes() !== minute ||
    c.getUTCSeconds() !== second ||
    c.getUTCMilliseconds() !== ms
  ) {
    throw new ParseError(`Non-existent calendar date/time: ${iso}`);
  }

  return { year, month, day, hour, minute, second, ms, offsetMinutes };
}

export function parseISO(iso: string): Date {
  const p = parseISOToParts(iso);
  const utcMs = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second, p.ms) - p.offsetMinutes * 60_000;
  return new Date(utcMs);
}

export function formatISO(d: Date): string {
  const pad2 = (n: number) => String(n).padStart(2, "0");
  const pad3 = (n: number) => String(n).padStart(3, "0");
  return (
    `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}-${pad2(d.getUTCDate())}` +
    `T${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}:${pad2(d.getUTCSeconds())}.` +
    `${pad3(d.getUTCMilliseconds())}Z`
  );
}
