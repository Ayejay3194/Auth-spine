
export interface TrustMetrics {
  sellerId: string;
  cancellations: number;
  disputes: number;
  avgRating: number;
  responseTimeMs: number;
}

export class TrustSafetySpine {
  score(m: TrustMetrics): number {
    let score = 100;
    score -= m.cancellations * 5;
    score -= m.disputes * 10;
    score += (m.avgRating - 3) * 10;
    score -= m.responseTimeMs / 1000;
    return Math.max(0, Math.min(100, score));
  }

  flagForReview(m: TrustMetrics): boolean {
    return this.score(m) < 50;
  }
}
