import type { EntitySpan, NLUModel } from "../types";

/**
 * Very small normalizers to keep this dependency-free.
 * You can swap this with a real date parser later.
 */
export function normalizeEntities(model: NLUModel, text: string, entities: EntitySpan[]): EntitySpan[] {
  const now = new Date();

  const weekdayIndex: Record<string, number> = {
    sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6,
  };

  function nextWeekday(target: number): Date {
    const d = new Date(now);
    const day = d.getDay();
    let add = (target - day + 7) % 7;
    if (add === 0) add = 7;
    d.setDate(d.getDate() + add);
    return d;
  }

  return entities.map(e => {
    const spec = model.entities.find(x => x.name === e.entity);
    const norm = spec?.normalizer;

    if (norm === "location") {
      return { ...e, normalized: String(e.value).trim() };
    }

    if (norm === "number") {
      const n = Number(e.value);
      return { ...e, normalized: Number.isFinite(n) ? n : undefined };
    }

    if (norm === "date") {
      const v = e.value.toLowerCase();
      let d: Date | null = null;

      if (v === "today") d = now;
      else if (v === "tomorrow") { d = new Date(now); d.setDate(d.getDate() + 1); }
      else if (v === "yesterday") { d = new Date(now); d.setDate(d.getDate() - 1); }
      else if (v.startsWith("next ")) {
        const wd = v.replace("next ", "").trim();
        if (weekdayIndex[wd] != null) d = nextWeekday(weekdayIndex[wd]);
      } else if (weekdayIndex[v] != null) {
        d = nextWeekday(weekdayIndex[v]);
      }

      // Basic ISO date literal detection: 2025-12-16
      if (!d) {
        const m = text.match(/\b(\d{4}-\d{2}-\d{2})\b/);
        if (m) d = new Date(m[1] + "T00:00:00");
      }

      return { ...e, normalized: d ? d.toISOString().slice(0, 10) : undefined };
    }

    return e;
  });
}
