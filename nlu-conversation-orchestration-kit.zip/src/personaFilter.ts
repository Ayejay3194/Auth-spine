import { ResponsePlan, ToneLevel } from "./types";

export type PersonaFilterResult = {
  plan: ResponsePlan;
  notes: string[];
};

// Ensures tone doesn't exceed "socially acceptable" for low confidence or sensitive intents.
// Customize sensitive intents as needed.
export function applyPersonaFilter(plan: ResponsePlan): PersonaFilterResult {
  const notes: string[] = [];
  const sensitiveIntents = new Set(["medical", "health", "mental_health", "grief", "self_harm", "legal", "finance"]);

  let adjusted = { ...plan };

  if (sensitiveIntents.has(plan.intent.toLowerCase()) && plan.toneLevel > 1) {
    notes.push("Sensitive intent -> cap tone at 1 and disable passive-aggressive.");
    adjusted.toneLevel = 1;
    adjusted.toneTag = "polite_shade";
    adjusted.shouldUsePassiveAggressiveLine = false;
  }

  // If tone is high but we aren't using passive-aggressive (blocked), ensure tag matches.
  if (!adjusted.shouldUsePassiveAggressiveLine && adjusted.toneLevel >= 2) {
    notes.push("Passive-aggressive blocked -> soften tone tag to polite_shade.");
    adjusted.toneLevel = 1 as ToneLevel;
    adjusted.toneTag = "polite_shade";
  }

  return { plan: adjusted, notes };
}
