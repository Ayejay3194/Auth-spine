import { readdir, stat, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";

const IGNORE_DIRS = new Set([".git","node_modules",".next","dist","build","coverage",".turbo"]);

export async function walkFiles(root: string): Promise<string[]> {
  const out: string[] = [];
  async function rec(dir: string) {
    const items = await readdir(dir, { withFileTypes: true });
    for (const it of items) {
      if (it.name === ".DS_Store") continue;
      const full = path.join(dir, it.name);
      const rel = path.relative(root, full).replace(/\\/g, "/");
      if (it.isDirectory()) {
        if (IGNORE_DIRS.has(it.name)) continue;
        await rec(full);
      } else if (it.isFile()) {
        out.push(rel);
      }
    }
  }
  await rec(root);
  return out.sort();
}

export async function sha256File(absPath: string): Promise<{ sha256: string; bytes: number; mtimeMs: number; }> {
  const s = await stat(absPath);
  const buf = await readFile(absPath);
  const sha256 = createHash("sha256").update(buf).digest("hex");
  return { sha256, bytes: buf.byteLength, mtimeMs: s.mtimeMs };
}
