export type TraceSpan = { name: string; startMs: number; endMs?: number; attrs?: Record<string, unknown> };

export class SimpleTracer {
  private spans: TraceSpan[] = [];
  start(name: string, attrs?: Record<string, unknown>) { const s: TraceSpan = { name, startMs: Date.now(), attrs }; this.spans.push(s); return s; }
  end(span: TraceSpan, attrs?: Record<string, unknown>) { span.endMs = Date.now(); span.attrs = { ...(span.attrs ?? {}), ...(attrs ?? {}) }; }
  snapshot() { return this.spans.map(s => ({ name: s.name, durationMs: (s.endMs ?? Date.now()) - s.startMs, attrs: s.attrs ?? {} })); }
  clear() { this.spans = []; }
}
