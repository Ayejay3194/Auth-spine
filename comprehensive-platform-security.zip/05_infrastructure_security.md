INFRASTRUCTURE SECURITY

Covers:
- Server hardening
- Cloud security posture
- Container & Kubernetes security
- Database security