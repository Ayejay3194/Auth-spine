import type { ID, ISODateTime, Result } from "../shared/types.js";
import { cuid } from "../shared/ids.js";

export type Platform = "instagram" | "tiktok" | "facebook" | "threads" | "x";

export type SocialTemplate = { id: ID; businessId: ID; name: string; body: string; hashtags?: string[] };
export type SocialPost = { id: ID; businessId: ID; platform: Platform; body: string; scheduledAt: ISODateTime; status: "queued"|"posted"|"failed"; error?: string };

export interface SocialPoster {
  post(platform: Platform, body: string): Promise<Result<{ externalId: string }>>;
}

export class SocialScheduler {
  private templates: SocialTemplate[] = [];
  private posts: SocialPost[] = [];

  createTemplate(t: Omit<SocialTemplate,"id">): SocialTemplate { const tt = { ...t, id: cuid("sTpl") }; this.templates.push(tt); return tt; }
  listTemplates(businessId: ID) { return this.templates.filter(t => t.businessId===businessId); }

  schedulePost(input: { businessId: ID; platform: Platform; body: string; scheduledAt: ISODateTime }): SocialPost {
    const p: SocialPost = { id: cuid("sPost"), businessId: input.businessId, platform: input.platform, body: input.body, scheduledAt: input.scheduledAt, status: "queued" };
    this.posts.push(p); return p;
  }

  due(nowISO: ISODateTime, limit=20): SocialPost[] {
    const t = Date.parse(nowISO);
    return this.posts.filter(p => p.status==="queued" && Date.parse(p.scheduledAt) <= t).slice(0, limit);
  }

  async runDue(nowISO: ISODateTime, poster: SocialPoster): Promise<{ posted: number; failed: number }> {
    const due = this.due(nowISO);
    let posted=0, failed=0;
    for (const p of due) {
      const res = await poster.post(p.platform, p.body);
      if (res.ok) { p.status="posted"; posted++; }
      else { p.status="failed"; p.error=res.error.message; failed++; }
    }
    return { posted, failed };
  }

  listPosts(businessId: ID, limit=200) { return this.posts.filter(p => p.businessId===businessId).slice(-limit).reverse(); }
}
