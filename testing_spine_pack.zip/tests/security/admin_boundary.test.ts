import { describe, it, expect } from "vitest";
import request from "supertest";
import "../helpers/env";

const BASE_URL = process.env.INTEGRATION_BASE_URL ?? "http://localhost:3000";

describe("security boundaries (template)", () => {
  it("denies admin endpoints for non-admin", async () => {
    const res = await request(BASE_URL)
      .get("/api/admin")
      .set({ "x-tenant-id": "tenantA", "x-user-id": "userA", "x-role": "staff" });

    expect([401, 403, 404]).toContain(res.status);
  });
});
