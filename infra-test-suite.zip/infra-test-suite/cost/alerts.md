# Cost Alerts

- Alert thresholds
- Routing
