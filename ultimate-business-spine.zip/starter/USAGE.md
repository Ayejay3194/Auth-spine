HOW TO USE THIS IN A NEW BUSINESS
================================

1) Copy /admin, /finance, /ops, /reliability, /templates into your repo.
2) Implement feature flags first (so you can ship safely).
3) Wire audit logging into all sensitive actions.
4) Add alerting + the Green Lights health panel.
5) Pass Launch Gate before production.

Verticalization:
- swap terminology
- add compliance rules
- add domain entities
