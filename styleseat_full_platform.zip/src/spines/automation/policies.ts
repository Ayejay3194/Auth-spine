// automation policies.ts
